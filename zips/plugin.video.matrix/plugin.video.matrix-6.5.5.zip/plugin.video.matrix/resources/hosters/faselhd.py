﻿#coding: utf-8

import base64
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.hosters.hoster import iHoster
from resources.lib.comaddon import dialog, VSlog, addon, siteManager
from resources.sites.faselhd import decode_page
from resources.lib import random_ua
import json
UA = random_ua.get_phone_ua()

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'faselhd', 'FaselHD', 'gold')

    def isDownloadable(self):
        return True

    def _getMediaLinkForGuest(self, autoPlay = False):
        api_call = False
        sReferer = siteManager().getUrlMain('faselhd')
        VSlog(self._url)

        oParser = cParser()   
        oRequest = cRequestHandler(self._url)
        oRequest.addHeaderEntry('user-agent',UA)
        oRequest.enableCache(False)
        sHtmlContent = oRequest.request()
       

        if 'adilbo' in sHtmlContent:
            sHtmlContent = decode_page(sHtmlContent)
          
        else:
            import xbmcgui
           
            try:
                patterns = [
                    r'</button>\s*<script[^>]*>(.*?)</script>\s*<button',
                    r'</video>\s*<script[^>]*>(.*?)</script',
                    r'<i class="fa fa-backward">.+?<script[^>]*>(.*?)</script'
                ]
              #  pa=r"(?:var|let|const)\s+video\s*=\s*([^;]+);"
             #   aResult = oParser.parse(sHtmlContent, patterns)
            #    xbmcgui.Dialog().ok("aResult",str(aResult))
           
             #   if 'video' in sHtmlContent :
              #   xbmcgui.Dialog().ok("video",str("yes"))
              

                all_results = []
                for sPattern in patterns:
                  
                    aResult = oParser.parse(sHtmlContent, sPattern)
                  
                 
                    if aResult[0]:
                        if '' in aResult[1]:
                            continue
                        all_results.extend(aResult[1])
                     
                        all_results = list(set(all_results))
                        xs=decode_page(all_results)

            # تحويل النتائج إلى JSON في متغير
                    jsonhtml = json.dumps({"results": xs}, ensure_ascii=False, indent=4)
                    xbmcgui.Dialog().ok("aResult",str(jsonhtml))
                    xbmcgui.Dialog().ok("code",str(all_results[0]))
                    if all_results:
                     xbmcgui.Dialog().ok("code", str(all_results[0]))
                    for coded in all_results:
                    # Don't use this, just for test
                         xbmcgui.Dialog().notification("code", str(coded))


                         oRequest = cRequestHandler("https://matrixflix-one.vercel.app//api")
                         oRequest.addHeaderEntry('user-agent',UA)
                         oRequest.enableCache(False)
                         oRequest.addParameters('code', coded)
                         oRequest.setRequestType(1)
                         sHtmlContent = oRequest.request(jsonDecode=True)['code'].replace('\\"', '"')
                  #   sHtmlContent = decode_page(sHtmlContent)
                         xbmcgui.Dialog().ok("code",str(sHtmlContent))

            except:
                VSlog('Failed Api')
        if 'data-url' in sHtmlContent :
             xbmcgui.Dialog().ok("data-url",str("yes"))

        sPattern =  'data-url="([^<]+)">([^<]+)</button>' 
        aResult = oParser.parse(sHtmlContent, sPattern)
       
        if aResult[0]:
            for aEntry in aResult[1]:
                sLink = []
                sQual = []
                for aEntry in aResult[1]:
                    sLink.append(str(aEntry[0]))
                    sQual.append(str(aEntry[1].upper()))
            api_call = dialog().VSselectqual(sQual, sLink)

        sPattern =  'videoSrc = ["\']([^"\']+)["\']' 
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            for aEntry in aResult[1]:
                api_call = aEntry
        
        if api_call:
            return True, f'{api_call}|Referer={sReferer}&User-Agent={UA}'

        return False, False
