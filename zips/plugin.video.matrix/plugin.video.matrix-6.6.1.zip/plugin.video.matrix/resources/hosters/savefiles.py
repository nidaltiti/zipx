#-*- coding: utf-8 -*-
from resources.hosters.hoster import iHoster
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog
from resources.lib.util import urlHostName
from resources.lib.parser import cParser
from resources.lib import random_ua

UA = random_ua.get_phone_ua()

class cHoster(iHoster):
    def __init__(self):
        iHoster.__init__(self, 'savefiles', 'SaveFiles')

    def isDownloadable(self):
        return True

    def setUrl(self, sUrl):
        self._url = str(sUrl)
        if '/e/' in self._url or '/v/' in self._url:
            host = urlHostName(self._url)
            self._media_id = self._url.rsplit('/', 1)[-1]
            self._url = f'https://{host}/dl'
        else:
            self._media_id = self._url.rsplit('/', 1)[-1]
            self._url = f'https://{urlHostName(self._url)}/dl'

    def _getMediaLinkForGuest(self, autoPlay=False):
        VSlog(self._url)
        oRequestHandler = cRequestHandler(f'{self._url}')
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('Origin', f'https://{urlHostName(self._url)}')
        oRequestHandler.addHeaderEntry('Referer', f'https://{urlHostName(self._url)}/e/{self._media_id}')
        oRequestHandler.enableCache(False)
        oRequestHandler.addParameters('op', 'embed')
        oRequestHandler.addParameters('auto', 1)
        oRequestHandler.addParameters('file_code', self._media_id)
        oRequestHandler.addParameters('referer', '')
        oRequestHandler.setRequestType(1)
        sHtmlContent = oRequestHandler.request()

        oParser = cParser()
        sPattern = r'sources:\s*\["([^"]+)"\]'
        aResult = oParser.parse(sHtmlContent,sPattern)
        if aResult[0]:
            api_call = aResult[1][0] 

        sPattern = r'sources:\s*\[\{\s*file\s*:\s*[\'"]([^\'"]+)[\'"]'
        aResult = oParser.parse(sHtmlContent,sPattern)
        if aResult[0]:
            api_call = aResult[1][0] 

        if api_call:
            headers = f'|User-Agent={UA}&Referer=https://{urlHostName(self._url)}/e/{self._media_id}&Origin=https://{urlHostName(self._url)}'
            return True, api_call + headers

        return False, False
