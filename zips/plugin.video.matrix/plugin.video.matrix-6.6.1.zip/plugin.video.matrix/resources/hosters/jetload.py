#-*- coding: utf-8 -*-

import re
import requests
import time
from resources.lib.comaddon import VSlog, siteManager
from resources.hosters.hoster import iHoster
from resources.lib.util import urlHostName
from resources.lib import random_ua

UA = random_ua.get_phone_ua()

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'jetload', 'Jetload')

    def setUrl(self, url):
        self._url = str(url)

    def _getMediaLinkForGuest(self):
        VSlog(self._url)
        api_call = False

        session = requests.Session()
        session.headers.update({
            "User-Agent": UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Accept-Language": "en-US,en;q=0.9",
        })

        sHtmlContent = session.get(self._url,
                            headers={"Referer": siteManager().getUrlMain("cimanow")})

        sHtmlContent2 = session.get(f"https://{urlHostName(self._url)}/Jetload3/",
                            headers={"Referer": sHtmlContent.url})
        sHtmlContent3 = sHtmlContent2.text

        match_data = re.search(r'data-token="([^"]+)"', sHtmlContent3)
        match_down = re.search(r'id="countdown-number">(.+?)</span>', sHtmlContent3)
        match_extra = re.search(r"window\.extraToken\s*=\s*'([^']+)'", sHtmlContent3)
        if not match_data or not match_extra:
            return False, False
        
        sData = match_data.group(1)
        sToken = match_extra.group(1)
        sCountDown = int(match_down.group(1)) if match_down else 0
        if sCountDown > 0:
            VSlog(f"Waiting {sCountDown} seconds...")
            time.sleep(sCountDown)

        sHtmlContent4 = session.get(f"https://{urlHostName(self._url)}/Jetload3/get-link.php?token={sData}",
                            headers={"Referer": f"https://{urlHostName(self._url)}/Jetload3/",
                                    "X-Requested-With": "XMLHttpRequest"})
        url = sHtmlContent4.text.strip()
        url = url.lstrip("\ufeff")

        sHtmlContent5 = session.get(f"{url}?t={sToken}",
                            headers={"Referer": f"https://{urlHostName(self._url)}/Jetload3/"},
                            allow_redirects=False)

        final_url = sHtmlContent5.headers.get("Location")
        if final_url:
            api_call = f'{final_url}|Referer=https://{urlHostName(self._url)}/Jetload3/&Host={urlHostName(final_url)}&User-Agent={UA}'
            return True, api_call


        return False, False
