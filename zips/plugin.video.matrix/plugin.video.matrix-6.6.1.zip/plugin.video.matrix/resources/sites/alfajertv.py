﻿# -*- coding: utf-8 -*-

import re
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, VSlog, siteManager, addon
from resources.lib.parser import cParser
from resources.lib.util import cUtil
from resources.lib import random_ua

UA = random_ua.get_ua()

SITE_IDENTIFIER = 'alfajertv'
SITE_NAME = 'Alfajertv'
SITE_DESC = 'arabic vod'
 
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

MOVIE_EN = (f'{URL_MAIN}genre/english-movies/', 'showMovies')
MOVIE_AR = (f'{URL_MAIN}genre/arabic-movies/', 'showMovies')
MOVIE_FAM = (f'{URL_MAIN}genre/family/', 'showMovies')
MOVIE_HI = (f'{URL_MAIN}genre/indian-movies/', 'showMovies')
MOVIE_TURK = (f'{URL_MAIN}genre/turkish-movies/', 'showMovies')
KID_MOVIES = (f'{URL_MAIN}genre/animation/', 'showMovies')
MOVIE_GENRES = (URL_MAIN, 'moviesGenres')

SERIE_TR = (f'{URL_MAIN}genre/turkish-series/', 'showSeries')
SERIE_EN = (f'{URL_MAIN}genre/english-series/', 'showSeries')
SERIE_AR = (f'{URL_MAIN}genre/arabic-series/', 'showSeries')
RAMADAN_SERIES = (f'{URL_MAIN}genre/ramadan2026', 'showSeries')
SERIE_GENRES = (URL_MAIN, 'seriesGenres')

REPLAYTV_PLAY = (f'{URL_MAIN}genre/plays/', 'showMovies')

URL_SEARCH = (f'{URL_MAIN}wp-admin/admin-ajax.php?action=fshow_live_search&s=', 'showMovies')
URL_SEARCH_MOVIES = (f'{URL_MAIN}wp-admin/admin-ajax.php?action=fshow_live_search&s=', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}wp-admin/admin-ajax.php?action=fshow_live_search&s=', 'showSeries')
FUNCTION_SEARCH = 'showMovies'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearchSeries', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', RAMADAN_SERIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'رمضان', 'rmdn.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام عربية', 'arab.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_TURK[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام تركية', 'turk.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_HI[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام هندية', 'hend.png', oOutputParameterHandler)
       
    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام كرتون', 'anim.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات عربية', 'arab.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', SERIE_TR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات تركية', 'turk.png', oOutputParameterHandler) 

    oOutputParameterHandler.addParameter('siteUrl', REPLAYTV_PLAY[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'مسرحيات', 'msrh.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_GENRES[0])
    oGui.addDir(SITE_IDENTIFIER, SERIE_GENRES[1], 'المسلسلات (الأنواع)', 'mslsl.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_GENRES[0])
    oGui.addDir(SITE_IDENTIFIER, MOVIE_GENRES[1], 'الأفلام (الأنواع)', 'film.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()
 
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}wp-admin/admin-ajax.php?action=fshow_live_search&s='+sSearchText
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showSearchSeries():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}wp-admin/admin-ajax.php?action=fshow_live_search&s='+sSearchText
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return
 
def moviesGenres():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = 'class="archive-filters">'
    sEnd = '</select>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'option value="([^"]+)">(.+?)</option>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            if 'مسلسلات' in aEntry[1]:
                continue
            sTitle = aEntry[1]  
            sGenres = aEntry[0]
            oOutputParameterHandler.addParameter('siteUrl', sGenres) 
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def seriesGenres():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = 'class="archive-filters">'
    sEnd = '</select>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'option value="([^"]+)">(.+?)</option>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            if 'أفلام' in aEntry[1]:
                continue
            sTitle = aEntry[1]  
            sGenres = aEntry[0]
            oOutputParameterHandler.addParameter('siteUrl', sGenres) 
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', sTitle, 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showMovies(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
        sPattern = r'<a href="([^"]+)"\s+class="search-result-item">.+?img src="([^"]+)"\s+alt="([^"]+)".+?<span>(.+?)</span>'
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        sPattern = r'<a href="([^"]+)"\s+class="item-card">.+?img src="([^"]+)"\s+alt="([^"]+)".+?<span class="year-badge">(.+?)</span>'

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break

            if "/tvshow"  in aEntry[2]:
                continue

            sTitle = cUtil().CleanMovieName(aEntry[2])
            siteUrl = aEntry[0]
            sThumb = aEntry[1]	
            sYear = aEntry[3]
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
			
            oGui.addMovie(SITE_IDENTIFIER, 'showServer', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
    if not sSearch:
        if 'class="archive-pagination">' in sHtmlContent:
            sStart = 'class="archive-pagination">'
            sEnd = '</main>'
            sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)
            sPattern = r'href=["\']([^"\']+)["\']>(.+?)</a>'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                for aEntry in aResult[1]:
                
                    sTitle = f'[COLOR red]Page: {aEntry[1]}[/COLOR]'
                    siteUrl = aEntry[0]

                    oOutputParameterHandler = cOutputParameterHandler()
                    oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                    oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()
	
def showSeries(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
        sPattern = r'<a href="([^"]+)"\s+class="search-result-item">.+?img src="([^"]+)"\s+alt="([^"]+)".+?<span>(.+?)</span>'
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        sPattern = r'<a href="([^"]+)"\s+class="item-card">.+?img src="([^"]+)"\s+alt="([^"]+)".+?<span class="year-badge">(.+?)</span>'

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            if "/movie"  in aEntry[2]:
                continue

            sTitle = cUtil().CleanSeriesName(aEntry[2])
            siteUrl = aEntry[0]
            sThumb = aEntry[1]	
            sYear = aEntry[3]	
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sDesc', sDesc)
			
            oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
    if not sSearch:
        if 'class="archive-pagination">' in sHtmlContent:
            sStart = 'class="archive-pagination">'
            sEnd = '</main>'
            sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)
            sPattern = r'href=["\']([^"\']+)["\']>(.+?)</a>'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                for aEntry in aResult[1]:
                
                    sTitle = f'[COLOR red]Page: {aEntry[1]}[/COLOR]'
                    siteUrl = aEntry[0]

                    oOutputParameterHandler = cOutputParameterHandler()
                    oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                    oGui.addDir(SITE_IDENTIFIER, 'showSeries', sTitle, 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()

def showSeasons():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'data-season="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0] is True:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:

            sMovieTitle = re.sub(r"S\d{2}|S\d", "", sMovieTitle)
            sSeason = aEntry
            sTitle = f'{sMovieTitle} S{sSeason}'
            sThumb = sThumb

            oOutputParameterHandler.addParameter('siteUrl', f'{sUrl}?season={sSeason}')
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
 
            oGui.addSeason(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, '', oOutputParameterHandler)
       
    oGui.setEndOfDirectory() 

def showEpisodes():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sDesc = oInputParameterHandler.getValue('sDesc')
    sUrl, sSeason = sUrl.split('?season=')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = f'class="season-episodes" id="season-{sSeason}"'
    sEnd = '</a> </div>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'href="([^"]+)".+?img src="([^"]+)".+?class="episode-number">(.+?)</span> '
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            if "x" in aEntry[2]:
                sEpi = aEntry[2].split("x")[1] 
            else: 
                sEpi = aEntry[2]
            sTitle = f'{sMovieTitle} E{sEpi}'
            siteUrl = aEntry[0]
            sThumb = aEntry[1]
            sDesc =  sDesc

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)

            oGui.addEpisode(SITE_IDENTIFIER, 'showServer', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
       
    oGui.setEndOfDirectory()

def showServer():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    results = []

    sPattern = r"postId\s*=\s*(\d+)"
    aResult = oParser.parse(sHtmlContent,sPattern)
    if aResult[0]:
        post = aResult[1][0]

    sPattern = r"postType\s*=\s*'([^']+)'"
    aResult = oParser.parse(sHtmlContent,sPattern)
    if aResult[0]:
        dtype = aResult[1][0]

    if post and dtype:
        sPattern = r'data-server="([^"]+)"'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            for aEntry in aResult[1]:
                pUrl = f'{URL_MAIN}wp-admin/admin-ajax.php'
                nume = aEntry
                pdata = f'action=doo_player_ajax&post={post}&nume={nume}&type={dtype}'

                oRequest = cRequestHandler(pUrl)
                oRequest.setRequestType(1)
                oRequest.addHeaderEntry('User-Agent', UA)
                oRequest.addHeaderEntry('Referer', sUrl)
                oRequest.addHeaderEntry('Host', 'fajer.show')
                oRequest.addHeaderEntry('Accept', '*/*')
                oRequest.addHeaderEntry('Accept-Language', 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3')
                oRequest.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded')
                oRequest.addParametersLine(pdata)
                sHtmlContent = oRequest.request() 

                sPattern = r"<iframe.+?src='(.+?)' frameborder"
                aResult = oParser.parse(sHtmlContent, sPattern)
                if aResult[0]:
                    for aEntry in aResult[1]:            
                        url = aEntry.replace("%2F","/").replace("%3A",":").replace("https://show.alfajertv.com/jwplayer/?source=","").replace("&type=mp4","").split("&id")[0]
                        if 'hadara.ps' in aEntry :
                            url = f'{url}|Referer{aEntry}&User-Agent={UA}&verifypeer=false'
                        if url.startswith('//'):
                            url = 'http:' + url
                
                        sHosterUrl = url
                        if 'userload' in sHosterUrl:
                            sHosterUrl = f'{sHosterUrl}|Referer={URL_MAIN}'
                        if 'mystream' in sHosterUrl:
                            sHosterUrl = f'{sHosterUrl}|Referer={URL_MAIN}'

                        results.append((SITE_NAME, sHosterUrl))

        useDialog = addon().getSetting('HosterDialog') == 'true'
        if useDialog:
            cHosterGui().selectHoster(results, sMovieTitle, SITE_NAME, sThumb)
        else:
            for sTitle, sHosterUrl in results:
                oHoster = cHosterGui().checkHoster(sHosterUrl)
                if oHoster:
                    oHoster.setDisplayName(sMovieTitle)
                    oHoster.setFileName(sMovieTitle)
                    cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)
            oGui.setEndOfDirectory()

    else:
        oGui.addText(SITE_IDENTIFIER, '[COLOR red]تعذر الحصول على الروابط.[/COLOR]')
        oGui.setEndOfDirectory()