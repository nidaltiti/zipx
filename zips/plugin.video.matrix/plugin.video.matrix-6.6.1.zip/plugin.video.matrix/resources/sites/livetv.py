# -*- coding: utf-8 -*-

import base64
import re
import xbmc
import json
from resources.lib.comaddon import isMatrix, siteManager, addon
from resources.lib.gui.gui import cGui
from resources.lib.gui.hoster import cHosterGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.packer import cPacker
from resources.lib.parser import cParser
from resources.lib.util import cUtil, Unquote, urlHostName
from resources.lib import random_ua

UA = random_ua.get_pc_ua()

SITE_IDENTIFIER = 'livetv'
SITE_NAME = 'Live TV'
SITE_DESC = 'Live sport events'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

SPORT_GENRES = (f'{URL_MAIN}enx/allupcomingsports/', 'showGenres') 
SPORT_LIVE = (f'{URL_MAIN}enx/', 'showLive') 
SPORT_SPORTS = (True, 'load')

HEURE_HIVER = True

def load():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()

    oOutputParameterHandler.addParameter('siteUrl', SPORT_GENRES[0])
    oGui.addDir(SITE_IDENTIFIER, SPORT_GENRES[1], 'الرياضة (حسب الصنف)', 'sport.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SPORT_LIVE[0])
    oGui.addDir(SITE_IDENTIFIER, SPORT_LIVE[1], 'رياضة (مباشر)', 'sport.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showLive():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = URL_MAIN + oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.disableSSL()
    sHtmlContent = oRequestHandler.request()

    oParser = cParser()
    sPattern = r'<a class="live" href="([^"]+)">([^<]+)<.a>\s*<br>\s*<a\s*class="live.+?span class="evdesc">([^<]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)

    if not aResult[0]:
        oGui.addText(SITE_IDENTIFIER)

    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()
        bMatrix = isMatrix()
        for aEntry in aResult[1]:
            sUrl3 = URL_MAIN + aEntry[0]
            heure, canal = aEntry[2].split(':')
            minute, compet = canal.split('(')
            heure = int(heure)
            if HEURE_HIVER:
                heure -= 1
                if heure == -1:
                    heure = 23
            sTitle2 = '%d:%s - %s (%s' % (heure, minute, aEntry[1], compet)
            sDisplayTitle = sTitle2

            if not bMatrix: 
                try:
                    sTitle2 = sTitle2.decode("utf-8", 'ignore')
                except:
                    pass
            sTitle2 = cUtil().unescape(sTitle2)
            if not bMatrix: 
                try:
                    sTitle2 = sTitle2.encode("utf-8", 'ignore')
                except:
                    pass

            oOutputParameterHandler.addParameter('siteUrl3', sUrl3)
            oOutputParameterHandler.addParameter('sMovieTitle2', sTitle2)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies3', sDisplayTitle, 'sport.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def showGenres():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = URL_MAIN + oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    sPattern = r'<a class="main" href="([^"]+)"><b>([^<]+)</b>.+?\s*</td>\s*<td width=.+?>\s*<a class="small" href=".+?"><b>([^<]+)</b></a>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if not aResult[0]:
        oGui.addText(SITE_IDENTIFIER)
    else:
        bMatrix = isMatrix()
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in sorted(aResult[1], key=lambda genre: genre[1]):
            sUrl2 = URL_MAIN + aEntry[0]
            sTitle = aEntry[1]

            if not bMatrix:
                try:
                    sTitle = sTitle.decode("utf-8", 'ignore')
                except:
                    pass
            sTitle = cUtil().unescape(sTitle)
            if not bMatrix:
                try:
                    sTitle = sTitle.encode("utf-8", 'ignore')
                    sTitle = str(sTitle , encoding="utf-8", errors='ignore')
                except:
                    pass

            oOutputParameterHandler.addParameter('siteUrl2', sUrl2)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'sport.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()


def showMovies(): 

    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl2 = oInputParameterHandler.getValue('siteUrl2')

    oRequestHandler = cRequestHandler(sUrl2)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'<a class="live" href="([^"]+)">([^<]+)</a>\s*(<br><img src=".+?/img/live.gif"><br>|<br>)\s*<span class="evdesc">([^<]+)\s*<br>\s*([^<]+)</span>'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, sPattern)

    if not aResult[0]:
        oGui.addText(SITE_IDENTIFIER)
    else:
        bMatrix = isMatrix()
        mois = ['filler', 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'aout', 'septembre', 'octobre', 'novembre', 'décembre']
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in aResult[1]:
            sThumb = ''
            taglive = ''
            sTitle2 = aEntry[1].replace('<br>', ' ')
            sUrl3 = URL_MAIN + aEntry[0]

            if 'live.gif' in aEntry[2]:
                taglive = ' [COLOR limegreen] Online[/COLOR]'

            sDate = aEntry[3]
            sQual = aEntry[4]

            if not bMatrix:
                try:
                    sTitle2 = sTitle2.decode("utf-8", 'ignore')
                    sQual = sQual.decode("utf-8", 'ignore')
                    sDate = sDate.decode("utf-8", 'ignore')
                except:
                    pass

                sTitle2 = cUtil().unescape(sTitle2)
                sQual = cUtil().unescape(sQual)

                if not bMatrix:
                    sTitle2 = sTitle2.encode("utf-8", 'ignore')
                    sQual = str(sQual.encode("utf-8", 'ignore'))
                    sDate = sDate.encode('utf-8')

            if sDate:
                try:
                    sDateTime = re.findall(r'(\d+) ([\S]+).+?(\d+)(:\d+)', str(sDate))
                    if sDateTime:
                        sMonth = mois.index(sDateTime[0][1])
                        heure = int(sDateTime[0][2])
                        heure = int(heure)
                        if HEURE_HIVER:
                            heure -=1
                            if heure == -1:
                                heure = 23
                        
                        sDate = '%02d/%02d %02d%s' % (int(sDateTime[0][0]), sMonth, heure, sDateTime[0][3])
                except Exception as e:
                    pass

            sTitle2 = ('%s - %s [COLOR yellow]%s[/COLOR]') % (sDate, sTitle2, sQual)
            sDisplayTitle = sTitle2 + taglive

            oOutputParameterHandler.addParameter('siteUrl3', sUrl3)
            oOutputParameterHandler.addParameter('sMovieTitle2', sTitle2)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies3', sDisplayTitle, 'sport.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def showMovies3():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl3 = oInputParameterHandler.getValue('siteUrl3')

    oRequestHandler = cRequestHandler(sUrl3)
    sHtmlContent = oRequestHandler.request()
    sMovieTitle2 = oInputParameterHandler.getValue('sMovieTitle2')

    sPattern = r'<td width=16><img title="(.*?)".+?<a title=".+?" *href="(.+?)"'
    oParser = cParser()

    aResult = oParser.parse(sHtmlContent, sPattern)

    if not aResult[0]:
        oGui.addText(SITE_IDENTIFIER)

    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in aResult[1]:
            sLang = aEntry[0]
            sLang = cUtil().unescape(sLang)
            try:
                sLang = sLang.encode("utf-8", 'ignore')
                sLang = str(sLang, encoding="utf-8", errors='ignore')
            except:
                pass

            sUrl4 = aEntry[1]
            if sUrl4.startswith('/'):
                sUrl4 = URL_MAIN + sUrl4
            elif not (sUrl4.startswith("http")):
                sUrl4 = "https:" + sUrl4
                
            if 'cdn' in sUrl4:
                sUrl4 = re.sub('https:\/\/cdn\.livetv\d+\.me\/', URL_MAIN, sUrl4)
                
            sTitle = ('%s (%s)') % (sMovieTitle2, sLang[:4])
            sThumb = ''

            oOutputParameterHandler.addParameter('siteUrl', sUrl4)
            oOutputParameterHandler.addParameter('sMovieTitle2', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oGui.addDir(SITE_IDENTIFIER, 'showHosters', sTitle, 'sport.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def showHosters():
    oGui = cGui()
    UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0'
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle2 = oInputParameterHandler.getValue('sMovieTitle2')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    oParser = cParser()
    sPattern = r'<iframe +(?:allowFullScreen|width).+?src="([^"]+)".+?<\/iframe>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:

        sHosterUrl = ''
        Referer = ''
        url = aResult[1][0]
        if not (url.startswith("http")):
            url = "https:" + url

        if 'youtube' in url:
            sHosterUrl = url

        if 'popofthestream' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent = oRequestHandler.request()
            sPattern = r'src="([^"]+)'
            aResult = re.findall(sPattern, sHtmlContent)
            if aResult:
                url2 = url.replace('-', '/')
                urlChannel = url2.replace('html', 'json')
                oRequestHandler = cRequestHandler(urlChannel)
                sHtmlContent = oRequestHandler.request()
                
                if not sHtmlContent.startswith('<!'):
                    result = json.loads(sHtmlContent)
                    if 'id' in result:
                        idChannel = result['id']
                        oRequestHandler = cRequestHandler(url2)
                        sHtmlContent2 = oRequestHandler.request()
                        sPattern = r'<iframe.+?src="([^\']+)'
                        aResult = re.findall(sPattern, sHtmlContent2)
                        if aResult:
                            url = aResult[0] + idChannel

        if 'sportlevel' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r"manifestUrl: '(.+?)',"
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl = 'https://d.sportlevel.com' + aResult[0]
            else:
                sPattern2 = r'(https:\/\/embedded.+?)"'
                aResult = oParser.parse(sHtmlContent2, sPattern2)
                if aResult[0]:
                    url2 = aResult[1][0]
                    oRequestHandler = cRequestHandler(url2)
                    sHtmlContent3 = oRequestHandler.request()
                    sPattern = r"RESOLUTION=(\w+)\s*(http.+?)(#|$)"
                    aResult2 = oParser.parse(sHtmlContent3, sPattern)
                    if aResult2[0] is True:
                        for aResult in aResult2[1]:
                            q = aResult[0]
                            sHosterUrl = aResult[1]
                            sDisplayTitle = sMovieTitle2 + ' [' + q + '] '

                        results.append((sDisplayTitle, sHosterUrl))

        if 'tv.rushandball' in url:
            sPattern = r'\/(\d+)'
            aResult = re.findall(sPattern, url)
            if aResult:
                videoId = aResult[0]
                url2 = 'https://tv.rushandball.ru/api/v2/content/' + videoId + '/access'

                oRequestHandler = cRequestHandler(url2)
                oRequestHandler.setRequestType(1)
                oRequestHandler.addHeaderEntry('Referer', url)
                sHtmlContent = oRequestHandler.request()
                sPattern = 'stream.+?"(https.+?)"'
                aResult = oParser.parse(sHtmlContent, sPattern)
                if aResult[0]:
                    sHosterUrl = aResult[1][0]

        if 'seenow.tv' in url:
            sPattern = r'api.(.+?)$'
            aResult = re.findall(sPattern, url)
            if aResult:
                data = 'url=' + aResult[0] + '&type=tv'
                oRequestHandler = cRequestHandler(url)
                oRequestHandler.addHeaderEntry('Referer', url)
                oRequestHandler.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
                sHtmlContent = oRequestHandler.request()
                cook = oRequestHandler.GetCookies()
                xbmc.sleep(200)
                oRequestHandler = cRequestHandler(url)
                oRequestHandler.setRequestType(1)
                oRequestHandler.addHeaderEntry('Content-Length', len(data))
                oRequestHandler.addHeaderEntry('Referer', url)
                oRequestHandler.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
                oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
                oRequestHandler.addHeaderEntry('Cookie', cook)
                oRequestHandler.addParametersLine(data)
                sHtmlContent2 = oRequestHandler.request()

                sPattern = r'stream_id.+?(\d+)'
                aResult = re.findall(sPattern, sHtmlContent2)
                if aResult:
                    stream_id = aResult[0]
                    url2 = 'https://www.filmon.com/api-v2/channel/' + stream_id + '?protocol=hls'
                    oRequestHandler = cRequestHandler(url2)
                    oRequestHandler.addHeaderEntry('Referer', url)
                    oRequestHandler.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
                    sHtmlContent2 = oRequestHandler.request()
                    sPattern = r'quality"."(\w+)".*?url.*?"(https.+?)"'
                    aResult = re.findall(sPattern, sHtmlContent2)
                    if aResult:
                        for Result in aResult:
                            q = Result[0]
                            sHosterUrl = Result[1]
                            sDisplayTitle = sMovieTitle2 + ' [' + q + '] '

                        results.append((sDisplayTitle, sHosterUrl))

        if 'faraoni1' in url:
            nextlink = url
            for x in range(0, 6): 
                oRequestHandler = cRequestHandler(nextlink)
                sHtmlContent = oRequestHandler.request()
                sPattern = r'url.+?(http.+?m3u8)'
                aResult = re.findall(sPattern, sHtmlContent)
                if aResult:
                    sHosterUrl = str(aResult[0])
                    break
                else:
                    sPattern = r'<iframe.+?src="([^"]+)'
                    aResult = re.findall(sPattern, sHtmlContent)
                    if aResult:
                        nextlink = 'https://faraoni1.ru' + aResult[0]

        if 'embed.tvcom.cz' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent = oRequestHandler.request()
            sPattern = r"source.+?hls.+?'(https.+?m3u8)"
            aResult = re.findall(sPattern, sHtmlContent)
            if aResult:
                sHosterUrl = aResult[0]

        if 'allsports.icu' in url:
            sPattern = r'ch(\d+).php'
            aResult = re.findall(sPattern, url)
            if aResult:
                videoId = aResult[0]
                url2 = 'https://allsports.icu/stream/ch' + videoId + '.html'
                sHosterUrl = getHosterIframe(url2, url2)

        if 'espn-live.stream' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            aResult = re.findall(sPattern, sHtmlContent2)
            if aResult:
                url = aResult[0]  

        if 'footballreal.xyz' in url or 'cdnz.one' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern1 = r'<iframe src=["\'](.+?)["\']'
            aResult = re.findall(sPattern1, sHtmlContent2)
            if aResult:
                Referer = url
                url = aResult[0] 

        if 'dailydeports.pw' in url:
            oRequestHandler = cRequestHandler(url)
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            oRequestHandler.addHeaderEntry('Referer', sUrl)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<iframe src="([^"]+)"'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                if 'cdnz.one' in aResult[0]:
                    url = aResult[0] 
            else:
                sPattern2 = r"str='([^']+)'"
                aResult = re.findall(sPattern2, sHtmlContent2)
                if aResult:
                    for aEntry in aResult:
                        aEntry = aEntry.replace('@', '')
                        data = bytearray.fromhex(aEntry).decode()
                        sPattern3 = r'<iframe src="([^"]+)"'
                        aResult1 = re.findall(sPattern3, data)
                        if aResult1:
                            url = aResult1[0] 
                            break

        if 'emb.apl' in url:
            if url.startswith('//'):
                url = 'https:' + url
            Referer = url
            oRequestHandler = cRequestHandler(url)
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            sHtmlContent2 = oRequestHandler.request()

            if not sHtmlContent2:
                url = url.replace('//emb.', '//').replace('player/live.php?id=', 'redir/c.php?i=')
                oRequestHandler = cRequestHandler(url)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                sHtmlContent2 = oRequestHandler.request()

            sPattern2 = r'source: *\'(.+?)\''
            
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl = aResult[0] + '|User-Agent=' + UA + '&referer=' + Referer
            else:
                sPattern2 = r"pl\.init\('([^']+)'\);"
                aResult = re.findall(sPattern2, sHtmlContent2)
                if aResult:
                    sHosterUrl = aResult[0] + '|User-Agent=' + UA + '&referer=' + Referer

        if 'sport7.pw' in url or 'vip7stream' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'videoLink = \'(.+?)\''
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl = aResult[0] + '|User-Agent=' + UA + '&referer=' + url

        if 'totalsport.me' in url or 'airhdx' in url or 'givemenbastreams' in url: 
            oRequestHandler = cRequestHandler(url)
            if Referer:
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', Referer)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'source: ["\'](.+?)["\']'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl = aResult[0]

        if 'sportsbar.pw' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'videoLink = \'(.+?)\''
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl = aResult[0]

        if 'livesoccers.pw' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<iframe src=\'(.+?)\''
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl2 = aResult[0]
                oRequestHandler = cRequestHandler(sHosterUrl2)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', sHosterUrl2)
                sHtmlContent3 = oRequestHandler.request()
                sPattern3 = r'<source src="([^"]+)"'
                aResult1 = re.findall(sPattern3, sHtmlContent3)
                if aResult1:
                    sHosterUrl = aResult1[0]

        if 'assia' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'file:"([^"]+)"|source: \'([^\']+)\''
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl = aResult[0][1] + '|User-Agent=' + UA + '&referer=' + url
            else:
                sPattern2 = r'<source src=\'([^\']+)\''
                aResult = re.findall(sPattern2, sHtmlContent2)
                if aResult:
                    sHosterUrl = aResult[0] + '|User-Agent=' + UA + '&referer=' + url

        if 'sawlive' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'src="([^"]+)"'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl3 = aResult[0]
                oRequestHandler = cRequestHandler(sHosterUrl3)
                sHtmlContent3 = oRequestHandler.request()
                sPattern3 = r'var .+? = "([^;]+);([^\"]+)";'
                aResult = re.findall(sPattern3, sHtmlContent3)
                if aResult:
                    sHosterUrl3 = "https://www.sawlive.tv/embedm/stream/" + aResult[0][1] + '/' + aResult[0][0]
                    oRequestHandler = cRequestHandler(sHosterUrl3)
                    sHtmlContent4 = oRequestHandler.request()

                    sPattern4 = r'(\s*eval\s*\(\s*function(?:.|\s)+?{}\)\))'
                    aResult = re.findall(sPattern4, sHtmlContent4)
                    if aResult:
                        str2 = aResult[0]
                        if not str2.endswith(';'):
                            str2 = str2 + ';'

                        strs = cPacker().unpack(str2)
                        sPattern5 = r'var .+?=([^;]+);'
                        aResult1 = re.findall(sPattern5, strs)
                        if aResult1:
                            jameiei = eval(aResult1[0])
                            data = ''
                            for c in jameiei:
                                data += chr(c)
                            sHosterUrl = data

        if 'sportlive.site' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<iframe src="(.+?)"'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl2 = aResult[0]
                oRequestHandler = cRequestHandler(sHosterUrl2)
                sHtmlContent3 = oRequestHandler.request()
                sPattern3 = r'<script type=\'text/javascript\'>id=\'(.+?)\''
                aResult2 = re.findall(sPattern3, sHtmlContent3)
                if aResult2:
                    sHosterUrl3 = aResult2[0]
                    sHosterUrl3 = "https://hdcast.pw/stream_jw2.php?id=" + sHosterUrl3
                    oRequestHandler = cRequestHandler(sHosterUrl3)
                    sHtmlContent4 = oRequestHandler.request()
                    sPattern4 = r'curl = "([^"]+)";'
                    aResult3 = re.findall(sPattern4, sHtmlContent4)
                    if aResult3:
                        sHosterUrl = aResult3[0]
                        sHosterUrl = base64.b64decode(sHosterUrl)

        if 'stream365' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'var a[ 0-9]+="(.+?)"'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                gameId = int(aResult[2]) + int(aResult[0]) - int(aResult[1]) - int(aResult[2])
                sHosterUrl = 'https://91.192.80.210/edge0/xrecord/' + str(gameId) + '/prog_index.m3u8'

        if 'streamup.me' in url:  
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<iframe src="([^"]+)"'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl2 = aResult[0]
                oRequestHandler = cRequestHandler(sHosterUrl2)
                sHtmlContent3 = oRequestHandler.request()
                sHtmlContent3 = Unquote(sHtmlContent3)
                sPattern3 = r'src: "\/\/(.+?)"'
                aResult = re.findall(sPattern3, sHtmlContent3)
                if aResult:
                    sHosterUrl = 'https://' + aResult[0]

        if 'livestream' in url:
            sPattern2 = r'<td bgcolor=".+?" *align="center".+?\s*<iframe.+?src="https://([^"]+)/player?.+?</iframe>'
            aResult = re.findall(sPattern2, sHtmlContent)
            if aResult:
                accountid = aResult[0]
                jsonUrl = 'https://player-api.new.' + accountid + '?format=short'
                oRequestHandler = cRequestHandler(jsonUrl)
                sHtmlContent = oRequestHandler.request()
                sPattern3 = r'"m3u8_url":"(.+?)"'
                aResult = re.findall(sPattern3, sHtmlContent)
            if aResult:
                sHosterUrl = aResult[0]

        if 'forbet.tv' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'file: "([^"]+)"'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl = aResult[0]

        if 'p.hd24.watch' in url:  
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'data-channel="([^"]+)">'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                Host = '190-2-146-56.livesports24.online'
                sHosterUrl = 'https://' + Host + '/' + aResult[0] + '.m3u8'

        if 'hdsoccerstreams.net' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<script>fid="(.+?)"'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                fid = aResult[0]
                url2 = 'https://webtv.ws/embed.php?live=spstream' + fid + '&vw=700&vh=440'
                Referer = url
                oRequestHandler = cRequestHandler(url2)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', Referer)
                sHtmlContent3 = oRequestHandler.request()

        if 'voodc' in url:  
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<script type="text/javascript" src="([^"]+)'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                url2 = 'https:' + aResult[0]
                Referer = url
                oRequestHandler = cRequestHandler(url2)
                oRequestHandler.addHeaderEntry('Referer', Referer)
                sHtmlContent2 = oRequestHandler.request()

                sPattern2 = r'var r = embedded\+"([^"]+)'
                aResult = re.findall(sPattern2, sHtmlContent2)
                if aResult:
                    url2 = 'https://voodc.com/play/d' + aResult[0]
                    Referer = url
                    oRequestHandler = cRequestHandler(url2)
                    oRequestHandler.addHeaderEntry('Referer', Referer)
                    sHtmlContent2 = oRequestHandler.request()
                    sPattern2 = r"var PlayS = \\'(.+?)\\'"
                    aResult = re.findall(sPattern2, sHtmlContent2)
                    if aResult:
                        sHosterUrl = aResult[0]
                                

        if 'acagem' in url:  
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<script>fid +="(.+?)"'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                fid = aResult[0]
                url = 'https://stsgmrs.com/panel/gen.php?playerid=%s' % fid
                Referer = url


        if 'lato.sx' in url or '1l1l' in url or 'bedsport' in url or 'lavents' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<script>fid=["\'](.+?)["\'].+?src=\'//([^/]+)([^\']+)'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                fid = aResult[0][0]
                site = 'https://' + aResult[0][1]
                host = aResult[0][2]
                url2 = '%s/%s?player=desktop&live=%s' % (site, host.replace('.js', '.php'), fid)
                
                Referer = url
                oRequestHandler = cRequestHandler(url2)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', Referer)
                sHtmlContent3 = oRequestHandler.request()

                sPattern2 = r'player.load\({source: (.+?)\('
                aResult = re.findall(sPattern2, sHtmlContent3)
                if aResult:
                    func = aResult[0]
                    sPattern2 = r'function %s\(\) +{\n + return\(\[([^\]]+)' % func
                    aResult = re.findall(sPattern2, sHtmlContent3)
                    if aResult:
                        sHosterUrl = aResult[0].replace('"', '').replace(',', '').replace('\\', '').replace('////', '//')
                        sHosterUrl += '|referer=' + site


        if 'wizospor' in url or 'tarjetarojaenvivo' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<div id="[^"]+".+?ThePlayerJS\(\'[^\']+\',\'([^\']+)'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                if 'wizospor' in url:
                    url2 = 'https://sharecast.ws/player/' + aResult[0]
                else:
                    url2 = 'https://eyespeeled.click/player/' + aResult[0]
                Referer = url
                oRequestHandler = cRequestHandler(url2)
                oRequestHandler.addHeaderEntry('Referer', Referer)
                sHtmlContent2 = oRequestHandler.request()

                sPattern2 = r'"player","([^"]+)",{["\'](.+?)["\']'

                aResult = re.findall(sPattern2, sHtmlContent2)
                if aResult:
                    sHosterUrl = 'https://%s/hls/%s/live.m3u8' % (aResult[0][1], aResult[0][0])
                    sHosterUrl += '|' + url2

        if 'thesports4u.net' in url or 'soccerstreams' in url or 'all.ive' in url: 
            if 'all.ive' in url:
                oRequestHandler = cRequestHandler(url)
                sHtmlContent2 = oRequestHandler.request()
                sPattern2 = r"<script>fid='(.+?)'"
                aResult = re.findall(sPattern2, sHtmlContent2)

                if aResult:
                    Referer = 'https://ragnaru.net/'
                    url2 = 'https://ragnaru.net/embed.php?player=desktop&live=' + aResult[0]
                    oRequestHandler = cRequestHandler(url2)
                    oRequestHandler.addHeaderEntry('User-Agent', UA)
                    oRequestHandler.addHeaderEntry('Referer', 'https://all.ive.zone/')
                    sHtmlContent3 = oRequestHandler.request()

            if 'thesports4u' in url:
                oRequestHandler = cRequestHandler(url)
                sHtmlContent2 = oRequestHandler.request()
                sPattern2 = r'<script>fid="(.+?)"'
                aResult = re.findall(sPattern2, sHtmlContent2)

                if aResult:
                    url2 = 'https://wlive.tv/embed.php?player=desktop&live=' + aResult[0] + '&vw=700&vh=440'
                    oRequestHandler = cRequestHandler(url2)
                    oRequestHandler.addHeaderEntry('User-Agent', UA)
                    oRequestHandler.addHeaderEntry('Referer', 'https://thesports4u.net/')
                    oRequestHandler.addHeaderEntry('Host', 'www.wlive.tv')
                    sHtmlContent3 = oRequestHandler.request()

            if 'soccerstreams' in url:
                url = url.replace('/hds', '/hdss/ch')

                oRequestHandler = cRequestHandler(url)
                sHtmlContent1 = oRequestHandler.request()
                sPattern2 = r'<script>fid="(.+?)"'
                aResult = re.findall(sPattern2, sHtmlContent1)

                if aResult:
                    url2 = 'https://wlive.tv/embedra.php?player=desktop&live=' + aResult[0] + '&vw=700&vh=440'
                    oRequestHandler = cRequestHandler(url2)
                    oRequestHandler.addHeaderEntry('User-Agent', UA)
                    oRequestHandler.addHeaderEntry('Referer', url)
                    oRequestHandler.addHeaderEntry('Host', 'www.wlive.tv')
                    sHtmlContent3 = oRequestHandler.request()

            if sHtmlContent3:
                m = re.search(r'return.*?\[(.*?)\].*?\+\s+(.*)\.join.*document.*?"(.*?)"', sHtmlContent3)
                if m:
                    timeVar = m.group(2)
                    hashVar = m.group(3)

                    url3 = ''.join(m.group(1).split(','))
                    url3 = url3.replace('"', '').replace(r'\/', '/')
                    if not url3.startswith('http'):
                        url3 = 'https:' + url3

                    m = re.search(timeVar + r'.*?\[(.*?)\]', sHtmlContent3)
                    if m:
                        timeStr = ''.join(m.group(1).split(',')).replace('"', '')
                        url3 += timeStr

                    m = re.search(hashVar + r'>(.*?)<', sHtmlContent3)
                    if m:
                        hashStr = ''.join(m.group(1).split(',')).replace('"', '')
                        url3 += hashStr
                        sHosterUrl = url3
                        if Referer:
                            sHosterUrl += '|referer=' + Referer

        if 'sports-stream.net' in url:  
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'sports-stream.+?ch=(.+?)"'
            aResult = re.findall(sPattern2, sHtmlContent2)

            if aResult:
                fid = aResult[0]
                url2 = 'https://webtv.ws/embeds.php?live=spstream' + fid + '&vw=700&vh=440'
                oRequestHandler = cRequestHandler(url2)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', 'https://www.sports-stream.net/chtv/sps.php?ch=' + fid)
                sHtmlContent2 = oRequestHandler.request()

                sPattern3 = r'source src="(.+?)".+?">'
                aResult = re.findall(sPattern3, sHtmlContent2)
                if aResult:
                    sHosterUrl = aResult[0]

        if 'sports-stream.link' in url:  
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'sports-stream.+?ch=(.+?)"'
            aResult = re.findall(sPattern2, sHtmlContent2)

            if aResult:
                fid = aResult[0]
                url2 = 'https://www.airhdx.com/embedd.php?live=spstream' + fid + '&vw=700&vh=440'
                oRequestHandler = cRequestHandler(url2)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', 'https://www.sports-stream.link/chtv/sps.php?ch=' + fid)
                sHtmlContent2 = oRequestHandler.request()

                sPattern3 = r'source: "(.+?)",'
                aResult = re.findall(sPattern3, sHtmlContent2)
                if aResult:
                    sHosterUrl = aResult[0] + '|referer=' + url2

        if 'foot.futbol' in url:  
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<iframe src=\'(.+?)\''
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl2 = aResult[0]
                Referer = sHosterUrl2
                oRequestHandler = cRequestHandler(sHosterUrl2)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', Referer)
                sHtmlContent3 = oRequestHandler.request()
                sPattern3 = r'<source src="([^"]+)"'
                aResult2 = re.findall(sPattern3, sHtmlContent3)
                if aResult2:
                    sHosterUrl = aResult2[0]

        if 'viewhd.me' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<script>fid="([^"]+)"'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl2 = 'https://www.hdstream.live/embed.php?player=desktop&live=' + aResult[0] + '&vw=620&vh=490'
                Referer = sHosterUrl2
                oRequestHandler = cRequestHandler(sHosterUrl2)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', Referer)
                sHtmlContent3 = oRequestHandler.request()

        if 'socolive.pro' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'channel=\'(.+?)\', g=\'(.+?)\''
            aResult = re.findall(sPattern2, sHtmlContent2)

            if aResult:
                for aEntry in aResult:
                    channel = aEntry[0]
                    g = aEntry[1]

            url2 = 'https://web.uctnew.com/hembedplayer/' + channel + '/' + g + '/700/480'
            oRequestHandler = cRequestHandler(url2)
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            oRequestHandler.addHeaderEntry('Referer', 'https://new.socolive.pro/')
            sHtmlContent2 = oRequestHandler.request()

            sPatternUrl = r'hlsUrl = "https:\/\/" \+ ea \+ "([^"]+)"'
            sPatternPK = r'var pk = "([^"]+)"'
            sPatternEA = r'ea = "([^"]+)";'
            aResultUrl = re.findall(sPatternUrl, sHtmlContent2)
            aResultEA = re.findall(sPatternEA, sHtmlContent2)
            aResultPK = re.findall(sPatternPK, sHtmlContent2)
            if aResultUrl and aResultPK and aResultEA:
                aResultPK = aResultPK[0][:53] + aResultPK[0][54:] 
                url3 = aResultEA[0] + aResultUrl[0] + aResultPK
                sHosterUrl = 'https://' + url3

        if 'socolive.xyz' in url or 'sportsfix' in url or 'bartsim' in url:  
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'iframe src="(.+?)"'
            aResult = re.findall(sPattern2, sHtmlContent2)

            if aResult:
                url2 = aResult[0]
                if not url.startswith('http'):
                    url2 = "https:" + url2
                oRequestHandler = cRequestHandler(url2)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', url)
                sHtmlContent2 = oRequestHandler.request()

                sPattern2 = r'(\s*eval\s*\(\s*function(?:.|\s)+?{}\)\))'
                aResult = re.findall(sPattern2, sHtmlContent2)

                if aResult:
                    str2 = aResult[0]
                    if not str2.endswith(';'):
                        str2 = str2 + ';'

                    strs = cPacker().unpack(str2)
                    sPattern3 = r'{source:"([^"]+)"'
                    aResult1 = re.findall(sPattern3, strs)
                    if aResult1:
                        sHosterUrl = aResult1[0] + '|User-Agent=' + UA + '&referer=' + url2
                    else:
                        sPattern3 = r'src="([^"]+)"'
                        aResult1 = re.findall(sPattern3, strs)
                        if aResult1:
                            sHosterUrl = aResult1[0] + '|User-Agent=' + UA + '&referer=' + url2

        if '1me.club' in url or 'sportz' in url or 'streamhd' in url or 'hdsportslive' in url or 'cricfree' in url:  
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()

            if 'hdsportslive' in url or 'cricfree' in url:
                sPattern2 = r'document.write\(unescape\(\'(.+?)\'\)\)'
                aResult = re.findall(sPattern2, sHtmlContent2)
                unQuote = Unquote(aResult[0])

                sPattern2 = r'<iframe.+?src="(.+?)"'
                aResult = re.findall(sPattern2, unQuote)

                url = aResult[0]
                if not url.startswith('http'):
                    url = 'https:' + url

                oRequestHandler = cRequestHandler(url)
                sHtmlContent2 = oRequestHandler.request()

                sPattern2 = r'<iframe.+?src=\'(.+?)\''
                aResult = re.findall(sPattern2, sHtmlContent2)

            else:
                sPattern2 = r'<iframe src="(.+?)"'
                aResult = re.findall(sPattern2, sHtmlContent2)

            if aResult:

                if 'wstream.to' in aResult[0] or 'streamcdn' in aResult[0]:  
                    embedUrl = aResult[0]

                    if embedUrl.startswith('//'):
                        embedUrl = 'https:' + embedUrl

                    if 'sportz' in url or 'hdsportslive' in url or 'cricfree' in url:
                        Referer = url
                    else:
                        Referer = 'https://1me.club'

                    oRequestHandler = cRequestHandler(embedUrl)
                    oRequestHandler.addHeaderEntry('User-Agent', UA)
                    oRequestHandler.addHeaderEntry('Referer', Referer)
                    sHtmlContent3 = oRequestHandler.request()

                    sPattern2 = r'(\s*eval\s*\(\s*function(?:.|\s)+?{}\)\))'
                    aResult = re.findall(sPattern2, sHtmlContent3)

                    if aResult:
                        str2 = aResult[0]
                        if not str2.endswith(';'):
                            str2 = str2 + ';'

                    strs = cPacker().unpack(str2)
                    sPattern3 = r'{source:"([^"]+)"'
                    aResult1 = re.findall(sPattern3, strs)
                    if aResult1:
                        sHosterUrl = aResult1[0]

                if 'widestream.io' in aResult[0]:  
                    oRequestHandler = cRequestHandler(aResult[0])
                    sHtmlContent3 = oRequestHandler.request()
                    sPattern3 = r'file:"([^"]+)"'
                    aResult1 = re.findall(sPattern3, sHtmlContent3)
                    if aResult1:
                        sHosterUrl = aResult1[0]

        if not sHosterUrl and (('shd' in url) or ('hd' in url and 'streamhd' not in url and 'hdsportslive' not in url and 'airhdx'
                              not in url and 'wizhd' not in url)):

            urlApi = 'https://api.livesports24.online/gethost'
            sHtmlContent2 = ''
            try:
                channel = url.split('/')[4]
                oRequestHandler = cRequestHandler(urlApi)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', url)
                oRequestHandler.addHeaderEntry('Origin', 'https://' + url.split('/')[2])
                sHtmlContent2 = oRequestHandler.request()
            except:
                pass
            if sHtmlContent2:

                sPattern1 = '([^"]+)'
                aResult = re.findall(sPattern1, sHtmlContent2)
                if aResult:
                    host = aResult[0]
            else:
                urlApi = 'https://api.livesports24.online:8443/gethost'
                oRequestHandler = cRequestHandler(urlApi)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', url)
                oRequestHandler.addHeaderEntry('Origin', 'https://' + url.split('/')[2])
                sHtmlContent2 = oRequestHandler.request()

                sPattern1 = r'([^"]+)'
                aResult = re.findall(sPattern1, sHtmlContent2)
                if aResult:
                    host = aResult[0]

            sHosterUrl = 'https://' + host + '/' + channel + '.m3u8'

        if 'sportgol7' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern1 = r'<source src="(.+?)"'
            aResult = re.findall(sPattern1, sHtmlContent2)
            if aResult:
                sHosterUrl = aResult[0]

        if 'nowlive.pro' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent3 = oRequestHandler.request()
            sPattern3 = r'src%3A%20%22//([^"]+)%3A([^"]+)m3u8'
            aResult1 = re.findall(sPattern3, sHtmlContent3)
            if aResult1:
                ip = aResult1[0][0]
                name = aResult1[0][1]
                sHosterUrl = 'https://' + ip + ':' + name + 'm3u8'

        if 'harleyquinn' in url or 'joker' in url:  
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'fid="(.+?)"; v_width=(.+?); v_height=(.+?);'
            aResult = re.findall(sPattern2, sHtmlContent2)

            if aResult:
                fid = aResult[0][0]
                vw = aResult[0][1]
                vh = aResult[0][2]

                url2 = 'https://www.jokersplayer.xyz/embed.php?u=' + fid + '&vw=' + vw + '&vh=' + vh
                oRequestHandler = cRequestHandler(url2)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', url)
                sHtmlContent2 = oRequestHandler.request()
                sPattern3 = r'src=https://(.+?)/(.+?) '
                aResult = re.findall(sPattern3, sHtmlContent2)
                if aResult:
                    ip = aResult[0][0]
                    url3 = 'https://' + ip + '/' + aResult[0][1]
                    oRequestHandler = cRequestHandler(url3)
                    oRequestHandler.addHeaderEntry('User-Agent', UA)
                    oRequestHandler.addHeaderEntry('Referer', url2)
                    oRequestHandler.addHeaderEntry('Connection', 'keep-alive')
                    sHtmlContent2 = oRequestHandler.request()
                    sPattern3 = r'src=.+?e=(.+?)&st=(.+?)&'
                    aResult = re.findall(sPattern3, sHtmlContent2)
                    if aResult:
                        e = aResult[0][0]
                        st = aResult[0][1]
                        sHosterUrl = 'https://' + ip + '/live/' + fid + '.m3u8'+'?e=' + e + '&st=' + st

                if sHosterUrl == '':
                    url2 = 'https://player.jokehd.com/one.php?u=' + fid + '&vw=' + vw + '&vh=' + vh
                    oRequestHandler = cRequestHandler(url2)
                    oRequestHandler.addHeaderEntry('User-Agent', UA)
                    oRequestHandler.addHeaderEntry('Referer', url)
                    sHtmlContent2 = oRequestHandler.request()
                    sPattern3 = r'source: \'(.+?)\''
                    aResult = re.findall(sPattern3, sHtmlContent2)
                    if aResult:
                        sHosterUrl = aResult[0]

        if 'baltak.biz' in url:  
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<iframe src="\/blok.php\?id=(.+?)"'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                url2 = aResult[0]
                oRequestHandler = cRequestHandler(url2)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', 'https://baltak.biz/blok.php?id=' + url2)
                sHtmlContent2 = oRequestHandler.request()

                sPattern2 = r'source: \'(.+?)\''
                aResult = re.findall(sPattern2, sHtmlContent2)
                if aResult:
                    sHosterUrl = aResult[0]
            else:
                sPattern2 = r'source: \"(.+?)\"'
                aResult = re.findall(sPattern2, sHtmlContent2)
                if aResult:
                    sHosterUrl = aResult[0]

        if 'footballstream' in url:  
            url = url.replace('/streams', '/hdstreams')
            oRequestHandler = cRequestHandler(url)
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            oRequestHandler.addHeaderEntry('Referer', url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'fid="(.+?)"; v_width=(.+?); v_height=(.+?);'
            aResult = re.findall(sPattern2, sHtmlContent2)

            if aResult:
                fid = aResult[0][0]
                vw = aResult[0][1]
                vh = aResult[0][2]

                embedded = "mobile"

                url2 = 'https://www.b4ucast.me/embedra.php?player=' + embedded + '&live=' + fid + '&vw=' + vw + '&vh=' + vh
                oRequestHandler = cRequestHandler(url2)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', url)
                sHtmlContent2 = oRequestHandler.request()

                sPattern3 = r'source: *["\'](.+?)["\']'
                aResult = re.findall(sPattern3, sHtmlContent2)
                if aResult:
                    sHosterUrl = 'https:' + aResult[0]

        if 'tennistvgroup' in url:  
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()

            sPattern2 = r'source: *["\'](.+?)["\']'
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl = aResult[0]

        if 'box-live.stream' in url:  
            oRequestHandler = cRequestHandler(url)
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            oRequestHandler.addHeaderEntry('Referer', sUrl)

            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'source: \'(.+?)\''
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl = aResult[0] + '|User-Agent=' + UA + '&referer=' + url
            else:
                sPattern2 = r'var source = \"(.+?)\"'
                aResult = re.findall(sPattern2, sHtmlContent2)
                if aResult:
                    sHosterUrl = aResult[0]
                else:
                    sPattern2 = r'<iframe.+?src="(http.+?)".+?</iframe>'
                    aResult = re.findall(sPattern2, sHtmlContent2)
                    if aResult:
                        Referer = url
                        url = aResult[0] 

        if 'telerium.tv' in url: 
            oRequestHandler = cRequestHandler(url)
            if Referer:
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', Referer)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'(\s*eval\s*\(\s*function(?:.|\s)+?{}\)\))'
            aResult = re.findall(sPattern2, sHtmlContent2)

            if aResult:
                str2 = aResult[0]
                if not str2.endswith(';'):
                    str2 = str2 + ';'

                strs = cPacker().unpack(str2)

                sPattern3 = r'{url:window\.atob\((.+?)\)\.slice.+?\+window\.atob\((.+?)\)'
                aResult1 = re.findall(sPattern3, strs)
                if aResult1:
                    m3u = aResult1[0][0]
                    sPatternM3u = m3u + '="(.+?)"'
                    m3u = re.findall(sPatternM3u, strs)
                    m3u = base64.b64decode(m3u[0])[14:]

                    token = aResult1[0][1]
                    sPatterntoken = token + '="(.+?)"'
                    token = re.findall(sPatterntoken, strs)
                    token = base64.b64decode(token[0])

                    sHosterUrl = 'https://telerium.tv/' + m3u + token + '|referer=' + url

        if 'usasports.live' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern1 = r'var sou = "  (.+?)"'
            aResult = re.findall(sPattern1, sHtmlContent2)
            if aResult:
                sHosterUrl = aResult[0]

        if 'wiz1' in url:
            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern1 = r'"iframe" src="(.+?)"'
            aResult = re.findall(sPattern1, sHtmlContent2)
            if aResult:
                sHosterUrl = aResult[0]

        if 'var16.ru' in url:
            sHosterUrl = getHosterVar16(url, url)

        if 'livesportone' in url:
            url = url.replace('livesportone.com', 'sportes.pw')

            oRequestHandler = cRequestHandler(url)
            sHtmlContent2 = oRequestHandler.request()
            sPattern2 = r'<iframe src=\'(.+?)\''
            aResult = re.findall(sPattern2, sHtmlContent2)
            if aResult:
                sHosterUrl2 = aResult[0] + '|User-Agent=' + UA + '&referer=' + url
                oRequestHandler = cRequestHandler(sHosterUrl2)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                oRequestHandler.addHeaderEntry('Referer', url)
                sHtmlContent3 = oRequestHandler.request()
                sPattern3 = r'source: "([^"]+)"'
                aResult1 = re.findall(sPattern3, sHtmlContent3)
                if aResult1:
                    sHosterUrl = aResult1[0] + '|User-Agent=' + UA + '&referer=' + url

        if url.endswith('.m3u8'): 
            return url

        if not sHosterUrl:
            sHosterUrl = getHosterIframe(url, url)

        if sHosterUrl:
            if sHosterUrl.startswith('//'):
                sHosterUrl = 'https:' + sHosterUrl

            results.append((sMovieTitle2, sHosterUrl))

    if useDialog and results:
        cHosterGui().selectHoster(results, sMovieTitle2, SITE_NAME, sThumb)
    else:
        for sTitle, sHosterUrl in results:
            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sTitle)
                oHoster.setFileName(sTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

        oGui.setEndOfDirectory()

def getHosterVar16(url, referer):
    oRequestHandler = cRequestHandler(url)
    oRequestHandler.addHeaderEntry('Referer', referer)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'file:\"([^"]+)\"'
    aResult = re.findall(sPattern, sHtmlContent)
    if aResult:
        return aResult[0] + '|referer=' + url

    sPattern = r'src=\"(.+?)\"'
    aResult = re.findall(sPattern, sHtmlContent)
    if aResult:
        referer = url
        url = 'https://var16.ru/' + aResult[0]
        return getHosterVar16(url, referer)


def getHosterIframe(url, referer):

    if 'getbanner.php' in url:
        return False
    
    if not url.startswith('http'):
        url = URL_MAIN + url

    oRequestHandler = cRequestHandler(url)
    if referer:
        oRequestHandler.addHeaderEntry('Referer', referer)
    sHtmlContent = oRequestHandler.request()
    realUrl = oRequestHandler.getRealUrl()
    if realUrl and realUrl != url:
        return getHosterIframe(realUrl, referer)
    
    sHtmlContent = str(sHtmlContent)
    if not sHtmlContent:
        return False
    return getUrl(sHtmlContent, url)

def getUrl(sHtmlContent, url):
    referer = url
    oParser = cParser()
    
    decoded = reveal_pipe_split(sHtmlContent)
    if decoded:
        return getUrl(decoded, referer)

    sPattern = r'(\s*eval\s*\(\s*function(?:.|\s)+?{}\)\))'
    aResult = re.findall(sPattern, sHtmlContent)
    if aResult:
        sstr = aResult[0]
        if not sstr.endswith(';'):
            sstr = sstr + ';'
        try:
            sHtmlContent = cPacker().unpack(sstr)
        except:
            pass

    sPattern = r'.atob\("(.+?)"'
    aResult = re.findall(sPattern, sHtmlContent)
    if aResult:
        bMatrix = isMatrix()
        for code in aResult:
            try:
                if bMatrix:
                    code = base64.b64decode(code).decode('ascii')
                else:
                    code = base64.b64decode(code)
                if '.m3u' in code:
                    return code + '|Referer=' + referer
            except Exception as e:
                pass
    
    sPattern = r"mimeType: *\"application\/x-mpegURL\",\r\nsource:'([^']+)"
    aResult = re.findall(sPattern, sHtmlContent)
    if aResult:
        oRequestHandler = cRequestHandler(aResult[0])
        oRequestHandler.request()
        sHosterUrl = oRequestHandler.getRealUrl()
        return sHosterUrl + '|referer=' + referer
    
    sPattern = r'<iframe.+?src=["\']([^"\']+)["\']'
    aResult = re.findall(sPattern, sHtmlContent)
    if aResult:
        for url in aResult:
            if url.startswith("./"):
                url = url[1:]
            if not url.startswith("http"):
                if not url.startswith("//"):
                    url = '//'+referer.split('/')[2] + '/' + url
                url = "https:" + url
            url = getHosterIframe(url, referer)
            if url:
                return url

    sPattern = r'player.load\({source: (.+?)\('
    aResult = re.findall(sPattern, sHtmlContent)
    if aResult:
        func = aResult[0]
        sPattern = r'function %s\(\) +{\n + return\(\[([^\]]+)' % func
        aResult = re.findall(sPattern, sHtmlContent)
        if aResult:
            referer = url
            sHosterUrl = aResult[0].replace('"', '').replace(',', '').replace('\\', '').replace('////', '//')
            return sHosterUrl + '|referer=' + referer

    sPattern = r';var.+?src=["\']([^"\']+)["\']'
    aResult = re.findall(sPattern, sHtmlContent)
    if aResult:
        url = aResult[0]
        if '.m3u8' in url:
            return url + '|referer=' + referer

    sPattern = r'[^/]source.+?["\'](https.+?)\\?["\']'
    aResult = re.findall(sPattern, sHtmlContent)
    if aResult:
        for sHosterUrl in aResult:
            if '.m3u8' in sHosterUrl:
                if 'fls/cdn/' in sHosterUrl:
                    sHosterUrl = sHosterUrl.replace('/playlist.', '/tracks-v1a1/mono.')
                else:
                    oRequestHandler = cRequestHandler(sHosterUrl)
                    oRequestHandler.addHeaderEntry('Referer', referer)
                    oRequestHandler.request()
                    sHosterUrl = oRequestHandler.getRealUrl()
                    return sHosterUrl + '|referer=' + referer

    sPattern = r'file|src: *["\'](https.+?\.m3u8(\?.+?=.+?)?)["\']'
    aResult = re.findall(sPattern, sHtmlContent)
    if aResult:
        oRequestHandler = cRequestHandler(aResult[0][0])
        oRequestHandler.request()
        sHosterUrl = oRequestHandler.getRealUrl()
        return sHosterUrl + '|referer=' + referer
    
    sPattern = r'"streamurl":"(https.+?\.m3u8)["\']'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        link = aResult[1][0]
        return link + '|referer=' + referer
    
    sPattern = r'https://(.+?\.xyz)/mono.php\?id=([0-9]+)'
    result = re.findall(sPattern, referer)
    hostname = None
    if result:
        hostname = result[0][0]
        id = result[0][1]
        channelKey = "mono" + id
        newUrl = 'new.newkso.ru'
    else: 
        sPattern = r'var channelKey = "([^"]+)";'
        result = re.findall(sPattern, sHtmlContent)
        if result:
            hostname = urlHostName(referer)
            channelKey = result[0]
            sPattern = r'(new\.[^\.]+\.ru)'
            newUrl = re.findall(sPattern, sHtmlContent)
            if newUrl:
                newUrl = newUrl[0]
    if hostname:
        referer = 'https://' + hostname + '/server_lookup.php?channel_id=' + channelKey
        oRequestHandler = cRequestHandler(referer)
        response = oRequestHandler.request(jsonDecode=True)
        serverKey = response['server_key']
        sHosterUrl = 'https://%s%s/%s/%s/mono.m3u8|Referer=%s' % (serverKey, newUrl, serverKey, channelKey, referer)
        return sHosterUrl
    
    
    return False

def reveal_pipe_split(html):
    pattern = r"return p\}(\(.*),'(.*?)'.split\('\|'\)"
    html = html.replace('\\', '')
    results = re.findall(pattern, html)
    
    if not results:
        return
    
    def is_numeric_mode():
        for char in list('abcdefghij'):
            if not re.search(r"\b{}\b".format(char), html):
                return True
        return False
    
    numeric_mode = is_numeric_mode()

    def tokenToInt(token):
        if numeric_mode:
            return int(token)
        if token.isalpha() and not token.isupper():
            return ord(token) - 87   
        elif token.isupper():
            return ord(token) - 29 
        elif len(token) == 1: 
            return int(token)
        return int(token) + 52 
    
    def replaceNumber(match):
        token = match.group(0)
        num = tokenToInt(token)

        if num < len(keywords):
            if keywords[num]:
                return keywords[num]
            else:
                return token
        return token
    
    text = ''
    for result in results:
        mask = result[0]
        keywords = result[1].split('|')
        text += re.sub(r'([0-9a-zA-Z]+)',replaceNumber, mask)
    return text