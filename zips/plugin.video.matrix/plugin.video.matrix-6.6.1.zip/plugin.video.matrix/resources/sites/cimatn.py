﻿#-*- coding: utf-8 -*-

import re, json
import base64
import urllib.parse
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, siteManager, addon, VSlog
from resources.lib.parser import cParser
from resources.lib.util import cUtil

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0'
 
SITE_IDENTIFIER = 'cimatn'
SITE_NAME = 'CimaTN'
SITE_DESC = 'arabic vod'
 
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

MOVIE_AR = (f'{URL_MAIN}/search/label/أفلام%20تونسية', 'showMovies')
SERIE_AR = (f'{URL_MAIN}/search/label/مسلسلات%20تونسية', 'showSeries')
RAMADAN_SERIES = (f'{URL_MAIN}/search/label/%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA%20%D8%B1%D9%85%D8%B6%D8%A7%D9%86', 'showSeries')

URL_SEARCH = (f'{URL_MAIN}search?q=', 'showMovies')
URL_SEARCH_MOVIES = (f'{URL_MAIN}search?q=', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}search?q=', 'showSeries')
FUNCTION_SEARCH = 'showMovies'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام تونسية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', RAMADAN_SERIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات رمضان', 'rmdn.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات تونسية', 'arab.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()
 
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search?q={sSearchText}'
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return	

def showSeriesSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search?q={sSearchText}'
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showMovies(sSearch = ''):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()

    if sSearch:
        sUrl = sSearch
    else:
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request()
    
    sPattern = r"itempost'\s*href='([^']+)'.+?src='([^']+)'.+?class='entry-label'>(.+?)</span>.+?id='item-name'>(.+?)</p>"
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            sTitle = (cUtil().CleanMovieName(aEntry[3])).replace('Film ','').replace('تونسي ','')
            siteUrl = aEntry[0]
            sThumb = aEntry[1]
            sDesc = aEntry[3]
            sYear = aEntry[2]

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear) 
            
            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
    if not sSearch:
        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
        oGui.setEndOfDirectory()

def showSeries(sSearch = ''):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    if sSearch:
        sUrl = sSearch
    else:
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request()

    sPattern = r"itempost'\s*href='([^']+)'.+?src='([^']+)'.+?class='entry-label'>(.+?)</span>.+?id='item-name'>(.+?)</p>"
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
           
            sTitle = cUtil().CleanSeriesName(aEntry[3])
            siteUrl = aEntry[0]
            sThumb = aEntry[1]
            sDesc = aEntry[3]
            sYear = aEntry[2]

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear) 
               
            oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
  
    if not sSearch:
        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()

def showSeasons():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    oOutputParameterHandler = cOutputParameterHandler()

    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler_html = cRequestHandler(sUrl)
    oRequestHandler_html.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler_html.request()

    slug_pattern = r'const\s+watchPageSlug\s*=\s*"([^"]+)"'
    try:
        slug = re.search(slug_pattern, sHtmlContent).group(1)
    except Exception as e:
        slug = ''

    if slug and slug != 'el-balas':
        sPattern = r'feedUrl\s*=\s*["\`]([^"\`]+)["\`]'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            for aEntry in aResult[1]:
                feed_path = aEntry
                if "${" in feed_path:
                    siteUrl = sUrl
                    sMovieTitle = re.sub(r'\s\d+\s', ' ', sMovieTitle).strip()
                    if not re.search(r'[Ss]\d+', sMovieTitle):
                        sMovieTitle += " S1"
                    oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                    oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
                    oOutputParameterHandler.addParameter('sThumb', sThumb)

                    oGui.addSeason(SITE_IDENTIFIER,'showEpisodes', sMovieTitle, '', sThumb, '',  oOutputParameterHandler)
                else:
                    if not feed_path.startswith('/'):
                        feed_path = '/' + feed_path

                    fUrl = URL_MAIN.rstrip('/') + feed_path

                    oRequestHandler = cRequestHandler(fUrl)
                    oRequestHandler.addHeaderEntry('User-Agent', UA)
                    jsonp_text = oRequestHandler.request()

                    json_start = jsonp_text.find('{')
                    json_end = jsonp_text.rfind('}') + 1
                    json_data = json.loads(jsonp_text[json_start:json_end])

                    entries = json_data.get("feed", {}).get("entry", []) or []
                    for entry in entries:
                        link = next((l.get("href", "") for l in entry.get("link", []) if l.get("rel") == "alternate"), "")
                        thumbnail = entry.get("media$thumbnail", {}).get("url", "")
                        thumbnail = thumbnail.replace("/s72-c/", "/w250/") if thumbnail else ""

                        sTitle = (cUtil().ConvertSeasons(entry.get("title", {}).get("$t", "")).strip())
                        siteUrl = link

                        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                        oOutputParameterHandler.addParameter('sThumb', thumbnail or sThumb)
                        oOutputParameterHandler.addParameter('sReferer', sUrl)

                        oGui.addSeason(SITE_IDENTIFIER,'showEpisodes', sTitle, '', thumbnail or sThumb, '', oOutputParameterHandler)

    else:
        siteUrl = sUrl
        sMovieTitle = re.sub(r'\s\d+\s', ' ', sMovieTitle).strip()
        if not re.search(r'[Ss]\d+', sMovieTitle):
            sMovieTitle += " S1"
        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)

        oGui.addSeason(SITE_IDENTIFIER,'showEpisodes', sMovieTitle, '', sThumb, '',  oOutputParameterHandler)


    oGui.setEndOfDirectory()

def showEpisodes():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    oOutputParameterHandler = cOutputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'const\s+feedUrl\s*=\s*`([^`]+)`'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        feed_path = aResult[1][0]
        if feed_path.startswith('/'):
            feed_path = URL_MAIN[:-1] + feed_path
    else:
        feed_path = None

    base_title_pattern = r'const\s+baseTitle\s*=\s*"([^"]+)"'
    image_url_pattern = r'const\s+imageURL\s*=\s*"([^"]+)"'
    slug_pattern = r'const\s+watchPageSlug\s*=\s*"([^"]+)"'
    episodes_pattern = r'const\s+totalEpisodes\s*=\s*(\d+)'
    try:
        base_title = re.search(base_title_pattern, sHtmlContent).group(1)
        sThumb = re.search(image_url_pattern, sHtmlContent).group(1)
        slug = re.search(slug_pattern, sHtmlContent).group(1)
        episodes = re.search(episodes_pattern, sHtmlContent).group(1)

        watch_page_slug = slug 
        total_episodes = episodes     
    except Exception as e:
        VSlog("Error extracting episode details:", e)
        watch_page_slug = None
        total_episodes = None

    if watch_page_slug:
        watch_page_url = find_watch_page(feed_path, watch_page_slug, total_episodes)

        for i in range(1, int(total_episodes) + 1):
            episode_url = f"{watch_page_url}?episode={i}"
            sTitle = f"{sMovieTitle} E{i}"

            oOutputParameterHandler.addParameter('siteUrl', episode_url)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sType', 'Episode')
            oOutputParameterHandler.addParameter('sEnumber', i)
                
            oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, '', oOutputParameterHandler)       

    else:

        def extract_episode_number(url: str) -> int:
            sPattern = r'epSlugBase:\s*["\']([^"\']+)["\']'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                base = aResult[1][0]

            sPattern = r'allowOptionalElPrefix:\s*(true|false)'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                allowOptionalElPrefix = aResult[1][0]

            if allowOptionalElPrefix == 'true':
                pattern = re.compile(rf"(?:el-)?{base}(\d+)", re.I)
            else:
                pattern = re.compile(rf"{base}(\d+)", re.I)
            m = pattern.search(url)
            return int(m.group(1)) if m else 0

        def is_episode_url(url: str) -> bool:
            sPattern = r'epSlugBase:\s*["\']([^"\']+)["\']'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                base = aResult[1][0]

            sPattern = r'allowOptionalElPrefix:\s*(true|false)'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                allowOptionalElPrefix = aResult[1][0]

            if allowOptionalElPrefix == 'true':
                pattern = re.compile(rf"(?:^|/)(?:el-)?{base}\d+", re.I)
            else:
                pattern = re.compile(rf"(?:^|/){base}\d+", re.I)
            return bool(pattern.search(url))

        def fetch_all_episode_pages():
            sPattern = r'\bmaxResults\s*=\s*(\d+)'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                max_results = aResult[1][0]

            sPattern = r'\bstartIndex\s*=\s*(\d+)'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                start_index = aResult[1][0]

            sPattern = r'\bhasMore\s*=\s*(true|false)'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                has_more = aResult[1][0]
            else:
                has_more = False
            map_by_number = {}

            while has_more:
                try:
                    oRequestHandler = cRequestHandler(feed_path.replace("${startIndex}", str(start_index)).replace("${maxResults}", str(max_results)))
                    oRequestHandler.addHeaderEntry('User-Agent', UA)
                    data = oRequestHandler.request(jsonDecode=True)
                    
                except Exception:
                    break

                entries = data.get("feed", {}).get("entry", [])
                if not entries:
                    break

                for entry in entries:
                    alt_link = next((l for l in entry.get("link", []) if l.get("rel") == "alternate" and l.get("type") == "text/html"), None)
                    if not alt_link:
                        continue
                    url = alt_link["href"]
                    if not is_episode_url(url):
                        continue
                    num = extract_episode_number(url)
                    if not num:
                        continue
                    if num not in map_by_number:
                        map_by_number[num] = url

                start_index += max_results
                has_more = len(entries) == max_results

            episode_links = [{"number": n, "url": u} for n, u in sorted(map_by_number.items())]
            return episode_links

        episodes = fetch_all_episode_pages()
        for ep in episodes:
            sTitle = f"{sMovieTitle} E{ep['number']}"
            oOutputParameterHandler.addParameter('siteUrl', ep['url'])
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sType', 'Any')
            oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, '', oOutputParameterHandler)

        pattern = r'link\.match\(/(.+?)/\);'
        match = re.search(pattern, sHtmlContent)
        if match:
            regex_inner = match.group(1)
            episode_pattern = re.compile(regex_inner)
        else:
            episode_pattern = re.compile(r'-(\d+)\.html$')

        if feed_path:
            feed_url = (
                feed_path
                .replace("${startIndex}", str(1))
                .replace("${maxResults}", str(50))
            )
        
            includes_pattern = r"includes\(\s*['\"]([^'\"]+)['\"]\s*\)"
            keywords = re.findall(includes_pattern, sHtmlContent)

            oRequestHandler = cRequestHandler(feed_url)
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            jsonp_text = oRequestHandler.request()

            json_start = jsonp_text.find('{')
            json_end = jsonp_text.rfind('}') + 1
            data = json.loads(jsonp_text[json_start:json_end])

            entries = data.get("feed", {}).get("entry", [])
            episode_links = []

            if entries:
                for entry in entries:
                    page_url = next((l["href"] for l in entry.get("link", []) if l.get("rel") == "alternate"), None)
                    if not page_url:
                        continue
                    if any(k in page_url for k in keywords):
                        episode_links.append(page_url)

            episode_numbers = []
            for link in episode_links:
                m = episode_pattern.search(link)
                if m:
                    episode_numbers.append(int(m.group(1)))
                else:
                    m2 = re.search(r'-(\d+)\.html$', link)
                    if m2:
                        episode_numbers.append(int(m2.group(1)))

            if episode_numbers:
                last_episode = max(episode_numbers)
                base_url = re.sub(r'-\d+\.html$', '', episode_links[0])
                all_episode_links = [f"{base_url}-{i}.html" for i in range(1, last_episode + 1)]

                for idx, link in enumerate(all_episode_links, start=1):
                    sTitle = f"{sMovieTitle} E{idx}"
                    oOutputParameterHandler.addParameter('siteUrl', link)
                    oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                    oOutputParameterHandler.addParameter('sThumb', sThumb)
                    oOutputParameterHandler.addParameter('sType', 'Episode2')
                    oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, '', oOutputParameterHandler)

    patterns = {
        "episodeSlug": r'const\s+episodeSlug\s*=\s*"([^"]+)"',
        "totalEpisodes": r'const\s+totalEpisodes\s*=\s*(\d+)'
    }

    config = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, sHtmlContent)
        if match:
            config[key] = match.group(1)
            
    if "episodeSlug" in config and "totalEpisodes" in config:
        config["totalEpisodes"] = int(config["totalEpisodes"])

        episodes = []
        for i in range(1, config["totalEpisodes"] + 1):
            episode_url = f"{config['episodeSlug']}{i}.html"
            encoded = encode_url(episode_url)
            decoded = decode_url(encoded)
            episodes.append({"number": i, "url": f'{URL_MAIN[:-1]}{decoded}'})

        for ep in episodes:
            sTitle = f"{sMovieTitle} E{ep['number']}"
            oOutputParameterHandler.addParameter('siteUrl', ep['url'])
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sType', 'Any')
            oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()
	 
def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sType = oInputParameterHandler.getValue('sType')
    sEnumber = oInputParameterHandler.getValue('sEnumber')
    
    oParser = cParser()    
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request()

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    if sType == 'Episode':
        sPattern = r'const\s+seriesData\s*=\s*({.*?});'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            series_block = aResult[1][0]

            ep_pattern = rf'{sEnumber}\s*:\s*\[(.*?)\]'
            ep_match = re.search(ep_pattern, series_block, re.DOTALL)
            if ep_match:
                ep_block = ep_match.group(1)

                watch_links = re.findall(r'name:\s*[\'"]([^\'"]+)[\'"]\s*,\s*url:\s*[\'"]([^\'"]+)[\'"]', ep_block)
                for name, url in watch_links:
                    if url.startswith('//'):
                        url = f'http:{url}'

                    sHosterUrl = url
                    results.append((name, sHosterUrl))

            dl_pattern = rf'{sEnumber}\s*:\s*[\'"]([^\'"]+)[\'"]'
            dl_match = re.search(dl_pattern, series_block)
            if dl_match:
                url = dl_match.group(1)
                if url.startswith('//'):
                    url = f'http:{url}'

                sHosterUrl = url
                results.append((SITE_NAME, sHosterUrl))

    if sType != 'Episode2':
            nUrl = fetch_movie_watch_url(sHtmlContent)
            if nUrl:
                if nUrl.startswith('/'):
                    nUrl = URL_MAIN[:-1] + nUrl
                oRequestHandler = cRequestHandler(nUrl)
                oRequestHandler.addHeaderEntry('Referer', sUrl)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                sHtmlContent = oRequestHandler.request()

                sPattern = r",\s*url:\s*'([^']+)'"
                aResult = oParser.parse(sHtmlContent, sPattern)	
                if aResult[0]:
                    for aEntry in aResult[1]:

                        url = str(aEntry)
                        if url.startswith('//'):
                            url = f'http:{url}'

                        sHosterUrl = url
                        results.append((SITE_NAME, sHosterUrl))

    if not results:
        watch_links = re.findall(r'name:\s*[\'"]([^\'"]+)[\'"]\s*,\s*url:\s*[\'"]([^\'"]+)[\'"]', sHtmlContent)
        for name, url in watch_links:
            if url.startswith('//'):
                url = f'http:{url}'

            sHosterUrl = url
            results.append((name, sHosterUrl))

    if useDialog and results:
        cHosterGui().selectHoster(results, sMovieTitle, SITE_NAME, sThumb)
    else:
        for sTitle, sHosterUrl in results:
            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

        oGui.setEndOfDirectory()

def __checkForNextPage(sHtmlContent):
    oParser = cParser()
    sPattern = r"older-link'\s*href='([^']+)'"
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        return aResult[1][0]

    return False  

def encode_url(url: str) -> str:
    encoded = base64.b64encode(urllib.parse.quote(url).encode()).decode()
    encoded = encoded[::-1]
    return "X" + encoded + "Z"

def decode_url(encoded: str) -> str:
    try:
        clean = encoded[1:-1][::-1]
        decoded = base64.b64decode(clean).decode()
        return urllib.parse.unquote(decoded)
    except Exception as e:
        print("URL decoding failed:", e)
        return "#"

def extract_feed_url_template(js_code: str) -> str:
    match = re.search(r'const\s+feedUrl\s*=\s*`([^`]+)`', js_code)
    if match:
        return match.group(1)

def extract_target_keyword(js_code: str) -> str:
    match = re.search(r"includes\('([^']+)'\)", js_code)
    if match:
        return match.group(1)

def fetch_movie_watch_url(js_code: str):
    feed_url_template = extract_feed_url_template(js_code)
    target_keyword = extract_target_keyword(js_code)

    start_index = 1
    max_results = 50
    has_more_data = True
    watch_url = None

    if feed_url_template:
        while has_more_data and not watch_url:
            feed_url = (
                feed_url_template
                .replace("${startIndex}", str(start_index))
                .replace("${maxResults}", str(max_results))
            )
            feed_url = feed_url.replace("json-in-script", "json").replace("&callback=processMoviePages", "")

            try:
                oRequestHandler = cRequestHandler(feed_url)
                oRequestHandler.addHeaderEntry('User-Agent', UA)
                data = oRequestHandler.request(jsonDecode=True)

                entries = data.get("feed", {}).get("entry", [])
                if entries:
                    for entry in entries:
                        links = entry.get("link", [])
                        for link in links:
                            if link.get("rel") == "alternate":
                                page_url = link.get("href")
                                if target_keyword in page_url:
                                    watch_url = page_url
                                    break
                    if not watch_url:
                        start_index += max_results
                    else:
                        has_more_data = False
                else:
                    has_more_data = False
            except Exception as e:
                print("Error fetching paginated pages:", e)
                has_more_data = False

    return watch_url

def find_watch_page(base_url, slug, total_episodes):

    start_index = 1
    max_results = int(total_episodes)

    while True:
        feed_url = (
            base_url
            .replace("${startIndex}", str(start_index))
            .replace("${maxResults}", str(max_results))
            .replace("&callback=processFoundouPages", "")
        )

        oRequestHandler = cRequestHandler(feed_url)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        jsonp_text = oRequestHandler.request()

        json_start = jsonp_text.find('{')
        json_end = jsonp_text.rfind('}') + 1
        data = json.loads(jsonp_text[json_start:json_end])

        entries = (data or {}).get("feed", {}).get("entry", [])
        if not entries:
            break

        for entry in entries:
            for link in entry.get("link", []):
                if link.get("rel") == "alternate" and slug in link.get("href", ""):
                    return link["href"]

        start_index += max_results

    return ""

