﻿# -*- coding: utf-8 -*-

import urllib.parse
import base64
import re, requests, time
import datetime
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, siteManager, addon
from resources.lib import random_ua

UA = random_ua.get_pc_ua()

SITE_IDENTIFIER = 'yallashoot'
SITE_NAME = 'Yallashoot'
SITE_DESC = 'Sports live'
 
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)
API_URL_MATCHES = 'https://ws.kora-api.space/'
API_POSTER_URL = 'https://cdn.kora-api.space/'
API_STREAM_URL = 'https://vsys.kora-top.zip/'

SPORT_LIVE = (f'{API_URL_MATCHES}api/matches/', 'showMovies')

def load():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()    
    oOutputParameterHandler.addParameter('siteUrl', SPORT_LIVE[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'بث مباشر', 'sport.png', oOutputParameterHandler)
   
    oGui.setEndOfDirectory()
	
    
def showMovies():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    dDate = datetime.date.today().isoformat()

    now = datetime.datetime.now()
    gmt_offset = datetime.timedelta(hours=3)
    gmt_time = now - gmt_offset
    time_str = gmt_time.strftime("%H%M")
    formatted = datetime.datetime.now().strftime("%Y%m%d%H%M")
    sUrl = f'{sUrl}{dDate}?t={time_str}'

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.enableCache(False)
    sHtmlContent2 = oRequestHandler.request(jsonDecode=True)

    for match in sHtmlContent2:
        oOutputParameterHandler = cOutputParameterHandler()
        if match['active'] == '0':
            continue

        sCondition = 'لم تبدأ'
        sDisplayTitle = sTitle =  f"{match['home']} vs {match['away']}"
        sThumb = f'{API_POSTER_URL}uploads/team/{match["home_logo"]}'
        siteUrl = "/"
        desc = f"{match['home_en']}-vs-{match['away_en']}".lower().replace(" ", "-")
        if match["has_channels"] == '1' and match["active"] == '1':
            sCondition = 'مباشر'
            sDisplayTitle = f'{sTitle} [COLOR red]● مباشر[/COLOR]'
            siteUrl = f"{API_URL_MATCHES}api/matche/{match['id']}/en?t={formatted}"
        sDesc = f'[COLOR orange]الدوري[/COLOR] \n {match["league"]} \n \n [COLOR orange]الوقت[/COLOR] \n {match["date"]} | {match["time"]}GMT \n \n [COLOR orange]حالة البث[/COLOR] \n {sCondition}'
        
        oOutputParameterHandler.addParameter('siteUrl',siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)

        oGui.addMisc(SITE_IDENTIFIER, 'showLinks', sDisplayTitle, 'foot.png', sThumb, sDesc, oOutputParameterHandler)
 
    oGui.setEndOfDirectory()
			
def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    try:
        if sUrl.startswith('/'):
            oGui.addText(SITE_IDENTIFIER, '[COLOR orange] تعذر الحصول على روابط [/COLOR]', 'none.png')  
        else:
            oRequestHandler = cRequestHandler(sUrl)
            oRequestHandler.enableCache(False)
            sHtmlContent = oRequestHandler.request(jsonDecode=True)
            
            result = extract_data(sHtmlContent)
            if result:
                    for ch, server_name, sLink in zip(result['ch'], result['server_name'], result["cLinks"]):

                        oOutputParameterHandler = cOutputParameterHandler()
                        token = generate_uuid()
                        timestamp = int(datetime.datetime.utcnow().timestamp())

                        sTitle = f'{sMovieTitle} [COLOR orange] {server_name} [/COLOR]'
                        sUrl = f"{API_STREAM_URL}frame.php?ch={ch}&p=12&token={token}&kt={timestamp}"

                        oOutputParameterHandler.addParameter('siteUrl', sUrl)
                        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                        oOutputParameterHandler.addParameter('sLink', sLink)
                        oOutputParameterHandler.addParameter('ch', ch)
                        oOutputParameterHandler.addParameter('sThumb', sThumb)

                        oGui.addMisc(SITE_IDENTIFIER, 'showHosters', sTitle, 'foot.png', sThumb, sTitle, oOutputParameterHandler)
    except:
        oGui.addText(SITE_IDENTIFIER, '[COLOR orange] تعذر الحصول على روابط [/COLOR]', 'none.png')        

    oGui.setEndOfDirectory()  

def showHosters():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    u_key = oInputParameterHandler.getValue('u_key')
    kt = oInputParameterHandler.getValue('kt')
    k_url = oInputParameterHandler.getValue('k_url')
    p = oInputParameterHandler.getValue('p')
    ch = oInputParameterHandler.getValue('ch')
    sLink = oInputParameterHandler.getValue('sLink')
    sThumb = oInputParameterHandler.getValue('sThumb')

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    headers = {
            "user-agent": UA,
            "referer": URL_MAIN
        }
    response = requests.get(sUrl, headers=headers).text


    token_pattern = r'var token = "(.*)";'
    token_match = re.search(token_pattern, response)
    if token_match:
        sHosterUrl = token_match.group(1)
        sHosterUrl = decode_token(sHosterUrl)
        sHosterUrl = f'{sHosterUrl}|Referer={sUrl.split("frame.php")[0]}'

    match = re.search(r'token:\s*"([^"]+)"', response)
    if match:
        base64_str = match.group(1)
        if base64_str.startswith('aHR'):
            sHosterUrl = safe_b64decode(base64_str)
        sHosterUrl = f'{sHosterUrl}|Referer={sUrl.split("frame.php")[0]}'
    
        if '/.m3u8' not in sHosterUrl:
            if useDialog:
                results.append((SITE_NAME, sHosterUrl, 'Dummy'))
            else:
                oHoster = cHosterGui().checkHoster(sHosterUrl)
                if oHoster:
                    oHoster.setDisplayName(sMovieTitle)
                    oHoster.setFileName(sMovieTitle)
                    cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)    
            
        else:
            from resources.sites.beinmatch import getHosterIframe

            sHosterUrl = sLink
            if '/share/' in sHosterUrl:
                response2 = requests.get(sHosterUrl, headers=headers).text
                match = re.search(r'url=([^">]+)', response2.replace('&quot;','"').replace("\\",''))
                if match:
                    sHosterUrl = match.group(1)
                    sHosterUrl = sHosterUrl.split('https://href.li/?', 1)[1] if sHosterUrl.split('https://href.li/?', 1)[1].startswith('http') else sHosterUrl
                    if 'streams.center' in sHosterUrl:
                        sHosterUrl = extract_streams_embed(sHosterUrl, user_agent=UA)

            if '?id=' in sHosterUrl:
                parsed_url = urllib.parse.urlparse(sHosterUrl)
                query_params = urllib.parse.parse_qs(parsed_url.query)
                base64_str = query_params.get('id', [''])[0]
                if base64_str.startswith('aHR'):
                    decoded_bytes = base64.b64decode(base64_str)
                    sHosterUrl = decoded_bytes.decode('utf-8') + f'|Referer={sLink}'

                    if useDialog:
                        results.append((SITE_NAME, sHosterUrl, 'direct_link'))
                    else:
                        oHoster = cHosterGui().getHoster('direct_link')
                        if oHoster:
                            oHoster.setDisplayName(sMovieTitle)
                            oHoster.setFileName(sMovieTitle)
                            cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)    

            elif 'https://href.li/?' in sHosterUrl:
                nUrl = sHosterUrl.split('https://href.li/?', 1)[1] if sHosterUrl.split('https://href.li/?', 1)[1].startswith('http') else sHosterUrl
                if nUrl.startswith('ttps://'):
                    nUrl = 'h' + nUrl

                sHosterUrl = getHosterIframe(nUrl, sHosterUrl)
                if sHosterUrl:
                    if '|' in sHosterUrl:
                        parts = sHosterUrl.split('|')
                        referer = next((p for p in reversed(parts) if p.lower().startswith('referer=')), '')
                        sHosterUrl = '|'.join([p for p in parts if not p.lower().startswith('referer=')] + [referer])

                if useDialog:
                    results.append((SITE_NAME, sHosterUrl, 'Dummy'))
                else:
                    oHoster = cHosterGui().checkHoster(sHosterUrl)
                    if oHoster:
                        oHoster.setDisplayName(sMovieTitle)
                        oHoster.setFileName(sMovieTitle)
                        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)    
            else:
                sgn = requests.Session()
                response3 = sgn.get(sHosterUrl, headers=headers)
                srefer = response3.url
                response3 = response3.text
                match = re.search(r'var source = "([^"]+)"', response3.replace('&quot;','"'))
                if match:
                    sHosterUrl = match.group(1)

                match = re.search(r'iframe src="([^"]+)"', response3.replace('&quot;','"'))
                if match:
                    nUrl = match.group(1)
                    if nUrl.startswith('//'):
                        nUrl = 'https:' + nUrl

                    headers = {
                            "user-agent": UA,
                            "referer": srefer
                        }
                    response4 = sgn.get(nUrl, headers=headers).text

                    sPattern = r'var src = "([^"]+)"'
                    aResult = re.findall(sPattern, response4)
                    if aResult:
                        sHosterUrl = f'{aResult[0]}|Referer={nUrl}&User-Agent={UA}'

                if useDialog:
                    results.append((SITE_NAME, sHosterUrl, 'direct_link'))
                else:
                    oHoster = cHosterGui().getHoster('direct_link')
                    if oHoster:
                        oHoster.setDisplayName(sMovieTitle)
                        oHoster.setFileName(sMovieTitle)
                        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)   

    if useDialog and results:
        if any(len(r) == 3 for r in results):
            for r in results:
                fixedHoster = r[2]
            select_results = [(r[0], r[1]) for r in results]
            cHosterGui().selectHoster(select_results, sMovieTitle, SITE_NAME, sThumb, fixedHoster=fixedHoster)

    else:
        oGui.setEndOfDirectory()  

def safe_b64decode(b64_str: str) -> str:
    b64_str = b64_str.strip()

    while len(b64_str) % 4 != 0:
        b64_str += "="

    decoded_bytes = base64.urlsafe_b64decode(b64_str)
    return decoded_bytes.decode("utf-8", errors="ignore")

def encode_token(data):
    encoded_str = urllib.parse.quote(str(data))
    replaced_str = ''.join(f'%{ord(char):02X}' for char in encoded_str)
    base64_bytes = base64.urlsafe_b64encode(replaced_str.replace('%', '').encode('latin-1'))
    base64_str = base64_bytes.decode('utf-8')
    
    return base64_str

def nowtime():
    current_timestamp = int(time.time())
    return current_timestamp

def get_current_minute():
    date = datetime.datetime.utcnow()
    hours = str(date.hour).zfill(2)
    minutes = str(date.minute).zfill(2)

    time = f"{hours}{minutes}"
    return time

def extract_data(html):
    data = {}

    sHtmlContent = html

    channels = sHtmlContent.get("channels", [])
    ch = []
    server = []
    cLinks = []
    for channel in channels:
        ch.append(channel.get("ch"))
        server.append(channel.get("server_name"))
        cLinks.append(channel.get("link"))
    data['ch'] = ch
    data['server_name'] = server
    data['cLinks'] = cLinks

    if not any(data.values()):
        return None

    return data

def decode_token(encoded_token):
    decoded_token = urllib.parse.unquote(base64.b64decode(encoded_token).decode('utf-8'))
    decoded_token = re.sub(r'(.{1,2})', r'%\1', decoded_token)
    return urllib.parse.unquote(decoded_token)

def generate_uuid():
    import random
    timestamp = int(time.time() * 1000)
    template = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'

    def replace(match):
        nonlocal timestamp
        random_number = int((timestamp + random.random() * 16) % 16)
        timestamp //= 16
        return hex(random_number if match.group(0) == 'x' else (random_number & 0x3) | 0x8)[2:]

    uuid = re.sub(r'[xy]', replace, template)
    return uuid

def extract_streams_embed(embed_url: str, user_agent: str = "Mozilla/5.0", timeout: int = 10):
    headers = {
        "User-Agent": user_agent,
        "Referer": "https://streams.center/",
        "Origin": "https://streams.center"
    }

    if not re.search(r"streams\.center/embed/", embed_url):
        return None

    try:
        r = requests.get(embed_url, headers=headers, timeout=timeout)
        iframe_match = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', r.text, re.IGNORECASE)
        if not iframe_match:
            return None

        iframe_url = iframe_match.group(1)
        if not iframe_url.startswith("http"):
            if iframe_url.startswith("//"):
                iframe_url = "https:" + iframe_url
            elif iframe_url.startswith("/"):
                iframe_url = "https://streams.center" + iframe_url
            else:
                iframe_url = "https://streams.center/" + iframe_url

        headers["Referer"] = embed_url
        r_iframe = requests.get(iframe_url, headers=headers, timeout=timeout)

        input_patterns = [
            r'(?:var\s+)?input\s*[=:]\s*["\']([^"\']+)["\']',
            r'data-input=["\']([^"\']+)["\']',
            r'input:\s*["\']([^"\']+)["\']'
        ]
        payload = None
        for pattern in input_patterns:
            m = re.search(pattern, r_iframe.text, re.IGNORECASE)
            if m:
                payload = m.group(1)
                break

        if not payload:
            m3u8_match = re.search(r'https?://[^\s\'"]+\.m3u8[^\s\'"]*', r_iframe.text, re.IGNORECASE)
            if m3u8_match:
                return f"{m3u8_match.group(1)}|Referer={embed_url}&User-Agent={user_agent}"
            return None

        decrypt_url = "https://streams.center/embed/decrypt.php"
        post_headers = headers.copy()
        post_headers.update({
            "Content-Type": "application/x-www-form-urlencoded",
            "X-Requested-With": "XMLHttpRequest"
        })
        r_decrypt = requests.post(decrypt_url, data={"input": payload}, headers=post_headers, timeout=timeout)
        decrypted = r_decrypt.text.strip()

        m3u8_match = re.search(r'(https?://[^\s\'"]+\.m3u8[^\s\'"]*)', decrypted, re.IGNORECASE)
        if m3u8_match:
            return f"{m3u8_match.group(1)}|Referer={embed_url}&User-Agent={user_agent}"

        stream_match = re.search(r'stream=([a-z0-9]+)', decrypted)
        if stream_match:
            m3u8_url = f"https://edgestreams.pro/hls/{stream_match.group(1)}.m3u8"
            return f"{m3u8_url}|Referer={embed_url}&User-Agent={user_agent}"

        return None

    except Exception:
        return None
