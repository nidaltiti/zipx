﻿# -*- coding: utf-8 -*-

import json
from urllib.parse import quote
import re	
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, VSlog, siteManager, addon
from resources.lib.util import cUtil
from resources.lib.parser import cParser
from resources.lib import random_ua
 
SITE_IDENTIFIER = 'cinemana'
SITE_NAME = 'Cinemana'
SITE_DESC = 'arabic vod'

UA = random_ua.get_ua()

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

MOVIE_EN = (f'{URL_MAIN}movies/', 'showMovies')

SERIE_EN = (f'{URL_MAIN}watch=category/مسلسلات-أجنبي/', 'showSeries')
SERIE_AR = (f'{URL_MAIN}watch=category/مسلسلات-عربية/', 'showSeries')
SERIE_TR = (f'{URL_MAIN}watch=category/مسلسلات-تركية/', 'showSeries')
SERIE_HEND = (f'{URL_MAIN}watch=category/مسلسلات-هندية/', 'showSeries')

ANIM_NEWS = (f'{URL_MAIN}عالم-الأنمي/', 'showSeries')

URL_SEARCH = (f'{URL_MAIN}?s=', 'showSeries')
URL_SEARCH_MOVIES = (f'{URL_MAIN}?s=', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}?s=', 'showSeries')
FUNCTION_SEARCH = 'showSearch'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_TR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات تركية', 'turk.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_HEND[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات هندية', 'hend.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات انمي', 'anime.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()
 
def showSeriesSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}?s={sSearchText}'
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}?s={sSearchText}&type=1'
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return

def showMovies(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
        sPattern = r'<div class="cn-grid-item w-full">\s+<a href="([^"]+)".+?url\([\'"]?(https?://[^\'")]+)[\'"]?\).+?<h3 .*?">(.+?)</h3>'

    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        sPattern = r'<div class="group relative.+?href="([^"]+)".+?url\([\'"]?(https?://[^\'")]+)[\'"]?\).+?<h3 .*?">(.+?)</h3>'

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request()

    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0] :
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            if any(keyword in aEntry[2] for keyword in ["مسلسل", "حلقة", "موسم"]):
                continue
            
            sTitle = cUtil().CleanMovieName(aEntry[2])
            siteUrl = aEntry[0]
            sThumb = aEntry[1]
            sDesc = ''
            sYear = ''
            m = re.search(r'([0-9]{4})', aEntry[2])
            if m:
                sYear = str(m.group(0))
                if 'عرض' in sTitle:
                    sTitle = sTitle.replace('عرض','')

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)

            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
    if not sSearch:
        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
            
        oGui.setEndOfDirectory()

def showSeries(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
        sPattern = r'<div class="cn-grid-item w-full">\s+<a href="([^"]+)".+?url\([\'"]?(https?://[^\'")]+)[\'"]?\).+?<h3 .*?">(.+?)</h3>'

    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        sPattern = r'<div class="group relative.+?href="([^"]+)".+?url\([\'"]?(https?://[^\'")]+)[\'"]?\).+?<h3 .*?">(.+?)</h3>'

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request()

    aResult = oParser.parse(sHtmlContent, sPattern)
    itemList = []
    if aResult[0] :
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break

            if any(keyword in aEntry[2] for keyword in ["فلم", "فيلم", "movie"]):
                continue

            siteUrl = aEntry[0]           
            sTitle = cUtil().CleanSeriesName(aEntry[2])
            sThumb = aEntry[1]
            sDesc = ''
            sYear = ''
            m = re.search(r'([0-9]{4})', aEntry[2])
            if m:
                sYear = str(m.group(0))

            if sTitle not in itemList:
                itemList.append(sTitle)			
                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sYear', sYear)
                oOutputParameterHandler.addParameter('sThumb', sThumb)

                if any(keyword in aEntry[2] for keyword in ["فلم", "فيلم", "movie"]):
                    oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
                else:
                    oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
 
        progress_.VSclose(progress_)
        
    if not sSearch:
        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()

def showSeasons():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'data-target="([^"]+)".+?class=".*?">(.+?)</button>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:

            sSeason = (cUtil().ConvertSeasons(aEntry[1])).strip()
            sSeasonTXT = aEntry[0]
            sTitle = re.sub(r"S\d{2}|S\d", "", sMovieTitle)
            sTitle = f'{sTitle} {sSeason}'

            oOutputParameterHandler.addParameter('siteUrl', f'{sUrl}|season={sSeasonTXT}')
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sSeason', sSeason)
            oOutputParameterHandler.addParameter('sSeasonTXT', sSeasonTXT)
 
            oGui.addSeason(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, '', oOutputParameterHandler)

    else:
        sPattern = r'<a href="([^"]+)" class=".*?">\s+<span class=".*?">EP</span>\s+<span class=".*?">(.+?)</span>' 
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            oOutputParameterHandler = cOutputParameterHandler()    
            for aEntry in aResult[1]:
    
                sEp = str(m.group(1)) if (m := re.search(r"EP\s*(\d+)", aEntry[1])) else None
                sSeason = str(m.group(1)) if (m := re.search(r"S\s*(\d+)", aEntry[1])) else '01'
                sTitle = re.sub(r"S\d{2}|S\d", "", sMovieTitle)
                sTitle = f'{sTitle} S{sSeason.strip()} E{sEp.strip()}'
                siteUrl = aEntry[0]
                sThumb = sThumb
                sDesc = ''

                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)

                oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, sThumb, sThumb, sDesc, oOutputParameterHandler)
       
    oGui.setEndOfDirectory() 

def showEpisodes():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    sUrl, sSeasonTXT = sUrl.split('|season=')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = (oRequestHandler.request())

    sStart = '>الحلقات والمواسم<'
    sEnd = '</section>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'<div id="([^"]+)"\s+class="season-wrapper.*?">(.+?)</div>' 
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            sSeasonNo = aEntry[0].replace('ال','')
            sEplinks = aEntry[1]
            if sSeasonTXT == sSeasonNo or sSeasonTXT == aEntry[0]:
                sPattern = r'<a href="([^"]+)".+?>EP</span>\s+<span class=".*?">(.+?)</span>' 
                aResult = oParser.parse(sEplinks, sPattern)
                if aResult[0]:
                    oOutputParameterHandler = cOutputParameterHandler()    
                    for aEntry in aResult[1]:
            
                        sEp = aEntry[1]
                        sTitle = f'{sMovieTitle} E{sEp}'
                        siteUrl = aEntry[0]
                        sThumb = sThumb
                        sDesc = ''

                        oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                        oOutputParameterHandler.addParameter('sThumb', sThumb)

                        oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, sThumb, sThumb, sDesc, oOutputParameterHandler)

    oGui.setEndOfDirectory() 

def __checkForNextPage(sHtmlContent):
    oParser = cParser()
    sPattern = r'next page-numbers" href="([^"]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        sNext = aResult[1][0]
        if 'http' not in sNext:
            sNext = URL_MAIN + aResult[1][0]
        return sNext

    return False

def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request()

    useDialog = addon().getSetting('HosterDialog') == 'true'
    results = []

    sPattern = r'<button id="like-btn"\s+data-id="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    sId = aResult[1][0] if aResult[0] else ''

    sPattern = r'data-server="([^"]+)">(.+?)</li>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        for Serv, sHost in aResult[1]:
            sTitle = f'{sMovieTitle} [COLOR coral]{sHost}[/COLOR]'
            if useDialog:
                qualityResults = resolveHosterUrls(sUrl, sId, Serv, sMovieTitle)
                results.extend(qualityResults)
            else:
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sUrl)
                oOutputParameterHandler.addParameter('Serv', Serv)
                oOutputParameterHandler.addParameter('sId', sId)
                oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sHost', sHost)
                oGui.addLink(SITE_IDENTIFIER, 'showLinks', sTitle, sThumb, sTitle, oOutputParameterHandler)
    else:

        oRequestHandler = cRequestHandler(f'{URL_MAIN}wp-content/themes/EEE/Inc/Ajax/Single/Server.php')
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('Referer', sUrl)
        oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
        oRequestHandler.addParameters("post_id", sId)
        oRequestHandler.addParameters("server", 0)
        oRequestHandler.setRequestType(1)
        sHtmlContent = oRequestHandler.request()

        urls_match = re.search(r'const\s+originalUrls\s*=\s*(\{.*?\});', sHtmlContent, re.DOTALL)
        urls_dict = {}
        if urls_match:
            obj_text = urls_match.group(1)
            urls_dict = json.loads(obj_text)

        session_match = re.search(r'const\s+post_id\s*=\s*(\d+);', sHtmlContent)
        session_id = session_match.group(1) if session_match else None

        final_urls = {}
        if session_id:
            for quality, url in urls_dict.items():
                quoted = quote(url, safe="")
                final_urls = f"{URL_MAIN}stream.php?url={quoted}&session={session_id}"

                if useDialog:
                    results.append((quality, final_urls, 'direct_link'))
                else:
                    sDisplayTitle = f'{sMovieTitle} [COLOR orange] [{quality}p] [/COLOR]'
                    oHoster = cHosterGui().getHoster('direct_link')
                    if oHoster:
                        oHoster.setDisplayName(sDisplayTitle)
                        oHoster.setFileName(sMovieTitle)
                        cHosterGui().showHoster(oGui, oHoster, final_urls, sThumb)

    if useDialog and results:
        cHosterGui().selectHoster(results, sMovieTitle, SITE_NAME, sThumb)
    else:
        oGui.setEndOfDirectory()

def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    Serv = oInputParameterHandler.getValue('Serv')
    sId = oInputParameterHandler.getValue('sId')

    useDialog = addon().getSetting('HosterDialog') == 'true'

    qualityResults = resolveHosterUrls(sUrl, sId, Serv, sMovieTitle)

    if useDialog:
        if qualityResults:
            cHosterGui().selectHoster(qualityResults, sMovieTitle, SITE_NAME, sThumb)
    else:
        if qualityResults:
            for sTitle, sHosterUrl in qualityResults:
                oHoster = cHosterGui().checkHoster(sHosterUrl)
                if oHoster:
                    oHoster.setDisplayName(sTitle)
                    oHoster.setFileName(sMovieTitle)
                    cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)
        oGui.setEndOfDirectory()


def resolveHosterUrls(baseUrl, sId, Serv, sMovieTitle):
    oParser = cParser()
    urls = []

    oRequestHandler = cRequestHandler(f'{URL_MAIN}wp-content/themes/EEE/Inc/Ajax/Single/Server.php')
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Referer', baseUrl)
    oRequestHandler.addParameters('post_id', sId)
    oRequestHandler.addParameters('server', Serv)
    oRequestHandler.enableCache(False)
    oRequestHandler.setRequestType(1)
    sHtmlContent = oRequestHandler.request()

    ok, matches = oParser.parse(sHtmlContent, r'const originalUrls\s*=\s*\{([^}]+)\}')
    if ok and matches:
        block = matches[0]
        urlMatches = re.findall(r'"(\d+|auto)"\s*:\s*"([^"]+)"', block)
        for quality, url in urlMatches:
            if url.startswith('//'):
                url = f'http:{url}'
            url = url.replace(' ', '%20')
            if 'AKWAM' in url: 
                url += ('&' if '|' in url else '|') + 'AUTH=TLS&verifypeer=false'
            qTitle = f'{sMovieTitle} [COLOR coral]{quality}p[/COLOR]' if quality.isdigit() else f'{sMovieTitle} [COLOR coral]{quality}[/COLOR]'
            urls.append((qTitle, url))

    ok, matches = oParser.parse(sHtmlContent, r'<iframe.+?src=["\']([^"\']+)["\']')
    if ok and matches:
        sHosterUrl = matches[0]
        if sHosterUrl.startswith('//'):
            sHosterUrl = f'http:{sHosterUrl}'

        if URL_MAIN in sHosterUrl or 'cinemana' in sHosterUrl:
            nestedReq = cRequestHandler(sHosterUrl)
            nestedReq.addHeaderEntry('User-Agent', UA)
            nestedReq.addHeaderEntry('Referer', baseUrl)
            nestedReq.setTimeout(120)
            nestedHtml = nestedReq.request()

            ok2, srcMatches = oParser.parse(nestedHtml, r'source\s*src=["\']([^"\']+)["\']')
            if ok2 and srcMatches:
                sHosterUrl = f'{srcMatches[0]}|Referer={baseUrl}'
                if sHosterUrl.startswith('//'):
                    sHosterUrl = f'http:{sHosterUrl}'
            else:
                ok3, iframeMatches = oParser.parse(nestedHtml, r'iframe.+?src=["\']([^"\']+)["\']')
                if ok3 and iframeMatches:
                    sHosterUrl = iframeMatches[0]
                    if sHosterUrl.startswith('//'):
                        sHosterUrl = f'http:{sHosterUrl}'

        if 'userload' in sHosterUrl or 'mystream' in sHosterUrl:
            sHosterUrl = f'{sHosterUrl}|Referer={baseUrl}'
        if 'AKWAM' in sHosterUrl: 
            sHosterUrl += ('&' if '|' in sHosterUrl else '|') + 'AUTH=TLS&verifypeer=false'

        urls.append((sMovieTitle, sHosterUrl))

    return urls

