﻿# -*- coding: utf-8 -*-

import re
import json
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, VSlog, siteManager, addon
from resources.lib.parser import cParser
from resources.lib.util import Quote, cUtil, urlHostName, Unquote
from resources.lib import random_ua

UA = random_ua.get_pc_ua()

SITE_IDENTIFIER = 'stardima'
SITE_NAME = 'Stardima'
SITE_DESC = 'arabic vod'
 
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

KID_MOVIES = (f'{URL_MAIN}aflam', 'showMovies')
KID_CARTOON = (f'{URL_MAIN}mosalsalat', 'showSeries')

URL_SEARCH = (f'{URL_MAIN}search?query=', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}search?query=', 'showSeries')
FUNCTION_SEARCH = 'showSeries'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearchMovies', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearchSeries', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام', 'crtoon.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', KID_CARTOON[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات', 'crtoon.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSearchMovies():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search?query={sSearchText}'
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return

def showSearchSeries():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search?query={sSearchText}'
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return
  
def showMovies(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Referer', sUrl)
    oRequestHandler.addHeaderEntry('Host', urlHostName(URL_MAIN))
    oRequestHandler.addHeaderEntry('X-Requested-With', "XMLHttpRequest")
    sHtmlContent = oRequestHandler.request()

    try:
        data = json.loads(sHtmlContent)
        isJson = True
    except:
        isJson = False

    oOutputParameterHandler = cOutputParameterHandler()

    if isJson:
        videos = data.get("videos", [])
        total = len(videos)
        progress_ = progress().VScreate(SITE_NAME)

        for item in videos:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            
            if item.get("is_series", False):
                continue

            sTitle = cUtil().CleanMovieName(item.get("title", ""))
            siteUrl = item.get("url", "").replace('/movie/','/play/')
            sThumb = item.get("poster_url", "")
            if not sThumb.startswith('http'):
                sThumb = f'{URL_MAIN}storage/{sThumb}'
            sYear = item.get("year", "")
            sDesc = item.get("description", "")

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)
            oOutputParameterHandler.addParameter('sReferer', item.get("url", ""))

            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        pagination = data.get("pagination", {})
        current_page = pagination.get("current_page", 1)
        last_page = pagination.get("last_page", 1)
        if current_page < last_page:
            nextPageUrl = f"{sUrl.split('?page=')[0]}?page={current_page+1}"
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', nextPageUrl)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

        progress_.VSclose(progress_)

    else:
        oParser = cParser()
        sStart = '<div id="results-container">'
        sEnd = '<aside id="filter-sidebar"'
        sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

        sPattern = r'<img src="([^"]+)".+?href="([^"]+)".+?<p class=".*?">(.+?)</p>.+?title="([^"]+)"'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            total = len(aResult[1])
            progress_ = progress().VScreate(SITE_NAME)

            for aEntry in aResult[1]:
                progress_.VSupdate(progress_, total)
                if progress_.iscanceled():
                    break

                sTitle = cUtil().CleanMovieName(aEntry[3])
                siteUrl = aEntry[1]
                sThumb = re.sub(r'-\d*x\d*.', '.', aEntry[0])
                sYear = ''
                sDesc = aEntry[2]

                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sYear', sYear)
                oOutputParameterHandler.addParameter('sDesc', sDesc)

                oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

            sNextPage = __checkForNextPage(sUrl)
            if sNextPage:
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

            progress_.VSclose(progress_)

    if not sSearch:
        oGui.setEndOfDirectory()

			
def showSeries(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Referer', sUrl)
    oRequestHandler.addHeaderEntry('Host', urlHostName(URL_MAIN))
    oRequestHandler.addHeaderEntry('X-Requested-With', "XMLHttpRequest")
    sHtmlContent = oRequestHandler.request()

    try:
        data = json.loads(sHtmlContent)
        isJson = True
    except:
        isJson = False

    oOutputParameterHandler = cOutputParameterHandler()

    if isJson:
        videos = data.get("videos", [])
        total = len(videos)
        progress_ = progress().VScreate(SITE_NAME)

        for item in videos:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break

            if not item.get("is_series", False):
                continue

            sTitle = cUtil().CleanMovieName(item.get("title", ""))
            siteUrl = item.get("url", "")
            sThumb = item.get("poster_url", "")
            if not sThumb.startswith('http'):
                sThumb = f'{URL_MAIN}storage/{sThumb}'
            sYear = item.get("year", "")
            sDesc = item.get("description", "")

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)
            oOutputParameterHandler.addParameter('sReferer', item.get("url", ""))

            if '/play/' in siteUrl:
                oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
            else:
                oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        pagination = data.get("pagination", {})
        current_page = pagination.get("current_page", 1)
        last_page = pagination.get("last_page", 1)
        if current_page < last_page:
            nextPageUrl = f"{sUrl.split('?page=')[0]}?page={current_page+1}"
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', nextPageUrl)
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

        progress_.VSclose(progress_)

    else:
        oParser = cParser() 
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        sHtmlContent = oRequestHandler.request()

        sStart = '<div id="results-container">'
        sEnd = '<aside id="filter-sidebar"'
        sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

        sPattern = r'<img src="([^"]+)".+?href="([^"]+)".+?<p class=".*?">(.+?)</p>.+?title="([^"]+)"'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            total = len(aResult[1])
            progress_ = progress().VScreate(SITE_NAME)
            oOutputParameterHandler = cOutputParameterHandler()
            for aEntry in aResult[1]:
                progress_.VSupdate(progress_, total)
                if progress_.iscanceled():
                    break
    
                sTitle = (cUtil().CleanMovieName(aEntry[3])).replace("الحلقة "," E")
                siteUrl = aEntry[1]
                sThumb = aEntry[0]
                sThumb = re.sub(r'-\d*x\d*.','.', sThumb)
                sYear = ''
                sDesc = aEntry[2]

                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sYear', sYear)
                oOutputParameterHandler.addParameter('sDesc', sDesc)
                
                oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
    
            sNextPage = __checkForNextPage(sHtmlContent)
            if sNextPage:
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sNextPage)
                oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

            progress_.VSclose(progress_)
 
    if not sSearch:
        oGui.setEndOfDirectory()

def showSeasons():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sDesc = oInputParameterHandler.getValue('sDesc')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'<div class="flex items-center gap-3 pt-4 flex-wrap">\s*<a href="([^"]+)"' 
    aResult = oParser.parse(sHtmlContent,sPattern)
    if aResult[0]:
        nUrl = aResult[1][0]
        oRequestHandler = cRequestHandler(nUrl)
        oRequestHandler.addHeaderEntry('Referer', Quote(sUrl))
        sHtmlContent = oRequestHandler.request()
        sCookies = oRequestHandler.GetCookies()

    sPattern = r'data-season-id="([^"]+)"\s*data-season-number="([^"]+)">'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            sSeasonID = aEntry[0]
            sSeasonNO = aEntry[1]
            sSeason = sSeasonNO.replace("Season", "").strip()

            if sSeason.upper().startswith("S"):
                sTitle = f"{sMovieTitle} {sSeason}"
            else:
                sTitle = f"{sMovieTitle} S{sSeason}"

            siteUrl = f'{URL_MAIN}series/season/{sSeasonID}?X-Requested-With=XMLHttpRequest'
            sThumb = sThumb

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sDesc', sDesc)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sSeasonID', sSeasonID)
            oOutputParameterHandler.addParameter('sReferer', sUrl)
            oOutputParameterHandler.addParameter('sCookies', sCookies)
 
            oGui.addSeason(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
       
    oGui.setEndOfDirectory() 

def showEpisodes():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sSeasonID = oInputParameterHandler.getValue('sSeasonID')
    sCookies = oInputParameterHandler.getValue('sCookies')
    sReferer = oInputParameterHandler.getValue('sReferer')
    sDesc = oInputParameterHandler.getValue('sDesc')
    
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Referer', sReferer)
    oRequestHandler.addHeaderEntry('Cookie', sCookies)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    sEpisodesJson = sHtmlContent.get('episodes', '')
    for sEpi in sEpisodesJson:
        oOutputParameterHandler = cOutputParameterHandler()

        sEpisode = sEpi["episode_number"]
        sEpisodeID = sEpi["id"]
        sTitle = f'{sMovieTitle} E{sEpisode}'
        siteUrl = sEpi["watch_url"]
        sThumb =  sThumb
        sDesc = ''
        
        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sEpisodeID', sEpisodeID)
        oOutputParameterHandler.addParameter('sReferer', sReferer)

        oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
       
    oGui.setEndOfDirectory()
	
def __checkForNextPage(sUrl):
        return f'{sUrl}?page=2'

def showHosters():
    oGui = cGui()
    import time

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sEpisodeID = oInputParameterHandler.getValue('sEpisodeID')
    sReferer = oInputParameterHandler.getValue('sReferer')

    oParser = cParser() 

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    if not sEpisodeID:
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        sHtmlContent2 = oRequestHandler.request()
        sPattern = r'<iframe src="([^"]+)' 
        aResult = oParser.parse(sHtmlContent2,sPattern)
        if aResult[0]:              
            sUrl = aResult[1][0]
            if sUrl.startswith('//'):
                sUrl = f'https:{sUrl}'
            if not sUrl.startswith('http'):
                sPattern = r'"embedUrl":\s*"([^"]+)' 
                aResult = oParser.parse(sHtmlContent2,sPattern)
                if aResult[0]:            
                    sUrl = aResult[1][0]                
                
    sHosterUrl = sUrl
    if 'hyperwatching' in sUrl:
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('Referer', sReferer)
        sHtmlContent = oRequestHandler.request()  

        sPattern = r'id: ["\']([^"\']+)["\'],\s*name: ["\']([^"\']+)["\'],'
        aResult = oParser.parse(sHtmlContent,sPattern)
        if aResult[0]:
            oOutputParameterHandler = cOutputParameterHandler()
            for aEntry in aResult[1]: 
            
                sId = aEntry[0]
                sName = aEntry[1]
                if useDialog:
                    sFrame = sUrl.split("iframe/")[1]
                    time.sleep(1)
                    oRequestHandler = cRequestHandler(f'https://{urlHostName(sUrl)}/api/videos/{sFrame}/link')
                    oRequestHandler.addHeaderEntry('User-Agent', UA)
                    oRequestHandler.addHeaderEntry('Referer', sUrl)
                    oRequestHandler.addJSONEntry('server_link_id', sId)
                    oRequestHandler.setRequestType(1)
                    try:
                        sHtmlContent3 = oRequestHandler.request(jsonDecode=True)  
                    except:
                        sHtmlContent3 = {}
                    
                    try:
                        sHosterUrl = sHtmlContent3.get('watch_url', '')
                        if '?id=' in sHosterUrl:
                            sHosterUrl = Unquote(sHosterUrl.split('?id=')[1])
                        if '?url=' in sHosterUrl:
                            sHosterUrl = Unquote(sHosterUrl.split('?url=')[1])
                        results.append((sName, sHosterUrl))
                    except:
                        pass
                else:
                    sDisplayTitle = f'{sMovieTitle} [COLOR orange] - {sName}[/COLOR]'      
                    oOutputParameterHandler.addParameter('sHosterUrl', sHosterUrl)
                    oOutputParameterHandler.addParameter('sId', sId)
                    oOutputParameterHandler.addParameter('siteUrl', sUrl)
                    oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
                    oOutputParameterHandler.addParameter('sThumb', sThumb)

                    oGui.addLink(SITE_IDENTIFIER, 'showLinks', sDisplayTitle, sThumb, sDisplayTitle, oOutputParameterHandler)
    else:           
        if '?id=' in sHosterUrl:
            sHosterUrl = Unquote(sHosterUrl.split('?id=')[1])
        if '?url=' in sHosterUrl:
            sHosterUrl = Unquote(sHosterUrl.split('?url=')[1])
        results.append((SITE_NAME, sHosterUrl))

    if useDialog and results:
        cHosterGui().selectHoster(results, sMovieTitle, SITE_NAME, sThumb)
    else:
        for sTitle, sHosterUrl in results:
            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

        oGui.setEndOfDirectory()		

def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sHosterUrl = oInputParameterHandler.getValue('sHosterUrl')
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sId = oInputParameterHandler.getValue('sId')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    sFrame = sHosterUrl.split("iframe/")[1]
    oRequestHandler = cRequestHandler(f'https://{urlHostName(sHosterUrl)}/api/videos/{sFrame}/link')
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Referer', sHosterUrl)
    oRequestHandler.addJSONEntry('server_link_id', sId)
    oRequestHandler.setRequestType(1)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)  

    sHosterUrl = sHtmlContent['watch_url']
    if '?id=' in sHosterUrl:
        sHosterUrl = Unquote(sHosterUrl.split('?id=')[1])
    if '?url=' in sHosterUrl:
        sHosterUrl = Unquote(sHosterUrl.split('?url=')[1])

    oHoster = cHosterGui().checkHoster(sHosterUrl)
    if oHoster != False:
        oHoster.setDisplayName(sMovieTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()