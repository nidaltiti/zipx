#-*- coding: utf-8 -*-
import time
from resources.hosters.hoster import iHoster
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog
from resources.lib.util import urlHostName
from resources.lib import random_ua

UA = random_ua.get_phone_ua()

class cHoster(iHoster):
    def __init__(self):
        iHoster.__init__(self, 'vidara', 'Vidara')

    def isDownloadable(self):
        return False

    def setUrl(self, sUrl):
        self._url = str(sUrl)
        if '|Referer=' in self._url:
            self._url = self._url.split('|Referer=')[0].strip()
            VSlog('Hoster Vidara - setUrl : ' + self._url)

        if '/e/' in self._url or '/v/' in self._url:
            host = urlHostName(self._url)
            media_id = self._url.rsplit('/', 1)[-1]
            self._url = f'https://{host}/api/stream'
            self.media_id = media_id

    def _getMediaLinkForGuest(self, autoPlay=False):
        VSlog(self._url)

        oRequest = cRequestHandler(self._url)
        oRequest.addHeaderEntry('User-Agent', UA)
        oRequest.request()
        cookie = oRequest.GetCookies()
        
        time.sleep(1.5)

        oRequestHandler = cRequestHandler(self._url)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('Referer', f'https://{urlHostName(self._url)}/')
        oRequestHandler.addHeaderEntry('Accept', 'application/json')
        oRequestHandler.addHeaderEntry('Cookie', cookie)
        oRequestHandler.addHeaderEntry('Content-Type', 'application/json')
        oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
        oRequestHandler.addJSONEntry('filecode', self.media_id)
        oRequestHandler.addJSONEntry('device', "android")
        oRequestHandler.setRequestType(1)
        oRequestHandler.enableCache(False)
        try:
            sHtmlContent = oRequestHandler.request(jsonDecode=True)

        except Exception as e:
            oRequestHandler = cRequestHandler(self._url.replace('/api/stream', '/ajax/stream'))
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            oRequestHandler.addHeaderEntry('Referer', f'https://{urlHostName(self._url)}/')
            oRequestHandler.addHeaderEntry('Accept', 'application/json')
            oRequestHandler.addHeaderEntry('Cookie', cookie)
            oRequestHandler.addHeaderEntry('Content-Type', 'application/json')
            oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
            oRequestHandler.enableCache(False)
            oRequestHandler.addJSONEntry('filecode', self.media_id)
            oRequestHandler.addJSONEntry('device', "android")
            oRequestHandler.setRequestType(1)
            sHtmlContent = oRequestHandler.request(jsonDecode=True)

        api_call = sHtmlContent.get('streaming_url')
        if api_call:
            headers = f'|User-Agent={UA}&Referer=https://{urlHostName(self._url)}/&Origin=https://{urlHostName(self._url)}' + '&Cookie=' + cookie +'&Host=' + urlHostName(api_call) 
            return True, api_call + headers

        return False, False
