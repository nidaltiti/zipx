# -*- coding: utf-8 -*-

import json
import re, base64
from resources.lib.gui.hoster import cHosterGui
from resources.lib.util import urlHostName
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, siteManager, VSlog, addon
from resources.lib.parser import cParser
from resources.lib.util import cUtil
from resources.lib import random_ua

UA = random_ua.get_ua()
 
SITE_IDENTIFIER = 'wecima'
SITE_NAME = 'Wecima (مقلد)'
SITE_DESC = 'arabic vod'
 
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

MOVIE_TOP = (f'{URL_MAIN}movies/best/', 'showMovies')
MOVIE_POP = (f'{URL_MAIN}movies/top/', 'showMovies')
MOVIE_CLASSIC = (f'{URL_MAIN}movies/old/', 'showMovies')
MOVIE_FAM = (f'{URL_MAIN}mpaa/pg/', 'showMovies')
MOVIE_EN = (f'{URL_MAIN}category/foreign-movies', 'showMovies')
MOVIE_DUBBED = (f'{URL_MAIN}category/dubbed-movies', 'showMovies')
MOVIE_AR = (f'{URL_MAIN}category/arabic-movies', 'showMovies')
MOVIE_TURK = (f'{URL_MAIN}category/turkish-movies', 'showMovies')
MOVIE_HI = (f'{URL_MAIN}category/indian-movies', 'showMovies')
MOVIE_ASIAN = (f'{URL_MAIN}category/asian-movies', 'showMovies')
KID_MOVIES = (f'{URL_MAIN}category/anime-movies', 'showMovies')

RAMADAN_SERIES = (f'{URL_MAIN}category/ramadan-series-2026', 'showSeries')

SERIE_AR = (f'{URL_MAIN}category/arabic-series', 'showSeries')
SERIE_EN = (f'{URL_MAIN}category/foreign-series', 'showSeries')
SERIE_HEND = (f'{URL_MAIN}category/indian-series', 'showSeries')
ANIM_NEWS = (f'{URL_MAIN}category/anime-series', 'showSeries')
SERIE_ASIA = (f'{URL_MAIN}category/asian-series', 'showSeries')
SERIE_TR = (f'{URL_MAIN}category/turkish-series', 'showSeries')

SPORT_WWE = (f'{URL_MAIN}category/wwe-shows', 'showMovies')
REPLAYTV_NEWS = (f'{URL_MAIN}category/tv-shows', 'showMovies')

URL_SEARCH_MOVIES = ('', 'showMovies')
#URL_SEARCH_SERIES = (f'{URL_MAIN}', 'showSeries')
FUNCTION_SEARCH = 'showSearch'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    # oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    # oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', RAMADAN_SERIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات رمضان', 'rmdn.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام عربية', 'arab.png', oOutputParameterHandler)
 
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_TURK[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام تركية', 'turk.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_HI[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام هندية', 'hend.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام كرتون', 'crtoon.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_ASIA[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أسيوية', 'asia.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_TR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات تركية', 'turk.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_HEND[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات هندية', 'hend.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات انمي', 'anime.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SPORT_WWE[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'مصارعة', 'wwe.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', REPLAYTV_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'برامج تلفزيونية', 'brmg.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSeriesSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        showSeries(sSearchText)
        oGui.setEndOfDirectory()
        return
		
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        showMovies(sSearchText)
        oGui.setEndOfDirectory()
        return

def showMovies(sSearch = ''):
    oGui = cGui()
    if sSearch:
        oRequestHandler = cRequestHandler(f'https://{urlHostName(URL_MAIN)}/search')
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('Origin', f'https://{urlHostName(URL_MAIN)}')
        oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
        oRequestHandler.addParameters('q', sSearch)
        oRequestHandler.setRequestType(1)
        sHtmlContent = oRequestHandler.request()
        sHtmlContent = json.loads(sHtmlContent)

        for item in sHtmlContent.get("results", []):
            oOutputParameterHandler = cOutputParameterHandler()
            sTitle = cUtil().CleanMovieName(item.get("title"))
            sYear = item.get("year", "")
            siteUrl = item.get("slug", "")
            siteUrl = f'{URL_MAIN}watch/{siteUrl}'
            sThumb = item.get("image", "")

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)

            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, '', oOutputParameterHandler)

    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

        oParser = cParser()
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()

        sStart = 'class="Grid--WecimaPosts">'
        sEnd = '</wecima'
        sHtmlContent1 = oParser.abParse(sHtmlContent, sStart, sEnd)

        sPattern = r'class="Thumb--GridItem">\s*<a href="([^"]+)"\s*title="([^"]+)".+?data-src="([^"]+)".+?class="year">(.+?)</span>'
        aResult = oParser.parse(sHtmlContent1, sPattern)
        if aResult[0]:
            total = len(aResult[1])
            progress_ = progress().VScreate(SITE_NAME)
            oOutputParameterHandler = cOutputParameterHandler()
            for aEntry in aResult[1]:
                progress_.VSupdate(progress_, total)
                if progress_.iscanceled():
                    break
                if 'مواسم' in aEntry[1] or 'موسم' in aEntry[1] or 'حلقة' in aEntry[1]:
                    continue

                sTitle = cUtil().CleanMovieName(aEntry[1])
                siteUrl = aEntry[0].replace((aEntry[0].split('/watch/')[0]), URL_MAIN[:-1])
                sDesc = ''
                sThumb = aEntry[2]
                sYear = ''
                m = re.findall(r'\b([0-9]{4})\b', aEntry[3])
                if m:
                    sYear = m[-1]

                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sYear', sYear)
                oOutputParameterHandler.addParameter('sDesc', sDesc)

                oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
            
            progress_.VSclose(progress_)
 
    if not sSearch:
        sStart = '<div class="pagination">'
        sEnd = '<footer'
        sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

        sPattern = r'href="([^"]+)">(.+?)</a>'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            for aEntry in aResult[1]:

                sTitle = f'[COLOR red]Page: {aEntry[1]}[/COLOR]'
                siteUrl = f'{URL_MAIN[:-1]}{aEntry[0]}'

                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
			
                oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'next.png', oOutputParameterHandler) 
 
        oGui.setEndOfDirectory()

def showSeries(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
    
    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = 'class="Grid--WecimaPosts">'
    sEnd = '</wecima'
    sHtmlContent1 = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'class="Thumb--GridItem">\s*<a href="([^"]+)"\s*title="([^"]+)".+?data-src="([^"]+)".+?class="year">(.+?)</span>'
    aResult = oParser.parse(sHtmlContent1, sPattern)
    itemList = []	
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            if "فيلم"  in aEntry[1]:
                continue
 
            siteUrl = aEntry[0]
            sTitle = cUtil().CleanMovieName(aEntry[1])
            sThumb = aEntry[2]
            sDesc = ''
            sTitle = sTitle.split('موسم')[0].split('حلقة')[0]
            sYear = ''
            m = re.findall(r'\b([0-9]{4})\b', aEntry[1])
            if m:
                sYear = m[-1]

            if sTitle not in itemList:
                itemList.append(sTitle)	
                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sYear', sYear)
                oOutputParameterHandler.addParameter('sDesc', sDesc)
                oOutputParameterHandler.addParameter('sThumb', sThumb)

                oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)

    if not sSearch:
        sStart = '<div class="pagination">'
        sEnd = '<footer'
        sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

        sPattern = r'href="([^"]+)">(.+?)</a>'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            for aEntry in aResult[1]:

                sTitle =  f'[COLOR red]Page: {aEntry[1]}[/COLOR]'
                siteUrl = f'{URL_MAIN[:-1]}{aEntry[0]}'

                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
			
                oGui.addDir(SITE_IDENTIFIER, 'showSeries', sTitle, 'next.png', oOutputParameterHandler) 
 
        oGui.setEndOfDirectory()
  
def showSeasons():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sSeason = oInputParameterHandler.getValue('sSeason')
    sThumb = oInputParameterHandler.getValue('sThumb')

    if sSeason is False:
        sSeason = 'S1'

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'<div class="Seasons--Episodes">(.+?)</div>' 
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        sHtmlContent1 = aResult[1][0]

        sPattern = r'data-id="([^"]+)"\s+data-season="([^"]+)"'
        aResult = oParser.parse(sHtmlContent1, sPattern)
        if aResult[0]:
            oOutputParameterHandler = cOutputParameterHandler()
            for aEntry in aResult[1]:

                sTitle = f"{sMovieTitle} {aEntry[1].replace('season-','S')}"
                sSeason = aEntry[0]
                sThumb = sThumb

                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sUrl)
                oOutputParameterHandler.addParameter('sSeasonID', aEntry[0])
                oOutputParameterHandler.addParameter('sSeasonName', aEntry[1])
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sDesc', '')
                
                oGui.addSeason(SITE_IDENTIFIER, 'showEps', sTitle, '', sThumb, '', oOutputParameterHandler)

        else: 
            sPattern =  'class="EpisodesList(.+?)</singlesection>' 
            aResult = oParser.parse(sHtmlContent,sPattern)
            if aResult[0]:
                sHtmlContent1 = aResult[1][0]

                sPattern = r'href="([^"]+)".+?<episodetitle>(.+?)</episodetitle>'
                aResult = oParser.parse(sHtmlContent1, sPattern)
                if aResult[0]:
                    oOutputParameterHandler = cOutputParameterHandler()  
                    for aEntry in aResult[1]:
            
                        siteUrl = aEntry[0]
                        sTitle = aEntry[1].replace("الحلقة ","").strip()
                        sTitle = f'{sMovieTitle} S{sSeason} E{sTitle}'
                        sThumb = sThumb

                        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                        oOutputParameterHandler.addParameter('sThumb', sThumb)

                        oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, '', oOutputParameterHandler)
 
    oGui.setEndOfDirectory() 
  
def showEps():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sSeasonID = oInputParameterHandler.getValue('sSeasonID')
    sSeasonName = oInputParameterHandler.getValue('sSeasonName')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(f'https://{urlHostName(sUrl)}/ajax/Episode')
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
    oRequestHandler.addHeaderEntry('Origin', f'https://{urlHostName(sUrl)}')
    oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
    oRequestHandler.addParameters('season', sSeasonName)
    oRequestHandler.addParameters('post_id', sSeasonID)
    oRequestHandler.setRequestType(1)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'href="([^"]+)".+?<episodetitle>(.+?)</episodetitle>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:

            siteUrl = aEntry[0]
            sTitle = aEntry[1].replace("الحلقة ","").strip()
            sTitle = f'{sMovieTitle} E{sTitle}'
            sThumb = sThumb

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)

            oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, '', oOutputParameterHandler)

    oGui.setEndOfDirectory() 

def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
    sHtmlContent = oRequestHandler.request()        

    sPattern = r'data-url=["\']([^"\']+)["\'].+?<strong>(.+?)</strong>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        for aEntry in aResult[1]:
            
            sHosterUrl = process_url(aEntry[0]).strip()
            if sHosterUrl.startswith('//'):
                sHosterUrl = 'http:' + sHosterUrl

            if 'userload' in sHosterUrl or '.shop' in sHosterUrl:
                sHosterUrl = f'{sHosterUrl}|Referer={URL_MAIN}'

            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)
				
    sPattern = r'data-href=["\']([^"\']+)["\'].+?</i>(.+?)</resolution>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        for aEntry in aResult[1]:
            
            sHosterUrl = process_url(aEntry[0]).strip()
            if sHosterUrl.startswith('//'):
                sHosterUrl = 'http:' + sHosterUrl
                
            if 'userload' in sHosterUrl or '.shop' in sHosterUrl:
                sHosterUrl = f'{sHosterUrl}|Referer={URL_MAIN}'

            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)
                
    oGui.setEndOfDirectory()

def process_url(data_url: str) -> str:
    if not data_url:
        return None

    cleaned = data_url.replace('+', '')
    encoded = 'aHR0c' + cleaned
    try:
        decoded_bytes = base64.b64decode(encoded)
        decoded_url = decoded_bytes.decode('utf-8')
        return decoded_url
    except Exception as e:
        VSlog("Decoding failed:", e)
        return data_url
