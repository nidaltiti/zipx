﻿# -*- coding: utf-8 -*-

import re
import base64
from urllib.parse import urlparse, parse_qs
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, addon, siteManager
from resources.sites.akwam import showHosters as showAkwam
from resources.sites.faselhd import decode_page
from resources.lib.parser import cParser

UA = "Dalvik/2.1.0 (Linux; U; Android 14; SM-S926B Build/UP1A.240105.004)"

SITE_IDENTIFIER = 'simo'
SITE_NAME = 'Simo-Drama'
SITE_DESC = 'arabic vod'

sHost = base64.b64decode('L21vYy5wcGEtdGFsc2xhc29tLm1pYy8vOnNwdHRo').decode("utf-8")
URL_MAIN = sHost[::-1]

MOVIE_EN = (f'{URL_MAIN}movie/api2.php?cat_id=11', 'showMovies')
MOVIE_HI = (f'{URL_MAIN}movie/api2.php?cat_id=13', 'showMovies')
MOVIE_AR = (f'{URL_MAIN}movie/api2.php?cat_id=12', 'showMovies')
MOVIE_ASIAN = (f'{URL_MAIN}movie/api2.php?cat_id=15', 'showMovies')
MOVIE_KR = (f'{URL_MAIN}movie/api2.php?cat_id=15', 'showMovies')
MOVIE_TURK = (f'{URL_MAIN}movie/api2.php?cat_id=14', 'showMovies')
KID_MOVIES = (f'{URL_MAIN}movie/api2.php?cat_id=17', 'showMovies')
MOVIE_NETFLIX = (f'{URL_MAIN}movie/api2.php?cat_id=16', 'showMovies')

SERIE_EN = (f'{URL_MAIN}youplay/api2.php', 'showSeries')
SERIE_HEND = (f'{URL_MAIN}india/api2.php', 'showSeries')
SERIE_ASIA = (f'{URL_MAIN}koria/api2.php', 'showSeries')
SERIE_AR = (f'{URL_MAIN}arabic/api2.php', 'showSeries')
SERIE_KR = (f'{URL_MAIN}koria/api2.php', 'showSeries')
SERIE_CN = (f'{URL_MAIN}china/api2.php', 'showSeries')
SERIE_JP = (f'{URL_MAIN}japan/api2.php', 'showSeries')
SERIE_TR = (f'{URL_MAIN}turky/api2.php', 'showSeries')
SERIE_THAI = (f'{URL_MAIN}thailand/api2.php', 'showSeries')
SERIE_PAK = (f'{URL_MAIN}pakistani/api2.php', 'showSeries')
SERIE_LATIN = (f'{URL_MAIN}maxic/api2.php', 'showSeries')

REPLAYTV_NEWS = (f'{URL_MAIN}program/api2.php', 'showSeries')
REPLAYTV_PLAY = (f'{URL_MAIN}movie/api2.php?cat_id=3', 'showMovies')

SERIE_NETFLIX = (f'{URL_MAIN}netflix/api2.php', 'showSeries')

# RAMADAN_SERIES = (f'{URL_MAIN}poster/by/filtres/88/created/0{mHost_Ext}', 'showSeries')

ANIM_NEWS = (f'{URL_MAIN}anime/api2.php', 'showSeries')

URL_SEARCH = (f'{URL_MAIN}upd/newupd5/search.php?search=', 'showSeries')
URL_SEARCH_MOVIES = (f'{URL_MAIN}upd/newupd5/search.php?search=', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}upd/newupd5/search.php?search=', 'showSeries')
FUNCTION_SEARCH = 'showMovies'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    #oOutputParameterHandler.addParameter('siteUrl', RAMADAN_SERIES[0])
    #oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'رمضان', 'rmdn.png', oOutputParameterHandler) 

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام عربية', 'arab.png', oOutputParameterHandler)
 
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_ASIAN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أسيوية', 'asia.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_TURK[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام تركية', 'turk.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_HI[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام هندية', 'hend.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام انيميشن', 'anim.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}egypt/api2.php')
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات مصرية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}syria/api2.php')
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات سورية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_ASIA[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أسيوية', 'asia.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_KR[0])
    oGui.addDir(SITE_IDENTIFIER, SERIE_KR[1], 'مسلسلات كورية', 'kr.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_JP[0])
    oGui.addDir(SITE_IDENTIFIER, SERIE_JP[1], 'مسلسلات يابانية', 'jp.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_CN[0])
    oGui.addDir(SITE_IDENTIFIER, SERIE_CN[1], 'مسلسلات صينية', 'cn.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_THAI[0])
    oGui.addDir(SITE_IDENTIFIER, SERIE_THAI[1], 'مسلسلات تايلندية', 'thai.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_TR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات تركية', 'turk.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_LATIN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات لاتنية', 'latin.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_PAK[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات باكستانية', 'paki.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات انمي', 'anime.png', oOutputParameterHandler)
 
    oOutputParameterHandler.addParameter('siteUrl', REPLAYTV_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'برامج تلفزيونية', 'brmg.png', oOutputParameterHandler) 

    oOutputParameterHandler.addParameter('siteUrl', SERIE_NETFLIX[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات Netfilx', 'netflix.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}apple/api2.php')
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات Apple', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', REPLAYTV_PLAY[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'مسرحيات', 'msrh.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()
	
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}upd/newupd5/search.php?search={sSearchText}'
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showSeriesSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}upd/newupd5/search.php?search={sSearchText}'
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return

def showMovies(sSearch='', page=0):
    ITEMS_PER_PAGE = 40
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()

    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        page = int(oInputParameterHandler.getValue('page'))

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.enableCache(True)
    oRequestHandler.addHeaderEntry('Connection', 'Keep-Alive')
    oRequestHandler.addHeaderEntry('Host', "cim.mosalslat-app.com")
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    if sSearch:
        sHtmlContent = sHtmlContent.get('cinema', [])
    else:
        sHtmlContent = sHtmlContent.get('HDvideo', [])

    start_index = page * ITEMS_PER_PAGE
    end_index = start_index + ITEMS_PER_PAGE
    paged_content = sHtmlContent[start_index:end_index]

    for aEntry in paged_content:
        sTitle = aEntry.get('video_title')
        siteUrl = f'{URL_MAIN}movie/api2.php?id={aEntry.get("id")}'
        sThumb = aEntry.get('vid_img_url', '')
        sDesc = aEntry.get('other_title', '')
        sYear = ''
        years = re.findall(r'\b(?:19|20)\d{2}\b', sTitle)
        if years:
            sYear = years[-1]
            sTitle = sTitle.replace(sYear, '').strip()

        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sYear', sYear)
        oOutputParameterHandler.addParameter('sDesc', sDesc)

        oGui.addMovie(SITE_IDENTIFIER, 'showLink', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if end_index < len(sHtmlContent):
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oOutputParameterHandler.addParameter('page', page + 1)
        oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()

def showSeries(sSearch='', page=0):
    ITEMS_PER_PAGE = 40
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()

    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        try:
            page = int(oInputParameterHandler.getValue('page'))
        except:
            page = 0

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.enableCache(True)
    oRequestHandler.addHeaderEntry('Connection', 'Keep-Alive')
    oRequestHandler.addHeaderEntry('Host', "cim.mosalslat-app.com")
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    if sSearch:
        sHtmlContent = sHtmlContent.get('drama', [])
    else:
        sHtmlContent = sHtmlContent.get('HDvideo', [])

    start_index = page * ITEMS_PER_PAGE
    end_index = start_index + ITEMS_PER_PAGE
    paged_content = sHtmlContent[start_index:end_index]

    for aEntry in paged_content:
        sTitle = aEntry.get('category_name')
        if sSearch:
            siteUrl = f'{URL_MAIN}{aEntry.get("section")}/api2.php?cat_id={aEntry.get("cid")}'
        else:
            siteUrl = f'{sUrl}?cat_id={aEntry.get("cid")}'
        sThumb = aEntry.get('category_image', '')
        if 'mosalslat-app' not in sThumb:
            sThumb = aEntry.get('cat_img_url', '')
        else:
            sThumb = build_image_url(sUrl, sThumb)
        sDesc = aEntry.get('other_name', '')
        sYear = ''
        years = re.findall(r'\b(?:19|20)\d{2}\b', sTitle)
        if years:
            sYear = years[-1]
            sTitle = sTitle.replace(sYear, '').strip()

        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sYear', sYear)
        oOutputParameterHandler.addParameter('sDesc', sDesc)

        oGui.addTV(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if end_index < len(sHtmlContent):
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oOutputParameterHandler.addParameter('page', page + 1)
        oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()

 
def showEpisodes():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    season_id = oInputParameterHandler.getValue('season_id')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sDesc = oInputParameterHandler.getValue('sDesc')

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('Connection', 'Keep-Alive')
    oRequestHandler.addHeaderEntry('Host', "cim.mosalslat-app.com")
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    for episode in sHtmlContent.get("HDvideo", []):

        episode_id = episode.get('id', '')
        sEpisode = episode.get('video_title', '').replace('الحلقة','E')
        siteUrl = f'{sUrl.split("?cat_id=")[0]}?id={episode_id}'
        sTitle = ("%s %s") % (sMovieTitle, sEpisode.replace('الحلقة ','E'))         
        sThumb = sThumb
        sDesc = sDesc

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('season_id', season_id)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        
        oGui.addEpisode(SITE_IDENTIFIER, 'showLink', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
       
    oGui.setEndOfDirectory() 
	
def showLink():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sYear = oInputParameterHandler.getValue('sYear')
    sDesc = oInputParameterHandler.getValue('sDesc')

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('Connection', 'Keep-Alive')
    oRequestHandler.addHeaderEntry('Host', "cim.mosalslat-app.com")
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    video_links = [value for key, value in sHtmlContent.items() if key.startswith("video_url_")]

    for sNo, aEntry in enumerate(video_links, 1):
        oOutputParameterHandler = cOutputParameterHandler()
           
        sHosterUrl = aEntry

        parsed = urlparse(sHosterUrl)
        query = parse_qs(parsed.query)

        if "/video_ext.php" in parsed.path and "oid" in query:
            sHosterUrl = f"https://vk.com/video_ext.php?oid={query['oid'][0]}&id={query['id'][0]}"
            if useDialog:
                results.append((SITE_NAME, sHosterUrl, 'Dummy'))
            else:
                oHoster = cHosterGui().checkHoster(sHosterUrl)
                if oHoster:
                    oHoster.setDisplayName(sMovieTitle)
                    oHoster.setFileName(sMovieTitle)
                    cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)      
                    
        elif 'zplayer.io' in sHosterUrl:
            sHosterUrl = f'https://short.ink/{sHosterUrl.split("/?v=")[1]}'
            if useDialog:
                results.append((SITE_NAME, sHosterUrl, 'Dummy'))
            else:
                oHoster = cHosterGui().checkHoster(sHosterUrl)
                if oHoster:
                    oHoster.setDisplayName(sMovieTitle)
                    oHoster.setFileName(sMovieTitle)
                    cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)      

        elif 'cimanow' in sHosterUrl or 'newcima' in sHosterUrl:
            sHosterUrl = f'{sHosterUrl}|Referer={siteManager().getUrlMain("cimanow")}' 

            if useDialog:
                if '/e/' in sHosterUrl:
                    results.append((sHost, sHosterUrl, 'cimanow'))
                else:
                    results.append((sHost, sHosterUrl, 'mycima'))
            else:
                oHoster = cHosterGui().getHoster('mycima')
                if '/e/' in sHosterUrl:
                    oHoster = cHosterGui().getHoster('cimanow')
                if oHoster:
                    oHoster.setDisplayName(sTitle)
                    oHoster.setFileName(sMovieTitle)
                    cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)  

        elif 'faselhd' in sHosterUrl:
            try:
                oParser = cParser() 
                oRequest = cRequestHandler(sHosterUrl)
                oRequest.enableCache(False)
                oRequest.addHeaderEntry('referer', URL_MAIN)
                data = oRequest.request()
                
                sPattern = r'file:"([^"]+)",label:"([^"}]+)"'
                aResult = oParser.parse(data, sPattern)

                if aResult[0]:
                    for aEntry in aResult[1]:
                        sHosterUrl = aEntry[0]
                        sHost = aEntry[1].upper()
                        sTitle = f'{sMovieTitle} ({sHost})'
                        if useDialog:
                            results.append((sHost, sHosterUrl, 'direct_link'))
                        else:
                            oHoster = cHosterGui().getHoster('direct_link') 
                            if oHoster:
                                oHoster.setDisplayName(sTitle)
                                oHoster.setFileName(sMovieTitle)
                                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)  
            except:
                VSlog('Fasel Failed')
                
        elif bool(re.search(r'mega.*max', sHosterUrl)):
            from resources.lib.multihost import cMegamax
            data = cMegamax().GetUrls(sHosterUrl)
            if data:
                if useDialog:
                    for item in data:
                        sHosterUrl = item.split(',')[0].split('=')[1]
                        sQual = item.split(',')[1].split('=')[1]
                        sLabel = item.split(',')[2].split('=')[1]
                        results.append((sQual, sHosterUrl))
                else:
                    for item in data:
                        sHosterUrl = item.split(',')[0].split('=')[1]
                        sQual = item.split(',')[1].split('=')[1]
                        sLabel = item.split(',')[2].split('=')[1]

                        sDisplayTitle = f'{sMovieTitle} [COLOR coral][{sQual}][/COLOR][COLOR orange] - {sLabel}[/COLOR]'
                        oOutput = cOutputParameterHandler()
                        oOutput.addParameter('sHosterUrl', sHosterUrl)
                        oOutput.addParameter('siteUrl', sUrl)
                        oOutput.addParameter('sMovieTitle', sMovieTitle)
                        oOutput.addParameter('sThumb', sThumb)
                        oGui.addLink(SITE_IDENTIFIER, 'showLinks', sDisplayTitle, sThumb, sDisplayTitle, oOutput)
        
        elif 'ak.sv' in sHosterUrl:
            if useDialog:
                results.append((SITE_NAME, sHosterUrl, 'Dummy'))
            else:
                oOutputParameterHandler.addParameter('siteUrl', sHosterUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sYear', sYear)
                oOutputParameterHandler.addParameter('sDesc', sDesc)

                oGui.addMovie(SITE_IDENTIFIER, 'showAkwam', f'{sMovieTitle} [COLOR gold] - Akwam[/COLOR]', '', sThumb, sDesc, oOutputParameterHandler)

        else:
            if useDialog:
                results.append((SITE_NAME, sHosterUrl, 'Dummy'))
            else:
                oHoster = cHosterGui().checkHoster(sHosterUrl)
                if oHoster:
                    oHoster.setDisplayName(sMovieTitle)
                    oHoster.setFileName(sMovieTitle)
                    cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)             

    if useDialog and results:
        if any(len(r) == 3 for r in results):
            for r in results:
                fixedHoster = r[2]
            select_results = [(r[0], r[1]) for r in results]
            cHosterGui().selectHoster(select_results, sMovieTitle, SITE_NAME, sThumb, fixedHoster=fixedHoster)

    else:
        oGui.setEndOfDirectory()   

def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sHosterUrl = oInputParameterHandler.getValue('sHosterUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oHoster = cHosterGui().checkHoster(sHosterUrl)
    if oHoster:
        oHoster.setDisplayName(sMovieTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()

def build_image_url(api_url, category_image):
    import os
    from urllib.parse import urlparse
    section = urlparse(api_url).path.split('/')[1]
    base_name = os.path.splitext(category_image)[0]
    return f"https://mio.mosalslat-app.com/img/{section}/th/{base_name}.th.jpg"