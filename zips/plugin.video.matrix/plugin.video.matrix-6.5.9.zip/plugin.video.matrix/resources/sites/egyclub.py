﻿#-*- coding: utf-8 -*-

import re
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, VSlog, siteManager, addon
from resources.lib.parser import cParser
from resources.lib.util import cUtil, Quote
from resources.lib import random_ua

UA = random_ua.get_ua()
 
SITE_IDENTIFIER = 'egyclub'
SITE_NAME = 'Egyclub'
SITE_DESC = 'arabic vod'
 
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)
MOVIE_AR = (f'{URL_MAIN}search/label/افلام%20عربية', 'showMovies')
MOVIE_EN = (f'{URL_MAIN}search/label/افلام%20اجنبية', 'showMovies')
KID_MOVIES = (f'{URL_MAIN}search/label/افلام%20كرتون', 'showMovies')

SERIE_EN = (f'{URL_MAIN}search/label/مسلسلات%20اجنبية', 'showSeries')
SERIE_AR = (f'{URL_MAIN}search/label/مسلسلات%20عربية', 'showSeries')
SERIE_TR = (f'{URL_MAIN}search/label/مسلسلات%20تركية', 'showSeries')
RAMADAN_SERIES = (f'{URL_MAIN}search/label/رمضان%202025', 'showSeries')

URL_SEARCH = (f'{URL_MAIN}feeds/posts/summary?start-index=1&alt=json&orderby=updated&q=', 'showMovies')
URL_SEARCH_MOVIES = (f'{URL_MAIN}feeds/posts/summary?start-index=1&alt=json&orderby=updated&q=', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}feeds/posts/summary?start-index=1&alt=json&orderby=updated&q=', 'showSeries')
FUNCTION_SEARCH = 'showMovies'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', RAMADAN_SERIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات رمضان', 'rmdn.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام كرتون', 'anim.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_TR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات تركية', 'turk.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()
 
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}feeds/posts/summary?start-index=1&alt=json&orderby=updated&q={sSearchText}'
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showSeriesSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}feeds/posts/summary?start-index=1&alt=json&orderby=updated&q={sSearchText}'
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showMovies(sSearch = ''):
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler() 
    
    if sSearch:
        sUrl = sSearch
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
        sHtmlContent = oRequestHandler.request(jsonDecode=True)
        for entry in sHtmlContent.get("feed", {}).get("entry", []):
            sDesc = ''
            sYear = ''
            sTitle = entry.get("title", {}).get("$t", None)
            siteUrl = ''
            sThumb = ''
            for l in entry.get("link", []):
                if l.get("rel") == "alternate":
                    siteUrl = l.get("href")
                    break
            if "media$thumbnail" in entry:
                sThumb = entry["media$thumbnail"].get("url")

            if 'مسلسل' not in sTitle:
                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle) 
                oOutputParameterHandler.addParameter('sYear', sYear)                  
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oGui.addMovie(SITE_IDENTIFIER, 'showServers', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r"<a class='thumb'\s*href='([^']+)'>\s*<img alt='([^']+)'.+?src='([^']+)'"
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME) 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            if "فيلم" not in aEntry[1]:
                continue
 
            sTitle = cUtil().CleanMovieName(aEntry[1])
            siteUrl = aEntry[0]
            sThumb = aEntry[2]
            sDesc = ''
            sYear = ''
            m = re.search(r'([0-9]{4})', sTitle)
            if m:
                sYear = str(m.group(0))

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle) 
            oOutputParameterHandler.addParameter('sYear', sYear)                  
            oOutputParameterHandler.addParameter('sThumb', sThumb)

            oGui.addMovie(SITE_IDENTIFIER, 'showServers', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()
 
def __checkForNextPage(sHtmlContent):
    oParser = cParser()
    sPattern = r"<a class='blog-pager-older-link' href='([^']+)'"
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:       
        return aResult[1][0]

    return False 
 
def showSeries(sSearch = ''):
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler() 

    if sSearch:
        itemList = []
        sUrl = sSearch
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
        sHtmlContent = oRequestHandler.request(jsonDecode=True)
        for entry in sHtmlContent.get("feed", {}).get("entry", []):
            sDesc = ''
            sYear = ''
            sTitle = entry.get("title", {}).get("$t", None)
            siteUrl = ''
            sThumb = ''
            for l in entry.get("link", []):
                if l.get("rel") == "alternate":
                    siteUrl = l.get("href")
                    break
            if "media$thumbnail" in entry:
                sThumb = entry["media$thumbnail"].get("url")

            if 'مسلسل' in sTitle:
                sTitle = cleanSeries(sTitle)
                if sTitle not in itemList:
                    itemList.append(sTitle)	
                    oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                    oOutputParameterHandler.addParameter('sMovieTitle', sTitle) 
                    oOutputParameterHandler.addParameter('sYear', sYear)                  
                    oOutputParameterHandler.addParameter('sThumb', sThumb)
                    oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r"<a class='thumb'\s*href='([^']+)'>\s*<img alt='([^']+)'.+?src='([^']+)'"
    aResult = oParser.parse(sHtmlContent, sPattern)	
    itemList = []	
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)   
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            if "فيلم" in aEntry[1]:
                continue

            sTitle = cleanSeries(aEntry[1])
            siteUrl = aEntry[0]
            sThumb = aEntry[2]
            sDesc = ''
            sYear = ''

            if sTitle not in itemList:
                itemList.append(sTitle)	
                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sYear', sYear)

                oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
 
    if not sSearch:
        oGui.setEndOfDirectory() 

def showSeasons():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r"onclick=\"openCity\(event, '([^']+)'\)\".*?<button[^>]*>([^<]+)</button>"
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0] is True:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:

            siteUrl = sUrl
            sCode = aEntry[0]
            sSeason = (cUtil().ConvertSeasons(aEntry[1])).strip()
            sTitle = f'{sMovieTitle} {sSeason}'
            sThumb = sThumb

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sCode', sCode)
 
            oGui.addSeason(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, '', oOutputParameterHandler)
       
    oGui.setEndOfDirectory()

def showEpisodes():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sCode = oInputParameterHandler.getValue('sCode')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = sCode
    sEnd = '</b:if>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'class="posts3"\s*>(.+?)</div>'
    aResult = oParser.parse(sHtmlContent, sPattern)  
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:

            sSeasonCode = Quote(aEntry.split('/')[1])
            oRequestHandler = cRequestHandler(f'{URL_MAIN}feeds/posts/default/-/{sSeasonCode}?alt=json&max-results=100')
            oRequestHandler.addHeaderEntry('Referer', sUrl)
            sHtmlContent = oRequestHandler.request(jsonDecode=True)

            for entry in sHtmlContent['feed']['entry']:
                title = entry['title']['$t']
                image = entry.get('media$thumbnail', {}).get('url', sThumb)
                content = entry['content']['$t']


                sEpi = get_episode(title)
                sTitle = f'{sMovieTitle} E{sEpi:02d}'
                siteUrl = sUrl
                sThumb = image
                sDesc = ''
                sYear = ''

                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sYear', sYear) 
                oOutputParameterHandler.addParameter('sContent', content) 
                
                oGui.addEpisode(SITE_IDENTIFIER, 'showServers', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
 
       
    oGui.setEndOfDirectory() 
 
def showServers():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sContent = oInputParameterHandler.getValue('sContent')

    oParser = cParser()
    if sContent:
        sHtmlContent = sContent
    else:
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    sPattern = r'class="elementor__server_item">.+?href="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        for aEntry in aResult[1]:

            url = aEntry
            if url.startswith('//'):
                url = f'http:{url}'

            sHosterUrl = url
            if 'userload' in sHosterUrl:
                sHosterUrl = f'{sHosterUrl}|Referer={URL_MAIN}'

            results.append((SITE_NAME, sHosterUrl))

    if useDialog and results:
        cHosterGui().selectHoster(results, sMovieTitle, SITE_NAME, sThumb)
    else:
        for sTitle, sHosterUrl in results:
            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

        oGui.setEndOfDirectory()


def cleanSeries(title: str):
    sPattern = r"^(?:مسلسل\s*)?(.*?)(?:\s+ج(\d+))?(?:\s+الحلقة\s+(\d+))?$"
    m = re.match(sPattern, title.strip())
    if not m:
        return None
    
    show, season, episode = m.groups()
    show = show.strip()
    show = show.replace("مترجم", "(مترجم)")
    
    return show.strip()

def get_season(title: str):
    sPattern = r"^(?:مسلسل\s*)?(.*?)(?:\s+ج(\d+))?(?:\s+الحلقة\s+(\d+))?$"
    m = re.match(sPattern, title)
    if m:
        season = m.group(2) 
        return int(season) if season else None
    return None

def get_episode(title: str):
    print(f"Processing title: {title}")
    sPattern = r"الحلقة\s+(\d+)"
    m = re.search(sPattern, title)
    if m:
        episode = m.group(1)
        return int(episode) if episode else 1
    return 1