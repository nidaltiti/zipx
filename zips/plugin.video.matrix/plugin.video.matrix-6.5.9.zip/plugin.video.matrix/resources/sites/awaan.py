﻿# -*- coding: utf-8 -*-

import re
import uuid
import urllib.parse
from resources.lib.gui.hoster import cHosterGui	
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, VSlog, siteManager, addon
from resources.lib.parser import cParser
from resources.lib.util import cUtil
from resources.lib import random_ua

UA = random_ua.get_ua()

SITE_IDENTIFIER = 'awaan'
SITE_NAME = 'Awaan'
SITE_DESC = 'arabic vod'
 
URL_MAIN = 'https://d1vr1mlm6fadud.cloudfront.net/'
sReferer = siteManager().getUrlMain(SITE_IDENTIFIER)
 
URL_SERIE = f'{URL_MAIN}show/allprograms/30348/%D8%A7%D9%84%D9%85%D8%B3%D9%84%D8%B3%D9%84%D8%A7%D8%AA'

MOVIE_AR = (f'{URL_MAIN}content/filters/DG-all-movies?origin=cvp&size=30&source=cvp&region=BH&maxParentalRatings=18&language=en&platform=web', 'showMovies')
SERIE_AR = (f'{URL_MAIN}series', 'showSeries')
#RAMADAN_SERIES = (f'{URL_MAIN}ramadan', 'showSeries')
REPLAYTV_PLAY = (f'{URL_MAIN}plays', 'showEps')

ISLAM_SHOWS = (f'{URL_MAIN}programs/30349/إسلاميات', 'showSeries')
ISLAM_QURAN = (f'{URL_MAIN}programs/208779/القرآن-الكريم', 'showSeries')

URL_SEARCH = (f'{URL_MAIN}search_result?term=', 'showMovies')
URL_SEARCH_MOVIES = (f'{URL_MAIN}search_result?term=', 'showMoviesSearch')
URL_SEARCH_SERIES= (f'{URL_MAIN}search_result?term=', 'showSeriesSearch')
FUNCTION_SEARCH = 'showMovies'
 
def load():
    addons = addon()

    if (addons.getSetting('hoster_awaan_username') == '') and (addons.getSetting('hoster_awaan_password') == ''):
        oGui = cGui()
        oGui.addText(SITE_IDENTIFIER, '[COLOR %s]%s[/COLOR]' % ('red', 'الموقع يطلب حساب لاظهار الروابط'))

        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
        oGui.addDir(SITE_IDENTIFIER, 'opensetting', addons.VSlang(30023), 'none.png', oOutputParameterHandler)
        oGui.setEndOfDirectory()
    else:

        oGui = cGui()
        addons = addon()
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
        oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

        oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
        oGui.addDir(SITE_IDENTIFIER, 'showSearchSeries', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

        oOutputParameterHandler.addParameter('siteUrl', ISLAM_QURAN[0])
        oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'القرآن الكريم', 'quran.png', oOutputParameterHandler)

        oOutputParameterHandler.addParameter('siteUrl', ISLAM_SHOWS[0])
        oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'إسلاميات', 'quran.png', oOutputParameterHandler)

        oOutputParameterHandler.addParameter('siteUrl', MOVIE_AR[0])
        oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'الأفلام ', 'arab.png', oOutputParameterHandler)

        oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
        oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'المسلسلات', 'arab.png', oOutputParameterHandler)

        # oOutputParameterHandler.addParameter('siteUrl', RAMADAN_SERIES[0])
        # oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات رمضان', 'arab.png', oOutputParameterHandler)

        oOutputParameterHandler.addParameter('siteUrl', REPLAYTV_PLAY[0])
        oGui.addDir(SITE_IDENTIFIER, 'showEps', 'المسرحيات', 'msrh.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()
 
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search_result?term={sSearchText}&page=1'
        showMoviesSearch(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showSearchSeries():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search_result?term={sSearchText}&page=1'
        showSeriesSearch(sUrl)
        oGui.setEndOfDirectory()
        return  
     
def showMoviesSearch(sSearch = ''):
    oGui = cGui()
    if sSearch:
      sUrl = f'{sSearch}&page=1'
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
    oRequestHandler.addHeaderEntry('Accept-Language', 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3')
    sHtmlContent = oRequestHandler.request()
    sHtmlContent = sHtmlContent.encode("utf8",errors='ignore').decode("unicode_escape")

    sPattern = r'<li class="show-item filter newcategory">.+?<a href="([^"]+)".+?data-src="([^"]+)".+?title="([^"]+)'               
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            sTitle = cUtil().CleanMovieName(aEntry[2])  
            siteUrl = aEntry[0]
            sThumb = aEntry[1]
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
			
            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
    if not sSearch:
        oGui.setEndOfDirectory()
    
def showSeriesSearch(sSearch = ''):
    oGui = cGui()
    if sSearch:
      sUrl = sSearch+'&page=1'
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
    oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
    oRequestHandler.addHeaderEntry('Accept-Language', 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3')
    sHtmlContent = oRequestHandler.request()
    sHtmlContent = sHtmlContent.encode("utf8",errors='ignore').decode("unicode_escape")

    sPattern = r'<div class="item info">.+?<a href="([^"]+)".+?data-src="([^"]+)".+?title="([^"]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            sTitle = cUtil().CleanSeriesName(aEntry[2])
            siteUrl = f'{aEntry[0]}?page=1'
            sThumb = aEntry[1]
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
			
            oGui.addMovie(SITE_IDENTIFIER, 'showEps', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
    if not sSearch:
        oGui.setEndOfDirectory()  

def showMovies(sSearch = ''):
    oGui = cGui()
    if sSearch:
      sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    client_id = generate_client_id()
    userid = generate_user_id()

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Accept', 'application/json, text/plain, */*')
    oRequestHandler.addHeaderEntry('Origin', sReferer[:-1])
    oRequestHandler.addHeaderEntry('Referer', sReferer)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    for item in sHtmlContent.get("content", []):
        oOutputParameterHandler = cOutputParameterHandler() 
        sTitle = item.get("title")
        sDesc = item.get("description")
        pId = item.get("pId")
        program_type = item.get("programType")
        siteUrl = f'https://link.theplatform.eu/s/dmimain/media/{pId}'
        params = {
            "format": "SMIL",
            "tracking": "true",
            "clientId": client_id,
            "userId": userid,
            "locale": "en-US",
            "platform": "android",
            "formats": "MPEG-DASH+widevine,MPEG-DASH+none,MP3",
            "region": "BH",
            "maxParentalRatings": "18",
            "language": "en-US"
        }

        siteUrl = f"{siteUrl}?{urllib.parse.urlencode(params)}"

        images = item.get("images", [])
        best_image = max(images, key=lambda img: img.get("width", 0) * img.get("height", 0), default={})
        sThumb = best_image.get("url")

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('userid', userid)
        oOutputParameterHandler.addParameter('client_id', client_id)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        
        oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
 
    if not sSearch:
        oGui.setEndOfDirectory()
 
def showSeries(sSearch = ''):
    oGui = cGui()
    if sSearch:
      sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        sPage = oInputParameterHandler.getValue('sPage')
    
    if sPage is False:
        sPage = '1'
    else:
        sPage = sPage
    if '208779' in sUrl:
        sUrl = f'{sUrl}?page={sPage}&category_id=208779'
    elif '30349' in sUrl:
        sUrl = f'{sUrl}?page={sPage}&category_id=30349'
    else:
        sUrl = f'{sUrl}?page={sPage}'

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7')
    oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
    oRequestHandler.addHeaderEntry('Accept-Language', 'en-US,en;q=0.9')
    sHtmlContent = oRequestHandler.request()
    if 'ramadan' not in sUrl:
        sHtmlContent = sHtmlContent.encode("utf8",errors='ignore').decode("unicode_escape")

    sPattern = r'<div class="item info">.+?href="([^"]+)".+?data-src="([^"]+)".+?<h3>(.+?)</h3>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break

            sTitle = cUtil().CleanSeriesName(aEntry[2])
            siteUrl = aEntry[0]
            sThumb = aEntry[1]
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            if '/show' in siteUrl:
                oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
            else:
                oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)

        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            sPage = int(sPage) +1
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sPage', sPage)
            oOutputParameterHandler.addParameter('siteUrl', sUrl.split('?')[0])
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]More >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    sStart = '<div class="ContainerEpisodesList"'
    sEnd = '<div style="clear: both;"></div>'
    sHtmlContent1 = oParser.abParse(sHtmlContent.replace("\\", ""), sStart, sEnd)

    sPattern = r'href="([^"]+)".+?img src="([^"]+)" alt="([^"]+)'
    aResult = oParser.parse(sHtmlContent1, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            try:
                sTitle = aEntry[2].replace("u", "\\u").encode('utf-8').decode('unicode-escape')
            except:
                sTitle = aEntry[2]
            sTitle = cUtil().CleanSeriesName(sTitle)
            siteUrl = aEntry[0]
            sThumb = aEntry[1]
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            if '/show' in siteUrl:
                oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)

        sPattern = 'url: "([^"]+)'
        aResult = oParser.parse(sHtmlContent, sPattern) 
        if aResult[0]:
            nUrl = aResult[1][0]

            sPattern = 'data-page="([^"]+)'
            aResult = oParser.parse(sHtmlContent, sPattern) 
            if aResult[0]:
                sPage = aResult[1][0]

                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('sPage', sPage)
                oOutputParameterHandler.addParameter('siteUrl', nUrl)
                oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]More >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()

def showSeasons():
    oGui = cGui()
    addons = addon()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sPage = oInputParameterHandler.getValue('sPage')

    aUser = addons.getSetting('hoster_awaan_username')
    aPass = addons.getSetting('hoster_awaan_password')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'<a class=" select-category.+?href="([^"]+)">(.+?)</a>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:
            sTitle = re.sub(r"S\d{2}|S\d", "", sMovieTitle)
            sTitle = sTitle.replace('S1','') + ' S' + aEntry[1]
            siteUrl = aEntry[0]
            sThumb = sThumb
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            if '/show' in siteUrl:
                oGui.addSeason(SITE_IDENTIFIER, 'showEps', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
    else:
        if sPage is False:
            sPage = '1'
        else:
            sPage = sPage

        sPattern = r'var selected_season = ["\']([^"\']+)["\']'
        aResult = oParser.parse(sHtmlContent,sPattern)
        if aResult[0]:
            sSeason = aResult[1][0]

        sPattern = r'_token: ["\']([^"\']+)["\']'
        aResult = oParser.parse(sHtmlContent,sPattern)
        if aResult[0]:
            _token = aResult[1][0]

            oRequestHandler = cRequestHandler(URL_MAIN+'auth/login')
            oRequestHandler.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7')
            oRequestHandler.addHeaderEntry('accept-language', 'en-US,en;q=0.9,ar;q=0.8')
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            oRequestHandler.addHeaderEntry('Referer', sUrl)
            oRequestHandler.addParameters('_token', _token)
            oRequestHandler.addParameters('back_rel', f'{sUrl}')
            oRequestHandler.addParameters('username', aUser)
            oRequestHandler.addParameters('password', aPass)
            oRequestHandler.setRequestType(1)
            sHtmlContent = oRequestHandler.request()

            oRequestHandler = cRequestHandler(f'{URL_MAIN}auth/manage-profiles?back_rel={URL_MAIN}')
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            sHtmlContent = oRequestHandler.request()

            sPattern = r'data-profile-id="([^"]+)' 
            aResult = oParser.parse(sHtmlContent,sPattern)
            if aResult[0]:
                sprofile = aResult[1][0]
            
            oRequestHandler = cRequestHandler(f'{URL_MAIN}auth/select-profile?back_rel={URL_MAIN}')
            oRequestHandler.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7')
            oRequestHandler.addHeaderEntry('accept-language', 'en-US,en;q=0.9,ar;q=0.8')
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            oRequestHandler.addHeaderEntry('Referer', sUrl)
            oRequestHandler.addParameters('_token', _token)
            oRequestHandler.addParameters('profile_id', sprofile)
            oRequestHandler.addParameters('back_rel', URL_MAIN)
            oRequestHandler.setRequestType(1)
            sHtmlContent = oRequestHandler.request()

            oRequestHandler = cRequestHandler(f'{sUrl}?page={sPage}&season={sSeason}')
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            sHtmlContent = oRequestHandler.request()

        sPattern = r'<div class="item info">.+?<a href="([^"]+)".+?data-src="([^"]+)".+?<h3>(.+?)</h3>'
        aResult = oParser.parse(sHtmlContent, sPattern)	
        if aResult[0]:
            oOutputParameterHandler = cOutputParameterHandler()  
            for aEntry in aResult[1]:

                sTitle = aEntry[2].replace("الحلقة "," E").replace("حلقة "," E").replace("مشاهدة","").replace("مسلسل","").replace("انمي","").replace("مترجمة","").replace("مترجم","").replace("فيلم","").replace("والأخيرة","").replace("مدبلج للعربية","مدبلج").replace("برنامج","").replace("والاخيرة","").replace("كاملة","").replace("حلقات كاملة","").replace("اونلاين","").replace("مباشرة","").replace("انتاج ","").replace("جودة عالية","").replace("كامل","").replace("HD","").replace("السلسلة الوثائقية","").replace("الفيلم الوثائقي","").replace("اون لاين","")           
                siteUrl = aEntry[0]
                sThumb = aEntry[1]
                sDesc = ''
                if sMovieTitle is False:
                    sMovieTitle = sTitle
                if ':' in aEntry[2]:
                    sTitle = f'{sMovieTitle} {sTitle.split(":")[1]}'
                else:
                    sTitle = f'{sMovieTitle} {sTitle}'       

                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
			
                oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

            sNextPage = __checkForNextPage(sHtmlContent)
            if sNextPage:
                sPage = int(sPage) +1
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('sPage', sPage)
                oOutputParameterHandler.addParameter('siteUrl', sUrl.split('?')[0])
                oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]More >>>[/COLOR]', 'next.png', oOutputParameterHandler)

        else:
            oGui.addText(SITE_IDENTIFIER, '[COLOR %s]%s[/COLOR]' % ('white', ' الموقع لم يرفع حلقات هذا الموسم من المسلسل'), 'none.png')

    oGui.setEndOfDirectory() 

def showEps():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sPage = oInputParameterHandler.getValue('sPage')

    oParser = cParser()
    if sPage is False:
        sPage = '1'
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        sHtmlContent = oRequestHandler.request()
    else:
        sPage = sPage
        if '#' in sUrl:
            sUrl = sUrl.split('#')[0]

            oRequestHandler = cRequestHandler(f'{sUrl}?page={sPage}')
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            oRequestHandler.addHeaderEntry('x-requested-with', 'XMLHttpRequest')
            sHtmlContent = oRequestHandler.request(jsonDecode=True)
            sHtmlContent = sHtmlContent['html']

    oParser = cParser()
    sPattern = r'<div class="item info">.+?<a href="([^"]+)".+?data-src="([^"]+)".+?<h3>(.+?)</h3>'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:

            sTitle = aEntry[2].replace("الحلقة "," E").replace("حلقة "," E").replace("مشاهدة","").replace("مسلسل","").replace("انمي","").replace("مترجمة","").replace("مترجم","").replace("فيلم","").replace("والأخيرة","").replace("مدبلج للعربية","مدبلج").replace("برنامج","").replace("والاخيرة","").replace("كاملة","").replace("حلقات كاملة","").replace("اونلاين","").replace("مباشرة","").replace("انتاج ","").replace("جودة عالية","").replace("كامل","").replace("HD","").replace("السلسلة الوثائقية","").replace("الفيلم الوثائقي","").replace("اون لاين","")           
            siteUrl = aEntry[0]
            sThumb = aEntry[1]
            sDesc = ''
            if sMovieTitle is False:
                sMovieTitle = sTitle
            if ':' in aEntry[2]:
                sTitle = f'{sMovieTitle} {sTitle.split(":")[1]}'
            else:
                sTitle = f'{sMovieTitle} {sTitle}'        

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
			
            oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            sPage = int(sPage) +1
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sPage', sPage)
            oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
            oOutputParameterHandler.addParameter('siteUrl', sUrl.split('?')[0])
            oGui.addDir(SITE_IDENTIFIER, 'showEps', '[COLOR teal]More >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    else:
        oGui.addText(SITE_IDENTIFIER, f'[COLOR white] الموقع لم يرفع حلقات هذا الموسم من المسلسل [/COLOR]', 'none.png')

    oGui.setEndOfDirectory() 

def __checkForNextPage(sHtmlContent):
    oParser = cParser()
    sPattern = r'"has_more":(.+?)'
    aResult = oParser.parse(sHtmlContent, sPattern) 
    if aResult[0]:
        return aResult[1][0]

    sPattern = r'data-page="([^"]+)'
    aResult = oParser.parse(sHtmlContent, sPattern) 
    if aResult[0]:
        return aResult[1][0]

    return False

def showHosters():
    oGui = cGui()
    addons = addon()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    userid = oInputParameterHandler.getValue('userid')
    client_id = oInputParameterHandler.getValue('client_id')

    headers = {
        "Accept-Encoding": "gzip",
        "Connection": "Keep-Alive",
        "dg_sid": client_id,
        "Host": "link.theplatform.eu",
        "session_id": client_id,
        "User-Agent": "okhttp/4.12.0"
    }

    oRequestHandler = cRequestHandler(sUrl)
    for key, value in headers.items():
        oRequestHandler.addHeaderEntry(key, value)
    sHtmlContent = oRequestHandler.request()

    oParser = cParser()        
    sPattern = r'<video src="([^"]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in aResult[1]:       
            url = aEntry
            if url.startswith('//'):
                url = f'http:{url}'

            sTitle = f'{sMovieTitle} [COLOR gold] Direct Link [/COLOR]'

            oOutputParameterHandler.addParameter('siteUrl', url)
            oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oGui.addLink(SITE_IDENTIFIER, 'showLinks', sTitle, sThumb, sTitle, oOutputParameterHandler)


    oGui.setEndOfDirectory()	

def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    sHosterUrl = sUrl
    oHoster = cHosterGui().checkHoster(sHosterUrl)
    if oHoster:
            oHoster.setDisplayName(sMovieTitle)
            oHoster.setFileName(sMovieTitle)
            cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()

def opensetting():
    addon().openSettings()

def generate_client_id():
    return str(uuid.uuid4())

def generate_user_id():
    return str(uuid.uuid4())