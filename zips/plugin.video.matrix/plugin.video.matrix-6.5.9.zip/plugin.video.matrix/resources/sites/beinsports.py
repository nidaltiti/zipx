﻿# -*- coding: utf-8 -*-

from datetime import datetime, timezone
import re, json
from urllib.parse import urlencode
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import VSlog, siteManager, addon
from resources.lib.util import urlHostName, QuoteThumb
from resources.lib import random_ua

UA = random_ua.get_random_ua()

SITE_IDENTIFIER = 'beinsports'
SITE_NAME = 'BeinSports'
SITE_DESC = 'sport vod'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

SPORT_FOOT = (f'{URL_MAIN}ar-mena', 'showGenres')
SPORT_SPORTS = (f'{URL_MAIN}ar-mena', 'showGenres')
SPORT_GENRES = (f'{URL_MAIN}ar-mena', 'showGenres')

URL_SEARCH = ('ar-mena/search?query=', 'showSports')
FUNCTION_SEARCH = 'showSports'

def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30330), 'search.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', SPORT_SPORTS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showGenres', 'Sports', 'genres.png', oOutputParameterHandler)    
            
    oGui.setEndOfDirectory()
  
def showSearch():
    oGui = cGui()
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
            sUrl = f'{URL_MAIN}ar-mena/search?query={sSearchText}'  
            showSports(QuoteThumb(sUrl))
            oGui.setEndOfDirectory()
            return  
        
def showGenres():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Host', urlHostName(URL_MAIN))
    sHtmlContent = oRequestHandler.request()

    sPattern = r'"buildId"\s*:\s*"([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)  
    if aResult[0] :
        build_id = aResult[1][0]

        jUrl = f"{URL_MAIN}_next/data/{build_id}/ar-mena/%D9%81%D9%8A%D8%AF%D9%8A%D9%88.json?page=%D9%81%D9%8A%D8%AF%D9%8A%D9%88"
        oRequestHandler = cRequestHandler(jUrl)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('Host', urlHostName(URL_MAIN))
        sHtmlContent = oRequestHandler.request(jsonDecode=True)

        try:
            qkey = 'getLayout({"queryParams":{},"regionLang":"ar-mena","slugArr":["فيديو"]})'
            items = sHtmlContent["pageProps"]["initialState"]["api"]["queries"][qkey]["data"]["items"]

            target = None
            for it in items:
                main_blocks = it.get("page_template", {}).get("main_blocks", [])
                if isinstance(main_blocks, list):
                    for block in main_blocks:
                        if "competition_and_sports" in block:
                            target = block["competition_and_sports"]
                            break
                if target:
                    break

            for comp in target:
                oOutputParameterHandler = cOutputParameterHandler() 
                siteUrl = f"https://prod-kontentadapter.{urlHostName(URL_MAIN).replace('www.', '')}/kp/domain/items/article"
                sCid = comp.get("_id")
                sTitle = comp.get("display_name")

                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sCid', sCid)
                oGui.addDir(SITE_IDENTIFIER, 'showSports', sTitle, 'genres.png', oOutputParameterHandler)
        
        except KeyError as e:
            VSlog("failed to parse", e)

    oGui.setEndOfDirectory() 

def showSports(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
        oInputParameterHandler = cInputParameterHandler()
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('Host', urlHostName(URL_MAIN))
        sHtmlContent = oRequestHandler.request()

        pattern = r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>'
        match = re.search(pattern, sHtmlContent, re.DOTALL)
        if match:
            jsonData = json.loads(match.group(1))

            items = jsonData["props"]["pageProps"]["initialState"]
            queries = items.get("searchApi", {}).get("queries", {})
            for key, val in queries.items():
                oOutputParameterHandler = cOutputParameterHandler()
                if key.startswith("getContentSearch"):
                    items = val.get("data", {}).get("NEWS", [])
                    for item in items:
                        article = item.get("articleData", {})
                        content_types = article.get("contentType", [])
                        videos = article.get("videos", [])
                        if "video" in content_types and videos:
                            if videos[0].get("url"):
                                sHosterUrl = videos[0]["url"]
                                sTitle = item.get("articleData", {}).get("title")
                                sDesc = item.get("articleData", {}).get("teaser")
                                sThumb = videos[0].get("thumbnail", "")

                        oOutputParameterHandler.addParameter('siteUrl', sHosterUrl)
                        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                        oOutputParameterHandler.addParameter('sThumb', sThumb)
                        oGui.addMisc(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

        sBase = oInputParameterHandler.getValue('sBase')
        if sBase:
            sUrl = sBase
        if not sBase:
            sBase = sUrl

        sToday = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")
        sCid = oInputParameterHandler.getValue('sCid')

        sSkip = oInputParameterHandler.getValue('sSkip')
        if not sSkip:
            sSkip = 0

        params = {
            "depth": 3,
            "limit": 12,
            "desiredLanguage": "ar-mena",
            "filterByLanguage": "ar-mena",
            "system.workflow_step[in]": "draft,published",
            "includeTotalCount": "true",
            "skip": sSkip,
            "order": "elements.publication_date[desc]",
            "elements": "title,teaser,video_manager,video_manager__video_manager",
            "elements.video_manager__video_manager[nempty]": "",
            "elements.tags_generator__main[all]": sCid,
            "elements.publication_date[lte]": sToday
        }
        query_string = urlencode(params)

        headers = {
            "accept": "application/json",
            "Origin": f"https://{urlHostName(URL_MAIN)}",
            "Referer": f"https://{urlHostName(URL_MAIN)}/",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0",
            "x-kp-api-key": "qwerty"
        }

        oRequestHandler = cRequestHandler(f"{sUrl}?{query_string}")
        for key, value in headers.items():
            oRequestHandler.addHeaderEntry(key, value)
        sHtmlContent = oRequestHandler.request(jsonDecode=True)

        for item in sHtmlContent["items"]:
            oOutputParameterHandler = cOutputParameterHandler() 
            sTitle = item.get("title")
            sDesc = item.get("teaser")

            vm_raw = item.get("video_manager", {}).get("video_manager__video_manager")
            videos = json.loads(vm_raw) if vm_raw else []

            sUrl = ''
            sThumb = ''
            if videos:
                sUrl = videos[0].get("url")
                sThumb = videos[0].get("thumbnail")
                
                oOutputParameterHandler.addParameter('siteUrl', sUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oGui.addMisc(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        pagination = sHtmlContent.get("pagination", {})
        if pagination["has_next_page"]: 
            next_skip = pagination["skip"] + pagination["limit"]
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sSkip', next_skip)
            oOutputParameterHandler.addParameter('sBase', sBase)
            oOutputParameterHandler.addParameter('sCid', sCid)
            oGui.addDir(SITE_IDENTIFIER, 'showSports', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()
   
def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sHosterUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
            
    results = []
    results.append((SITE_NAME, sHosterUrl))

    useDialog = addon().getSetting('HosterDialog') == 'true'
    if useDialog and results:
        cHosterGui().selectHoster(results, sMovieTitle, SITE_NAME, sThumb)
    else:
        for sTitle, sHosterUrl in results:
            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

        oGui.setEndOfDirectory()