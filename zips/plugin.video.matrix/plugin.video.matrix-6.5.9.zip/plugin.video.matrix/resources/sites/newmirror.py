﻿# -*- coding: utf-8 -*-

import re
import xbmcgui
import six
import time
import json
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, addon
from resources.lib.util import urlHostName

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0 /OS.GatuNewTV v1.0"

addons = addon()

SITE_IDENTIFIER = 'newmirror'
SITE_NAME = 'NewMirror Revamped'
SITE_DESC = 'multi audio vod'

URL_MAIN = 'https://net22.cc/newtv/'

# URL_MAIN = base64.b64decode(URL_MAIN).decode("utf-8")[::-1]
IMG_MAIN = 'https://imgcdn.kim/'

HEADERS = {
            "accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip",
            "cache-control": "no-cache, no-store, must-revalidate",
            "Connection": "Keep-Alive",
            "expires": "0",
            "Host": urlHostName(URL_MAIN),
            "pragma": "no-cache",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0 /OS.Gatu v1.0",
            "x-requested-with":"NetmirrorNewTV v1.0"
            }

MOVIE_EN = ('', 'showPack')
MOVIE_NETFLIX = ('nf', 'showMovies')
SERIE_EN = ('show', 'showSeriesPack')

URL_SEARCH_MOVIES = (URL_MAIN + 'search.php?s=', 'showSearchAll')
URL_SEARCH_SERIES = (URL_MAIN + 'search.php?s=', 'showSearchAll')
FUNCTION_SEARCH = 'showMovies'
	
def load():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showPack', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_NETFLIX[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام نتفلكس', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesPack', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def set_setting(id, value):
    if not isinstance(value, six.string_types):
        value = str(value)
    addons.setSetting(id, value)

def bypass():
    try:
        last_gen = int(addons.getSetting('newmirror_token_create'))
    except Exception:
        last_gen = 0

    if not addons.getSetting('newmirror_token') or last_gen < (time.time() - (1 * 15 * 60 * 60)):
        oRequestHandler = cRequestHandler(f"{URL_MAIN}otp.php")
        oRequestHandler.addHeaderEntry('otp', '111111')
        for key, value in HEADERS.items():
            oRequestHandler.addHeaderEntry(key, value)
        response = oRequestHandler.request()
        usertoken = json.loads(response).get('usertoken')

        set_setting('newmirror_token', usertoken)
        set_setting('newmirror_token_create', str(int(time.time()))) 
        return usertoken

    else:
       return(addons.getSetting('newmirror_token'))

def showSearch():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        oOutputParameterHandler.addParameter('sType', 'movie')
        sUrl = f'{URL_MAIN}search.php?s={sSearchText}'
        showSearchAll(sUrl)
        oGui.setEndOfDirectory()
        return  
    
def showSeriesSearch():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        oOutputParameterHandler.addParameter('sType', 'show')
        sUrl = f'{URL_MAIN}search.php?s={sSearchText}'
        showSearchAll(sUrl)
        oGui.setEndOfDirectory()
        return  

def showPack():
    oGui = cGui()
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'nf')
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'Netflix Section', 'neflix.png', oOutputParameterHandler)
    oOutputParameterHandler.addParameter('siteUrl', 'hs')
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'Disney Section', 'agnab.png', oOutputParameterHandler)
    oOutputParameterHandler.addParameter('siteUrl', 'pv')
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'PrimeVideo Section', 'agnab.png', oOutputParameterHandler)
 
    oGui.setEndOfDirectory()

def showSeriesPack():
    oGui = cGui()
    
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'nf')
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'Netflix Section', 'neflix.png', oOutputParameterHandler)
    oOutputParameterHandler.addParameter('siteUrl', 'hs')
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'Disney Section', 'agnab.png', oOutputParameterHandler)
    oOutputParameterHandler.addParameter('siteUrl', 'pv')
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'PrimeVideo Section', 'agnab.png', oOutputParameterHandler)
 
    oGui.setEndOfDirectory()

def showSearchAll(sSearch = ''):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()

    sType = oInputParameterHandler.getValue('sType')
    if sSearch:
        oOutputParameterHandler = cOutputParameterHandler()
        for ott in ['nf', 'hs', 'pv']:
            oRequestHandler = cRequestHandler(sSearch)
            for key, value in HEADERS.items():
                oRequestHandler.addHeaderEntry(key, value)
            oRequestHandler.addHeaderEntry('ott', ott)
            oRequestHandler.enableCache(False)
            response = oRequestHandler.request()
            data = json.loads(response)
            if 'searchResult' in data and data['searchResult']:
                for key in data['searchResult']:

                    siteUrl = f"{URL_MAIN}player.php?id={key['id']}"
                    sThumb = f"{IMG_MAIN}poster/h/{key['id']}.jpg"
                    if ott == 'pv':
                        sThumb = f"{IMG_MAIN}pv/h/{key['id']}.jpg"
                    if ott == 'hs':
                        sThumb = f"{IMG_MAIN}hs/h/{key['id']}.jpg"   
                    sTitle = key['t']
                    sDesc = ''

                    oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                    oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                    oOutputParameterHandler.addParameter('sThumb', sThumb)
                    oOutputParameterHandler.addParameter('ott', ott)

                    if sType == 'movie':
                        oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
                    else:
                        siteUrl = f"{URL_MAIN}post.php?id={key['id']}"
                        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                        oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()  

def showMovies(sSearch = ''):
    oGui = cGui()
    usertoken = bypass()

    oInputParameterHandler = cInputParameterHandler()
    oOutputParameterHandler = cOutputParameterHandler()
    ott = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(f"{URL_MAIN}main.php")
    for key, value in HEADERS.items():
        oRequestHandler.addHeaderEntry(key, value)
    oRequestHandler.addHeaderEntry('usertoken', usertoken)
    if ott == 'hs':
        oRequestHandler.addHeaderEntry('page', 'all')
    else:
        oRequestHandler.addHeaderEntry('page', 'movie')
    oRequestHandler.addHeaderEntry('ott', ott)
    oRequestHandler.enableCache(False)
    response = oRequestHandler.request()
    data = json.loads(response)

    img_referer = data.get("img_referer", "")

    listitems = [item.get("cate") for item in data.get("post", [])]
    
    index = xbmcgui.Dialog().select("Select Category", listitems)
    if index != -1:
        selected_category = listitems[index]

    for item in data.get("post", []):
        if item.get("cate") == selected_category:
            ids = item.get("ids", "")
            ids_list = ids.split(",") if ids else []

    for aEntry in ids_list:

        sThumb = f"{IMG_MAIN}poster/h/{aEntry}.jpg"
        if ott == 'pv':
            sThumb = f"{IMG_MAIN}pv/h/{aEntry}.jpg"
        if ott == 'hs':
            sThumb = f"{IMG_MAIN}hs/h/{aEntry}.jpg"   
        sMovie = f'{URL_MAIN}post.php?id={aEntry}'
        oRequestHandler = cRequestHandler(sMovie)
        for key, value in HEADERS.items():
            oRequestHandler.addHeaderEntry(key, value)
        oRequestHandler.addHeaderEntry('usertoken', usertoken)
        oRequestHandler.addHeaderEntry('ott', ott)
        response = oRequestHandler.request()
        data = json.loads(response)
        if data['type'] == 't':
            continue
        sTitle = data['title']
        siteUrl = f'{URL_MAIN}player.php?id={aEntry}'
        sDesc = ''

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('ott', ott)

        oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()  

def showSeries(sSearch = ''):
    oGui = cGui()
    usertoken = bypass()

    oInputParameterHandler = cInputParameterHandler()
    oOutputParameterHandler = cOutputParameterHandler()
    ott = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(f"{URL_MAIN}main.php")
    for key, value in HEADERS.items():
        oRequestHandler.addHeaderEntry(key, value)
    oRequestHandler.addHeaderEntry('usertoken', usertoken)
    if ott == 'hs':
        oRequestHandler.addHeaderEntry('page', 'all')
    else:
        oRequestHandler.addHeaderEntry('page', 'show')
    oRequestHandler.addHeaderEntry('ott', ott)
    oRequestHandler.enableCache(False)
    response = oRequestHandler.request()
    data = json.loads(response)

    img_referer = data.get("img_referer", "")

    listitems = [item.get("cate") for item in data.get("post", [])]
    
    index = xbmcgui.Dialog().select("Select Category", listitems)
    if index != -1:
        selected_category = listitems[index]

    for item in data.get("post", []):
        if item.get("cate") == selected_category:
            ids = item.get("ids", "")
            ids_list = ids.split(",") if ids else []

    for aEntry in ids_list:

        sThumb = f"{IMG_MAIN}poster/h/{aEntry}.jpg"
        if ott == 'pv':
            sThumb = f"{IMG_MAIN}pv/h/{aEntry}.jpg"
        if ott == 'hs':
            sThumb = f"{IMG_MAIN}hs/h/{aEntry}.jpg"   
        siteUrl = f'{URL_MAIN}post.php?id={aEntry}'
        oRequestHandler = cRequestHandler(siteUrl)
        for key, value in HEADERS.items():
            oRequestHandler.addHeaderEntry(key, value)
        oRequestHandler.addHeaderEntry('usertoken', usertoken)
        oRequestHandler.addHeaderEntry('ott', ott)
        response = oRequestHandler.request()
        data = json.loads(response)
        if data['type'] != 't':
            continue
        sTitle = data['title']
        sDesc = ''

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('ott', ott)
        oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()  

def showSeasons():
    oGui = cGui()
    usertoken = bypass()

    oOutputParameterHandler = cOutputParameterHandler()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    ott = oInputParameterHandler.getValue('ott')
    
    oRequestHandler = cRequestHandler(sUrl)
    for key, value in HEADERS.items():
        oRequestHandler.addHeaderEntry(key, value)
    oRequestHandler.addHeaderEntry('usertoken', usertoken)
    oRequestHandler.addHeaderEntry('ott', ott)
    response = oRequestHandler.request()
    data = json.loads(response)

    if data['type'] != 't':
        oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
        oOutputParameterHandler.addParameter('ott', ott)
        oOutputParameterHandler.addParameter('siteUrl', sUrl.replace('post.php?id=', 'player.php?id='))
        oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sMovieTitle, '', sThumb, '', oOutputParameterHandler)
    else:
        if 'season' in data and data['season']:
            for key in data['season']:
                sSeason = key['s']
                siteUrl = f"{URL_MAIN}episodes.php?id={key['id']}"      
                sTitle = data['title']
                sTitle = f'{sTitle} {sSeason}'
                sDesc = data['desc']
                    
                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sDesc', sDesc)
                oOutputParameterHandler.addParameter('ott', ott)

                oGui.addSeason(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        else:
            oGui.addText(SITE_IDENTIFIER, '[COLOR orange]تعذر الحصول على موسم - جرب البحث في الأفلام[/COLOR]')

    oGui.setEndOfDirectory() 
        
def showEpisodes():
    oGui = cGui()
    usertoken = bypass()

    oOutputParameterHandler = cOutputParameterHandler()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sDesc = oInputParameterHandler.getValue('sDesc')
    ott = oInputParameterHandler.getValue('ott')

    oRequestHandler = cRequestHandler(sUrl)
    for key, value in HEADERS.items():
        oRequestHandler.addHeaderEntry(key, value)
    oRequestHandler.addHeaderEntry('usertoken', usertoken)
    oRequestHandler.addHeaderEntry('ott', ott)
    response = oRequestHandler.request()
    data = json.loads(response)
    for key in data['episodes']:
        sEpisode = key['ep']
        siteUrl = f"{URL_MAIN}player.php?id={key['id']}"
        sMovieTitle = re.sub(r"\([^)]*\)", "", sMovieTitle)
        sTitle = f'{sMovieTitle} E{sEpisode}'
        sDesc = sDesc

        oOutputParameterHandler.addParameter('siteUrl',siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('ott', ott)

        oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, sThumb, sThumb, sDesc, oOutputParameterHandler)

    sPage = int(data['nextPageShow'])
    if sPage > 0: 
            siteUrl = f'{URL_MAIN}episodes.php?id={data["nextPageSeason"]}&page={data["nextPage"]}'
            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('ott', ott)
            oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oGui.addDir(SITE_IDENTIFIER, 'showEpisodes', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory() 

def showHosters():
    oGui = cGui()
    usertoken = bypass()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    ott = oInputParameterHandler.getValue('ott')

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    oRequestHandler = cRequestHandler(sUrl)
    for key, value in HEADERS.items():
        oRequestHandler.addHeaderEntry(key, value)
    oRequestHandler.addHeaderEntry('usertoken', usertoken)
    oRequestHandler.addHeaderEntry('ott', ott)
    response = oRequestHandler.request()

    data = json.loads(response)

    sReferer = data.get("referer")
    sHosterUrl = data.get("video_link") + f'|Referer={sReferer}&X-Requested-With=NetmirrorNewTV v1.0'
    
    results.append((SITE_NAME, sHosterUrl))

    if useDialog and results:
        cHosterGui().selectHoster(results, sMovieTitle, SITE_NAME, sThumb)
    else:
        for sTitle, sHosterUrl in results:
            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

        oGui.setEndOfDirectory()
