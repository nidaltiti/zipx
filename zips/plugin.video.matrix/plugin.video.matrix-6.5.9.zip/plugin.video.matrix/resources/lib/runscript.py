# -*- coding: utf-8 -*-
# vStream https://github.com/Kodi-vStream/venom-xbmc-addons

import json
import xbmcvfs
import xbmc
import xbmcgui
import sys

import os, shutil
from requests.auth import HTTPBasicAuth

import urllib.request as urllib2
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import addon, dialog, VSlog, window, VSPath, siteManager

try:
    from sqlite3 import dbapi2 as sqlite
    VSlog('SQLITE 3 as DB engine')
except:
    from pysqlite2 import dbapi2 as sqlite
    VSlog('SQLITE 2 as DB engine')

SITE_IDENTIFIER = 'runscript'
SITE_NAME = 'runscript'

class cClear:

    DIALOG = dialog()
    ADDON = addon()

    def __init__(self):
        self.main(sys.argv[1])

    def main(self, env):

        if (env == 'resolveurl'):
            addon('script.module.resolveurl').openSettings()
            return

        if (env == 'metahandler'):
            addon('script.module.metahandler').openSettings()
            return

        if (env == 'changelog_old'):
            addons = addon()

            try:
                addon_path = VSPath(addons.getAddonInfo('path')).decode("utf-8")
                changelog_file = VSPath(addon_path + 'changelog.txt').decode("utf-8")
            except AttributeError:
                addon_path = VSPath(addons.getAddonInfo('path'))
                changelog_file = VSPath(addon_path + 'changelog.txt')

            try:
                with open(changelog_file, 'r', encoding='utf-8') as f:
                    sContent = f.read()
                self.TextBoxes('[B][COLOR gold]matrix Changelog[/COLOR][/B]', sContent)
            except Exception as e:
                self.DIALOG.VSerror("Failed to load changelog: %s" % str(e))

        if (env == 'changelog'):

            sUrl = 'https://api.github.com/repos/matrix/Dist/commits'
            try:
                oRequest = urllib2.Request(sUrl)
                oResponse = urllib2.urlopen(oRequest)

                if xbmc.getInfoLabel('system.buildversion')[0:2] >= '19':
                    sContent = oResponse.read().decode('utf-8')
                else:
                    sContent = oResponse.read()

                result = json.loads(sContent)
                detailitems = []

                for item in result:
                    login = item['author']['login']
                    try:
                        desc = item['commit']['message']
                    except:
                        desc = 'None'
            
                    detailitems.append(desc)

                    cClear.TextBoxes(self, f'[B][COLOR gold]{login}[/COLOR][/B]', "\n\n".join(map(str, detailitems)))
            except:
                self.DIALOG.VSerror("%s, %s" % (self.ADDON.VSlang(30205), sUrl))
            return

        if (env == 'soutient'):
            sUrl = 'https://matrix1.vercel.app/repo/plugin.video.matrix/soutient.txt'
            try:
                oRequest = urllib2.Request(sUrl)
                oResponse = urllib2.urlopen(oRequest)

                # En python 3 on doit décoder la reponse
                if xbmc.getInfoLabel('system.buildversion')[0:2] >= '19':
                    sContent = oResponse.read().decode('utf-8')
                else:
                    sContent = oResponse.read()

                self.TextBoxes('matrix Soutient', sContent)
            except:
                self.DIALOG.VSerror("%s, %s" % (self.ADDON.VSlang(30205), sUrl))
            return

        if (env == 'clean'):
            liste = ['Search history', 'Marque-Pages', 'Now Playing',
                     'Readings', 'Tagged views', 'Downloads']
            ret = self.DIALOG.VSselect(liste, self.ADDON.VSlang(30110))
            cached_DB = "special://home/userdata/addon_data/plugin.video.matrix/matrix.db"
            # important seul xbmcvfs peux lire le special
            try:
                cached_DB = VSPath(cached_DB).decode("utf-8")
            except AttributeError:
                cached_DB = VSPath(cached_DB)

            sql_drop = ""

            if ret > -1:

                if ret == 0:
                    sql_drop = 'DELETE FROM history'
                elif ret == 1:
                    sql_drop = 'DELETE FROM favorite'
                elif ret == 2:
                    sql_drop = 'DELETE FROM viewing'
                elif ret == 3:
                    sql_drop = 'DELETE FROM resume'
                elif ret == 4:
                    sql_drop = 'DELETE FROM watched'
                elif ret == 5:
                    sql_drop = 'DELETE FROM download'

                try:
                    db = sqlite.connect(cached_DB)
                    dbcur = db.cursor()
                    dbcur.execute(sql_drop)
                    db.commit()
                    dbcur.close()
                    db.close()
                    self.DIALOG.VSok(self.ADDON.VSlang(30090))
                except Exception as err:
                    self.DIALOG.VSerror(self.ADDON.VSlang(30091))
                    VSlog("Exception runscript sql_drop: {0}".format(err))
            return

        # activer toutes les sources
        if (env == 'enableSources'):
            if self.DIALOG.VSyesno(self.ADDON.VSlang(30456)):
                useUserJson = self.ADDON.getSetting('setting_use_userjson') == 'true'
                sitesManager = siteManager(useUserJson=useUserJson)
                sitesManager.enableAll()
                sitesManager.save()
                self.DIALOG.VSinfo(self.ADDON.VSlang(30014))

            return


        # désactiver toutes les sources
        if (env == 'disableSources' or env == 'disableSourcesSilent'):
            if env == 'disableSources' and not self.DIALOG.VSyesno(self.ADDON.VSlang(30456)):
                return

            useUserJson = self.ADDON.getSetting('setting_use_userjson') == 'true'
            sitesManager = siteManager(useUserJson=useUserJson)
            sitesManager.disableAll()
            sitesManager.save()
            self.DIALOG.VSinfo(self.ADDON.VSlang(30014))

            return


        # Updates Sites
        if (env == 'updatesites'):
            if self.DIALOG.VSyesno(self.ADDON.VSlang(30473)):
                import datetime
                addons = addon()
                time_now = datetime.datetime.now()
                sUrl = 'https://matrix1.vercel.app/repo/plugin.video.matrix/resources/sites.json'
                oRequestHandler = cRequestHandler(sUrl)
                properties = oRequestHandler.request(jsonDecode=True)
                if properties == "":
                    return
                # Always update the default repo file (sites.json), not user.json
                siteManager(useUserJson=False).setUserProps(properties)

                addons.setSetting('setting_time', str(time_now))

                self.DIALOG.VSinfo(self.ADDON.VSlang(30014))

            return

        # Updates Hosters
        if (env == 'updatehosters'):
            addons = addon()
            sUrl = 'https://matrix1.vercel.app/repo/plugin.video.matrix/resources/lib/gui/hoster.py'
            file_path = VSPath('special://home/addons/plugin.video.matrix/resources/lib/gui/hoster.py')
            if self.DIALOG.VSyesno(self.ADDON.VSlang(30456)):
                oRequestHandler = cRequestHandler(sUrl)
                sHosts = oRequestHandler.request()
                if sHosts == "":
                    return
                with open(file_path, 'w') as f:
                    f.write(sHosts)

                self.DIALOG.VSinfo(self.ADDON.VSlang(70021))

                return

        # aciver/désactiver les sources
        if (env == 'search'):

            from resources.lib.handler.pluginHandler import cPluginHandler
            valid = '[COLOR green][x][/COLOR]'

            class XMLDialog(xbmcgui.WindowXMLDialog):

                ADDON = addon()
                useUserJson = addon().getSetting('setting_use_userjson') == 'true'
                sitesManager = siteManager(useUserJson=useUserJson)
                
                def __init__(self, *args, **kwargs):
                    xbmcgui.WindowXMLDialog.__init__(self)
                    pass

                def onInit(self):

                    self.container = self.getControl(6)
                    self.button = self.getControl(5)
                    self.getControl(3).setVisible(False)
                    self.getControl(1).setLabel(self.ADDON.VSlang(30094))
                    self.button.setLabel('OK')
                    listitems = []
                    oPluginHandler = cPluginHandler()
                    aPlugins = oPluginHandler.getAllPlugins()

                    #self.data = json.load(open(self.path))

                    for aPlugin in aPlugins:
                        # teste si deja dans le dsip
                        sPluginName = aPlugin[1]
                        isActive = self.sitesManager.isActive(sPluginName)
                        icon = "special://home/addons/plugin.video.matrix/resources/art/sites/%s.png" % sPluginName
                        stitle = self.sitesManager.getProperty(sPluginName, self.sitesManager.LABEL)

                        if isActive:
                            stitle = ('%s %s') % (stitle, valid)
                        listitem = xbmcgui.ListItem(label=stitle, label2=aPlugin[2])
                        listitem.setArt({'icon': icon, 'thumb': icon})
                        listitem.setProperty('Addon.Summary', aPlugin[2])
                        listitem.setProperty('sitename', aPlugin[1])
                        if isActive:
                            listitem.select(True)

                        listitems.append(listitem)
                    self.container.addItems(listitems)
                    self.setFocus(self.container)

                def onClick(self, controlId):
                    if controlId == 5:       # OK
                        self.sitesManager.save()
                        self.close()
                        return
                    elif controlId == 99:
                        window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
                        del window
                        self.close()
                        return
                    elif controlId == 7:
                        window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
                        del window
                        self.close()
                        return
                    elif controlId == 6:
                        item = self.container.getSelectedItem()
                        if item.isSelected() == True:
                            label = item.getLabel().replace(valid, '')
                            item.setLabel(label)
                            item.select(False)
                            sPluginSettingsName = item.getProperty('sitename')
                            self.sitesManager.setActive(sPluginSettingsName, False)
                        else:
                            label = ('%s %s') % (item.getLabel(), valid)
                            item.setLabel(label)
                            item.select(True)
                            sPluginSettingsName = item.getProperty('sitename')
                            self.sitesManager.setActive(sPluginSettingsName, True)
                        return

                def onFocus(self, controlId):
                    self.controlId = controlId

            path = "special://home/addons/plugin.video.matrix"
            wd = XMLDialog('DialogSelect.xml', path, "Default")
            wd.doModal()
            del wd
            return

        # Set Protected / Unprotected Site
        if (env == 'cloudflare'):

            from resources.lib.handler.pluginHandler import cPluginHandler
            valid = '[COLOR red][Cloudflare][/COLOR]'

            class XMLDialog(xbmcgui.WindowXMLDialog):

                ADDON = addon()
                useUserJson = addon().getSetting('setting_use_userjson') == 'true'
                sitesManager = siteManager(useUserJson=useUserJson)
                
                def __init__(self, *args, **kwargs):
                    xbmcgui.WindowXMLDialog.__init__(self)
                    pass

                def onInit(self):

                    self.container = self.getControl(6)
                    self.button = self.getControl(5)
                    self.getControl(3).setVisible(False)
                    self.getControl(1).setLabel(self.ADDON.VSlang(30094))
                    self.button.setLabel('OK')
                    listitems = []
                    oPluginHandler = cPluginHandler()
                    aPlugins = oPluginHandler.getAllPlugins()

                    for aPlugin in aPlugins:
                        sPluginName = aPlugin[1]
                        isCloudFlare = self.sitesManager.isCloudFlare(sPluginName)
                        icon = "special://home/addons/plugin.video.matrix/resources/art/sites/%s.png" % sPluginName
                        stitle = self.sitesManager.getProperty(sPluginName, self.sitesManager.LABEL)

                        if isCloudFlare:
                            stitle = ('%s %s') % (stitle, valid)
                        listitem = xbmcgui.ListItem(label=stitle, label2=aPlugin[2])
                        listitem.setArt({'icon': icon, 'thumb': icon})
                        listitem.setProperty('Addon.Summary', aPlugin[2])
                        listitem.setProperty('sitename', aPlugin[1])
                        if isCloudFlare:
                            listitem.select(True)

                        listitems.append(listitem)
                    self.container.addItems(listitems)
                    self.setFocus(self.container)

                def onClick(self, controlId):
                    if controlId == 5:       # OK
                        self.sitesManager.save()
                        self.close()
                        return
                    elif controlId == 99:
                        window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
                        del window
                        self.close()
                        return
                    elif controlId == 7:
                        window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
                        del window
                        self.close()
                        return
                    elif controlId == 6:
                        item = self.container.getSelectedItem()
                        if item.isSelected() == True:
                            label = item.getLabel().replace(valid, '')
                            item.setLabel(label)
                            item.select(False)
                            sPluginSettingsName = item.getProperty('sitename')
                            self.sitesManager.setCloudFlare(sPluginSettingsName, False)
                        else:
                            label = ('%s %s') % (item.getLabel(), valid)
                            item.setLabel(label)
                            item.select(True)
                            sPluginSettingsName = item.getProperty('sitename')
                            self.sitesManager.setCloudFlare(sPluginSettingsName, True)
                        return

                def onFocus(self, controlId):
                    self.controlId = controlId

            path = "special://home/userdata/addon_data/plugin.video.matrix"
            wd = XMLDialog('DialogSelect.xml', path, "Default")
            wd.doModal()
            del wd
            return

        # Update Site Links
        if (env == 'sitelink'):

            from resources.lib.handler.pluginHandler import cPluginHandler
            from resources.lib.gui.gui import cGui
            valid = '[COLOR red][Cloudflare][/COLOR]'
            oGui = cGui()
            
            class XMLDialog(xbmcgui.WindowXMLDialog):

                ADDON = addon()
                sitesManager = siteManager(useUserJson=True)
                
                def __init__(self, *args, **kwargs):
                    xbmcgui.WindowXMLDialog.__init__(self)
                    pass

                def onInit(self):

                    self.container = self.getControl(6)
                    self.button = self.getControl(5)
                    self.getControl(3).setVisible(False)
                    self.getControl(1).setLabel(self.ADDON.VSlang(30094))
                    self.button.setLabel('OK')
                    listitems = []
                    oPluginHandler = cPluginHandler()
                    aPlugins = oPluginHandler.getAllPlugins()

                    for aPlugin in aPlugins:
                        sPluginName = aPlugin[1]
                        siteURL = self.sitesManager.getUrlMain(sPluginName)
                        icon = "special://home/addons/plugin.video.matrix/resources/art/sites/%s.png" % sPluginName
                        stitle = self.sitesManager.getProperty(sPluginName, self.sitesManager.LABEL)
                        listitem = xbmcgui.ListItem(label=stitle, label2=siteURL)
                        listitem.setArt({'icon': icon, 'thumb': icon})
                        listitem.setProperty('Addon.Summary', aPlugin[2])
                        listitem.setProperty('sitename', aPlugin[1])
                        listitems.append(listitem)

                    self.container.addItems(listitems)
                    self.setFocus(self.container)

                def onClick(self, controlId):
                    if controlId == 5:       # OK
                        self.sitesManager.save()
                        self.close()
                        return
                    elif controlId == 99:
                        window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
                        del window
                        self.close()
                        return
                    elif controlId == 7:
                        window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
                        del window
                        self.close()
                        return
                    elif controlId == 6:
                        item = self.container.getSelectedItem()
                        sNewUrl = oGui.showKeyBoard(sDefaultText=self.sitesManager.getUrlMain(item.getProperty('sitename')))
                        if sNewUrl:
                            item.setLabel2(sNewUrl)
                            item.select(True)
                            sPluginSettingsName = item.getProperty('sitename')
                            self.sitesManager.setUrlMain(sPluginSettingsName, sNewUrl)
                            return

                def onFocus(self, controlId):
                    self.controlId = controlId

            path = "special://home/userdata/addon_data/plugin.video.matrix"
            wd = XMLDialog('DialogSelect.xml', path, "Default")
            wd.doModal()
            del wd
            return

        if (env == 'refreshuserjson'):
            if self.DIALOG.VSyesno(self.ADDON.VSlang(30474)):
                try:
                    defaultPath = VSPath('special://home/addons/plugin.video.matrix/resources/sites.json')
                    with open(defaultPath, 'r') as f:
                        defaultData = json.load(f)

                    userPath = VSPath('special://home/userdata/addon_data/plugin.video.matrix/user.json')
                    with open(userPath, 'w') as f:
                        f.write(json.dumps(defaultData, indent=4))

                    self.DIALOG.VSinfo(self.ADDON.VSlang(30015))

                except Exception as e:
                    xbmc.log("Failed to refresh user.json: " + str(e), xbmc.LOGERROR)
                    self.DIALOG.VSinfo("Error refreshing user.json")

            return

        if (env == 'stalker'):
            from resources.lib import set_stalker
            set_stalker.setpvrstalker()
            return

        if (env == 'sauv'):
            select = self.DIALOG.VSselect(['Import', 'Export'])
            DB = "special://home/userdata/addon_data/plugin.video.matrix/matrix.db"
            if select >= 0:
                try:
                    if select == 0:
                        # sélection d'un fichier
                        new = self.DIALOG.VSbrowse(1, 'matrix', "files")
                        if new:
                            xbmcvfs.delete(DB)
                            xbmcvfs.copy(new, DB)
                            self.DIALOG.VSinfo(self.ADDON.VSlang(30099))
                    elif select == 1:
                        # sélection d'un répertoire
                        new = self.DIALOG.VSbrowse(3, 'matrix', "files")
                        if new:
                            xbmcvfs.copy(DB, new + 'matrix.db')
                            self.DIALOG.VSinfo(self.ADDON.VSlang(30099))
                except:
                    self.DIALOG.VSerror(self.ADDON.VSlang(30100))

                return

        if (env == 'cache'):
            if self.DIALOG.VSyesno(self.ADDON.VSlang(30456)):
                from requests_cache import CachedSession
                CACHE = 'special://home/userdata/addon_data/plugin.video.matrix/requests_cache.db'
                session = CachedSession(VSPath(CACHE))
                try:
                    session.cache.clear()
                    self.DIALOG.VSok(self.ADDON.VSlang(30089))
                except:
                    self.DIALOG.VSerror(self.ADDON.VSlang(30096))
            return

        if (env == 'testpremium'): 
            from resources.lib.gui.hoster import cHosterGui
            oHoster = cHosterGui().getHoster("alldebrid")
            oHoster.testPremium()
            return


        if (env == 'resolverupdate'): 
            import zipfile

            def removeFilesNotInRepo(updateFile, LocalDir):
                ignored_files = ['settings.xml']
                updateFileNameList = [i.split("/")[-1] for i in updateFile.namelist()]

                for root, dirs, files in os.walk(LocalDir):
                    if ".git" in root or "pydev" in root or ".idea" in root:
                        continue
                    for file in files:
                        if file in ignored_files:
                            continue
                        if file not in updateFileNameList:
                            os.remove(os.path.join(root, file))

            def doUpdate(LocalDir, REMOTE_PATH, localFileName):
                try:
                    oRequestHandler = cRequestHandler(REMOTE_PATH)
                    response = oRequestHandler.request()
                    if response:
                        with open(localFileName, "wb") as f:
                            f.write(response)
                    else:
                        return False

                    updateFile = zipfile.ZipFile(localFileName)
                    removeFilesNotInRepo(updateFile, LocalDir)

                    for n in updateFile.namelist():
                        if n[-1] != "/":
                            dest = os.path.join(LocalDir, "/".join(n.split("/")[1:]))
                            destdir = os.path.dirname(dest)
                            if not os.path.isdir(destdir):
                                os.makedirs(destdir)
                            data = updateFile.read(n)
                            if os.path.exists(dest):
                                os.remove(dest)
                            with open(dest, 'wb') as f:
                                f.write(data)

                    updateFile.close()
                    os.remove(localFileName)
                    xbmc.executebuiltin("UpdateLocalAddons()")
                    return True
                except Exception as e:
                    VSlog(f'doUpdate failed: {e}')
                    return False

            def commitUpdate(onlineFile, offlineFile, downloadLink, LocalDir, localFileName):
                try:
                    jsData = json.loads(onlineFile)
                    if not os.path.exists(offlineFile) or open(offlineFile).read() != jsData['sha']:
                        VSlog('Started updating!')
                        isTrue = doUpdate(LocalDir, downloadLink, localFileName)
                        if isTrue:
                            try:
                                with open(offlineFile, 'w') as f:
                                    f.write(jsData['sha'])
                                return True
                            except Exception as e:
                                VSlog(f'Failed to write sha: {e}')
                                return False
                        else:
                            return False
                    else:
                        return None
                except Exception as e:
                    if os.path.exists(offlineFile):
                        os.remove(offlineFile)
                    VSlog(f'commitUpdate failed: {e}')
                    return False

            def _getXmlString(xml_url):
                try:
                    oRequestHandler = cRequestHandler(xml_url)
                    xmlString = oRequestHandler.request()
                    if "sha" in json.loads(xmlString):
                        return xmlString
                    else:
                        VSlog('Update-URL incorrect')
                except Exception as e:
                    VSlog(f'_getXmlString failed: {e}')
                return None

            username = 'Gujal00'
            resolve_dir = 'ResolveURL'
            resolve_id = 'script.module.resolveurl'
            REMOTE_PLUGIN_COMMITS = f"https://api.github.com/repos/{username}/{resolve_dir}/commits/master"
            REMOTE_PLUGIN_DOWNLOADS = f"https://api.github.com/repos/{username}/{resolve_dir}/zipball/master"
            PACKAGES_PATH = VSPath(os.path.join('special://home/addons/packages/'))
            ADDON_PATH = VSPath(os.path.join('special://home/addons/packages/', resolve_id))
            INSTALL_PATH = VSPath(os.path.join('special://home/addons/', resolve_id))

            VSlog(f"{resolve_id} - Search for updates.")
            try:
                ADDON_DIR = VSPath(os.path.join('special://userdata/addon_data/', resolve_id))
                LOCAL_PLUGIN_VERSION = os.path.join(ADDON_DIR, "update_sha")
                LOCAL_FILE_NAME_PLUGIN = os.path.join(ADDON_DIR, f'update-{resolve_id}.zip')
                if not os.path.exists(ADDON_DIR):
                    os.mkdir(ADDON_DIR)

                if os.path.exists(LOCAL_PLUGIN_VERSION):
                    os.remove(LOCAL_PLUGIN_VERSION)

                commitXML = _getXmlString(REMOTE_PLUGIN_COMMITS)
                if commitXML:
                    isTrue = commitUpdate(commitXML, LOCAL_PLUGIN_VERSION, REMOTE_PLUGIN_DOWNLOADS,
                                        PACKAGES_PATH, LOCAL_FILE_NAME_PLUGIN)

                    if isTrue is True:
                        VSlog(f"{resolve_id} - download new update.")
                        shutil.make_archive(ADDON_PATH, 'zip', ADDON_PATH)
                        shutil.unpack_archive(ADDON_PATH + '.zip', INSTALL_PATH)
                        VSlog(f"{resolve_id} - install new update.")
                        if os.path.exists(ADDON_PATH + '.zip'):
                            os.remove(ADDON_PATH + '.zip')
                        self.DIALOG.VSinfo(f"{resolve_id} updated successfully!")
                        return
                    elif isTrue is None:
                        VSlog(f"{resolve_id} - no update available.")
                        return

                VSlog(f"{resolve_id} - Error updating!")
                self.DIALOG.VSinfo(f"Error updating {resolve_id}")
                return
            except Exception as e:
                VSlog(f"{resolve_id} - Exception: {e}")
                self.DIALOG.VSinfo(f"Error updating {resolve_id}")
                return

        if (env == 'addon' or env == 'cleanAll'): # Clear the metadata cache
            if env == 'cleanAll' or self.DIALOG.VSyesno(self.ADDON.VSlang(30456)):
                cached_Cache = "special://home/userdata/addon_data/plugin.video.matrix/video_cache.db"
                # Important: Only xbmcvfs can read the special
                try:
                    cached_Cache = VSPath(cached_Cache).decode("utf-8")
                except AttributeError:
                    cached_Cache = VSPath(cached_Cache)

                try:
                    db = sqlite.connect(cached_Cache)
                    dbcur = db.cursor()
                    dbcur.execute('DELETE FROM movie')
                    dbcur.execute('DELETE FROM tvshow')
                    dbcur.execute('DELETE FROM saga')
                    dbcur.execute('DELETE FROM season')
                    dbcur.execute('DELETE FROM episode')
                    db.commit()
                    dbcur.close()
                    db.close()
                    if env != 'cleanAll':
                        self.DIALOG.VSinfo(self.ADDON.VSlang(30090))
                except:
                    self.DIALOG.VSerror(self.ADDON.VSlang(30091))

        if (env == 'xbmc' or env == 'cleanAll'):
            if env == 'cleanAll' or self.DIALOG.VSyesno(self.ADDON.VSlang(30456)):
                path = "special://temp/"
                try:
                    xbmcvfs.rmdir(path, True)
                    if env != 'cleanAll':
                        self.DIALOG.VSok(self.ADDON.VSlang(30092))
                except:
                    self.DIALOG.VSerror(self.ADDON.VSlang(30093))

        if (env == 'fi' or env == 'cleanAll'):
            if env == 'cleanAll' or self.DIALOG.VSyesno(self.ADDON.VSlang(30456)):
                path = "special://temp/archive_cache/"
                try:
                    xbmcvfs.rmdir(path, True)
                    if env != 'cleanAll':
                        self.DIALOG.VSok(self.ADDON.VSlang(30095))
                except:
                    self.DIALOG.VSerror(self.ADDON.VSlang(30096))

        if (env == 'thumb' or env == 'cleanAll'):

            if env == 'cleanAll' or self.DIALOG.VSyesno(self.ADDON.VSlang(30098)):

                text = False
                path = "special://userdata/Thumbnails/"
                path_DB = "special://userdata/Database"
                try:
                    xbmcvfs.rmdir(path, True)
                    text = 'Clear Thumbnail Folder, Successful[CR]'
                except:
                    text = 'Clear Thumbnail Folder, Error[CR]'

                folder, items = xbmcvfs.listdir(path_DB)
                items.sort()
                for sItemName in items:
                    if "extures" in sItemName:
                        cached_Cache = "/".join([path_DB, sItemName])
                        try:
                            xbmcvfs.delete(cached_Cache)
                            text += 'Clear Thumbnail DB, Successful[CR]'
                        except:
                            text += 'Clear Thumbnail DB, Error[CR]'

                text = "%s [CR][COLOR Red]IMPORTANT[/COLOR] - Restart Kodi" % text
                if env != 'cleanAll':
                    self.DIALOG.VSok(text)

        return

    # def ClearDir(self, dir, clearNested=False):
    #     try:
    #         dir = dir.decode("utf8")
    #     except:
    #         pass
    #     for the_file in os.listdir(dir):
    #         file_path = os.path.join(dir, the_file).encode('utf-8')
    #         if clearNested and os.path.isdir(file_path):
    #             self.ClearDir(file_path, clearNested)
    #             try:
    #                 os.rmdir(file_path)
    #             except Exception as e:
    #                 print(str(e))
    #         else:
    #             try:
    #                 os.unlink(file_path)
    #             except Exception as e:
    #                 print str(e)

    # def ClearDir2(self, dir, clearNested=False):
    #     try:
    #         dir = dir.decode("utf8")
    #     except:
    #         pass
    #     try:
    #         os.unlink(dir)
    #     except Exception as e:
    #         print(str(e))

    def TextBoxes(self, heading, anounce):
        # activate the text viewer window
        xbmc.executebuiltin("ActivateWindow(%d)" % 10147)
        # get window
        win = window(10147)
        # win.show()
        # give window time to initialize
        xbmc.sleep(100)
        # set heading
        win.getControl(1).setLabel(heading)
        win.getControl(5).setText(str(anounce))
        return


cClear()
