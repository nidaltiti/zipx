# -*- coding: utf-8 -*-

from resources.lib.comaddon import siteManager, VSlog
from resources.lib.handler.requestHandler import cRequestHandler

class cUpdate:

    def getUpdateSetting(self):
        try:
            sUrl = 'https://matrix1.vercel.app/repo/plugin.video.matrix/resources/sites.json'
            oRequestHandler = cRequestHandler(sUrl)
            properties = oRequestHandler.request(jsonDecode=True)
            if properties == "":
                return

            # Always update the default repo file (sites.json), not user.json
            siteManager(useUserJson=False).setUserProps(properties)

        except Exception as e:
            VSlog('Error during update: ' + str(e))
