# -*- coding: utf-8 -*-

import re
import xbmcplugin
import xbmc
import os
import xbmcgui
import json
import xbmcaddon
from resources.lib.comaddon import addon, dialog, VSlog, KodiVersion, addonManager, VSPath
from resources.lib.db import cDb
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.pluginHandler import cPluginHandler
from resources.lib.upnext import UpNext
from resources.lib.util import cUtil, Unquote
from resources.lib.trakt import cTrakt
from resources.lib import subtitles

LANG_MAP = {
    'en': 'English',
    'ar': 'Arabic',
    'vi': 'Vietnamese',
    'ko': 'Korean',
    'sl': 'Slovenian',
    'id': 'Indonesian',
    'hr': 'Croatian',
    'ru': 'Russian',
    'sv': 'Swedish',
    'no': 'Norwegian',
    'it': 'Italian',
    'el': 'Greek',
    'de': 'German',
    'fi': 'Finnish',
    'nl': 'Dutch',
    'es': 'Spanish',
    'da': 'Danish',
    'fr': 'French',
    'ro': 'Romanian',
    'ms': 'Malay',
    'bn': 'Bengali',
    'th': 'Thai',
    'is': 'Icelandic',
    'zh': 'Chinese',
    'si': 'Sinhala',
    'tr': 'Turkish',
    'he': 'Hebrew',
    'ja': 'Japanese',
    'pt': 'Portuguese',
    'pl': 'Polish',
    'cs': 'Czech',
    'sr': 'Serbian',
    'bg': 'Bulgarian',
    'et': 'Estonian',
    'sq': 'Albanian',
    'fa': 'Farsi',
    'hu': 'Hungarian',
    'uk': 'Ukrainian',

    'pob': 'BrazilianPortuguese',
    'alb': 'Albanian',
    'ron': 'Romanian',
    'ell': 'Greek',
    'por': 'Portuguese',
    'cze': 'Czech',
    'jpn': 'Japanese',
    'est': 'Estonian',
    'hrv': 'Croatian',
    'ara': 'Arabic',
    'srp': 'Serbian',
    'nld': 'Dutch',
    'may': 'Malay',
    'slv': 'Slovenian',
    'vie': 'Vietnamese',
    'kor': 'Korean',
    'bul': 'Bulgarian',
    'heb': 'Hebrew',
    'zht': 'ChineseTraditional',

    'farsi/persian': 'Farsi',
    'brazillian-portuguese': 'BrazilianPortuguese',
    'big_5_code': 'Chinese',
    'chinese-bg-code': 'Chinese',
    'english-german': 'EnglishGerman',

    'Unknown': 'Unknown'
}

class cPlayer(xbmc.Player):
    ADDON = addon()

    def __init__(self, *args):
        sPlayerType = self.__getPlayerType()
        xbmc.Player.__init__(self, sPlayerType)
        self.Subtitles_file = []
        self.SubtitleActive = False

        self.totalTime = 0.0
        self.currentTime = 0.0
        self.infotag = None

        oInputParameterHandler = cInputParameterHandler()
        self.sHosterIdentifier = oInputParameterHandler.getValue('sHosterIdentifier')

        self.sTitle = oInputParameterHandler.getValue('sFileName') if oInputParameterHandler.exist('sFileName') else xbmc.getInfoLabel('ListItem.Title')
        if self.sTitle:
            self.sTitle = Unquote(self.sTitle)

        self.sCat = oInputParameterHandler.getValue('sCat')
        self.sSaison = oInputParameterHandler.getValue('sSeason') if oInputParameterHandler.exist('sSeason') else xbmc.getInfoLabel('ListItem.Season')
        self.sEpisode = oInputParameterHandler.getValue('sEpisode') if oInputParameterHandler.exist('sEpisode') else xbmc.getInfoLabel('ListItem.Episode')
        self.tvShowTitle = oInputParameterHandler.getValue('tvShowTitle')
        self.sSite = oInputParameterHandler.getValue('siteUrl')
        self.sSource = oInputParameterHandler.getValue('sourceName')
        self.sFav = oInputParameterHandler.getValue('sourceFav')
        self.saisonUrl = oInputParameterHandler.getValue('saisonUrl')
        self.nextSaisonFunc = oInputParameterHandler.getValue('nextSaisonFunc')
        self.movieUrl = oInputParameterHandler.getValue('movieUrl')
        self.movieFunc = oInputParameterHandler.getValue('movieFunc')
        self.sTmdbId = oInputParameterHandler.getValue('sTmdbId') if oInputParameterHandler.exist('sTmdbId') else xbmc.getInfoLabel('ListItem.Property(TmdbId)')
        self.sImdbId = oInputParameterHandler.getValue('sImdbId')
        self.sYear = oInputParameterHandler.getValue('sYear') if oInputParameterHandler.exist('sYear') else xbmc.getInfoLabel('ListItem.Year')

        self.playBackEventReceived = False
        self.playBackStoppedEventReceived = False
        self.forcestop = False

        # Used to skip onAVStarted resume when we handle resume before play (useDialog mode)
        self._resumeHandled = False

        VSlog('player initialized')

    def clearPlayList(self):
        oPlaylist = self.__getPlayList()
        oPlaylist.clear()

    def __getPlayList(self):
        return xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

    def addItemToPlaylist(self, oGuiElement):
        oGui = cGui()
        oListItem = oGui.createListItem(oGuiElement)
        self.__addItemToPlaylist(oGuiElement, oListItem)

    def __addItemToPlaylist(self, oGuiElement, oListItem):
        oPlaylist = self.__getPlayList()
        oPlaylist.add(oGuiElement.getMediaUrl(), oListItem)

    def AddSubtitles(self, files):
        if type(files) is list or type(files) is tuple:
            self.Subtitles_file = files
        else:
            self.Subtitles_file.append(files)

    def run(self, oGuiElement, sUrl, title='', force_resolve=False, **kwargs):
        useDialog = self.ADDON.getSetting('HosterDialog') == 'true'
        self.sTitle = title if (useDialog and title) else self.sTitle
        self.tvShowTitle = self.clean_season_episode(title) if (useDialog and title) else self.tvShowTitle

        if kwargs and useDialog:
            self.sCat = kwargs.get('sCat', self.sCat)
            self.sSite = kwargs.get('siteUrl', self.sSite)
            self.sSource = kwargs.get('site', self.sSource)
            self.sFav = kwargs.get('sFav', self.sFav)
            self.sTmdbId = kwargs.get('sTmdbId', self.sTmdbId)
            self.sSaison = kwargs.get('sSeason', self.sSaison)
            self.sEpisode = kwargs.get('sEpisode', self.sEpisode)
            self.movieUrl = kwargs.get('movieUrl', self.movieUrl)
            self.movieFunc = kwargs.get('movieFunc', self.movieFunc)
            self.saisonUrl = kwargs.get('saisonUrl', self.saisonUrl)
            self.nextSaisonFunc = kwargs.get('nextSaisonFunc', self.nextSaisonFunc)

        sPluginHandle = cPluginHandler().getPluginHandle()

        # 1. Dialog-specific Plugin URL handling
        if useDialog and sUrl.startswith('plugin://'):
            listitem = xbmcgui.ListItem(label=oGuiElement.getTitle(), path=sUrl)
            listitem.setArt({'thumb': oGuiElement.getThumbnail()})
            xbmcplugin.addDirectoryItem(handle=sPluginHandle, url=sUrl, listitem=listitem, isFolder=True)
            xbmcplugin.endOfDirectory(sPluginHandle)
            VSlog('Run: created directory entry for plugin URL (Dialog Mode)')
            return

        # 2. Trakt Metadata Logic
        if self.ADDON.getSetting('use_trakt_addon') == 'true':
            if self.sImdbId:
                ids = json.dumps({u'imdb': self.sImdbId})
                xbmcgui.Window(10000).setProperty('script.trakt.ids', ids)
            elif not self.sTmdbId:
                if self.sTitle or self.tvShowTitle:
                    if self.sCat:
                        ctrakt = cTrakt()
                        sType = ctrakt.convertCatToType(self.sCat)
                        if sType != -1:
                            year = oGuiElement.getItemValue('year')
                            self.sTmdbId = int(ctrakt.getTmdbID(self.sTitle, sType, year))
                if self.sTmdbId:
                    ids = json.dumps({u'tmdb': self.sTmdbId})
                    xbmcgui.Window(10000).setProperty('script.trakt.ids', ids)

        # 3. Watched Status Logic
        if self.isPlaying():
            sEpisode = str(oGuiElement.getEpisode())
            if sEpisode:
                numEpisode = int(sEpisode)
                prevEpisode = numEpisode - 1
                sPrevEpisode = '%02d' % prevEpisode
                self._setWatched(sPrevEpisode)
            else:
                self._setWatched()
            self.totalTime = 0
            self.currentTime = 0

        # 4. ListItem Creation
        kodiver = KodiVersion()
        listitem = xbmcgui.ListItem(path=sUrl.encode('utf-8'))
        oGui = cGui()
        listitem = oGui._createListItem(oGuiElement)
        listitem.setPath(sUrl.encode('utf-8'))

        # 5. Mime Type and InputStream Logic
        if '.m3u8' in sUrl or '&ct=6&' in sUrl or '.txt' in sUrl or '.json' in sUrl:
            if kodiver < 21:
                listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
            mime_type = 'application/vnd.apple.mpegurl'
        elif '.mpd' in sUrl:
            if kodiver < 21:
                listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            mime_type = 'application/dash+xml'
        elif '.mkv' in sUrl:
            mime_type = 'video/x-matroska'
        elif '.ism' in sUrl:
            if kodiver < 21:
                listitem.setProperty('inputstream.adaptive.manifest_type', 'ism')
            mime_type = 'application/vnd.ms-sstr+xml'
        else:
            mime_type = None

        # 6. Video Info Tags
        media_type = 'movie' if self.sCat == '1' else 'tv'
        self.sTitle = self.sTitle if media_type == 'movie' else self.tvShowTitle
        try:
            self.fetch_imdb_id_from_title(media_type)
            self.info_tag = listitem.getVideoInfoTag()
            if self.sTitle:
                self.info_tag.setTitle(self.sTitle)
            self.info_tag.setYear(int(self.sYear) if self.sYear else 0)
            self.info_tag.setMediaType(media_type)
            if self.sImdbId:
                self.info_tag.setIMDBNumber(self.sImdbId)
            if media_type == 'tv':
                self.info_tag.setSeason(int(self.sSaison) if self.sSaison else 1)
                self.info_tag.setEpisode(int(self.sEpisode) if self.sEpisode else 1)
        except Exception as e:
            VSlog(f"Failed to set InfoTagVideo: {e}")

        # 7. DRM and Headers
        if mime_type:
            if any(ext in sUrl for ext in ['.m3u8', '&ct=6&', '.mpd', '.txt', '.json']):
                listitem.setProperty('inputstream', 'inputstream.adaptive')
                addonManager().enableAddon('inputstream.adaptive')
            listitem.setMimeType(mime_type)
            listitem.setContentLookup(False)

            if '|' in sUrl:
                parts = sUrl.split('|')
                sUrl_only = parts[0]
                strhdr = parts[1]

                if '&license=' in sUrl:
                    sUrl_only, license_key = sUrl.split('&license=')
                    strhdr = sUrl_only.split('|')[1]
                    if strhdr and not strhdr.endswith('&'):
                        strhdr += '&'
                    strhdr += 'Range=bytes=0-'
                    listitem.setProperty('inputstream.adaptive.drm_legacy', license_key)
                elif '###' in sUrl_only:
                    import base64
                    sKeys = sUrl_only.split("###")[1].replace("%20","+")
                    sKey1, sKey2 = sKeys.split(':')
                    sKey1 = base64.urlsafe_b64decode(sKey1 + '==').hex()
                    sKey2 = base64.urlsafe_b64decode(sKey2 + '==').hex()
                    sUrl_only = sUrl_only.split("###")[0]
                    listitem.setProperty('inputstream.adaptive.drm_legacy', f"org.w3.clearkey|{sKey2}:{sKey1},{sKey2}:{sKey1}")
                else:
                    listitem.setProperty('inputstream.adaptive.license_key', '|%s' % strhdr)

                listitem.setProperty('inputstream.adaptive.stream_headers', strhdr.encode('utf-8'))
                if kodiver > 21.8:
                    listitem.setProperty('inputstream.adaptive.common_headers', strhdr)
                elif kodiver > 19.8:
                    listitem.setProperty('inputstream.adaptive.manifest_headers', strhdr)

                sUrl = sUrl_only
                listitem.setPath(sUrl.encode('utf-8'))

        # 8. Subtitles
        if self.Subtitles_file:
            try:
                listitem.setSubtitles(self.Subtitles_file)
                self.SubtitleActive = True
            except:
                pass
        elif self.ADDON.getSetting('srt-get') == 'true':
            subtitle_files = self.fetch_and_load_subtitles(self.sImdbId, self.sSaison, self.sEpisode)
            if subtitle_files:
                try:
                    listitem.setSubtitles(subtitle_files)
                    self.SubtitleActive = True
                except:
                    pass

        player_conf = self.ADDON.getSetting('playerPlay')

        # Close busy dialog before we might show another prompt
        xbmc.executebuiltin("Dialog.Close(busydialog)")

        # Pre-play resume for useDialog mode ===
        if useDialog:
            try:
                self._ask_resume(listitem)
            except Exception as e_resume:
                VSlog(f"Resume pre-play failed: {e_resume}")


        # If a caller (e.g., Up Next) needs true plugin resolution semantics, do it.
        if force_resolve:
            xbmcplugin.setResolvedUrl(sPluginHandle, True, listitem)
            VSlog('Player: force_resolve → setResolvedUrl (UpNext)')
            return True

        if useDialog or player_conf == '0':
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            playlist.add(sUrl, listitem)
            self.play(playlist)

            VSlog('Player: Direct Play (useDialog)')
        elif player_conf == 'neverused':
            xbmc.executebuiltin('PlayMedia(' + sUrl + ')')
        else:
            xbmcplugin.setResolvedUrl(sPluginHandle, True, listitem)
            VSlog('Player: setResolvedUrl')

        import threading
        monitor_thread = threading.Thread(target=self._playback_monitor, args=(oGuiElement,))
        monitor_thread.daemon = True
        monitor_thread.start()

        if player_conf == '0' and not useDialog:
            return xbmcplugin.addDirectoryItem(handle=sPluginHandle, url=sUrl, listitem=listitem, isFolder=False)

        return True


    def _playback_monitor(self, oGuiElement):
        useDialog = (self.ADDON.getSetting('HosterDialog') == 'true')

        EARLY_UPNEXT_TICKS = 10 
        MIN_SECONDS_BEFORE_END = 25.0 
        PCT_BEFORE_END = 0.08 
        SHORT_MEDIA_NEAR_END_PCT = 0.05 
        SHORT_MEDIA_SECONDS = 5 * MIN_SECONDS_BEFORE_END  # 125s

        self._upnext_notified = False
        upnext_called_once = False
        ticks = 0

        VSlog("Background monitor started (useDialog=%s)" % useDialog)
        xbmc.sleep(1500)

        retries = 12
        while self.isPlaying() and retries > 0 and not self.forcestop:
            try:
                total = float(self.getTotalTime())
                if total > 0.0:
                    self.totalTime = total
                    break
            except Exception:
                pass
            retries -= 1
            xbmc.sleep(500)

        while self.isPlaying() and not self.forcestop:
            try:
                try:
                    self.currentTime = float(self.getTime())
                except Exception:
                    self.currentTime = float(getattr(self, 'currentTime', 0.0))

                try:
                    t = float(self.getTotalTime())
                    if t > 0.0:
                        self.totalTime = t
                except Exception:
                    self.totalTime = float(getattr(self, 'totalTime', 0.0))

                if not getattr(self, 'infotag', None):
                    try:
                        self.infotag = self.getVideoInfoTag()
                    except Exception:
                        pass

                if not useDialog and not upnext_called_once:
                    ticks += 1
                    if ticks >= EARLY_UPNEXT_TICKS:
                        upnext_called_once = True
                        try:
                            UpNext().nextEpisode(oGuiElement)
                            VSlog("UpNext (non-dialog): early schedule after %d ticks" % ticks)
                        except Exception as err:
                            VSlog(f"UpNext (non-dialog) error: {err}")

                if (useDialog or not upnext_called_once) and not self._upnext_notified:
                    total_ok = float(getattr(self, 'totalTime', 0.0))
                    if total_ok > 0.0:
                        remaining = self.totalTime - self.currentTime
                        threshold = max(self.totalTime * PCT_BEFORE_END, MIN_SECONDS_BEFORE_END)
                        if self.totalTime < SHORT_MEDIA_SECONDS:
                            threshold = max(self.totalTime * SHORT_MEDIA_NEAR_END_PCT, 10.0)

                        if remaining <= threshold:
                            self._upnext_notified = True
                            if not getattr(self, 'infotag', None):
                                try:
                                    self.infotag = self.getVideoInfoTag()
                                except Exception:
                                    self.infotag = None

                            VSlog(
                                "UpNext trigger: remaining=%.1fs (threshold=%.1fs), total=%.1fs, current=%.1fs"
                                % (remaining, threshold, self.totalTime, self.currentTime)
                            )
                            try:
                                UpNext().nextEpisode(
                                    oGuiElement,
                                    self.sSource,
                                    self.sTmdbId,
                                    self.sSaison,
                                    self.sEpisode,
                                    self.nextSaisonFunc
                                )
                            except Exception as err:
                                VSlog(f"UpNext schedule error: {err}")

            except Exception as err:
                VSlog(f"Monitor loop error: {err}")

            xbmc.sleep(1000)

        try:
            try:
                self.currentTime = float(self.getTime())
            except Exception:
                self.currentTime = float(getattr(self, 'currentTime', 0.0))

            try:
                t = float(self.getTotalTime())
                if t > 0.0:
                    self.totalTime = t
            except Exception:
                self.totalTime = float(getattr(self, 'totalTime', 0.0))
        except Exception:
            pass

        if not self.playBackStoppedEventReceived:
            self.onPlayBackStopped()

    def get_unique_filename(self, base_path, base_name, lang_label, ext=".srt"):
        filename = f"{base_name}.{lang_label}{ext}"
        counter = 1
        unique_filename = filename
        while os.path.exists(os.path.join(base_path, unique_filename)):
            unique_filename = f"{base_name}.{lang_label}.{counter}{ext}"
            counter += 1
        return unique_filename

    def cleanup_subtitles(self, subtitle_path):
        try:
            for file in os.listdir(subtitle_path):
                if file.lower().endswith('.srt'):
                    full_path = os.path.join(subtitle_path, file)
                    os.remove(full_path)
        except Exception as e:
            VSlog(f"Subtitle cleanup failed: {e}")

    def fetch_and_load_subtitles(self, imdb_id, season=None, episode=None):
        subtitle_path = VSPath('special://temp/')
        self.cleanup_subtitles(subtitle_path)
        base_name = f"matrix.{imdb_id}"
        if season and episode:
            base_name += f".{season}.{episode}"

        subLang = self.ADDON.getSetting('srt-lang')
        subtitle_files = []

        try:
            subs = subtitles.search(imdb_id, subLang, season, episode) or []
        except Exception as e:
            VSlog(f"Subtitle search failed: {e}")
            subs = []

        normalized = []
        for item in subs:
            if 'language' in item and 'url' in item:
                normalized.append({
                    'language': item.get('language', 'Unknown'),
                    'url': item.get('url'),
                    'format': item.get('format', 'srt')
                })

            elif 'lang' in item and 'url' in item:
                normalized.append({
                    'language': item.get('lang', 'Unknown'),
                    'url': item.get('url'),
                    'format': 'srt'
                })

        for i, item in enumerate(normalized):
            lang = item.get('language', 'Unknown')
            lang_label = LANG_MAP.get(lang, lang).replace(' ', '.')
            ext = f".{item.get('format', 'srt')}"
            filename = self.get_unique_filename(subtitle_path, base_name, lang_label, ext)
            final_path = os.path.join(subtitle_path, filename)
            try:
                subtitles.download(item['url'], final_path)
                if os.path.exists(final_path) and os.path.getsize(final_path) > 100:
                    subtitle_files.append(final_path)
                else:
                    VSlog(f"Subtitle file invalid or too small: {final_path}")
            except Exception as e:
                VSlog(f"Failed to download subtitle: {e}")

        return subtitle_files

    def startPlayer(self, window=False):
        oPlayList = self.__getPlayList()
        self.play(oPlayList, windowed=window)

    def onPlayBackEnded(self):
        self.onPlayBackStopped()

    def onPlayBackStopped(self):
        VSlog('player stopped')
        if self.playBackStoppedEventReceived:
            return

        self.playBackStoppedEventReceived = True
        self._setWatched(self.sEpisode)

    # MARK AS VIEWED
    # uses the information from the video that has just been played
    # which is not the one that was launched if several videos have been chained
    # sEpisode = the previous episode in case of a chain of episodes
    # MARK AS VIEWED
    def _setWatched(self, sEpisode=''):
        try:
            with cDb() as db:
                if self.isPlaying():
                    self.totalTime = self.getTotalTime()
                    self.currentTime = self.getTime()
                    self.infotag = self.getVideoInfoTag()

                if self.totalTime > 0:
                    pourcent = float('%.2f' % (self.currentTime / self.totalTime))
                    saisonViewing = False

                    VALUE_WATCHTIME = 0.90
                    TRAKT_ID = "script.trakt"

                    if self.ADDON.getSetting('use_trakt_addon') == 'true':
                        traktAddon = xbmcaddon.Addon(TRAKT_ID)
                        VALUE_WATCHTIME = int(traktAddon.getSetting("rate_min_view_time")) / 100

                    if (pourcent > VALUE_WATCHTIME) or (pourcent == 0.0 and self.currentTime == self.totalTime):

                        self.sTitleWatched = self.infotag.getOriginalTitle()
                        if self.sTitleWatched:
                            if self.sEpisode :
                                self.sTitle = '%s S%sE%s' % (self.tvShowTitle, self.sSaison, self.sEpisode)
                            else:
                                self.sTitle = self.sTitle
                            meta = {}
                            meta['cat'] = self.sCat
                            meta['title'] = self.sTitle
                            meta['titleWatched'] = self.sTitleWatched
                            if self.movieUrl and self.movieFunc:
                                meta['siteurl'] = self.movieUrl
                                meta['fav'] = self.movieFunc
                            else:
                                meta['siteurl'] = self.sSite
                                meta['fav'] = self.sFav

                            meta['tmdbId'] = self.sTmdbId
                            meta['site'] = self.sSource

                            if self.sSaison:
                                meta['season'] = self.sSaison
                            meta['seasonUrl'] = self.saisonUrl
                            meta['seasonFunc'] = self.nextSaisonFunc
                            db.insert_watched(meta)

                            db.del_resume(meta)

                            if self.sCat == '1':
                                db.del_viewing(meta)
                            elif self.sCat == '8':
                                saisonViewing = True

                        self.__setWatchlist(sEpisode)

                    elif self.currentTime > 180.0:
                        self.sTitleWatched = self.infotag.getOriginalTitle()
                        if self.sTitleWatched:
                            meta = {}
                            meta['title'] = self.sTitle
                            meta['titleWatched'] = self.sTitleWatched
                            meta['site'] = self.sSite
                            meta['point'] = self.currentTime
                            meta['total'] = self.totalTime
                            db.insert_resume(meta)

                            self.__setProgress(self.sEpisode, self.currentTime, self.totalTime)
                            
                            meta['cat'] = self.sCat
                            meta['site'] = self.sSource
                            meta['tmdbId'] = self.sTmdbId

                            if self.sCat == '8':
                                saisonViewing = True
                            else:
                                if self.sCat == '5' and self.totalTime < 2700:
                                    pass
                                else:
                                    if self.movieUrl and self.movieFunc:
                                        meta['siteurl'] = self.movieUrl
                                        meta['fav'] = self.movieFunc
                                    else:
                                        meta['siteurl'] = self.sSite
                                        meta['fav'] = self.sFav

                                    db.insert_viewing(meta)

                    if saisonViewing:
                        meta['cat'] = '4'
                        meta['tmdbId'] = self.sTmdbId
                        self.tvShowTitleWatched = cUtil().titleWatched(self.tvShowTitle).replace(' ', '')
                        if self.sSaison:
                            meta['season'] = self.sSaison
                            meta['title'] = self.tvShowTitle + " S" + self.sSaison
                            meta['titleWatched'] = self.tvShowTitleWatched + "_S" + self.sSaison
                        else:
                            meta['title'] = self.tvShowTitle
                            meta['titleWatched'] = self.tvShowTitleWatched
                        meta['site'] = self.sSource
                        meta['siteurl'] = self.saisonUrl
                        meta['fav'] = self.nextSaisonFunc
                        db.insert_viewing(meta)

        except Exception as err:
            VSlog("ERROR Player_setWatched : {0}".format(err))

    def _setSeasonViewing(self, db, meta):
        """Helper to handle series 'Currently Watching' state."""
        try:
            tv_meta = meta.copy()
            tv_meta['cat'] = '4'  # Season Category
            tvShowTitleWatched = cUtil().titleWatched(self.tvShowTitle).replace(' ', '')
            if self.sSaison:
                tv_meta['season'] = self.sSaison
                tv_meta['title'] = self.tvShowTitle + " S" + self.sSaison
                tv_meta['titleWatched'] = tvShowTitleWatched + "_S" + self.sSaison
            else:
                tv_meta['title'] = self.tvShowTitle
                tv_meta['titleWatched'] = tvShowTitleWatched
            tv_meta['siteurl'] = self.saisonUrl
            tv_meta['fav'] = self.nextSaisonFunc
            db.insert_viewing(tv_meta)
        except:
            pass

    def onAVStarted(self):
        VSlog('Player started - Entering Resume Logic')

        # If resume already handled before play (useDialog), skip onAVStarted logic
        if getattr(self, '_resumeHandled', False):
            VSlog('Resume already handled pre-play; skipping onAVStarted resume')
            return

        if self.playBackEventReceived:
            return

        self.playBackEventReceived = True
        self._upnext_notified = False
        xbmc.sleep(1000)
        if not self.isPlayingVideo():
            return

        with cDb() as db:
            self.sTitleWatched = ""
            try:
                self.infotag = self.getVideoInfoTag()
                self.sTitleWatched = self.infotag.getOriginalTitle() or self.infotag.getTitle()
            except:
                pass

            if not self.sTitleWatched:
                self.sTitleWatched = getattr(self, 'sTitleWatched', self.sTitle)

            if not self.sTitleWatched:
                VSlog("Resume Error: No title found to query database")
                return

            meta = {'titleWatched': self.sTitleWatched}
            resumePoint, total = db.get_resume(meta)
            VSlog(f"DB Check for {self.sTitleWatched}: Point {resumePoint} / Total {total}")

            # Only show if the resume point is significant (> 3 mins)
            if resumePoint and resumePoint > 180:
                # Format time for the Arabic label
                h = int(resumePoint // 3600)
                m = int((resumePoint % 3600) // 60)
                s = int(resumePoint % 60)
                timeStr = '%02d:%02d:%02d' % (h, m, s)

                options = [f'استئناف من {timeStr}', 'شاهد من البداية']

                # We use a slight delay here to force focus
                xbmc.sleep(500)
                ret = xbmcgui.Dialog().select('استئناف المشاهدة؟', options)
                if ret == 0:
                    VSlog(f"Seeking to {resumePoint}")
                    xbmc.sleep(200)
                    self.seekTime(resumePoint)
                elif ret == 1:
                    VSlog("Starting from beginning")
                    self.seekTime(0.0)
                    db.del_resume(meta)

    def __setWatchlist(self, sEpisode=''):
        # Checking whether the Trakt addon is used or not, if yes, we exit the function.
        if self.ADDON.getSetting('use_trakt_addon') == 'true':
            return

        # Reading tracking in Trakt if account
        if self.ADDON.getSetting('bstoken') == '':
            return

        plugins = __import__('resources.lib.trakt', fromlist=['trakt']).cTrakt()
        function = getattr(plugins, 'getAction')
        function(Action="SetWatched", sEpisode=sEpisode)

    def __setProgress(self, sEpisode='', currentTime=0, totalTime=0):
        if self.ADDON.getSetting('use_trakt_addon') == 'true':
            return
        if self.ADDON.getSetting('bstoken') == '':
            return
        if totalTime == 0:
            return

        progress = currentTime/ totalTime
        plugins = __import__('resources.lib.trakt', fromlist=['trakt']).cTrakt()
        function = getattr(plugins, 'getAction')
        function(Action="SetProgress", sEpisode=sEpisode, progress=progress)

    def __getPlayerType(self):
        sPlayerType = self.ADDON.getSetting('playerType')
        try:
            if sPlayerType == '0':
                VSlog('playertype from config: auto')
                return xbmc.PLAYER_CORE_AUTO
            if sPlayerType == '1':
                VSlog('playertype from config: mplayer')
                return xbmc.PLAYER_CORE_MPLAYER
            if sPlayerType == '2':
                VSlog('playertype from config: dvdplayer')
                return xbmc.PLAYER_CORE_DVDPLAYER
        except:
            return False

    def fetch_imdb_id_from_title(self, media_type):
        if self.sImdbId and self.sTmdbId:
            return

        for attempt in range(3):
            try:
                if self.ADDON.getSetting('use_omdb') == 'true':
                    from resources.lib.omdb import cOMDb
                    tmdb = cOMDb()
                else:
                    from resources.lib.tmdb import cTMDb
                    tmdb = cTMDb()

                meta = tmdb.search_movie_name(self.sTitle, self.sYear) if media_type == 'movie' else tmdb.search_tvshow_name(self.tvShowTitle, self.sYear)
                if meta:
                    self.sImdbId = meta.get('external_ids', {}).get('imdb_id') or meta.get('imdb_id')
                    self.sTmdbId = meta.get('id')
                    VSlog(f"Metadata found on attempt {attempt + 1}")
                    break 
            except Exception as e:
                VSlog(f"Metadata attempt {attempt + 1} failed: {e}")
                xbmc.sleep(500)

    def clean_season_episode(self, text: str) -> str:
        text = re.sub(r'[Ss]\d{1,2}', '', text)
        text = re.sub(r'[Ee]\d{1,2}', '', text)
        return text.strip().replace('  ', ' ')

    def _ask_resume(self, listitem: xbmcgui.ListItem) -> None:
        try:
            try:
                self.infotag = listitem.getVideoInfoTag()
            except Exception as e_tag:
                VSlog(f"Resume: cannot get listitem VideoInfoTag: {e_tag}")
                return

            self.sTitleWatched = None
            try:
                self.sTitleWatched = self.infotag.getOriginalTitle() or self.infotag.getTitle()
            except:
                pass

            if not self.sTitleWatched:
                self.sTitleWatched = self.sTitle

            if not self.sTitleWatched:
                return

            meta = {'titleWatched': self.sTitleWatched}

            with cDb() as db:
                try:
                    resumePoint, total = db.get_resume(meta)
                except Exception as e_db:
                    VSlog(f"Resume: db.get_resume failed: {e_db}")
                    return

                if not resumePoint:
                    return

                try:
                    resumePoint = float(resumePoint)
                    total = float(total) if total else 0.0
                except Exception:
                    VSlog("Resume: invalid resume values in DB")
                    return

                # Only prompt for meaningful resume (> 3 min and not near the end if total known)
                if resumePoint > 180.0 and (total <= 0.0 or resumePoint < 0.9 * total):
                    h = int(resumePoint // 3600)
                    m = int((resumePoint % 3600) // 60)
                    s = int(resumePoint % 60)
                    timeStr = f"{h:02d}:{m:02d}:{s:02d}"

                    options = [f'استئناف من {timeStr}', 'شاهد من البداية']
                    xbmc.sleep(100)
                    choice = xbmcgui.Dialog().select('استئناف المشاهدة؟', options)

                    if choice == 0:
                        listitem.setProperty("StartOffset", str(int(resumePoint)))
                        VSlog(f"Resume: set StartOffset={int(resumePoint)} (pre-play)")
                        self._resumeHandled = True
                    elif choice == 1:
                        try:
                            db.del_resume(meta)
                            VSlog("Resume: user chose start over → deleted resume record")
                        except Exception as e_del:
                            VSlog(f"Resume: db.del_resume failed: {e_del}")
                        self._resumeHandled = True
        except Exception as e:
            VSlog(f"Resume pre-play exception: {e}")
