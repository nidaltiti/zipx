import random
import time
import requests
import xbmcaddon

UA_TIMEOUT_SECS = 7 * 24 * 60 * 60
REQUEST_TIMEOUT = 10

PC_UA_TEMPLATES = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv} Safari/537.36',
    'Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv} Safari/537.36',
    'Mozilla/5.0 (X11; Ubuntu 22.04; x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv} Safari/537.36',
    'Mozilla/5.0 (X11; Fedora 37; x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv} Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 26_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv} Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 26_1_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv} Safari/537.36',
]

PHONE_UA_TEMPLATES = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 26_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (iPad; CPU OS 26_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (Linux; Android 13; Pixel 6 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv} Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 12; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv} Mobile Safari/537.36',
    'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv} Mobile Safari/537.36',
]

ALL_UA_TEMPLATES = PC_UA_TEMPLATES + PHONE_UA_TEMPLATES

addon = xbmcaddon.Addon()

get_setting_str = addon.getSetting

def get_setting_int(id, default=0):
    try:
        return int(get_setting_str(id))
    except (ValueError, TypeError):
        return default

def set_setting(id, value):
    addon.setSetting(id, str(value))

def generate_chrome_version():
    major = random.randint(110, 124)
    build = random.randint(4000, 5000)
    patch = random.randint(100, 200)
    return f"{major}.0.{build}.{patch}"

def build_ua_from_template(template_list):
    template = random.choice(template_list)
    if "{cv}" in template:
        chrome_version = generate_chrome_version()
        return template.format(cv=chrome_version)
    return template

def get_random_ua():
    return build_ua_from_template(ALL_UA_TEMPLATES)

def get_pc_ua():
    return build_ua_from_template(PC_UA_TEMPLATES)

def get_phone_ua():
    return build_ua_from_template(PHONE_UA_TEMPLATES)

def get_ua():
    last_gen = get_setting_int('last_ua_create')
    current_ua = get_setting_str('current_ua')

    if not current_ua or last_gen < time.time() - UA_TIMEOUT_SECS:
        user_agent = get_random_ua()
        set_ua(user_agent)
    else:
        user_agent = current_ua

    return user_agent

def set_ua(ua):
    set_setting('current_ua', ua)
    set_setting('last_ua_create', int(time.time()))

def save_cookies(flarejson):
    set_setting('current_cook', {
        cookie['name']: cookie['value'] for cookie in flarejson
    })

def get_url_with_cache(url, cache_key, expiration_hours):
    last_gen = get_setting_int(f'last_{cache_key}_create')
    cached_url = get_setting_str(cache_key)
    
    expiration_secs = expiration_hours * 3600

    if not cached_url or last_gen < time.time() - expiration_secs:
        try:
            headers = {'User-Agent': get_ua()}
            response = requests.get(
                url, 
                allow_redirects=True, 
                headers=headers, 
                timeout=REQUEST_TIMEOUT
            )
            response.raise_for_status()
            
            resolved_url = response.url
            
            if resolved_url and resolved_url != url:
                set_setting(cache_key, resolved_url)
                set_setting(f'last_{cache_key}_create', int(time.time()))

        except requests.exceptions.RequestException:
            resolved_url = url
    else:
        resolved_url = cached_url

    return resolved_url

def get_arabseed_url(url):
    return get_url_with_cache(url, 'seed_url', 24)

def get_wecima_url(url):
    return get_url_with_cache(url, 'wecima_url', 120)