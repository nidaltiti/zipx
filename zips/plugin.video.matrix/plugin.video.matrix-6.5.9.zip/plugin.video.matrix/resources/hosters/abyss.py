﻿#coding: utf-8
from resources.lib.handler.requestHandler import cRequestHandler
from resources.hosters.hoster import iHoster
from resources.lib.comaddon import VSlog

import re, json
import requests
from urllib.parse import quote

UA = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36 Edg/142.0.0.0'

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'abyss', 'Abyss')

    def isDownloadable(self):
        return True

    def _getMediaLinkForGuest(self, autoPlay = False):
        api_call = False
        VSlog(self._url)
 
        oRequest = cRequestHandler(self._url)
        oRequest.addHeaderEntry('user-agent', UA)
        oRequest.addHeaderEntry('Referer', self._url)
        oRequest.enableCache(False)
        sHtmlContent = oRequest.request()

        if 'https://abysscdn.com/' in sHtmlContent:
            self._url = 'https://abysscdn.com/?v=%s' % (self._url.split('?v=', 1)[1])

            oRequest = cRequestHandler(self._url)
            oRequest.addHeaderEntry('user-agent', UA)
            oRequest.addHeaderEntry('Referer', self._url)
            oRequest.enableCache(False)
            sHtmlContent = oRequest.request()

        src_match = re.search(r'src:\s*"([^"]+)"', sHtmlContent)
        src_url = src_match.group(1) if src_match else None

        referer_match = re.search(r"headers\['Referer'\]\s*=\s*'([^']+)'", sHtmlContent)
        referer_url = referer_match.group(1) if referer_match else None
        api_call = f'{src_url}|Referer={referer_url}'

        all_scripts = re.findall(r"<script>(.*?)</script>", sHtmlContent, re.DOTALL)
        sHtmlContent2 = None
        for script_content in all_scripts:
            if "atob" in script_content:
                sHtmlContent2 = get_decoded_code(script_content, UA)

                api_call = get_video_from_abyss_player(sHtmlContent2) + f'|Referer={self._url}&User-Agent={UA}'

        if api_call:
            return True, api_call

        return False, False

def extract_base64_from_js(js_code):
    pattern = r'window\.atob;\s*var\s+[\w]+\s*=\s*"([^"]+)"'
    match = re.search(pattern, js_code)
    if match:
        base64_str = match.group(1)
        return base64_str
    
def get_video_from_abyss_player(coded):

        coded = extract_base64_from_js(coded)
        binary_data = _decode_custom_base64_to_bytes(coded)
        json_string = binary_data.decode('utf-8', errors='ignore')

        decoder = json.JSONDecoder()
        config_data, _ = decoder.raw_decode(json_string)

        stream_url = _construct_abyss_stream_url(config_data)

        if not stream_url:
            return None

        return stream_url

def _decode_custom_base64_to_bytes(encoded_string):
    CUSTOM_ALPHABET = "RB0fpH8ZEyVLkv7c2i6MAJ5u3IKFDxlS1NTsnGaqmXYdUrtzjwObCgQP94hoeW+/="
    DECODING_MAP = {char: index for index, char in enumerate(CUSTOM_ALPHABET)}
    encoded_string = encoded_string.replace('_', '')
    result_bytes = bytearray()
    i = 0
    while i < len(encoded_string):
        chunk = [DECODING_MAP.get(encoded_string[j], 0) for j in range(i, i + 4)]
        byte1 = (chunk[0] << 2) | (chunk[1] >> 4)
        byte2 = ((chunk[1] & 15) << 4) | (chunk[2] >> 2)
        byte3 = ((chunk[2] & 3) << 6) | chunk[3]
        result_bytes.append(byte1)
        if i + 2 < len(encoded_string) and encoded_string[i + 2] != 'v':
            result_bytes.append(byte2)
        if i + 3 < len(encoded_string) and encoded_string[i + 3] != 'v':
            result_bytes.append(byte3)
        i += 4
    return bytes(result_bytes)


def _construct_abyss_stream_url(config_data):
    sources = config_data.get('sources')
    if not sources or not isinstance(sources, list):
        return None

    best_source = None
    max_quality = -1
    for source in sources:
        if 'label' in source and ('size' in source or 'ize' in source):
            try:
                quality_num = int(re.sub(r'\D', '', source['label']))
                if quality_num > max_quality:
                    max_quality = quality_num
                    best_source = source
            except (ValueError, TypeError):
                continue
    if not best_source:
        return None

    quality_label = best_source.get('label')
    size = best_source.get('size') or best_source.get('ize')
    if 'url' in best_source and 'path' in best_source:
        source_url_to_encode = f"{best_source['url']}/{best_source['path']}"
        encoded_url = quote(source_url_to_encode, safe='')
        final_stream_url = f"https://abysscdn.com/#chunk/{size}/{size}?maxChunkSize=15728640&url={encoded_url}"
        return final_stream_url
    elif size and quality_label:
        final_stream_url = f"https://abysscdn.com/#mp4/{size}/{quality_label}"
        return final_stream_url
    return None

def get_decoded_code(coded, UA):
    url = "https://matrix-one.vercel.app//api"
    
    headers = {
        "User-Agent": UA
    }
    
    response = requests.post(url, headers=headers, data={"code": coded})
    
    response_json = response.json()
    
    decoded_code = response_json['code'].replace('\\"', '"')
    
    return decoded_code

