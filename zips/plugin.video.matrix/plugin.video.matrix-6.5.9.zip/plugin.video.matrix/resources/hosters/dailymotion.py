#-*- coding: utf-8 -*-
# https://github.com/Kodi-vStream/venom-xbmc-addons

import re
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.hosters.hoster import iHoster
from resources.lib.comaddon import dialog, VSlog

class cHoster(iHoster):
    def __init__(self):
        iHoster.__init__(self, 'dailymotion', 'Dailymotion')

    def isDownloadable(self):
        return True

    def setUrl(self, sUrl):
        self._url = str(sUrl)
        self.embedder = self._url

        if "metadata" not in self._url:
            url_path = self._url
            if '?video=' in self._url:
                video_id = self._url.split('?video=')[1]
            else:
                url_path = self._url.split('?')[0]

                if 'embed/video' in url_path or '/swf/video' in url_path:
                    video_id = url_path.split('/')[5]
                else:
                    video_id = url_path.split('/')[4]

            self._url = (
                f"https://www.dailymotion.com/player/metadata/video/{video_id}"
                f"?embedder={self.embedder}"
            )

    def _getMediaLinkForGuest(self, autoPlay = False):
        api_call = False
        url=[]
        qua=[]

        oRequest = cRequestHandler(self._url)
        oRequest.enableCache(False)
        sHtmlContent = oRequest.request()
        VSlog(self._url)

        oParser = cParser()
        sPattern =  r'{"type":"application.+?mpegURL","url":"([^"]+)"}'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            api_call = aResult[1][0]
            import urllib.request
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:70.0) Gecko/20100101 Firefox/70.0",
                "Accept-Language": "fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3"
            }

            req = urllib.request.Request(api_call, headers=headers, method="GET")
            with urllib.request.urlopen(req) as response:
                sHtmlContent = response.read().decode("utf-8", errors="ignore")

            qua = []
            url = []
            pattern = r'NAME="([^"]+)".*?\n\s*(https?://\S+)'
            matches = re.findall(pattern, sHtmlContent)
            for quality, link in matches:
                qua.append(quality)
                url.append(link)

            api_call = dialog().VSselectqual(qua, url)

        if api_call:
            return True, api_call+ f'|Referer={self.embedder}'

        return False, False