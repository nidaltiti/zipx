# -*- coding: utf-8 -*-

import base64
import re
import json
from urllib.parse import urlparse
from Cryptodome.Cipher import AES
from resources.lib.handler.requestHandler import cRequestHandler
from resources.hosters.hoster import iHoster
from resources.lib.comaddon import dialog, VSlog
from resources.lib import random_ua
from six.moves import urllib_parse

UA = random_ua.get_pc_ua()

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'byse', 'Byse')

    def b64_url_decode(self, s: str) -> bytes:
        fixed = s.replace('-', '+').replace('_', '/')
        pad = (4 - len(fixed) % 4) % 4
        return base64.b64decode(fixed + "=" * pad)

    def get_base_url(self, url: str) -> str:
        parsed = urlparse(url)
        return f"{parsed.scheme}://{parsed.netloc}"

    def get_code_from_url(self, url: str) -> str:
        path = urlparse(url).path or ""
        return path.rstrip('/').split('/')[-1]

    def get_details(self, main_url: str):
        base = self.get_base_url(main_url)
        code = self.get_code_from_url(main_url)
        url = f"{base}/api/videos/{code}/embed/details"

        oRequestHandler = cRequestHandler(url)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('referer', main_url)
        sHtmlContent = oRequestHandler.request()

        try:
            return json.loads(sHtmlContent)
        except Exception:
            match = re.search(r'<iframe[^>]+src="([^"]+)"', sHtmlContent)
            if not match:
                return None
            iframe_url = match.group(1)

            oRequestHandler = cRequestHandler(iframe_url)
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            oRequestHandler.addHeaderEntry('referer', main_url)
            iframe_resp = oRequestHandler.request(jsonDecode=True)
            try:
                return iframe_resp
            except Exception:
                return None

    def get_playback(self, main_url: str):
        details = self.get_details(main_url)
        if not details:
            return None
        embed_frame_url = details.get("embedFrameUrl") or details.get("embed_frame_url")
        embed_base = self.get_base_url(embed_frame_url)
        code = self.get_code_from_url(embed_frame_url)
        playback_url = f"{embed_base}/api/videos/{code}/embed/playback"

        headers = {
            "accept": "*/*",
            "user-agent": UA,
            "accept-language": "en-US,en;q=0.5",
            "priority": "u=1, i",
            "referer": embed_frame_url,
            "x-embed-parent": main_url.replace("/d/", "/e/")
        }

        oRequestHandler = cRequestHandler(playback_url)
        for key, value in headers.items():
            oRequestHandler.addHeaderEntry(key, value)
        oRequestHandler.setRequestType(1)
        sHtmlContent = oRequestHandler.request(jsonDecode=True)

        return sHtmlContent, embed_frame_url

    def build_aes_key(self, playback: dict) -> bytes:
        p1 = self.b64_url_decode(playback["key_parts"][0])
        p2 = self.b64_url_decode(playback["key_parts"][1])
        return p1 + p2

    def decrypt_playback(self, playback: dict):
        key_bytes = self.build_aes_key(playback)
        iv_bytes = self.b64_url_decode(playback["iv"])
        cipher_bytes = self.b64_url_decode(playback["payload"])

        cipher = AES.new(key_bytes, AES.MODE_GCM, nonce=iv_bytes)
        plain_bytes = cipher.decrypt(cipher_bytes)

        json_str = plain_bytes.decode("utf-8", errors="ignore")
        if json_str.startswith("\ufeff"):
            json_str = json_str[1:]
        last_brace = json_str.rfind("}")
        if last_brace != -1:
            json_str = json_str[:last_brace+1]

        root = json.loads(json_str)
        return root.get("sources", [])

    def _getMediaLinkForGuest(self, autoPlay=False):
        VSlog(self._url)

        playback_data = self.get_playback(self._url)
        if not playback_data:
            return False, False

        playback_root, m3u8referer = playback_data
        sources = self.decrypt_playback(playback_root["playback"])
        if not sources:
            return False, False

        urls = [src["url"] for src in sources if "url" in src]
        quals = [src.get("label", src.get("quality", "")) for src in sources]

        headers = {
            "User-Agent": UA,
            "Referer": m3u8referer,
            "Origin": urllib_parse.urljoin(self._url, '/')[:-1]
        }

        if len(urls) == 1:
            api_call = urls[0] + '|%s' % '&'.join(['%s=%s' % (key, (headers[key])) for key in headers])
        else:
            api_call = dialog().VSselectqual(quals, urls) + '|%s' % '&'.join(['%s=%s' % (key, (headers[key])) for key in headers])

        if api_call:
            return True, api_call
        
        return False, False
