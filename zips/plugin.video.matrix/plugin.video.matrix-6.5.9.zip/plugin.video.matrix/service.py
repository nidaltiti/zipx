# -*- coding: utf-8 -*-

from resources.lib.update import cUpdate

def service():
    # Always update sites.json from repo
    cUpdate().getUpdateSetting()

if __name__ == '__main__':
    service()
