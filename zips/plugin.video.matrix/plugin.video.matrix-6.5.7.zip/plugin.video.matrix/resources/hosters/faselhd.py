﻿#coding: utf-8
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.hosters.hoster import iHoster
from resources.lib.comaddon import dialog, VSlog, siteManager
from resources.sites.faselhd import decode_page
from resources.lib import random_ua

UA = random_ua.get_phone_ua()

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'faselhd', 'FaselHD', 'gold')

    def isDownloadable(self):
        return True

    def _getMediaLinkForGuest(self, autoPlay = False):
        api_call = False
        sReferer = siteManager().getUrlMain('faselhd')
        VSlog(self._url)

        oParser = cParser()   
        oRequest = cRequestHandler(self._url)
        oRequest.addHeaderEntry('user-agent', UA)
        oRequest.addHeaderEntry('Referer', sReferer)
        oRequest.enableCache(False)
        sHtmlContent = oRequest.request()

        if 'adilbo' in sHtmlContent:
            sHtmlContent = decode_page(sHtmlContent)
        else:
            sHtmlContent2 = ''
            try:
                patterns = [
                    r'</button>\s*<script[^>]*>(.*?)</script>\s*<button',
                    r'</video>\s*<script[^>]*>(.*?)</script',
                    r'<i class="fa fa-backward">.+?<script[^>]*>(.*?)</script'
                ]

                all_results = []
                for sPattern in patterns:
                    aResult = oParser.parse(sHtmlContent, sPattern)
                    if aResult[0]:
                        if '' in aResult[1]:
                            continue
                        all_results.extend(aResult[1])

                for coded in all_results:
                    oRequest = cRequestHandler("https://matrixflix-one.vercel.app//api")
                    oRequest.addHeaderEntry('user-agent', UA)
                    oRequest.enableCache(False)
                    oRequest.addParameters('code', coded)
                    oRequest.setRequestType(1)
                    response = oRequest.request(jsonDecode=True)
                    decoded_code = response['code'].replace('\\"', '"')
                    sHtmlContent2 += decoded_code

            except:
                sHtmlContent2 = ''
                VSlog('Failed Api')

        sPattern = r'file\s*[:=]\s*["\']([^"\']+)["\']'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if not aResult[0]:
            aResult = oParser.parse(sHtmlContent2, sPattern)
        if aResult[0]:
            api_call = aResult[1][0]

        sPattern = r'data-url="([^<]+)">([^<]+)</button>'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if not aResult[0]:
            aResult = oParser.parse(sHtmlContent2, sPattern)
        if aResult[0]:
            sLink = [str(entry[0]) for entry in aResult[1]]
            sQual = [str(entry[1].upper()) for entry in aResult[1]]
            api_call = dialog().VSselectqual(sQual, sLink)

        sPattern = r'videoSrc\s*=\s*["\']([^"\']+)["\']'
        aResult = oParser.parse(sHtmlContent2, sPattern)
        if not aResult[0]:
            aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            api_call = aResult[1][0]

        if api_call:
            return True, f'{api_call}|Referer={sReferer}&User-Agent={UA}'

        return False, False
