﻿# coding: utf-8

from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.util import urlHostName
from resources.lib.parser import cParser
from resources.hosters.hoster import iHoster
from resources.lib.comaddon import VSlog
from resources.lib.packer import cPacker
from six.moves import urllib_parse
from resources.lib import random_ua

UA = random_ua.get_pc_ua()

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'filelions', 'FileLions')

    def _getMediaLinkForGuest(self, autoPlay = False):
        VSlog(self._url)
        referer = self._url
        if '|Referer=' in self._url:
            self._url, referer = self._url.split('|Referer=')
            referer = urllib_parse.urljoin(referer, '/')
        else:
            referer = self._url

        self._url = self._url.replace('/d/','/v/').replace('/f/','/v/').replace('/file/','/v/').replace('/download/','/v/')
        oRequest = cRequestHandler(self._url)
        oRequest.addHeaderEntry('Referer', referer)
        oRequest.enableCache(False)
        sHtmlContent = oRequest.request()

        api_call = ''

        oParser = cParser()
        if 'Page is loading' in sHtmlContent:
            self._url = self.get_redirect_url()
            sReferer = self._url
            oRequest = cRequestHandler(self._url)
            oRequest.addHeaderEntry("User-Agent", UA)
            oRequest.addHeaderEntry('Referer', sReferer)
            oRequest.enableCache(False)
            sHtmlContent = oRequest.request()

        sPattern = '(\s*eval\s*\(\s*function\(p,a,c,k,e(?:.|\s)+?)<\/script>'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0] is True:
            sHtmlContent = cPacker().unpack(aResult[1][0])
        
        sPattern = 'sources:\s*\[{file:\s*["\']([^"\']+)'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0] is True:
            api_call = aResult[1][0]

        sPattern = 'file:"(.+?)"'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            api_call = aResult[1][0] 

        sPattern = r'"(hls2|hls3|hls4)"\s*:\s*"([^"]+)"'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult and aResult[0]:
            link_map = {item[0]: item[1] for item in aResult[1]}

            base_url = f'https://{urlHostName(self._url)}'
            api_call = None
            fallback_txt = None

            for key in ["hls4", "hls2", "hls3"]:
                if key in link_map:
                    link = link_map[key]
                    if not link.startswith("http"):
                        link = base_url + link
                    if not link.endswith(".txt"):
                        api_call = link
                        break
                    else:
                        fallback_txt = link

            if api_call is None and fallback_txt:
                api_call = fallback_txt

        if api_call:
            return True, api_call

        return False, False

def get_redirect_url(self):
        import random
        from urllib.parse import urlparse, urlunparse
        dmca = [
            'hgplaycdn.com',
            'habetar.com',
            'yuguaab.com',
            'guxhag.com',
            'auvexiug.com',
            'xenolyzb.com',
        ]

        main = [
            'kravaxxa.com',
            'davioad.com',
            'haxloppd.com',
            'tryzendm.com',
            'dumbalag.com',
        ]

        rules = [
            'dhcplay.com',
            'hglink.to',
            'test.hglink.to',
            'wish-redirect.aiavh.com',
        ]

        parsed = urlparse(self._url)
        hostname = parsed.hostname

        if hostname in rules:
            destination = random.choice(main)
        else:
            destination = random.choice(dmca)

        final_url = urlunparse(('https', destination, parsed.path, '', parsed.query, ''))
        return final_url