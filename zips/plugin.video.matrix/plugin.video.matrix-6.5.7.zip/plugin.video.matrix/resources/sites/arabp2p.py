﻿# -*- coding: utf-8 -*-

import re
import urllib.request
import urllib.parse
import http.cookiejar
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress, VSlog, siteManager, addon
from resources.lib import random_ua

UA = random_ua.get_random_ua()	

SITE_IDENTIFIER = 'arabp2p'
SITE_NAME = 'Arab P2P'
SITE_DESC = 'arabic torrents'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

MOVIE_EN = (f'{URL_MAIN}index.php?page=torrents&category=42', 'showMovies')
MOVIE_AR = (f'{URL_MAIN}index.php?page=torrents&category=41', 'showMovies')
MOVIE_DUBBED = (f'{URL_MAIN}index.php?page=torrents&category=88', 'showMovies')
MOVIE_HI = (f'{URL_MAIN}index.php?page=torrents&category=86', 'showMovies')
MOVIE_ASIAN = (f'{URL_MAIN}index.php?page=torrents&category=59', 'showMovies')
MOVIE_TURK = (f'{URL_MAIN}index.php?page=torrents&category=116', 'showMovies')
KID_MOVIES = (f'{URL_MAIN}index.php?page=torrents&category=98', 'showMovies')

SERIE_TR = (f'{URL_MAIN}index.php?page=torrents&category=115', 'showMovies')
SERIE_DUBBED = (f'{URL_MAIN}index.php?page=torrents&category=71', 'showMovies')
SERIE_ASIA = (f'{URL_MAIN}index.php?page=torrents&category=57', 'showMovies')
SERIE_EN = (f'{URL_MAIN}index.php?page=torrents&category=45', 'showMovies')
SERIE_AR = (f'{URL_MAIN}index.php?page=torrents&category=44', 'showMovies')

DOC_NEWS = (f'{URL_MAIN}index.php?page=torrents&category=19', 'showMovies')
ANIM_NEWS = (f'{URL_MAIN}index.php?page=torrents&category=101', 'showMovies')
REPLAYTV_PLAY = (f'{URL_MAIN}index.php?page=torrents&category=52', 'showMovies')

URL_SEARCH = (f'{URL_MAIN}index.php?page=torrents&search=', 'showMovies')
URL_SEARCH_MOVIES = (f'{URL_MAIN}index.php?page=torrents&search=', 'showMovies')
FUNCTION_SEARCH = 'showMovies'
	
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', URL_SEARCH[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30076), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام عربية', 'arab.png', oOutputParameterHandler)
 
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_ASIAN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أسيوية', 'asia.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_TURK[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام تركية', 'turk.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_HI[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام هندية', 'hend.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام كرتون', 'anim.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_DUBBED[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام مدبلجة', 'mdblg.png', oOutputParameterHandler) 

    oOutputParameterHandler.addParameter('siteUrl', DOC_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام وثائقية', 'doc.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'مسلسلات عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_ASIA[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'مسلسلات أسيوية', 'asia.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_TR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'مسلسلات تركية', 'turk.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_DUBBED[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'مسلسلات مدبلجة', 'mdblg.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'مسلسلات انمي', 'anime.png', oOutputParameterHandler)  

    oOutputParameterHandler.addParameter('siteUrl', REPLAYTV_PLAY[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'مسرحيات', 'msrh.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSearch():
    oGui = cGui()
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}index.php?page=torrents&search={sSearchText}'
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return  

def showMovies(sSearch = ''):
    oGui = cGui()
    cook = account_login()
    if sSearch:
      sUrl = sSearch.replace(' ', '+')
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('cookie', cook)
    sHtmlContent = oRequestHandler.request()

    blocks = re.findall(r'<div class="file-header">(.*?)</div>\s*<!--', sHtmlContent, re.DOTALL)

    for block in blocks:
        oOutputParameterHandler = cOutputParameterHandler() 

        sPattern = r'name=["\']t_url["\']\s*href="([^"]+)"'
        aResult = oParser.parse(block, sPattern)
        if aResult[0]:   
            for aEntry in aResult[1]:
                siteUrl = aEntry

        sPattern = r'rel="([^"]+)"'
        aResult = oParser.parse(block, sPattern)
        if aResult[0]:   
            for aEntry in aResult[1]:
                sThumb = f'{aEntry}|referer={URL_MAIN}'

        sPattern = r'<span style=".+?">(.+?)</span>(.+?)</span></a>'
        aResult = oParser.parse(block, sPattern)
        if aResult[0]:   
            for aEntry in aResult[1]:
                sName = aEntry[0]
                if '">' in sName:
                    sName = sName.split('">')[1]
                sTitle = f"{sName.replace('[', ' ').replace(']', ' ')} [{aEntry[1].replace('[', ' ').replace(']', ' ')}]"

        sPattern = r'class="tor_free_link">(.+?)</span>'
        aResult = oParser.parse(block, sPattern)
        if aResult[0]:   
            for aEntry in aResult[1]:
                sTitle = aEntry.replace('[', ' ').replace(']', ' ')

        sPattern = r'class="tor_link">(.+?)</span>'
        aResult = oParser.parse(block, sPattern)
        if aResult[0]:   
            for aEntry in aResult[1]:
                sTitle = aEntry.replace('[', ' ').replace(']', ' ')

        sPattern = r'<button class="download-btn">\s*<a href=["\']([^"\']+)["\']'
        aResult = oParser.parse(block, sPattern)
        if aResult[0]:   
            for aEntry in aResult[1]:
                siteUrl = aEntry
                if not aEntry.startswith('magnet:'):
                    siteUrl = f'{URL_MAIN}{aEntry}'

        sDesc = ''
        sYear = ''
        m = re.search('([0-9]{4})', sTitle)
        if m:
            sYear = str(m.group(0))

        if not sThumb.startswith('http'):
             sThumb = f'{URL_MAIN}{sThumb}'

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sYear', sYear)
        oOutputParameterHandler.addParameter('sDesc', sDesc)

        oGui.addTV(SITE_IDENTIFIER, 'showServer', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if not sSearch:  
        sStart = 'name="change_pagepages"'
        sEnd = '</form'
        sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

        sPattern = 'class="pager"><a href="([^"]+)">(.+?)</a>'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            oOutputParameterHandler = cOutputParameterHandler() 
            for aEntry in aResult[1]:
 
                sTitle =   f'[COLOR red]Page: {aEntry[1]}[/COLOR]'
                siteUrl = f'{URL_MAIN[:-1]}{aEntry[0]}'

                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
			
                oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()  

def showServer():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    			   
    sHosterUrl = f'{sUrl}'
    oHoster = cHosterGui().getHoster('torrent')  
    if oHoster:
        sDisplayTitle = sMovieTitle
        oHoster.setDisplayName(sDisplayTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()  

def account_login():
    import time
    addons = addon()
    aUser = addons.getSetting('hoster_arabp2p_username')
    aPass = addons.getSetting('hoster_arabp2p_password')

    try:
        last_gen = int(addons.getSetting('last_arabp2p_cookie_create'))
    except Exception:
        last_gen = 0
    if not addons.getSetting('last_arabp2p_cookie') or last_gen < (time.time() - (1 * 20 * 60 * 60)):

        data = {
            "uid": aUser,
            "pwd": aPass
        }
        encoded_data = urllib.parse.urlencode(data).encode("utf-8")

        cookie_jar = http.cookiejar.CookieJar()
        handler = urllib.request.HTTPCookieProcessor(cookie_jar)
        opener = urllib.request.build_opener(handler)

        req = urllib.request.Request(
            url= f"{URL_MAIN}index.php?page=login",
            data=encoded_data,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "https://arabp2p.net",
                "Referer": "https://arabp2p.net/index.php?page=signup",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0"
            }
        )

        response = opener.open(req)

        cookie_header = "; ".join([f"{cookie.name}={cookie.value}" for cookie in cookie_jar])

        addons.setSetting('last_arabp2p_cookie', cookie_header)
        addons.setSetting('last_arabp2p_cookie_create', str(int(time.time())))

        return cookie_header
    else:
        return addons.getSetting('last_arabp2p_cookie')

def opensetting():
    addon().openSettings()