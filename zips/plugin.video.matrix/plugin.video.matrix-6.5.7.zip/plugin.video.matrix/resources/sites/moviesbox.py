﻿# -*- coding: utf-8 -*-

import time
import hmac
import hashlib
import base64
from urllib.parse import urlparse, parse_qsl, urlencode
import json
import os
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, addon, siteManager, VSPath
from resources.lib.util import cUtil, urlHostName

UA = 'com.community.oneroom/50020064 (Linux; U; Android 11; en_US; Mi 5s; Build/RQ3A.211001.001; Cronet/141.0.7340.3)'

SITE_IDENTIFIER = 'moviesbox'
SITE_NAME = 'MoviesBox'
SITE_DESC = 'multi vod'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER) 

PRIMARY_KEY = "76iRl07s0xSN9jqmEWAt79EBJZulIQIsV64FZr2O"
ALTERNATE_KEY = "Xqn2nnO41/L92o1iuXhSLHTbXvY4Z5ZZ62m8mSLA"

MOVIE_AR = (f'{URL_MAIN}wefeed-mobile-bff/subject-api/genre-top|1581736020528300216', 'showMovies')
MOVIE_EN = (f'{URL_MAIN}wefeed-mobile-bff/subject-api/genre-top|1275429657646694560', 'showMovies')
MOVIE_HI = (f'{URL_MAIN}wefeed-mobile-bff/subject-api/list|India', 'showMovies')
KID_MOVIES = (f'{URL_MAIN}wefeed-mobile-bff/subject-api/list|genre=Animation', 'showMovies')

SERIE_EN = (f'{URL_MAIN}wefeed-mobile-bff/subject-api/list|class=All', 'showSeries')
SERIE_AR = (f'{URL_MAIN}wefeed-mobile-bff/subject-api/list|class=Arabic dub', 'showSeries')

ANIM_NEWS = (f'{URL_MAIN}wefeed-mobile-bff/subject-api/list|genre=Animation', 'showSeries')

URL_SEARCH = ('', 'showSeries')
URL_SEARCH_MOVIES = ('', 'showMovies')
URL_SEARCH_SERIES = ('', 'showSeries')
FUNCTION_SEARCH = 'showMovies'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_HI[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام هندية', 'hend.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام انيميشن', 'anim.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات انمي', 'anime.png', oOutputParameterHandler) 

    oGui.setEndOfDirectory()

def make_api_request(url, method="GET", body=""):

    sig = sign_request(PRIMARY_KEY, url, method, body)
    headers = {
        "User-Agent": UA,
        "Accept": "application/json",
        "Host": urlHostName(URL_MAIN),
        "Content-Type": "application/json; charset=utf-8",
        "x-client-info": json.dumps({"package_name":"com.community.oneroom","version_name":"3.0.08.0911.03","region":"US","timezone":"Asia/Bahrain","sp_code":"","X-Play-Mode":"2"}),
        "x-client-token": sig["x-client-token"],
        "x-tr-signature": sig["x-tr-signature"],
        "x-client-status": "1"
    }

    if method.upper() == "POST":
        oRequestHandler = cRequestHandler(url)
        for key, value in headers.items():
            oRequestHandler.addHeaderEntry(key, value)

        for key, value in json.loads(body).items():
            oRequestHandler.addJSONEntry(key, value)
        oRequestHandler.setRequestType(1)
        response = oRequestHandler.request(jsonDecode=True)

    else:
        oRequestHandler = cRequestHandler(url)
        for key, value in headers.items():
            oRequestHandler.addHeaderEntry(key, value)
        response = oRequestHandler.request(jsonDecode=True)

    try:
        return response
    except ValueError:
        return {}

def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        showMovies(sSearchText)
        oGui.setEndOfDirectory()
        return
 
def showSeriesSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        showSeries(sSearchText)
        oGui.setEndOfDirectory()
        return

def showFilters():
    oGui = cGui()
    sUrl =f"{URL_MAIN}wefeed-mobile-bff/subject-api/filter-items?tabId=2&filterItemVer=v3"

    sHtmlContent_Main = make_api_request(sUrl)

    entries = []
    data = sHtmlContent_Main.get('data', {})
    type_list = data.get("typeList", [])

    genres = []
    countries = []
    dubs = []

    for type_entry in type_list:
        oOutputParameterHandler = cOutputParameterHandler()
        for item in type_entry.get("items", []):
            filter_type = item.get("filterType")
            values = item.get("filterValsV2", [])

            if filter_type == "genre":
                genres = [v.get("name") for v in values if v.get("name")]
                oOutputParameterHandler.addListParameter('sList', genres)
                oOutputParameterHandler.addParameter('sType', 'genre')
                oGui.addDir(SITE_IDENTIFIER, 'showFiltersLists', addon().VSlang(30105), 'genres.png', oOutputParameterHandler)
            elif filter_type == "country":
                countries = [v.get("name") for v in values if v.get("name")]
                oOutputParameterHandler.addListParameter('sList', countries)
                oOutputParameterHandler.addParameter('sType', 'country')
                oGui.addDir(SITE_IDENTIFIER, 'showFiltersLists', 'Country|البلد', 'genres.png', oOutputParameterHandler)
            elif filter_type == "classify":
                dubs = [v.get("name") for v in values if v.get("name")]
                oOutputParameterHandler.addListParameter('sList', dubs)
                oOutputParameterHandler.addParameter('sType', 'classify')
                oGui.addDir(SITE_IDENTIFIER, 'showFiltersLists', addon().VSlang(70002), 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showFiltersLists():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    oInputParameterHandler = cInputParameterHandler()

    sList = oInputParameterHandler.getList('sList')
    filter_type = oInputParameterHandler.getValue('sType')

    for type_entry in sList:
        if filter_type == "genre":
            oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}wefeed-mobile-bff/subject-api/list|genre={type_entry}')
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', type_entry, 'genres.png', oOutputParameterHandler)

        elif filter_type == "country":
            oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}wefeed-mobile-bff/subject-api/list|country={type_entry}')
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', type_entry, 'genres.png', oOutputParameterHandler)

        elif filter_type == "classify":
            oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}wefeed-mobile-bff/subject-api/list|class={type_entry}')
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', type_entry, 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSeriesFilters():
    oGui = cGui()
    sUrl =f"{URL_MAIN}wefeed-mobile-bff/subject-api/filter-items?tabId=5&filterItemVer=v3"

    sHtmlContent_Main = make_api_request(sUrl)

    entries = []
    data = sHtmlContent_Main.get('data', {})
    type_list = data.get("typeList", [])

    genres = []
    countries = []
    dubs = []

    for type_entry in type_list:
        oOutputParameterHandler = cOutputParameterHandler()
        for item in type_entry.get("items", []):
            filter_type = item.get("filterType")
            values = item.get("filterValsV2", [])

            if filter_type == "genre":
                genres = [v.get("name") for v in values if v.get("name")]
                oOutputParameterHandler.addListParameter('sList', genres)
                oOutputParameterHandler.addParameter('sType', 'genre')
                oGui.addDir(SITE_IDENTIFIER, 'showFiltersLists', addon().VSlang(30105), 'genres.png', oOutputParameterHandler)
            elif filter_type == "country":
                countries = [v.get("name") for v in values if v.get("name")]
                oOutputParameterHandler.addListParameter('sList', countries)
                oOutputParameterHandler.addParameter('sType', 'country')
                oGui.addDir(SITE_IDENTIFIER, 'showFiltersLists', 'Country|البلد', 'genres.png', oOutputParameterHandler)
            elif filter_type == "classify":
                dubs = [v.get("name") for v in values if v.get("name")]
                oOutputParameterHandler.addListParameter('sList', dubs)
                oOutputParameterHandler.addParameter('sType', 'classify')
                oGui.addDir(SITE_IDENTIFIER, 'showFiltersLists', addon().VSlang(70002), 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSeriesFiltersLists():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    oInputParameterHandler = cInputParameterHandler()

    sList = oInputParameterHandler.getList('sList')
    filter_type = oInputParameterHandler.getValue('sType')

    for type_entry in sList:
        if filter_type == "genre":
            oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}wefeed-mobile-bff/subject-api/list|genre={type_entry}')
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', type_entry, 'genres.png', oOutputParameterHandler)

        elif filter_type == "country":
            oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}wefeed-mobile-bff/subject-api/list|country={type_entry}')
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', type_entry, 'genres.png', oOutputParameterHandler)

        elif filter_type == "classify":
            oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}wefeed-mobile-bff/subject-api/list|class={type_entry}')
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', type_entry, 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showMovies(sSearch = ''):
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    oInputParameterHandler = cInputParameterHandler()
    
    if sSearch:
        sUrl =f"{URL_MAIN}wefeed-mobile-bff/subject-api/search/v2"

        payload_dict = {
            "keyword": sSearch,
            "page": 1,
            "perPage": 10
        }

        payload = json.dumps(payload_dict)
        sHtmlContent_Main = make_api_request(sUrl, "POST", payload)

        entries = []
        data = sHtmlContent_Main.get('data', {})

        for result in data.get('results', []):
            for info in result.get('subjects', []):
                if info.get('subjectType') != 1:
                    continue 

                sTitle = info.get('title', '')
                sDesc = info.get('description', '')
                sThumb = info.get('cover', {}).get('url', '')
                sYear = info.get('releaseDate', '')[:4] if info.get('releaseDate') else ''
                subjectId = info.get('subjectId', '')

                siteUrl = f"{URL_MAIN}|{subjectId}"

                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sYear', sYear)
                oOutputParameterHandler.addParameter('sDesc', sDesc)
                oOutputParameterHandler.addParameter('subject_id', subjectId)

                oGui.addMovie(SITE_IDENTIFIER, 'showLink', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    else:
        oGui.addDir(SITE_IDENTIFIER, 'showFilters', addon().VSlang(30105), 'genres.png', oOutputParameterHandler)

        sUrlRaw = oInputParameterHandler.getValue('siteUrl')
        sPage = oInputParameterHandler.getValue('sPage') or 1

        if '|' in sUrlRaw:
            sUrl, sType = sUrlRaw.split('|')
        else:
            sUrl = sUrlRaw
            sType = "1581736020528300216"

        if '/list' in sUrl:
            payload_dict = {
                "page": sPage,
                "perPage": 12,
                "channelId": "1",
                "classify": "All",
                "country": "All",
                "year": "All",
                "genre": "All",
                "sort": "ForYou"
            }

            if 'genre=' in sType:
                payload_dict["genre"] = sType.split('=')[1]
            elif 'class=' in sType:
                payload_dict["classify"] = sType.split('=')[1]
            elif 'country=' in sType:
                payload_dict["country"] = sType.split('=')[1]
            else:
                payload_dict["country"] = sType

        else:
            payload_dict = {
                "type": sType,
                "page": sPage,
                "perPage": 10
            }

        payload = json.dumps(payload_dict)
        sHtmlContent_Main = make_api_request(sUrl, "POST", payload)

    entries = []
    data = sHtmlContent_Main.get('data', {})
    if 'list' in data:
        entries = [entry.get('info', {}) for entry in data.get('list', [])]
    elif 'items' in data:
        entries = data.get('items', [])

    for info in entries:
        sTitle = info.get('title', '')
        sDesc = info.get('description', '')
        sThumb = info.get('cover', {}).get('url', '')
        sYear = info.get('releaseDate', '')[:4] if info.get('releaseDate') else ''
        subjectId = info.get('subjectId', '')

        siteUrl = f"{URL_MAIN}|{subjectId}"

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sYear', sYear)
        oOutputParameterHandler.addParameter('sDesc', sDesc)
        oOutputParameterHandler.addParameter('subject_id', subjectId)

        oGui.addMovie(SITE_IDENTIFIER, 'showLink', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if not sSearch:
        sNextPage = __checkForNextPage(sHtmlContent_Main)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sPage', sNextPage)
            oOutputParameterHandler.addParameter('siteUrl', sUrlRaw)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()

def showSeries(sSearch = ''):
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    oInputParameterHandler = cInputParameterHandler()
    
    if sSearch:
        sUrl =f"{URL_MAIN}wefeed-mobile-bff/subject-api/search/v2"

        payload_dict = {
            "keyword": sSearch,
            "page": 1,
            "perPage": 10
        }

        payload = json.dumps(payload_dict)
        sHtmlContent_Main = make_api_request(sUrl, "POST", payload)

        entries = []
        data = sHtmlContent_Main.get('data', {})

        for result in data.get('results', []):
            for info in result.get('subjects', []):
                if info.get('subjectType') != 2:
                    continue 

                sTitle = info.get('title', '')
                sDesc = info.get('description', '')
                sThumb = info.get('cover', {}).get('url', '')
                sYear = info.get('releaseDate', '')[:4] if info.get('releaseDate') else ''
                subjectId = info.get('subjectId', '')

                siteUrl = f"{URL_MAIN}wefeed-mobile-bff/subject-api/season-info?subjectId={subjectId}"

                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sYear', sYear)
                oOutputParameterHandler.addParameter('sDesc', sDesc)
                oOutputParameterHandler.addParameter('subject_id', subjectId)

                oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    else:
        oGui.addDir(SITE_IDENTIFIER, 'showSeriesFilters', addon().VSlang(30105), 'genres.png', oOutputParameterHandler)

        sUrlRaw = oInputParameterHandler.getValue('siteUrl')
        sPage = oInputParameterHandler.getValue('sPage') or 1

        if '|' in sUrlRaw:
            sUrl, sType = sUrlRaw.split('|')
        else:
            sUrl = sUrlRaw
            sType = "1581736020528300216"

        if '/list' in sUrl:
            payload_dict = {
                "page": sPage,
                "perPage": 12,
                "channelId": "2",
                "classify": "All",
                "country": "All",
                "year": "All",
                "genre": "All",
                "sort": "ForYou"
            }

            if 'genre=' in sType:
                payload_dict["genre"] = sType.split('=')[1]
            elif 'class=' in sType:
                payload_dict["classify"] = sType.split('=')[1]
            elif 'country=' in sType:
                payload_dict["country"] = sType.split('=')[1]
            else:
                payload_dict["country"] = sType

        else:
            payload_dict = {
                "type": sType,
                "page": sPage,
                "perPage": 10
            }

        payload = json.dumps(payload_dict)
        sHtmlContent_Main = make_api_request(sUrl, "POST", payload)

    entries = []
    data = sHtmlContent_Main.get('data', {})

    if 'list' in data:
        entries = [entry.get('info', {}) for entry in data.get('list', [])]
    elif 'items' in data:
        entries = data.get('items', [])

    for info in entries:
        sTitle = info.get('title', '')
        sDesc = info.get('description', '')
        sThumb = info.get('cover', {}).get('url', '')
        sYear = info.get('releaseDate', '')[:4] if info.get('releaseDate') else ''
        subjectId = info.get('subjectId', '')

        siteUrl = f"{URL_MAIN}wefeed-mobile-bff/subject-api/season-info?subjectId={subjectId}"

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sYear', sYear)
        oOutputParameterHandler.addParameter('sDesc', sDesc)
        oOutputParameterHandler.addParameter('subject_id', subjectId)

        oGui.addMovie(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if not sSearch:
        sNextPage = __checkForNextPage(sHtmlContent_Main)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sPage', sNextPage)
            oOutputParameterHandler.addParameter('siteUrl', sUrlRaw)
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()
		
def showSeasons():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler() 
    oInputParameterHandler = cInputParameterHandler()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sDesc = oInputParameterHandler.getValue('sDesc')
    subject_id = oInputParameterHandler.getValue('subject_id')

    sHtmlContent_Main = make_api_request(sUrl)

    for season in sHtmlContent_Main["data"].get("seasons", []):

        sSeason = season.get('se', '')
        sTitle = f"{sMovieTitle} S{sSeason}"
        sDesc = sDesc
        sThumb = sThumb
        sYear = ''
        subjectId = subject_id

        siteUrl = f"{URL_MAIN}wefeed-mobile-bff/subject-api/resource|season={sSeason}"

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sYear', sYear)
        oOutputParameterHandler.addParameter('sDesc', sDesc)
        oOutputParameterHandler.addParameter('subject_id', subjectId)
        oOutputParameterHandler.addParameter('sSeason', sSeason)

        oGui.addSeason(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    oGui.setEndOfDirectory() 
  
def showEpisodes():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    oInputParameterHandler = cInputParameterHandler()
    
    sUrlRaw = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sDesc = oInputParameterHandler.getValue('sDesc')
    subject_id = oInputParameterHandler.getValue('subject_id')
    sSeason = oInputParameterHandler.getValue('sSeason')

    sPage = oInputParameterHandler.getValue('sPage') or 1

    if '|' in sUrlRaw:
        sUrl, sSeason = sUrlRaw.split('|')
        sSeason = sSeason.split('=')[1]
    else:
        sUrl = f'{URL_MAIN}wefeed-mobile-bff/subject-api/resource'
        sSeason = sSeason

    params = {
        "subjectId": subject_id,
        "page": sPage,
        "perPage": 10,
        "all": 0,
        "startPosition": 1,
        "endPosition": 1,
        "pagerMode": 0,
        "resolution": 0,
        "se": sSeason,
        "epFrom": 1,
        "epTo": 1
    }

    sUrl = f"{sUrl}?{urlencode(params)}"
    sHtmlContent_Main = make_api_request(sUrl)

    for episodes in sHtmlContent_Main["data"].get("list", []):

        sEpisode = episodes.get('ep', '')
        sTitle = f"{sMovieTitle} E{sEpisode}"
        sDesc = sDesc
        sThumb = sThumb
        sYear = ''

        sUrl = f'{URL_MAIN}wefeed-mobile-bff/subject-api/season-info?subjectId={subject_id}'

        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sYear', sYear)
        oOutputParameterHandler.addParameter('sDesc', sDesc)
        oOutputParameterHandler.addParameter('subject_id', subject_id)
        oOutputParameterHandler.addParameter('season_id', sSeason)
        oOutputParameterHandler.addParameter('episode_id', sEpisode)
            
        oGui.addEpisode(SITE_IDENTIFIER, 'showLink', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    sNextPage = __checkForNextPage(sHtmlContent_Main)
    if sNextPage:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('sPage', sNextPage)
        oOutputParameterHandler.addParameter('siteUrl', sUrlRaw)
        oOutputParameterHandler.addParameter('subject_id', subject_id)
        oGui.addDir(SITE_IDENTIFIER, 'showEpisodes', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory() 
	
def showLink():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    season_id = oInputParameterHandler.getValue('season_id')
    episode_id = oInputParameterHandler.getValue('episode_id')
    subject_id = oInputParameterHandler.getValue('subject_id')

    if season_id and episode_id:
        url = f"{URL_MAIN}wefeed-mobile-bff/subject-api/play-info?subjectId={subject_id}&se={season_id}&ep={episode_id}"
    else:
        url = f"{URL_MAIN}wefeed-mobile-bff/subject-api/play-info?subjectId={subject_id}"

    res = make_api_request(url)
    data = res.get("data", {})
    streams = data.get("streams", []) or data.get("playInfo", {}).get("streams", [])
    for aEntry in streams:
        sQual = aEntry.get("resolutions", [])
        sDisplayTitle = f'{sMovieTitle} - [{sQual}]'
        sHosterUrl = aEntry.get('url')
        streamId  = aEntry.get('id')
        if not sHosterUrl:
            continue
        
        if season_id and episode_id:
            suburl = f"{URL_MAIN}wefeed-mobile-bff/subject-api/get-ext-captions?subjectId={subject_id}&resourceId={streamId}&episode={episode_id}"
        else:
            suburl = f"{URL_MAIN}wefeed-mobile-bff/subject-api/get-stream-captions?subjectId={subject_id}&streamId={streamId}"

        subres = request_subtitles(suburl)
        captions = subres.get("data", {}).get("extCaptions", [])

        LANG_MAP = {
                'en': 'English',
                'ar': 'Arabic',
                'vi': 'Vietnamese',
                'ko': 'Korean',
                'sl': 'Slovenian',
                'id': 'Indonesian',
                'hr': 'Croatian',
                'ru': 'Russian',
                'sv': 'Swedish',
                'no': 'Norwegian',
                'it': 'Italian',
                'el': 'Greek',
                'de': 'German',
                'fi': 'Finnish',
                'nl': 'Dutch',
                'es': 'Spanish',
                'da': 'Danish',
                'fr': 'French',
                'ro': 'Romanian',
                'ms': 'Malay',
                'bn': 'Bengali',
                'th': 'Thai',
                'is': 'Icelandic',
                'zh': 'Chinese',
                'si': 'Sinhala',
                'tr': 'Turkish',
                'fil': 'Finland',
                'in_id': 'Indian',
                'farsi/persian': 'Farsi',
                'brazillian-portuguese': 'BrazilianPortuguese',
                'big_5_code': 'Chinese',
                'chinese-bg-code': 'Chinese',
                'english-german': 'EnglishGerman',
                'Unknown': 'Unknown'
            }

        subtitle_files = []
        subtitle_path = VSPath('special://home/')
        cleanup_subtitles(subtitle_path)
        base_name = f"Matrixflix.{sMovieTitle.replace(' ', '.')}"
        if season_id and episode_id:
            base_name += f".{season_id}.{episode_id}"
        for captions in captions:
            if not captions.get('url'):
                continue
            lang = captions['lan']
            lang_label = LANG_MAP.get(lang, lang).replace(' ', '.')
            ext = f".{captions.get('format', 'srt')}"
            filename = get_unique_filename(subtitle_path, base_name, lang_label, ext)
            final_path = os.path.join(subtitle_path, filename)
            try:
                from resources.lib import subtitles
                subtitles.download(captions['url'], final_path)
                if os.path.exists(final_path) and os.path.getsize(final_path) > 100:
                    subtitle_files.append(final_path)
                else:
                    VSlog(f"Subtitle file invalid or too small: {final_path}")
            except Exception as e:
                VSlog(f"Failed to download subtitle: {e}")

        headers = []
        sReferer = "https://api.inmoviebox.com"
        headers.append(f"Referer={sReferer}")
        headers.append(f"User-Agent={UA}")

        sign_cookie = aEntry.get('signCookie')
        if sign_cookie:
            headers.append(f"Cookie={sign_cookie}")

        if headers:
            sHosterUrl = f"{sHosterUrl}|{'&'.join(headers)}"
        if subtitle_files:
            sHosterUrl = f"{sHosterUrl}?sub.info={subtitle_files}"

        oHoster = cHosterGui().getHoster('directplay')
        if oHoster:
            oHoster.setDisplayName(sDisplayTitle)
            oHoster.setFileName(sMovieTitle)
            cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)          

    oGui.setEndOfDirectory()       

def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sHosterUrl = oInputParameterHandler.getValue('sHosterUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oHoster = cHosterGui().checkHoster(sHosterUrl)
    if oHoster:
        oHoster.setDisplayName(sMovieTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()

def __checkForNextPage(sHtmlContent):

    sNextPage = sHtmlContent['data']['pager']['nextPage'] if sHtmlContent['data']['pager']['nextPage'] else 1
    if sNextPage:
        return sNextPage

    return False

def md5_hex(data: str) -> str:
    return hashlib.md5(data.encode("utf-8")).hexdigest()

def sign_request(key_b64: str, url: str, method: str = "GET", body: str = "") -> dict:
    timestamp = int(time.time() * 1000)
    parsed_url = urlparse(url)
    path = parsed_url.path or ""
    
    params = sorted(parse_qsl(parsed_url.query))
    qs = urlencode(params)
    canonical_url = f"{path}?{qs}" if qs else path

    body_hash = ""
    body_length = ""
    if body:
        body_hash = md5_hex(body)
        body_length = str(len(body.encode("utf-8")))

    canonical = "\n".join([
        method.upper(),
        "application/json",
        "application/json; charset=utf-8",
        body_length,
        str(timestamp),
        body_hash,
        canonical_url
    ])

    key_bytes = base64.b64decode(key_b64)
    signature = hmac.new(key_bytes, canonical.encode("utf-8"), hashlib.md5).digest()
    encoded_signature = base64.b64encode(signature).decode("utf-8")
    x_tr_signature = f"{timestamp}|2|{encoded_signature}"

    reversed_ts = str(timestamp)[::-1]
    x_client_token = f"{timestamp},{md5_hex(reversed_ts)}"

    return {
        "x-tr-signature": x_tr_signature,
        "x-client-token": x_client_token
    }

def request_subtitles(url, method="GET", body=""):

    sig = sign_request(PRIMARY_KEY, url, method, body)
    headers = {
        "User-Agent": UA,
        "Accept": "application/json",
        "Content-Type": "application/json; charset=utf-8",
        "x-client-info": json.dumps({ "package_name": "com.community.mbox.in" }),
        "x-client-token": sig["x-client-token"],
        "x-tr-signature": sig["x-tr-signature"],
        "x-client-status": "0"
    }

    oRequestHandler = cRequestHandler(url)
    for key, value in headers.items():
        oRequestHandler.addHeaderEntry(key, value)
    response = oRequestHandler.request(jsonDecode=True)

    try:
        return response
    except ValueError:
        return {}
    
def cleanup_subtitles(subtitle_path):
    try:
        for file in os.listdir(subtitle_path):
            if file.lower().endswith('.srt'):
                full_path = os.path.join(subtitle_path, file)
                os.remove(full_path)

    except Exception as e:
        VSlog(f"Subtitle cleanup failed: {e}")

def get_unique_filename(base_path, base_name, lang_label, ext=".srt"):
    filename = f"{base_name}.{lang_label}{ext}"
    counter = 1
    unique_filename = filename
    while os.path.exists(os.path.join(base_path, unique_filename)):
        unique_filename = f"{base_name}.{lang_label}.{counter}{ext}"
        counter += 1
    return unique_filename