﻿# -*- coding: utf-8 -*-

import re, json
from urllib.parse import urlparse, parse_qs, urlencode
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, siteManager, addon
from resources.lib.parser import cParser
 
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0"

SITE_IDENTIFIER = 'aljazeera'
SITE_NAME = 'Aljazeera'
SITE_DESC = 'arabic vod'
 
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

DOC_NEWS = (f'{URL_MAIN}', 'showCategories')
DOC_SERIES = (f'{URL_MAIN}', 'showCategories')
REPLAYTV_NEWS = (f'{URL_MAIN}', 'showCategories')

def load():
    oGui = cGui()
    addons = addon()
    
    oOutputParameterHandler = cOutputParameterHandler()
    #oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    #oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30076), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', DOC_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showCategories', 'وثائقيات', 'doc.png', oOutputParameterHandler)
	
    oGui.setEndOfDirectory()

def showSearch():
    oGui = cGui()

    sSearchText = oGui.showKeyBoard()    
    if sSearchText:

        variables = {
            "query": sSearchText,
            "start": 1,
            "sort": "relevance"
        }

        params = {
            "wp-site": "aja",
            "operationName": "SearchQuery",
            "variables": json.dumps(variables),
            "extensions": "{}"
        }

        sUrl = f"{URL_MAIN}graphql?{urlencode(params)}"
        showSearchResults(sUrl)
        oGui.setEndOfDirectory()
        return

def showSearchResults(sUrl):
    oGui = cGui()
 
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('referer', f'{URL_MAIN}video/')
    oRequestHandler.addHeaderEntry('wp-site', 'aja')
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    for item in sHtmlContent.get('data', {}).get('searchPosts', {}).get('items', []):
        oOutputParameterHandler = cOutputParameterHandler()

        sTitle = item.get('title', 'No Title')
        sDesc = item.get('snippet', 'No Description')
        siteUrl = item.get('link', '')

        sThumb = ''
        pagemap = item.get('pagemap', {})

        if pagemap.get('cse_image'):
            sThumb = pagemap['cse_image'][0].get('src', '')
        elif pagemap.get('cse_thumbnail'):
            sThumb = pagemap['cse_thumbnail'][0].get('src', '')
        elif item.get('post', {}).get('featuredImage', {}).get('sourceUrl'):
            sThumb = f"{URL_MAIN}{item['post']['featuredImage']['sourceUrl']}"

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)

        oGui.addMisc(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)


    oGui.setEndOfDirectory() 


def showCategories():
    oGui = cGui()

    sCats = ['investigative', 'documentaries', 'news', 'digital']

    for sCat in sCats:
        oOutputParameterHandler = cOutputParameterHandler()

        variables = {
            "category": sCat,
            "quantity": 0,
            "offset": 0
        }

        params = {
            "wp-site": "aja",
            "operationName": "ArchipelagoProgramsQuery",
            "variables": json.dumps(variables),
            "extensions": "{}"
        }

        if sCat == 'news':
            variables = {"category":"news","categoryType":"categories","postTypes":["video","episode"],"excludeIds":["8038455","8038436","8017921","8037851","8036823","8035519"],"quantity":0,"offset":0}

            params = {
                "wp-site": "aja",
                "operationName": "ArchipelagoSectionPostsQuery",
                "variables": json.dumps(variables),
                "extensions": "{}"
            }

        siteUrl = f"{URL_MAIN}graphql?{urlencode(params)}"
    
        sTitle = sCat.capitalize()           
        
        oOutputParameterHandler.addParameter('siteUrl',siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        if sCat == 'news':
            oGui.addMisc(SITE_IDENTIFIER, 'showEpisodes', sTitle, 'sites/aljazeera.png', '', '', oOutputParameterHandler) 
        else:
            oGui.addMisc(SITE_IDENTIFIER, 'showContent', sTitle, 'sites/aljazeera.png', '', '', oOutputParameterHandler) 
       
    oGui.setEndOfDirectory() 

def showContent():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
 
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('referer', f'{URL_MAIN}video/')
    oRequestHandler.addHeaderEntry('wp-site', 'aja')
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    for program in sHtmlContent.get('data', {}).get('programs') or sHtmlContent.get('data', {}).get('articles'):
        oOutputParameterHandler = cOutputParameterHandler()

        sTitle = program.get('title', 'No Title')
        sDesc = program.get('excerpt', 'No Description')
        sLink = program.get('link', '')
        sThumbPath = program.get('outsideImage', {}).get('sourceUrl', '')

        variables = {
            "category": sLink.split('video/')[1],
            "quantity": 0,
            "offset": 0
        }

        params = {
            "wp-site": "aja",
            "operationName": "ArchipelagoEpisodesQuery",
            "variables": json.dumps(variables),
            "extensions": "{}"
        }

        siteUrl = f"{URL_MAIN}graphql?{urlencode(params)}"
        sThumb = f'{URL_MAIN}{sThumbPath}'

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)

        oGui.addMisc(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

 
    oGui.setEndOfDirectory() 

def showEpisodes():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
 
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('referer', f'{URL_MAIN}video/')
    oRequestHandler.addHeaderEntry('wp-site', 'aja')
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    for program in sHtmlContent.get('data', {}).get('programs') or sHtmlContent.get('data', {}).get('articles'):
        oOutputParameterHandler = cOutputParameterHandler()

        sTitle = program.get('title', 'No Title')
        sDesc = program.get('excerpt', 'No Description')
        sLink = program.get('link', '')
        siteUrl = f'{URL_MAIN}{sLink}'
        sThumbPath = program.get('outsideImage', {}).get('sourceUrl', '')
        sThumb = f'{URL_MAIN}{sThumbPath}'

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)

        oGui.addMisc(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    sUrl = oInputParameterHandler.getValue('siteUrl').replace('+', '')

    parsed = urlparse(sUrl)
    base_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
    query_raw = parse_qs(parsed.query)

    query_params = {k: v[0] for k, v in query_raw.items()}

    variables = json.loads(query_params.get('variables', '{}'))
    quantity = int(variables.get('quantity', 10)) or 10
    variables['offset'] = int(variables.get('offset', 0)) + quantity
    query_params['variables'] = json.dumps(variables)

    next_url = f"{base_url}?{urlencode(query_params)}"
    if next_url:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', next_url)
        oGui.addDir(SITE_IDENTIFIER, 'showEpisodes', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory() 

def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()    
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'"embedUrl":\s*"([^"]+)"' 
    aResult = oParser.parse(sHtmlContent,sPattern)
    if aResult[0]:
       for aEntry in aResult[1]:
            url = aEntry
            if url.startswith('//'):
                url = 'http:' + url

            oRequestHandler = cRequestHandler(url)
            sHtmlContent = oRequestHandler.request()

            sPattern = r'policyKey:\s*"([^"]+)"'
            aResult = oParser.parse(sHtmlContent,sPattern)
            if aResult[0]:
                oOutputParameterHandler = cOutputParameterHandler()
                policyKey = aResult[1][0]

                match = re.search(r'players\.brightcove\.net/(\d+)/.*?videoId=(\d+)', url)
                if match:
                    account_id = match.group(1)
                    video_id = match.group(2)
                    api_url = f"https://edge.api.brightcove.com/playback/v1/accounts/{account_id}/videos/{video_id}"

                    oRequestHandler = cRequestHandler(api_url)
                    oRequestHandler.addHeaderEntry('referer', url)
                    oRequestHandler.addHeaderEntry('Accept', f'application/json;pk={policyKey}')
                    sHtmlContent = oRequestHandler.request(jsonDecode=True)

                    itemList = []
                    for source in sHtmlContent.get("sources", []):
                        stream_type = source.get("type", "MP4")
                        stream_url = source.get("src")

                        sHosterUrl = stream_url
                        sDisplayTitle = f'[COLOR orange]{stream_type}[/COLOR] - {sMovieTitle}'
                        
                        if sHosterUrl not in itemList:
                            itemList.append(sHosterUrl)	
                            oOutputParameterHandler.addParameter('sHosterUrl', sHosterUrl)
                            oOutputParameterHandler.addParameter('siteUrl', sUrl)
                            oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
                            oOutputParameterHandler.addParameter('sThumb', sThumb)

                            oGui.addLink(SITE_IDENTIFIER, 'showLinks', sDisplayTitle, sThumb, sDisplayTitle, oOutputParameterHandler)
               
    oGui.setEndOfDirectory()

def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sHosterUrl = oInputParameterHandler.getValue('sHosterUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oHoster = cHosterGui().checkHoster(sHosterUrl)
    if oHoster != False:
        oHoster.setDisplayName(sMovieTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()