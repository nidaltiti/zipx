﻿# -*- coding: utf-8 -*-

import base64
import time
import hashlib
import json
import random
import string
import requests, re
import ssl
from requests.adapters import HTTPAdapter
from Cryptodome.Cipher import DES3
from Cryptodome.Util.Padding import pad
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.comaddon import VSlog, siteManager, addon, VSPath
from resources.lib import random_ua

UA = random_ua.get_phone_ua()

SITE_IDENTIFIER = 'showb'
SITE_NAME = 'SuperShow'
SITE_DESC = ''

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

sHost = base64.b64decode(URL_MAIN)
dHost = sHost.decode("utf-8")
URL_MAIN = dHost[::-1]

APP_KEY = base64.b64decode("bW92aWVib3g=").decode()
APP_ID = base64.b64decode("Y29tLnRkby5zaG93Ym94").decode()
APP_VERSION = "11.7"
APP_VERSION_CODE = "131"
TOKEN = ''.join(random.choices(string.hexdigits.lower(), k=32))
IV = base64.b64decode("d0VpcGhUbiE=")
KEY = base64.b64decode("MTIzZDZjZWRmNjI2ZHk1NDIzM2FhMXc2")

FIRST_API = base64.b64decode("aHR0cHM6Ly9zaG93Ym94c3NsLnNoZWd1Lm5ldC9hcGkvYXBpX2NsaWVudC8=").decode()
SECOND_API = base64.b64decode("aHR0cHM6Ly9zaG93Ym94YXBpc3NsLnN0c29zby5jb20vYXBpL2FwaV9jbGllbnQv").decode()
THIRD_API = base64.b64decode("aHR0cHM6Ly93d3cuZmViYm94LmNvbQ==").decode()


CLIENT_CERT_PEM = """-----BEGIN CERTIFICATE-----
MIIEFTCCAv2gAwIBAgIUCrILmXOevO03gUhhbEhG/wZb2uAwDQYJKoZIhvcNAQEL
BQAwgagxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYDVQQH
Ew1TYW4gRnJhbmNpc2NvMRkwFwYDVQQKExBDbG91ZGZsYXJlLCBJbmMuMRswGQYD
VQQLExJ3d3cuY2xvdWRmbGFyZS5jb20xNDAyBgNVBAMTK01hbmFnZWQgQ0EgM2Q0
ZDQ4ZTQ2ZmI3MGM1NzgxZmI0N2VhNzk4MjMxZDMwHhcNMjQwNjA0MDkxMTAwWhcN
MzkwNjAxMDkxMTAwWjAiMQswCQYDVQQGEwJVUzETMBEGA1UEAxMKQ2xvdWRmbGFy
ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJhpMlr/+IatuBqpuZuA
6QvqdI2QiFb1UMVujb/xiaBC/vqJMlMenLSDysk8xd4fLeC+GC8AyWf1IMJIz6d9
rBjOhN4D+MxvgphufkdIVqs63SqKcrr/ZL0JaRpxxEg/pKqSjH55Ik71keB8tt0m
mQ76WK1swMydOAqn6DIKVAi7wF9acWyX/6Ly+cmxfueLDZvkLigXl3gMHbuoa5Y+
CadqKl2qlijhnvjpuEbAvyDyXWe838TUi0PYMMVuOu7PV4By2LINsm+gKv83od4k
RCSWTrLKlgfqneqnudMrqeWckNUHGVB+3Lruw1ebB/Rs4gJ59VhJYpbNmM2mYT0r
VQkCAwEAAaOBuzCBuDATBgNVHSUEDDAKBggrBgEFBQcDAjAMBgNVHRMBAf8EAjAA
MB0GA1UdDgQWBBSF9Jkz4ZkbS5+LANO3YGWZRuX/PDAfBgNVHSMEGDAWgBTj01Q6
MJPAjpPqCEcv8rjxAUTO9jBTBgNVHR8ETDBKMEigRqBEhkJodHRwOi8vY3JsLmNs
b3VkZmxhcmUuY29tL2U1YTYzNzc5LTQ3NWQtNGI5OS04YzQxLTIwMjE5MmZhNjNj
ZC5jcmwwDQYJKoZIhvcNAQELBQADggEBALD+9MsfANm7fbzYH5/lXl07hwn2KSN8
PH7zxyo87ED62IL9U7YOnhb3rqLS1RXUzyHEmb9kzYgzKzzNrELdKH77vNk172Vk
iRQwGD0MZiYNERWhmmBtjV1oxllz74fL4+aZTYAespIbOekmFn9NZJ+XSdyF9RqS
fzDiz27GP5ZSHHI6xwdUP+a87N/RnfI4UwGxyXvPpHfoAZWjoXDqLKKwEL36/Sqi
nGcp970y0gnZ2zI2ehqivsF7BATMZqvU+LJKCH8NEE2bnbCJ6qlPHZWZFNKYWBOe
I1Crf0gNAWD/q3HKGMVZiyxlhU6SsQS4/08tDXXQjWYfl6i3oviexSk=
-----END CERTIFICATE-----"""
CLIENT_KEY_PEM = """-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCYaTJa//iGrbga
qbmbgOkL6nSNkIhW9VDFbo2/8YmgQv76iTJTHpy0g8rJPMXeHy3gvhgvAMln9SDC
SM+nfawYzoTeA/jMb4KYbn5HSFarOt0qinK6/2S9CWkaccRIP6Sqkox+eSJO9ZHg
fLbdJpkO+litbMDMnTgKp+gyClQIu8BfWnFsl/+i8vnJsX7niw2b5C4oF5d4DB27
qGuWPgmnaipdqpYo4Z746bhGwL8g8l1nvN/E1ItD2DDFbjruz1eActiyDbJvoCr/
N6HeJEQklk6yypYH6p3qp7nTK6nlnJDVBxlQfty67sNXmwf0bOICefVYSWKWzZjN
pmE9K1UJAgMBAAECggEAQFvnxjKiJWkVPbkfJjHU91GtnxwB3sqfrYdmN0ANUE4K
MwydYikinj2q87iEi6wZ6PYM60hHRG1oRHKPsZgphJ4s0D3YIagS+0Bpdbtv0cW9
IBovoZR4WzUum1qgOqwZYmgZCM0pNjOPwr6XT6Ldbkw8BxvN/HmFcUZ/ECZ5XugW
cKqKoy0HSlxwXT4PUAgLVfL4KvWy4A4yJJF24zgRKE4QYveOR4nUFvoRdxhuAyYW
xsajItj6sc6Jyr9FJzdw5Ra9EFwcWFM4uDdjHoaQrjwKId9fkCA+9eUCERWKTxCR
P8mU4p2cAJYO+ME9fZfs8H2uqGNj13XUzoT6JzM8UwKBgQDUFZWcfmlgCM2BjU9c
8qhYjD2egT3qxWJLYSUTUZfdOGgB6lxTqnOhsy93xYmVInz6r9XEZsLVoQj/wcZk
p7y+MxjiWNcBcUmviwHee42fe6BQZHaYlAFtlAKNSiHumfq6AtXpZvkQZJWTSRyW
lI4LBEL6fSuqpk88EH9FXJbChwKBgQC3+F/1Qi3EoeohhWD+jMO0r8IblBd7jYbp
2zs17KQsCEyc1qyIaE+a8Ud8zUqsECKWBuSFsQ2qrR3jZW6DZOw8hmp1foYC+Jjr
C/BHyWsyYxrCoxpvSJMXCY6ulyFHjIZboopRVi/jgfowteMW6WyxvOMqVAqZtxRW
HyFbsa+/7wKBgQCGHRwd+SZjr01dZmHQcjaYwB5bNHlWE/nDlyvd2pQBNaE3zN8T
nU8/6tLSl50YLNYBpN22NBFzDEFnkj8F+bh2QlOzFuDnrZ8eHfZRnaoCNyg6jj0c
4UNB6v3uIPnyK3cM16wzy4Umo6SenfYxFsH4H3rHcg4B/OdQIVKKJzHC0wKBgQCj
QxhlX0WeqtJMzUE2pVVIlHF+Z/4u93ozLwts34USTosu5JRYublrl5QJfWY3LFqF
KbjDrEykmt1bYDijAn1jeSYg/xeOq2+JqB6klms7XBfzgyuCdrWSTDkDV7uA84SI
7cYySHpXPJH7iG7vdlevpCE0/0ApCgBSLW49IYMGoQKBgAxVRqAhLdA0RO+nTAC/
whOL5RGy5M2oXKfqNkzEt2k5og7xXY7ZoYTye5Byb3+wLpEJXW+V8FlfXk/u5ZI7
oFuZne+lYcCPMNDXdku6wKdf9gSnOSHOGMu8TvHcud4uIDYmFH5qabJL5GDoQi7Q
12XvK21e6GNOEaRRlTHz0qUB
-----END PRIVATE KEY-----"""

client_cert = VSPath('special://home/addons/plugin.video.matrixflix/resources/extra/client_cert.pem')
with open(client_cert, "w") as cert_file:
    cert_file.write(CLIENT_CERT_PEM)

client_key = VSPath('special://home/addons/plugin.video.matrixflix/resources/extra/client_key.pem')
with open(client_key, "w") as key_file:
    key_file.write(CLIENT_KEY_PEM)

UI_TOKEN = ["eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3MzMzNzUwODMsIm5iZiI6MTczMzM3NTA4MywiZXhwIjoxNzY0NDc5MTAzLCJkYXRhIjp7InVpZCI6MjU1Njk4LCJ0b2tlbiI6Ijc1MDQ3MjM4YWJjODg4NmUxZDVlMmYzNGNkZjliNjNkIn19.QMLeSFq_KQZuk1GO0Gd7boSqRSq05g4GKxfHUrU72E8", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3MzM0MjMwNTUsIm5iZiI6MTczMzQyMzA1NSwiZXhwIjoxNzY0NTI3MDc1LCJkYXRhIjp7InVpZCI6NDM0Mjg1LCJ0b2tlbiI6IjM3MjYyNTQ3ZDlkNzk4YmExMTI0NTNjMGFjOTJiYTRiIn19.t_dMkn--gtRzBqWGJuITjiixxwOGP-nVvNRKvjvtsg0"]

class SSLAdapter(HTTPAdapter):
    def __init__(self, cert_file, key_file, *args, **kwargs):
        self.cert_file = cert_file
        self.key_file = key_file
        super().__init__(*args, **kwargs)

    def init_poolmanager(self, *args, **kwargs):
        context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
        context.load_cert_chain(certfile=self.cert_file, keyfile=self.key_file)
        kwargs['ssl_context'] = context
        return super().init_poolmanager(*args, **kwargs)

MOVIE_EN = ('cid=0', 'showMovies')
MOVIE_4K = ('quality=4K', 'showMovies')
DOC_NEWS = ('cid=7', 'showMovies')
KID_MOVIES = ('cid=73', 'showMovies')

SERIE_EN = ('cid=0', 'showSeries')
DOC_SERIES = ('cid=7', 'showSeries')

URL_SEARCH_MOVIES = (f'', 'search')
URL_SEARCH_SERIES = (f'', 'search')
FUNCTION_SEARCH = 'search'

def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', '')
    oGui.addDir(SITE_IDENTIFIER, 'home', 'الصفحة الرئيسية', 'films.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_4K[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', ' 4K أفلام', '4k.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام كرتون', 'anim.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', DOC_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام وثائقية', 'doc.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', DOC_SERIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات وثائقية', 'doc.png', oOutputParameterHandler) 

    oGui.setEndOfDirectory()

def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        search(sSearchText)
        oGui.setEndOfDirectory()
        return
 
def showSeriesSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        search(sSearchText)
        oGui.setEndOfDirectory()
        return

def build_search_query(keyword, enable_adult=True):
    hide_nsfw = 0 if enable_adult else 1
    query_payload = {
        "childmode": str(hide_nsfw),
        "app_version": APP_VERSION,
        "module": "Search3",
        "channel": "Website",
        "page": "1",
        "lang": "en",
        "type": "all",
        "keyword": keyword,
        "pagelimit": "15",
        "expired_date": str(get_expiry_date()),
        "platform": "android",
        "appid": APP_ID
    }
    return json.dumps(query_payload)

def search_superstream(keyword, enable_adult=True):
    query = build_search_query(keyword, enable_adult)
    raw_response = query_api(query, use_alternative_api=True)
    parsed = json.loads(raw_response)

    results = []
    for item in parsed.get("data", []):
        title = item.get("title")
        poster = item.get("poster") or item.get("poster_org")
        box_type = item.get("box_type", 1)
        imdb_rating = item.get("imdb_rating")
        media_id = item.get("id") or item.get("mid")
        if title and media_id:
            results.append({
                "id": media_id,
                "title": title,
                "poster": poster,
                "type": "Movie" if box_type == 1 else "Series",
                "rating": imdb_rating
            })
    return results

def search(keyword=''):
    oGui = cGui()
    results = search_superstream(keyword, enable_adult=False)

    for item in results:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', str(item['id']))
        oOutputParameterHandler.addParameter('sMovieTitle', item['title'])
        oOutputParameterHandler.addParameter('sThumb', item['poster'])
        if item['type'] == "Movie":
            oGui.addMovie(SITE_IDENTIFIER, 'showLinks', item['title'], '', item['poster'], '', oOutputParameterHandler)
        else:
            oGui.addTV(SITE_IDENTIFIER, 'showSeasons', item['title'], '', item['poster'], '', oOutputParameterHandler)

    if not keyword:
        oGui.setEndOfDirectory()

def home():
    oGui = cGui()

    results = get_main_page_movies(page=1, enable_adult=False)
    for item in results:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', str(item['id']))
        oOutputParameterHandler.addParameter('sMovieTitle', item['title'])
        oOutputParameterHandler.addParameter('sThumb', item['poster'])
        if item['type'] == "Movie":
            oGui.addMovie(SITE_IDENTIFIER, 'showLinks', item['title'], '', item['poster'], '', oOutputParameterHandler)
        else:
            oGui.addTV(SITE_IDENTIFIER, 'showSeasons', item['title'], '', item['poster'], '', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showMovies():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    page = int(oInputParameterHandler.getValue('nPage'))
    filter_param  = oInputParameterHandler.getValue('siteUrl')

    if page is False or page == 0:
        page = 1

    cid = None
    quality = None
    if 'cid=' in filter_param :
        cid = filter_param .split('cid=')[1]
    if 'quality=' in filter_param :
        quality = filter_param.split('quality=')[1]

    movies, has_next = get_movie_list(page=page, enable_adult=False, cid=cid, quality=quality)
    for movie in movies:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', str(movie['id']))
        oOutputParameterHandler.addParameter('sMovieTitle', movie['title'])
        oOutputParameterHandler.addParameter('sThumb', movie['poster'])
        oGui.addMovie(SITE_IDENTIFIER, 'showLinks', movie['title'], '', movie['poster'], '', oOutputParameterHandler)

    if has_next:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('nPage', str(page + 1))
        if 'cid=' in filter_param :
            oOutputParameterHandler.addParameter('siteUrl', f'cid={cid}')
        if 'quality=' in filter_param :
            oOutputParameterHandler.addParameter('siteUrl', f'quality={quality}')
        oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSeries():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    page = int(oInputParameterHandler.getValue('nPage'))

    if page is False or page == 0:
        page = 1

    series_list, has_next = get_series_list(page=page, enable_adult=False)
    for series in series_list:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', str(series['id']))
        oOutputParameterHandler.addParameter('sMovieTitle', series['title'])
        oOutputParameterHandler.addParameter('sThumb', series['poster'])
        oGui.addTV(SITE_IDENTIFIER, 'showSeasons', series['title'], '', series['poster'], '', oOutputParameterHandler)

    if has_next:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('nPage', str(page + 1))
        oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSeasons():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    series_id = int(oInputParameterHandler.getValue('siteUrl'))
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    from collections import defaultdict
    episodes = get_series_episodes(series_id, enable_adult=False)
    seasons = defaultdict(list)
    for ep in episodes:
        seasons[ep['season']].append(ep)

    for season_num, eps in seasons.items():
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', str(series_id))
        oOutputParameterHandler.addParameter('sMovieTitle', f"{sMovieTitle} S{season_num}")
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sSeason', str(season_num))
        oGui.addSeason(SITE_IDENTIFIER, 'showEpisodes', f"{sMovieTitle} Season {season_num}", '', sThumb, '', oOutputParameterHandler)
    oGui.setEndOfDirectory()

def showEpisodes():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    series_id = int(oInputParameterHandler.getValue('siteUrl'))
    season = int(oInputParameterHandler.getValue('sSeason'))
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    episodes = get_series_episodes(series_id, enable_adult=False)
    for ep in episodes:
        if ep['season'] != season:
            continue

        sDisplayTitle = f"{sMovieTitle} E{str(ep['episode'])} [{ep['title']}]"
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', str(ep['id']))
        oOutputParameterHandler.addParameter('sMovieTitle', sDisplayTitle)
        oOutputParameterHandler.addParameter('sSeason', str(ep['season']))
        oOutputParameterHandler.addParameter('sEpisode', str(ep['episode']))
        oOutputParameterHandler.addParameter('sThumb', ep['poster'])
        oOutputParameterHandler.addParameter('tid', str(ep['tid']))
        oGui.addEpisode(SITE_IDENTIFIER, 'showSeriesLinks', sDisplayTitle, '', ep['poster'], '', oOutputParameterHandler)
    oGui.setEndOfDirectory()

def showSeriesLinks():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    tid = int(oInputParameterHandler.getValue('tid'))
    file_id = int(oInputParameterHandler.getValue('siteUrl'))
    season = int(oInputParameterHandler.getValue('sSeason'))
    episode = int(oInputParameterHandler.getValue('sEpisode'))
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    supertoken = UI_TOKEN[random.randint(0, len(UI_TOKEN)-1)]

    links = invoke_external_source(media_id=tid, type_=2, season=season, episode=episode, uitoken=supertoken)
    for link in links:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', link['url'])
        oOutputParameterHandler.addParameter('sQual', link['quality'])
        oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oGui.addLink(SITE_IDENTIFIER, 'showHosters', f"{sMovieTitle} [{link['quality']}]", sThumb, '', oOutputParameterHandler)
    oGui.setEndOfDirectory()

def showLinks():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    media_id = int(oInputParameterHandler.getValue('siteUrl'))
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    supertoken = UI_TOKEN[random.randint(0, len(UI_TOKEN)-1)]

    links = invoke_external_source(media_id, type_=1, uitoken=supertoken)
    for link in links:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', link['url'])
        oOutputParameterHandler.addParameter('sQual', link['quality'])
        oOutputParameterHandler.addParameter('sHeaders', link['headers'])
        oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oGui.addLink(SITE_IDENTIFIER, 'showHosters', f"{sMovieTitle} [{link['quality']}]", sThumb, '', oOutputParameterHandler)
    oGui.setEndOfDirectory()

def showHosters():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sQual = oInputParameterHandler.getValue('sQual')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sHeaders = oInputParameterHandler.getValue('sHeaders')

    sHosterUrl = sUrl
    if isinstance(sHeaders, str):
        try:
            headers_dict = eval(sHeaders) if sHeaders.startswith("{") else {}
        except:
            headers_dict = {}

        if headers_dict:
            header_string = "&".join([f"{k}={v}" for k, v in headers_dict.items()])
            sHosterUrl = f"{sUrl}|{header_string}"

    oHoster = cHosterGui().checkHoster(sHosterUrl)
    sDisplayTitle = ('%s [COLOR coral] (%s) [/COLOR]') % (sMovieTitle, sQual) 
    if oHoster:
        oHoster.setDisplayName(sDisplayTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()

def encrypt(data, key, iv):
    key = key[:24].ljust(24, b'\0')
    cipher = DES3.new(key, DES3.MODE_CBC, iv)
    encrypted = cipher.encrypt(pad(data.encode(), DES3.block_size))
    return base64.b64encode(encrypted).decode()

def md5(data):
    return hashlib.md5(data.encode()).hexdigest()

def get_verify(encrypted_data, app_key, key):
    return md5(md5(app_key) + key.decode() + encrypted_data)

def query_api(query, use_alternative_api=True):
    encrypted_query = encrypt(query, KEY, IV)
    app_key_hash = md5(APP_KEY)
    verify = get_verify(encrypted_query, APP_KEY, KEY)

    payload = {
        "app_key": app_key_hash,
        "verify": verify,
        "encrypt_data": encrypted_query
    }

    base64_body = base64.b64encode(json.dumps(payload).encode()).decode()

    data = {
        "data": base64_body,
        "appid": "27",
        "platform": "android",
        "version": APP_VERSION_CODE,
        "medium": "Website",
        "token": TOKEN
    }

    url = SECOND_API if use_alternative_api else FIRST_API

    session = requests.Session()
    session.mount(url, SSLAdapter(client_cert, client_key)) 

    response = session.post(url, data=data, headers={"Platform": "android", "Accept": "charset=utf-8"})
    return response.text

def get_expiry_date():
    return int(time.time()) + 60 * 60 * 12

def build_main_page_query(page=1, enable_adult=True):
    hide_nsfw = 0 if enable_adult else 1
    query_payload = {
        "childmode": str(hide_nsfw),
        "app_version": APP_VERSION,
        "module": "Home_list_type_v2",
        "channel": "Website",
        "page": str(page),
        "lang": "en",
        "type": "all",
        "pagelimit": "20",
        "expired_date": str(get_expiry_date()),
        "platform": "android",
        "appid": APP_ID
    }
    return json.dumps(query_payload)

def get_main_page_movies(page=1, enable_adult=True):
    query = build_main_page_query(page, enable_adult)
    raw_response = query_api(query, use_alternative_api=True)
    parsed = json.loads(raw_response)

    results = []
    for section in parsed.get("data", [])[1:]:
        section_name = section.get("name", "Featured")
        for post in section.get("list", []):
            title = post.get("title")
            poster = post.get("poster") or post.get("poster_2")
            box_type = post.get("box_type", 1)
            imdb_rating = post.get("imdb_rating")
            if title:
                results.append({
                    "id": post.get("id"),
                    "section": section_name,
                    "title": title,
                    "poster": poster,
                    "type": "Movie" if box_type == 1 else "Series",
                    "rating": imdb_rating
                })
    return results


def get_main_page_series(page=1, enable_adult=True):
    query = build_main_page_query(page, enable_adult)
    raw_response = query_api(query, use_alternative_api=True)
    parsed = json.loads(raw_response)

    series_list = []
    for section in parsed.get("data", [])[1:]:
        for post in section.get("list", []):
            if post.get("box_type") == 2:
                series_list.append({
                    "id": post.get("id"),
                    "title": post.get("title"),
                    "poster": post.get("poster") or post.get("poster_2"),
                    "rating": post.get("imdb_rating")
                })
    return series_list

def get_series_episodes(series_id, enable_adult=True):
    hide_nsfw = 0 if enable_adult else 1
    query_payload = {
        "childmode": str(hide_nsfw),
        "uid": "",
        "app_version": APP_VERSION,
        "appid": APP_ID,
        "module": "TV_detail_1",
        "display_all": "1",
        "channel": "Website",
        "lang": "en",
        "expired_date": str(get_expiry_date()),
        "platform": "android",
        "tid": str(series_id)
    }
    raw_response = query_api(json.dumps(query_payload), use_alternative_api=True)
    parsed = json.loads(raw_response)

    episodes = []
    seasons = parsed.get("data", {}).get("season", [])
    for season_number in seasons:
        season_query = {
            "childmode": str(hide_nsfw),
            "uid": "",
            "app_version": APP_VERSION,
            "appid": APP_ID,
            "module": "TV_episode",
            "display_all": "1",
            "season": str(season_number),
            "channel": "Website",
            "lang": "en",
            "expired_date": str(get_expiry_date()),
            "platform": "android",
            "tid": str(series_id)
        }
        season_response = query_api(json.dumps(season_query), use_alternative_api=True)
        season_data = json.loads(season_response).get("data", [])
        for ep in season_data:
            episodes.append({
                "season": ep.get("season"),
                "episode": ep.get("episode"),
                "title": ep.get("title"),
                "id": ep.get("id"),
                "tid": ep.get("tid"),
                "poster": ep.get("thumbs_original") or ep.get("thumbs_bak") or ep.get("thumbs"),
                "rating": ep.get("imdb_rating")
            })
    return episodes

def get_episode_links(tid, episode_id, season, episode, media_id=None, imdb_id=None):
    link_data = {
        "id": episode_id,
        "type": 2,
        "season": season,
        "episode": episode,
        "mediaId": media_id,
        "imdbId": imdb_id
    }
    query = json.dumps(link_data)
    raw_response = query_api(query, use_alternative_api=True)
    parsed = json.loads(raw_response).get("data", {}).get("list", [])

    links = []
    for item in parsed:
        links.append({
            "path": item.get("path"),
            "quality": item.get("quality"),
            "format": item.get("format"),
            "size": item.get("size")
        })
    return links

def build_series_list_query(page=1, enable_adult=True):
    hide_nsfw = 0 if enable_adult else 1
    query_payload = {
        "childmode": str(hide_nsfw),
        "app_version": APP_VERSION,
        "year": "",
        "module": "TV_list_v2",
        "channel": "Website",
        "rating": "",
        "orderby": "adder",
        "pagelimit": "15",
        "expired_date": str(get_expiry_date()),
        "platform": "android",
        "quality": "",
        "uid": "",
        "open_udid": "865fbdda624be56e0ed4c4ade07e84e3",
        "appid": APP_ID,
        "page": str(page),
        "lang": "en",
        "cid": "0"
    }
    return json.dumps(query_payload)

def get_series_list(page=1, enable_adult=True):
    query = build_series_list_query(page, enable_adult)
    raw_response = query_api(query, use_alternative_api=True)
    parsed = json.loads(raw_response)

    series = []
    for post in parsed.get("data", []):
        title = post.get("title")
        poster = post.get("poster") or post.get("poster_2")
        imdb_rating = post.get("imdb_rating")
        series_id = post.get("id")
        if title:
            series.append({
                "id": series_id,
                "title": title,
                "poster": poster,
                "rating": imdb_rating
            })

    has_next = len(parsed.get("data", [])) > 0
    return series, has_next


def get_movie_list(page=1, enable_adult=True, cid=None, quality=None):
    query_payload = {
        "childmode": str(0 if enable_adult else 1),
        "app_version": APP_VERSION,
        "year": "",
        "module": "Movie_list_v2",
        "channel": "Website",
        "rating": "",
        "orderby": "adder",
        "pagelimit": "15",
        "expired_date": str(get_expiry_date()),
        "platform": "android",
        "quality": quality or "",
        "uid": "",
        "open_udid": "865fbdda624be56e0ed4c4ade07e84e3",
        "appid": APP_ID,
        "page": str(page),
        "lang": "en",
        "cid": str(cid or "0")
    }
    query = json.dumps(query_payload)
    raw_response = query_api(query, use_alternative_api=True)
    parsed = json.loads(raw_response)

    movies = []
    for post in parsed.get("data", []):
        movies.append({
            "id": post.get("id"),
            "title": post.get("title"),
            "poster": post.get("poster") or post.get("poster_2"),
            "rating": post.get("imdb_rating")
        })

    has_next = len(parsed.get("data", [])) > 0
    return movies, has_next


VIDEO_HEADERS = {
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.8",
    "Connection": "keep-alive",
    "Range": "bytes=0-",
    "Referer": "https://www.febbox.com",
    "Sec-Fetch-Dest": "video",
    "Sec-Fetch-Mode": "no-cors",
    "Sec-Fetch-Site": "cross-site",
    "Sec-Fetch-Storage-Access": "none",
    "Sec-GPC": "1",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
    "sec-ch-ua": "\"Not;A=Brand\";v=\"99\", \"Brave\";v=\"139\", \"Chromium\";v=\"139\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\""
}

def get_episode_slug(season, episode):
    season_slug = f"{season:02}" if season else ""
    episode_slug = f"{episode:02}" if episode else ""
    return season_slug, episode_slug

def invoke_external_source(media_id, type_, season=None, episode=None, uitoken=None):
    season_slug, episode_slug = get_episode_slug(season, episode)

    share_url = f"{THIRD_API}/mbp/to_share_page?box_type={type_}&mid={media_id}&json=1"
    res = requests.get(share_url).json()
    share_key = res.get("data", {}).get("link") or res.get("data", {}).get("share_link", "").split("/")[-1]
    if not share_key:
        return []

    headers = {"Accept-Language": "en"}
    file_list_url = f"{THIRD_API}/file/file_share_list?share_key={share_key}"
    file_list = requests.get(file_list_url, headers=headers).json().get("data", {}).get("file_list", [])
    if season:
        parent_id = next((f["fid"] for f in file_list if f["file_name"].lower() == f"season {season}".lower()), None)
        if not parent_id:
            return []
        episode_url = f"{THIRD_API}/file/file_share_list?share_key={share_key}&parent_id={parent_id}&page=1"
        file_list = requests.get(episode_url, headers=headers).json().get("data", {}).get("file_list", [])
        file_list = [f for f in file_list if f["file_name"] and f"s{season_slug}e{episode_slug}" in f["file_name"].lower()]

    links = []
    for index, file in enumerate(file_list):
        fid = file.get("fid")
        if not fid:
            continue
        cookie_header = {"Cookie": f"ui={uitoken}" if not uitoken.startswith("ui=") else uitoken}
        quality_url = f"{THIRD_API}/console/video_quality_list?fid={fid}&share_key={share_key}"
        html_json = requests.get(quality_url, headers=cookie_header).json()
        html = html_json.get("html", "")
        if not html:
            continue

        pattern = r'<div class="file_quality"\s*data-url="([^"]+)"\s*data-quality="([^"]+)".+?class="size">([^<]+)</p>'
        matches = re.findall(pattern, html, re.DOTALL)

        for url, quality, size in matches:
            if quality.upper() == "ORG":
                match = re.search(r"(\d{3,4}p)", url)
                quality = match.group(1) if match else "2160p"
            links.append({
                "server": f"Server {index + 1}",
                "url": url.replace("\\/", "/"),
                "quality": quality,
                "size": size.strip(),
                "headers": VIDEO_HEADERS
            })
    return links