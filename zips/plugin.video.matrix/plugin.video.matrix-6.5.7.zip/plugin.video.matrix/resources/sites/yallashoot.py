﻿# -*- coding: utf-8 -*-

import urllib.parse
import base64
import re, requests, time
import datetime
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, siteManager
from resources.lib import random_ua

UA = random_ua.get_pc_ua()

SITE_IDENTIFIER = 'yallashoot'
SITE_NAME = 'Yallashoot'
SITE_DESC = 'Sports live'
 
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)
API_URL_MATCHES = 'https://ws.kora-api.top/'
API_POSTER_URL = 'https://cdn.kora-api.top/'
API_STREAM_URL = 'https://vsys.kora-plus.top/'

SPORT_LIVE = (f'{API_URL_MATCHES}api/matches/', 'showMovies')

def load():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()    
    oOutputParameterHandler.addParameter('siteUrl', SPORT_LIVE[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'بث مباشر', 'sport.png', oOutputParameterHandler)
   
    oGui.setEndOfDirectory()
	
    
def showMovies():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    dDate = datetime.date.today().isoformat()

    now = datetime.datetime.now()
    gmt_offset = datetime.timedelta(hours=3)
    gmt_time = now - gmt_offset
    time_str = gmt_time.strftime("%H%M")
    formatted = datetime.datetime.now().strftime("%Y%m%d%H%M")
    sUrl = f'{sUrl}{dDate}?t={time_str}'

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.enableCache(False)
    sHtmlContent2 = oRequestHandler.request(jsonDecode=True)

    for match in sHtmlContent2:
        oOutputParameterHandler = cOutputParameterHandler()
        if match['active'] == '0':
            continue

        sCondition = 'لم تبدأ'
        sDisplayTitle = sTitle =  f"{match['home']} vs {match['away']}"
        sThumb = f'https://cdn.kora-api.top/uploads/team/{match["home_logo"]}'
        siteUrl = "/"
        desc = f"{match['home_en']}-vs-{match['away_en']}".lower().replace(" ", "-")
        if match["has_channels"] == '1' and match["active"] == '1':
            sCondition = 'مباشر'
            sDisplayTitle = f'{sTitle} [COLOR red]● مباشر[/COLOR]'
            siteUrl = f"{API_URL_MATCHES}api/matche/{match['id']}/en?t={formatted}"
        sDesc = f'[COLOR orange]الدوري[/COLOR] \n {match["league"]} \n \n [COLOR orange]الوقت[/COLOR] \n {match["date"]} | {match["time"]}GMT \n \n [COLOR orange]حالة البث[/COLOR] \n {sCondition}'
        
        oOutputParameterHandler.addParameter('siteUrl',siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)

        oGui.addMisc(SITE_IDENTIFIER, 'showLinks', sDisplayTitle, 'foot.png', sThumb, sDesc, oOutputParameterHandler)
 
    oGui.setEndOfDirectory()
			
def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    try:
        if sUrl.startswith('/'):
            oGui.addText(SITE_IDENTIFIER, '[COLOR orange] تعذر الحصول على روابط [/COLOR]', 'none.png')  
        else:
            oRequestHandler = cRequestHandler(sUrl)
            oRequestHandler.enableCache(False)
            sHtmlContent = oRequestHandler.request(jsonDecode=True)
            
            result = extract_data(sHtmlContent)
            if result:
                    for ch, server_name, sLink in zip(result['ch'], result['server_name'], result["cLinks"]):

                        oOutputParameterHandler = cOutputParameterHandler()
                        token = generate_uuid()
                        timestamp = int(datetime.datetime.utcnow().timestamp())

                        sTitle = f'{sMovieTitle} [COLOR orange] {server_name} [/COLOR]'
                        sUrl = f"{API_STREAM_URL}frame.php?ch={ch}&p=12&token={token}&kt={timestamp}"

                        oOutputParameterHandler.addParameter('siteUrl', sUrl)
                        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                        oOutputParameterHandler.addParameter('sLink', sLink)
                        oOutputParameterHandler.addParameter('ch', ch)
                        oOutputParameterHandler.addParameter('sThumb', sThumb)

                        oGui.addMisc(SITE_IDENTIFIER, 'showHosters', sTitle, 'foot.png', sThumb, sTitle, oOutputParameterHandler)
    except:
        oGui.addText(SITE_IDENTIFIER, '[COLOR orange] تعذر الحصول على روابط [/COLOR]', 'none.png')        

    oGui.setEndOfDirectory()  

def showHosters():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    u_key = oInputParameterHandler.getValue('u_key')
    kt = oInputParameterHandler.getValue('kt')
    k_url = oInputParameterHandler.getValue('k_url')
    p = oInputParameterHandler.getValue('p')
    ch = oInputParameterHandler.getValue('ch')
    sLink = oInputParameterHandler.getValue('sLink')
    sThumb = oInputParameterHandler.getValue('sThumb')
   
    oOutputParameterHandler = cOutputParameterHandler()

    headers = {
            "user-agent": UA,
            "referer": URL_MAIN
        }
    response = requests.get(sUrl, headers=headers).text
    token_pattern = r'var token = "(.*)";'

    token_match = re.search(token_pattern, response)
    if token_match:
        sHosterUrl = token_match.group(1)
        sHosterUrl = decode_token(sHosterUrl)
        sHosterUrl = f'{sHosterUrl}|Referer={sUrl.split("frame.php")[0]}'
    
        if '/.m3u8' not in sHosterUrl:
            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb, oOutputParameterHandler)
            
        else:
            from resources.sites.beinmatch import getHosterIframe

            sHosterUrl = sLink
            if 'https://href.li/?' in sHosterUrl:
                nUrl = sHosterUrl.split('https://href.li/?', 1)[1] if sHosterUrl.split('https://href.li/?', 1)[1].startswith('http') else sHosterUrl
                if nUrl.startswith('ttps://'):
                    nUrl = 'h' + nUrl

                sHosterUrl = getHosterIframe(nUrl, sHosterUrl)
                if '|' in sHosterUrl:
                    parts = sHosterUrl.split('|')
                    referer = next((p for p in reversed(parts) if p.lower().startswith('referer=')), '')
                    sHosterUrl = '|'.join([p for p in parts if not p.lower().startswith('referer=')] + [referer])

            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb, oOutputParameterHandler)

    oGui.setEndOfDirectory()    

def decode_token(token):
    decoded_bytes = base64.urlsafe_b64decode(token)
    decoded_str = decoded_bytes.decode('latin-1')
    replaced_str = ''.join(f'%{decoded_str[i:i+2]}' for i in range(0, len(decoded_str), 2))
    final_str = urllib.parse.unquote(replaced_str)
    
    return final_str

def encode_token(data):
    encoded_str = urllib.parse.quote(str(data))
    replaced_str = ''.join(f'%{ord(char):02X}' for char in encoded_str)
    base64_bytes = base64.urlsafe_b64encode(replaced_str.replace('%', '').encode('latin-1'))
    base64_str = base64_bytes.decode('utf-8')
    
    return base64_str

def nowtime():
    current_timestamp = int(time.time())
    return current_timestamp

def get_current_minute():
    date = datetime.datetime.utcnow()
    hours = str(date.hour).zfill(2)
    minutes = str(date.minute).zfill(2)

    time = f"{hours}{minutes}"
    return time

def extract_data(html):
    data = {}

    sHtmlContent = html

    channels = sHtmlContent.get("channels", [])
    ch = []
    server = []
    cLinks = []
    for channel in channels:
        ch.append(channel.get("ch"))
        server.append(channel.get("server_name"))
        cLinks.append(channel.get("link"))
    data['ch'] = ch
    data['server_name'] = server
    data['cLinks'] = cLinks

    if not any(data.values()):
        return None

    return data

def decode_token(encoded_token):
    decoded_token = urllib.parse.unquote(base64.b64decode(encoded_token).decode('utf-8'))
    decoded_token = re.sub(r'(.{1,2})', r'%\1', decoded_token)
    return urllib.parse.unquote(decoded_token)

def generate_uuid():
    import random
    timestamp = int(time.time() * 1000)
    template = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'

    def replace(match):
        nonlocal timestamp
        random_number = int((timestamp + random.random() * 16) % 16)
        timestamp //= 16
        return hex(random_number if match.group(0) == 'x' else (random_number & 0x3) | 0x8)[2:]

    uuid = re.sub(r'[xy]', replace, template)
    return uuid