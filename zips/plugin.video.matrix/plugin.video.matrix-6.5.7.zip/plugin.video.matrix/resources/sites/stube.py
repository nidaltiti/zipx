﻿# -*- coding: utf-8 -*-

from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, addon, siteManager
from resources.lib.parser import cParser
from resources.lib.util import Unquote, cUtil
from resources.lib import random_ua

UA = random_ua.get_pc_ua()

SITE_IDENTIFIER = 'stube'
SITE_NAME = 'ShiaTube'
SITE_DESC = 'farsi vod'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER) 

MOVIE_IR = (f'{URL_MAIN}@movies', 'showMovies')
SERIE_IR = (f'{URL_MAIN}@series', 'showSeries')

URL_SEARCH = (f'{URL_MAIN}search?keyword=', 'showSeries')
URL_SEARCH_MOVIES = (f'{URL_MAIN}search?keyword=', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}search?keyword=', 'showSeries')
FUNCTION_SEARCH = 'showMovies'

def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_IR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_IR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_IR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات ايرانية', 'iran.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_IR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'افلام ايرانية', 'iran.png', oOutputParameterHandler) 

    oGui.setEndOfDirectory()

def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search?keyword=' + sSearchText.replace(' ','%20')
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showSeriesSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search?keyword=' + sSearchText.replace(' ','%20')
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return

def showMovies(sSearch = ''):
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sHash = oInputParameterHandler.getValue('sHash')
    dataID = oInputParameterHandler.getValue('dataID')
    dataViews = oInputParameterHandler.getValue('dataViews')
    user_id = oInputParameterHandler.getValue('user_id')
    sUrl = oInputParameterHandler.getValue('siteUrl')
    cook = oInputParameterHandler.getValue('cook')

    if sSearch:
        sUrl = sSearch

    oParser = cParser() 
    if sHash:
        oRequestHandler = cRequestHandler(f'{URL_MAIN}aj/load-more/profile_videos?views={dataViews}')
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
        oRequestHandler.addHeaderEntry('Accept', '*/*')
        oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
        oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
        oRequestHandler.addHeaderEntry("Cookie", cook)
        oRequestHandler.addParameters('hash', sHash)
        oRequestHandler.addParameters('last_id', dataID)
        oRequestHandler.addParameters('ids[0]', dataID)
        oRequestHandler.addParameters('user_id', user_id)
        oRequestHandler.setRequestType(1)
        sHtmlContent = oRequestHandler.request(jsonDecode=True)
        sHtmlContent = sHtmlContent['videos']
    else:
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('user-agent', UA)
        sHtmlContent = oRequestHandler.request()
        cook = oRequestHandler.GetCookies()

    sPattern = 'class="main_session" value="([^"]+)"'
    aResult = oParser.parse(sHtmlContent,sPattern)
    if aResult[0]:
        sHash = aResult[1][0]

        sPattern = 'id="profile-id" value="([^"]+)">'
        aResult = oParser.parse(sHtmlContent,sPattern)
        if aResult[0]:
            user_id = aResult[1][0]

    sPattern = '<div class="video-latest-list.+?data-id="([^"]+)"\s*data-views="([^"]+)".+?href="([^"]+)".+?src="([^"]+)"\s*alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            if 'الفيلم' not in aEntry[4] and 'فیلم' not in aEntry[4]:
                continue

            dataID = aEntry[0]
            dataViews = aEntry[1]
            sTitle = aEntry[4]
            sTitle = sTitle.replace('المسلسل','').replace('مسلسل','').replace(' - مترجم للعربية','').replace('الفيلم','').replace('الإيراني','').replace('الايراني','').replace('(','').replace(')','').replace('4K','')
            siteUrl = aEntry[2]
            sThumb = aEntry[3]
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)

            oGui.addMovie(SITE_IDENTIFIER, 'showLink', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    lastEntry = aResult[1][-1]
    lastDataID = lastEntry[0]
    lastDataViews = lastEntry[1]

    if not sSearch:
        sPattern = 'data-type="profile_videos">(.+?)</div>'
        aResult = oParser.parse(sHtmlContent,sPattern)
        if aResult[0]:
            sMore = aResult[1][0]
            if 'أظهر المزيد' in sMore:
                sTitle = f'[COLOR red]{sMore}[/COLOR]'

                oOutputParameterHandler = cOutputParameterHandler() 
                oOutputParameterHandler.addParameter('sHash', sHash)
                oOutputParameterHandler.addParameter('dataID', lastDataID)
                oOutputParameterHandler.addParameter('dataViews', lastDataViews)
                oOutputParameterHandler.addParameter('user_id', user_id)
                oOutputParameterHandler.addParameter('cook', cook)
                
                oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()

def showSeries(sSearch = ''):
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sHash = oInputParameterHandler.getValue('sHash')
    dataID = oInputParameterHandler.getValue('dataID')
    dataViews = oInputParameterHandler.getValue('dataViews')
    user_id = oInputParameterHandler.getValue('user_id')
    sUrl = oInputParameterHandler.getValue('siteUrl')
    cook = oInputParameterHandler.getValue('cook')

    if sSearch:
        sUrl = sSearch

    oParser = cParser() 
    if sHash:
        oRequestHandler = cRequestHandler(f'{URL_MAIN}aj/load-more/profile_videos?views={dataViews}')
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
        oRequestHandler.addHeaderEntry('Accept', '*/*')
        oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
        oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
        oRequestHandler.addHeaderEntry("Cookie", cook)
        oRequestHandler.addParameters('hash', sHash)
        oRequestHandler.addParameters('last_id', dataID)
        oRequestHandler.addParameters('ids[0]', dataID)
        oRequestHandler.addParameters('user_id', user_id)
        oRequestHandler.setRequestType(1)
        sHtmlContent = oRequestHandler.request(jsonDecode=True)
        sHtmlContent = sHtmlContent['videos']
    else:
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('user-agent', UA)
        sHtmlContent = oRequestHandler.request()
        cook = oRequestHandler.GetCookies()

    sPattern = 'class="main_session" value="([^"]+)"'
    aResult = oParser.parse(sHtmlContent,sPattern)
    if aResult[0]:
        sHash = aResult[1][0]

        sPattern = 'id="profile-id" value="([^"]+)">'
        aResult = oParser.parse(sHtmlContent,sPattern)
        if aResult[0]:
            user_id = aResult[1][0]

    sPattern = '<div class="video-latest-list.+?data-id="([^"]+)"\s*data-views="([^"]+)".+?href="([^"]+)".+?src="([^"]+)"\s*alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            if 'المسلسل' not in aEntry[4] and 'مسلسل' not in aEntry[4]:
                continue

            dataID = aEntry[0]
            dataViews = aEntry[1]
            sTitle = aEntry[4]
            sTitle = sTitle.replace('المسلسل','').replace('مسلسل','').replace(' - مترجم للعربية','').replace('الفيلم','').replace('الإيراني','').replace('الايراني','').replace('(','').replace(')','').replace('4K','').split('الحلقة')[0]
            siteUrl = aEntry[2]
            sThumb = aEntry[3]
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)

            oGui.addTV(SITE_IDENTIFIER, 'showEps', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    lastEntry = aResult[1][-1]
    lastDataID = lastEntry[0]
    lastDataViews = lastEntry[1]

    if not sSearch:
        sPattern = 'data-type="profile_videos">(.+?)</div>'
        aResult = oParser.parse(sHtmlContent,sPattern)
        if aResult[0]:
            sMore = aResult[1][0]
            if 'أظهر المزيد' in sMore:
                sTitle = f'[COLOR red]{sMore}[/COLOR]'

                oOutputParameterHandler = cOutputParameterHandler() 
                oOutputParameterHandler.addParameter('sHash', sHash)
                oOutputParameterHandler.addParameter('dataID', lastDataID)
                oOutputParameterHandler.addParameter('dataViews', lastDataViews)
                oOutputParameterHandler.addParameter('user_id', user_id)
                oOutputParameterHandler.addParameter('cook', cook)
                
                oGui.addDir(SITE_IDENTIFIER, 'showSeries', sTitle, 'next.png', oOutputParameterHandler)
 
        oGui.setEndOfDirectory()

def showEps():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oOutputParameterHandler = cOutputParameterHandler() 

    if '&page_id=' not in sUrl:
        oRequestHandler = cRequestHandler(f'{URL_MAIN}search?keyword={sMovieTitle.replace(" ","%20")}')
    else:
        oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('user-agent', UA)
    sHtmlContent = oRequestHandler.request()

    sPattern = '<div class="video-latest-list.+?data-id="([^"]+)"\s*data-views="([^"]+)".+?href="([^"]+)".+?src="([^"]+)"\s*alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:

            sTitle = aEntry[4]
            sTitle = sTitle.replace('المسلسل','').replace('مسلسل','').replace(' - مترجم للعربية','').replace('الفيلم','').replace('الإيراني','').replace('الايراني','').replace('(','').replace(')','').replace('4K','').replace('الحلقة','E')
            siteUrl = aEntry[2]
            sThumb = aEntry[3]
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)

            oGui.addEpisode(SITE_IDENTIFIER, 'showLink', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
             
    sPattern = '<li class="active"><a[^>]+GoToPage\((\d+)\)'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        currentPage = int(aResult[1][0])
        nextPage = currentPage + 1

        nextUrl = f'https://shiatube.org/search?keyword={sMovieTitle.replace(" ","%20")}&page_id={nextPage}'

        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', nextUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
        oOutputParameterHandler.addParameter('sThumb', 'next.png')
        if 'title="Next Page"' in sHtmlContent:
            oGui.addDir(SITE_IDENTIFIER, 'showEps', f'[COLOR red]More Episodes (Page {nextPage})[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory() 

def showLink():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('user-agent', UA)
    sHtmlContent = oRequestHandler.request()

    sPattern = '<div class="video-player.+?src="([^"]+)"'
    aResult = oParser.parse(sHtmlContent,sPattern)
    if aResult[0]:
        sHosterUrl = aResult[1][0]
        if sHosterUrl.startswith('//'):
            sHosterUrl = 'https:' + sHosterUrl

        if 'shiatube' in sHosterUrl:
            oRequestHandler = cRequestHandler(sHosterUrl)
            oRequestHandler.addHeaderEntry('user-agent', UA)
            oRequestHandler.addHeaderEntry('referer', sUrl)
            sHtmlContent = oRequestHandler.request()   

            sPattern = '<source src="([^"]+)"'
            aResult = oParser.parse(sHtmlContent,sPattern)
            if aResult[0]:
                sHosterUrl = aResult[1][0]
                if sHosterUrl.startswith('//'):
                    sHosterUrl = 'https:' + sHosterUrl

        oHoster = cHosterGui().checkHoster(sHosterUrl)
        if oHoster != False:
            oHoster.setDisplayName(sMovieTitle)
            oHoster.setFileName(sMovieTitle)
            cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()       
  