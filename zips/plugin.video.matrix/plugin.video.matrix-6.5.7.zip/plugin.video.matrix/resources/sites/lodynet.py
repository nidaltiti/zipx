﻿#-*- coding: utf-8 -*-

import re, json
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, siteManager, addon, VSlog
from resources.lib.parser import cParser
from resources.lib.util import cUtil

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0'
 
SITE_IDENTIFIER = 'lodynet'
SITE_NAME = 'Lodynet'
SITE_DESC = 'arabic vod'
 
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

MOVIE_TURK = (f'{URL_MAIN}category/افلام-تركية-مترجم/', 'showMovies')
MOVIE_HI = (f'{URL_MAIN}category/افلام-هندية/', 'showMovies')
MOVIE_ASIAN = (f'{URL_MAIN}category/افلام-اسيوية-a/', 'showMovies')
KID_MOVIES = (f'{URL_MAIN}category/انيمي/', 'showMovies')

SERIE_TR = (f'{URL_MAIN}category/مسلسلات-تركي/', 'showSerie')
SERIE_TR_AR = (f'{URL_MAIN}dubbed-turkish-series-g/', 'showSerie')
SERIE_HEND = (f'{URL_MAIN}category/مسلسلات-هندية-مترجمة/', 'showSerie')
SERIE_HEND_AR = (f'{URL_MAIN}dubbed-indian-series-p5/', 'showSerie')
SERIE_ASIA = (f'{URL_MAIN}tag/new-asia/', 'showMovies')
SERIE_CN = (f'{URL_MAIN}category/مسلسلات-صينية-مترجمة/', 'showSerie')
SERIE_KR = (f'{URL_MAIN}korean-series-b/', 'showSerie')
SERIE_THAI = (f'{URL_MAIN}مشاهدة-مسلسلات-تايلندية/', 'showSerie')
SERIE_PAK = (f'{URL_MAIN}category/المسلسلات-باكستانية/', 'showSerie')
SERIE_LATIN = (f'{URL_MAIN}category/مسلسلات-مكسيكية-a/', 'showSerie')

REPLAYTV_NEWS = (f'{URL_MAIN}category/البرامج-و-حفلات-tv/', 'showMovies')

URL_SEARCH = (f'{URL_MAIN}wp-content/themes/Lodynet2020/Api/RequestSearch.php?value=', 'showMoviesSearch')
URL_SEARCH_MOVIES = (f'{URL_MAIN}wp-content/themes/Lodynet2020/Api/RequestSearch.php?value=', 'showMoviesSearch')
URL_SEARCH_SERIES = (f'{URL_MAIN}wp-content/themes/Lodynet2020/Api/RequestSearch.php?value=', 'showSearchSerie')
FUNCTION_SEARCH = 'showMovies'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_ASIAN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أسيوية', 'asia.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_TURK[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام تركية', 'turk.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_HI[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام هندية', 'hend.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام كرتون', 'anim.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_ASIA[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'مسلسلات أسيوية', 'asia.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_TR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSerie', 'مسلسلات تركية', 'turk.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_HEND[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSerie', 'مسلسلات هندية', 'hend.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_HEND_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSerie', 'مسلسلات هندية مدبلجة', 'hend.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', SERIE_PAK[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSerie', 'مسلسلات باكستانية', 'paki.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', SERIE_LATIN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSerie', 'مسلسلات لاتنية', 'latin.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_CN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSerie' ,'مسلسلات صينية', 'asia.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', SERIE_KR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSerie' ,'مسلسلات كورية', 'asia.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', SERIE_THAI[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSerie' ,'مسلسلات تايلاندية', 'asia.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', REPLAYTV_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'برامج تلفزيونية', 'brmg.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', URL_MAIN)
    oGui.addDir(SITE_IDENTIFIER, 'showPack', 'أقسام الموقع', 'listes.png', oOutputParameterHandler)	
    oGui.setEndOfDirectory()
 
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}wp-content/themes/Lodynet2020/Api/RequestSearch.php?value={sSearchText}'
        showMoviesSearch(sUrl)
        oGui.setEndOfDirectory()
        return	

def showSeriesSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}wp-content/themes/Lodynet2020/Api/RequestSearch.php?value={sSearchText}'
        showSearchSerie(sUrl)
        oGui.setEndOfDirectory()
        return

def showMoviesSearch(sSearch = ''):
    oGui = cGui()
    sUrl = sSearch
 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)
    searchResults = sHtmlContent[1]
    if searchResults:
        total = len(searchResults)
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()

        for entry in searchResults:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break

            sRawTitle = entry.get('Title', '')
            if 'فيلم' not in sRawTitle:
                continue

            sTitle = (cUtil().CleanMovieName(sRawTitle)).replace("&#8217;", "'")
            sTitle = re.sub('[^a-zA-Z]', ' ', sTitle)

            siteUrl = URL_MAIN + entry.get('Url', '')
            sThumb = entry.get('Cover', '')
            sThumb = sThumb
            sDesc = ''
            sYear = ''

            m = re.search(r'([0-9]{4})', sTitle)
            if m:
                sYear = str(m.group(0))

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
			
            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)

    if not sSearch:
        oGui.setEndOfDirectory()

def showPack():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = '>الرئيسية</a></li>'
    sEnd = '<div class="SiteSlider">'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = '<a href="([^<]+)">([^<]+)</a>'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in aResult[1]:
            if '#' in aEntry[0] or 'الطلبات' in aEntry[1] or 'ممثل' in aEntry[1]:
                continue 
            sTitle = aEntry[1]
            if 'رياح' in sTitle  or 'لون' in sTitle:
                continue
            siteUrl = aEntry[0]	

            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            if 'برامج' in sTitle:
                oGui.addMisc(SITE_IDENTIFIER, 'showSearchSerie', sTitle, 'mslsl.png', '', '', oOutputParameterHandler)
            elif 'اغاني' in sTitle:
                oGui.addMisc(SITE_IDENTIFIER, 'showMovies', sTitle, 'mslsl.png', '', '', oOutputParameterHandler)
            elif 'مسلسل' in sTitle:
                oGui.addMisc(SITE_IDENTIFIER, 'showSerie', sTitle, 'mslsl.png', '', '', oOutputParameterHandler)
            else:
                oGui.addMisc(SITE_IDENTIFIER, 'showMovies', sTitle, 'film.png', '', '', oOutputParameterHandler)
  
    oGui.setEndOfDirectory()

def showSearchSerie(sSearch = ''):
    oGui = cGui()
    sUrl = sSearch

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    searchResults = sHtmlContent[1]
    if searchResults:
        total = len(searchResults)
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()

        for entry in searchResults:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break

            sRawTitle = entry.get('Title', '')
            if 'فيلم' in sRawTitle:
                continue

            sTitle = cUtil().CleanMovieName(sRawTitle).replace('الحلقة ', 'E').replace('حلقة ', 'E')
            sTitle = cUtil().ConvertSeasons(sTitle)

            siteUrl = URL_MAIN + entry.get('Url', '')
            sThumb = entry.get('Cover', '')
            sThumb = sThumb
            sDesc = ''
            sYear = ''

            m = re.search(r'([0-9]{4})', sTitle)
            if m:
                sYear = str(m.group(0))

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)

            oGui.addTV(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()
 
def showMovies(sSearch = ''):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    if sSearch:
        sUrl = sSearch
    else:
        sUrl = oInputParameterHandler.getValue('siteUrl')

    sHtmlContent = oInputParameterHandler.getValue('sHtmlContent')
    sParent = oInputParameterHandler.getValue('sParent')
    sType = oInputParameterHandler.getValue('sType')
    sTaxonomy = oInputParameterHandler.getValue('sTaxonomy')

    oParser = cParser() 
    if not sHtmlContent:
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        sHtmlContent = oRequestHandler.request()
    
    itemList = []
    sPattern = r'<div class="ItemNewly">\s*<a title="([^"]+)"\s*href="([^"]+)".+?src="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            if 'CategoryItem.name' in aEntry[0]:
                continue
 
            sTitle = cUtil().CleanMovieName(aEntry[0]).replace("&#8217;", "'")
            if 'فيلم'  not in aEntry[0]:
                sTitle = (cUtil().CleanSeriesName(aEntry[0])).replace('حصرياً','').replace('التايلندي','').replace('التايلاندي','').replace('الصيني','').replace('الباكستاني','')
                sTitle = re.sub(r"S\d{2}|S\d", "", sTitle)
            sTitle = re.sub('[^a-zA-Z0-9]', ' ', sTitle)
            siteUrl = aEntry[1]
            sThumb = re.sub(r'-\d*x\d*.','.', aEntry[2])
            sDesc = ""
            sYear = ''
            m = re.search('([0-9]{4})', sTitle)
            if m:
                sYear = str(m.group(0))
            if sTitle not in itemList:
                itemList.append(sTitle)	
                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sYear', sYear) 
                
                if 'فيلم' not in aEntry[0]:
                    oGui.addTV(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
                else:    
                    oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
    if not sSearch:
        sNextPage, sParent, sType, sTaxonomy = __checkForNextPage(sHtmlContent, sParent, sType, sTaxonomy)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sHtmlContent', sNextPage)
            oOutputParameterHandler.addParameter('sParent', sParent)
            oOutputParameterHandler.addParameter('sType', sType)
            oOutputParameterHandler.addParameter('sTaxonomy', sTaxonomy)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()

def showSerie(sSearch = ''):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    if sSearch:
        sUrl = sSearch
    else:
        sUrl = oInputParameterHandler.getValue('siteUrl')

    sHtmlContent = oInputParameterHandler.getValue('sHtmlContent')
    sParent = oInputParameterHandler.getValue('sParent')
    sType = oInputParameterHandler.getValue('sType')
    sTaxonomy = oInputParameterHandler.getValue('sTaxonomy')

    oParser = cParser() 
    if not sHtmlContent:
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        sHtmlContent = oRequestHandler.request()
    
    itemList = []
    sPattern = r'<div\s+class="ItemNewly">\s*<a\s+title="([^"]+)"\s+href="([^"]+)">\s*<div\s+class="[^"]*?"\s+style="[^"]*?"\s+data-src="([^"]*?)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break

            if 'CategoryItem.name' in aEntry[0]:
                continue
            if aEntry[2] == '':
                continue
            
            sTitle = (cUtil().CleanSeriesName(aEntry[0])).replace('حصرياً','').replace('التايلندي','').replace('التايلاندي','').replace('الصيني','').replace('الباكستاني','')
            siteUrl = aEntry[1]
            sThumb = re.sub(r'-\d*x\d*.','.', aEntry[2])
            sDesc = ""

            if sTitle not in itemList:
                itemList.append(sTitle)	
                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                
                oGui.addTV(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
  
    if not sSearch:
        sNextPage, sParent, sType, sTaxonomy = __checkForNextPage(sHtmlContent, sParent, sType, sTaxonomy)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sHtmlContent', sNextPage)
            oOutputParameterHandler.addParameter('sParent', sParent)
            oOutputParameterHandler.addParameter('sType', sType)
            oOutputParameterHandler.addParameter('sTaxonomy', sTaxonomy)
            oGui.addDir(SITE_IDENTIFIER, 'showSerie', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()
		
def showEpisodes():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sHtmlContent = oInputParameterHandler.getValue('sHtmlContent')
    sParent = oInputParameterHandler.getValue('sParent')
    sType = oInputParameterHandler.getValue('sType')
    sTaxonomy = oInputParameterHandler.getValue('sTaxonomy')

    oParser = cParser() 
    if not sHtmlContent:
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        sHtmlContent = oRequestHandler.request()

    sPattern = '<li><a href="([^<]+)">([^<]+)</a></li>'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
 
            sTitle = (cUtil().CleanMovieName(aEntry[1])).replace('الحلقة ','E').replace('حلقة ','E')
            sTitle = cUtil().ConvertSeasons(sTitle)
            siteUrl = aEntry[0]
            sThumb = sThumb
            sDesc = ""

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
			
            oGui.addEpisode(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    sPattern = 'class="ItemEpisode.+?href="([^"]+)"\s*title="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
 
            sTitle = (cUtil().CleanMovieName(aEntry[1])).replace('الحلقة ','E').replace('حلقة ','E')
            sTitle = cUtil().ConvertSeasons(sTitle)
            siteUrl = aEntry[0]
            sThumb = sThumb
			
            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, '', oOutputParameterHandler)

    sPattern = r'<div\s+class="ItemNewly">\s*<a\s+title="([^"]+)"\s+href="([^"]+)">\s*<div\s+class="[^"]*?"\s+style="[^"]*?"\s+data-src="([^"]*?)"'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:

            if 'CategoryItem.name' in aEntry[0]:
                continue

            sTitle = (cUtil().CleanMovieName(aEntry[0])).replace('الحلقة ','E').replace('حلقة ','E')
            sTitle = cUtil().ConvertSeasons(sTitle)
            siteUrl = aEntry[1]
            sThumb = aEntry[2]
			
            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, '', oOutputParameterHandler)
        
        sNextPage, sParent, sType, sTaxonomy = __checkForNextPage(sHtmlContent, sParent, sType, sTaxonomy)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('sHtmlContent', sNextPage)
            oOutputParameterHandler.addParameter('sParent', sParent)
            oOutputParameterHandler.addParameter('sType', sType)
            oOutputParameterHandler.addParameter('sTaxonomy', sTaxonomy)
            oGui.addDir(SITE_IDENTIFIER, 'showEpisodes', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
            
    else:
        oOutputParameterHandler = cOutputParameterHandler() 
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        
        oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sMovieTitle, '', sThumb, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()
	
def __checkForNextPage(sHtmlContent, sParent='', sType='', sTaxonomy=''):
    oParser = cParser()

    sPattern = r"GetMoreCategory\('([^']+)',\s*'([^']+)'\)"
    aResult = oParser.parse(sHtmlContent, sPattern)
    if not aResult[0] or not aResult[1]:
        return False, None, None, None

    try:
        sOrder = aResult[1][0][0]
        sId = aResult[1][0][1]

    except IndexError:
        return False, None, None, None

    sPattern = r"DataPosting\.append\(\s*'parent'\s*,\s*'([^']+)'\s*\)"
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:   
        sParent = aResult[1][0]

    sPattern = r"DataPosting\.append\(\s*'type'\s*,\s*'([^']+)'\s*\)"
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:   
        sType = aResult[1][0]

    sPattern = r"DataPosting\.append\(\s*'taxonomy'\s*,\s*'([^']+)'\s*\)"
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:   
        sTaxonomy = aResult[1][0]

    pdata = {
        "order": sOrder,
        "parent": sParent,
        'type': sType,
        'taxonomy': sTaxonomy,
        "id": sId
    }

    oRequestHandler = cRequestHandler(f'{URL_MAIN}wp-content/themes/Lodynet2020/Api/RequestMoreCategory.php')
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.enableCache(False)
    oRequestHandler.addMultipartFiled(pdata)
    oRequestHandler.setRequestType(1)

    sHtmlContent = oRequestHandler.request(jsonDecode=True)
    if not sHtmlContent or not isinstance(sHtmlContent, list):
        return False, None, None, None

    html_output = ""
    max_items = 20
    for index, item in enumerate(sHtmlContent):
        if not isinstance(item, dict):
            continue

        if index < max_items:
            ribbon_html = f'<div class="NewlyRibbon">{item["ribbon"]}</div>' if item.get("ribbon") else ""
            ago_html = f'<div class="NewlyTimeAgo">{item["ago"]}</div>' if item.get("ago") else ""
            episode_html = (
                f'<div class="NewlyEpNumber"><small>حلقة رقم </small>{item["episode"]}</div>'
                if item.get("episode", 0) > 0 else ""
            )

            html_output += (
                f'<div class="ItemNewly">'
                f'<a title="{item["name"]}" href="https://lodynet.watch{item["url"]}">'
                f'<div class="NewlyCover LoadingCover" style="" data-src="{item["cover"]}">'
                f'{episode_html}</div>{ribbon_html}'
                f'<div class="NewlyTitle">{item["name"]}</div>{ago_html}'
                f'</a></div>'
            )
        else:
            html_output += (
                f'<div id="ItemMore">'
                f'<span id="ItemMoreBtn" onclick="GetMoreCategory(\'{item["type"]}\', \'{item["ID"]}\')">'
                f'عرض المزيد</span></div>'
            )
            break
    
    return html_output, sParent, sType, sTaxonomy
  
def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()    
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request()
       
    sPattern = r"SwitchServer\(this, '([^']+)'\)\">([^<]+)<\/span>"
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        for aEntry in aResult[1]:
            
            url = str(aEntry[0])
            if url.startswith('//'):
               url = 'http:' + url
            
            sHosterUrl = url
            if 'userload' in sHosterUrl:
                sHosterUrl = f'{sHosterUrl}|Referer={URL_MAIN}'
 
            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
               oHoster.setDisplayName(f'{sMovieTitle} [{aEntry[1]}]')
               oHoster.setFileName(sMovieTitle)
               cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    sPattern = 'data-embed="([^"]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        for aEntry in aResult[1]:

            url = str(aEntry)
            if url.startswith('//'):
               url = 'http:' + url

            sHosterUrl = url
            if 'userload' in sHosterUrl:
                sHosterUrl = f'{sHosterUrl}|Referer={URL_MAIN}'

            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
               oHoster.setDisplayName(sMovieTitle)
               oHoster.setFileName(sMovieTitle)
               cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)


    sPattern = r'var\s+ServerDownload\s*=\s*(\[\{.*?\}\]);'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        for aEntry in aResult[1]:
            try:
                jsonDown = json.loads(aEntry)
                for item in jsonDown:
                    url = item["Link"]
                    sName = item["Name"]
                    sDisplayTitle = f'{sMovieTitle} -{cUtil().unescape(sName)}'
                    if url.startswith('//'):
                        url = 'http:' + url

                    sHosterUrl = url
                    if 'userload' in sHosterUrl:
                        sHosterUrl = f'{sHosterUrl}|Referer={URL_MAIN}'

                    oHoster = cHosterGui().checkHoster(sHosterUrl)
                    if oHoster:
                        oHoster.setDisplayName(sDisplayTitle)
                        oHoster.setFileName(sMovieTitle)
                        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)
            except:
                VSlog('Failed to get json')

    if 'class="DownloadLinks">' in sHtmlContent:
        sStart = '<div class="DownloadLinks">'
        sEnd = '</div></div>'
        sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

        sPattern = '<a href="(.+?)" target='
        aResult = oParser.parse(sHtmlContent, sPattern)	
        if aResult[0]:
            for aEntry in aResult[1]:

                url = str(aEntry)
                if url.startswith('//'):
                    url = 'http:' + url

                sHosterUrl = url
                if 'userload' in sHosterUrl:
                    sHosterUrl = f'{sHosterUrl}|Referer={URL_MAIN}'

                oHoster = cHosterGui().checkHoster(sHosterUrl)
                if oHoster:
                    oHoster.setDisplayName(sMovieTitle)
                    oHoster.setFileName(sMovieTitle)
                    cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)
    else:
        if 'id="DownloadAreaMobile"' in sHtmlContent:
            sStart = '<div id="DownloadAreaMobile">'
            sEnd = '<div id="SpaceBottomNotices">'
            sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

            sPattern = 'href="([^"]+)"'
            aResult = oParser.parse(sHtmlContent, sPattern)	
            if aResult[0]:
                for aEntry in aResult[1]:
                    
                    url = str(aEntry)
                    if url.startswith('//'):
                        url = 'http:' + url
                    
                    sHosterUrl = url
                    if 'userload' in sHosterUrl:
                        sHosterUrl = f'{sHosterUrl}|Referer={URL_MAIN}'
        
                    oHoster = cHosterGui().checkHoster(sHosterUrl)
                    if oHoster:
                        oHoster.setDisplayName(sMovieTitle)
                        oHoster.setFileName(sMovieTitle)
                        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)
				                
    oGui.setEndOfDirectory()