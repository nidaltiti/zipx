﻿# -*- coding: utf-8 -*-

import re
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, VSlog, siteManager, addon
from resources.lib.parser import cParser
from resources.lib.util import cUtil
from resources.lib import random_ua

UA = random_ua.get_phone_ua()

SITE_IDENTIFIER = 'fivetv'
SITE_NAME = '5iveTV'
SITE_DESC = 'arabic vod'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

MOVIE_EN = (f'{URL_MAIN}country/united-states-of-america/', 'showMovies')
MOVIE_ASIAN = (f'{URL_MAIN}category/asian/?type=movies', 'showMovies')
MOVIE_HI = (f'{URL_MAIN}category/hendi-rows/?type=movies', 'showMovies')
MOVIE_TURK = (f'{URL_MAIN}category/turkey-rows/?type=movies', 'showMovies')

SERIE_TR = (f'{URL_MAIN}category/turkey-rows/?type=series', 'showSeries')
SERIE_EN = (f'{URL_MAIN}category/new-rows/?type=series', 'showSeries')
SERIE_ASIA = (f'{URL_MAIN}category/asian/?type=series', 'showSeries')
SERIE_HEND = (f'{URL_MAIN}category/hendi-rows/?type=series', 'showSeries')

URL_SEARCH = (f'{URL_MAIN}?s=', 'showMovies')
URL_SEARCH_MOVIES = (f'{URL_MAIN}?s=فيلم%20', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}?s=مسلسل%20', 'showSeries')
FUNCTION_SEARCH = 'showMovies'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_ASIAN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أسيوية', 'asia.png', oOutputParameterHandler)
 
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_TURK[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام تركية', 'turk.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_HI[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام هندية', 'hend.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_ASIA[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أسيوية', 'asia.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_TR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات تركية', 'turk.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_HEND[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات هندية', 'hend.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()
 
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}?s=فيلم%20{sSearchText}'
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showSeriesSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}?s=مسلسل%20{sSearchText}'
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return
		
def showMovies(sSearch = ''):
    oGui = cGui()
    if sSearch:
      sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser()    
    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('User-Agent', UA)
    page = oRequest.request()

    sPattern = 'class="entry-title">(.+?)<.+?data-src="([^"]+)".+?class="year">(.+?)</span>.+?href="([^"]+)"'
    aResult = oParser.parse(page, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            sTitle = cUtil().CleanMovieName(aEntry[0])
            sThumb = re.sub(r'-\d+x\d+', '', aEntry[1])
            siteUrl = aEntry[3]
            sYear = aEntry[2]
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)
			
            oGui.addMovie(SITE_IDENTIFIER, 'showServer', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)

    if not sSearch:
        sStart = '<nav class="navigation pagination">'
        sEnd = '</nav>'
        page = oParser.abParse(page, sStart, sEnd)

        sPattern = 'href="([^"]+)"\s*>(.+?)</a>'
        aResult = oParser.parse(page, sPattern)	
        if aResult[0]:
            oOutputParameterHandler = cOutputParameterHandler()  
            for aEntry in aResult[1]:
 
                sTitle = f'[COLOR red]Page: {aEntry[1].replace("الصفحة التالية",">>")}[/COLOR]'
                siteUrl = aEntry[0]
                sThumb = ""

                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
			
                oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'next.png', oOutputParameterHandler)
 
        oGui.setEndOfDirectory()
 
def showSeries(sSearch = ''):
    oGui = cGui()
    if sSearch:
      sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('User-Agent', UA)
    page = oRequest.request()

    itemList = []
    sPattern = 'class="entry-title">(.+?)<.+?data-src="([^"]+)".+?class="year">(.+?)</span>.+?href="([^"]+)"'
    aResult = oParser.parse(page, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            sTitle = cUtil().CleanSeriesName(aEntry[0])
            sThumb = re.sub(r'-\d+x\d+', '', aEntry[1])
            siteUrl = aEntry[3]
            sYear = aEntry[2]
            sDesc = ''
            if sTitle not in itemList:
                itemList.append(sTitle)                
                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sYear', sYear)
                oOutputParameterHandler.addParameter('sDesc', sDesc)
			
                oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)

    if not sSearch:
        sStart = '<nav class="navigation pagination">'
        sEnd = '</nav>'
        page = oParser.abParse(page, sStart, sEnd)

        sPattern = 'href="([^"]+)"\s*>(.+?)</a>'
        aResult = oParser.parse(page, sPattern)	
        if aResult[0]:
            oOutputParameterHandler = cOutputParameterHandler()  
            for aEntry in aResult[1]:
 
                sTitle = f'[COLOR red]Page: {aEntry[1].replace("الصفحة التالية",">>")}[/COLOR]'
                siteUrl = aEntry[0]
                sThumb = ""

                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
			
                oGui.addDir(SITE_IDENTIFIER, 'showSeries', sTitle, 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()
 
def showSeasons():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('User-Agent', UA)
    page = oRequest.request()

    sPattern = 'data-post="([^"]+)"\s*data-season="([^"]+)"'
    aResult = oParser.parse(page, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:
            
            sSeason = aEntry[1]
            dPost = aEntry[0]
            sTitle = f'{sMovieTitle} S{sSeason}'
            siteUrl = sUrl
            sThumb = sThumb
            sDesc = ""
 
            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('dPost', dPost)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sSeason', sSeason)
            
            oGui.addSeason(SITE_IDENTIFIER, 'showEps', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
    
    oGui.setEndOfDirectory() 
 
def showEps():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    dPost = oInputParameterHandler.getValue('dPost')
    sSeason = oInputParameterHandler.getValue('sSeason')

    oParser = cParser()
    oRequestHandler = cRequestHandler(f'{URL_MAIN}wp-admin/admin-ajax.php')
    oRequestHandler.addHeaderEntry('Accept', '*/*')
    oRequestHandler.addHeaderEntry('sec-fetch-dest', 'empty')
    oRequestHandler.addHeaderEntry('sec-fetch-mode', 'cors')
    oRequestHandler.addHeaderEntry('sec-fetch-site', 'same-origin')
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
    oRequestHandler.addParameters('action', 'action_select_season')
    oRequestHandler.addParameters('season', sSeason)
    oRequestHandler.addParameters('post', dPost)
    oRequestHandler.setRequestType(1)
    page = oRequestHandler.request()

    sPattern = '<div class="post-thumbnail">.+?src="([^"]+)".+?class="entry-title">(.+?)</.+?href="([^"]+)"'
    aResult = oParser.parse(page, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:

            sTitle = (cUtil().ConvertSeasons(aEntry[1])).replace('الحلقة','E')
            siteUrl = aEntry[2]
            sThumb = aEntry[0]
            sDesc = ""

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
 
            oGui.addEpisode(SITE_IDENTIFIER, 'showServer', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
       
    oGui.setEndOfDirectory() 
 
def showServer():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()  
    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('User-Agent', UA)
    page = oRequest.request()

    sPattern = '<form\s*action="([^"]+)".+?name="servers">(.+?)</'
    aResult = oParser.parse(page, sPattern)
    if aResult[0]:
        sPost = aResult[1][0][1] 
        sAction = aResult[1][0][0] 

        oRequestHandler = cRequestHandler(sAction)
        oRequestHandler.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7')
        oRequestHandler.addHeaderEntry('sec-fetch-dest', 'document')
        oRequestHandler.addHeaderEntry('sec-fetch-mode', 'navigate')
        oRequestHandler.addHeaderEntry('sec-fetch-site', 'cross-site')
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
        oRequestHandler.addParameters('servers', sPost)
        oRequestHandler.setRequestType(1)
        data = oRequestHandler.request()

        sPattern = '<form\s*action="([^"]+)".+?name="servers">(.+?)</'
        aResult = oParser.parse(data, sPattern)
        if aResult[0]:
            sPost = aResult[1][0][1] 
            sServers = aResult[1][0][0] 

            oRequestHandler = cRequestHandler(sServers)
            oRequestHandler.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7')
            oRequestHandler.addHeaderEntry('sec-fetch-dest', 'document')
            oRequestHandler.addHeaderEntry('sec-fetch-mode', 'navigate')
            oRequestHandler.addHeaderEntry('sec-fetch-site', 'cross-site')
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            oRequestHandler.addHeaderEntry('Referer', sAction)
            oRequestHandler.addParameters('servers', sPost)
            oRequestHandler.setRequestType(1)
            data = oRequestHandler.request()

    sPattern =  'data-url="([^"]+)"'
    aResult = oParser.parse(data, sPattern)
    if aResult[0]:
        for aEntry in aResult[1]:
    
            url = aEntry
            if url.startswith('//'):
                url = f'http:{url}'
    
            sHosterUrl = url
            if 'userload' in sHosterUrl:
                sHosterUrl = f'{sHosterUrl}|Referer={URL_MAIN}'

            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()
