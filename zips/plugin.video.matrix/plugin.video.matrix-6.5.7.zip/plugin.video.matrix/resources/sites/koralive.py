﻿# -*- coding: utf-8 -*-

import base64, json
import requests
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, siteManager

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0"

SITE_IDENTIFIER = 'koralive'
SITE_NAME = 'Koralive'
SITE_DESC = 'arabic vod'
 
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

sHost = base64.b64decode('L21vYy5vaWVzYWJlcmlmLmJkdHItdGx1YWZlZC00MjAyLWViaXZlbGV0Ly86c3B0dGg=')
dHost = sHost.decode("utf-8")

URL_MAIN = dHost[::-1]

SPORT_LIVE = (f'{URL_MAIN}.json', 'showMatches')

def load():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()    
    oOutputParameterHandler.addParameter('siteUrl', SPORT_LIVE[0])
    oGui.addDir(SITE_IDENTIFIER, 'showChannels', 'بث مباشر', 'foot.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', '')
    oGui.addDir(SITE_IDENTIFIER, 'showMatches', 'بث المباريات', 'foot.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()
	
def showChannels():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('content-type', "application/json")
    oRequestHandler.addHeaderEntry('User-Agent', "Firebase/5/19.3.1/30/Android")
    oRequestHandler.enableCache(False)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    channels = sHtmlContent["channel"]
    oOutputParameterHandler = cOutputParameterHandler() 
    for key, value in channels.items():
        sTitle = value["channelName"]
        sThumb = value["tvgLogo"]
        siteUrl = value["url"]
        sDesc = ''
        
        oOutputParameterHandler.addParameter('siteUrl',siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)

        oGui.addMisc(SITE_IDENTIFIER, 'showLinks', sTitle, 'foot.png', sThumb, sDesc, oOutputParameterHandler)
         
    oGui.setEndOfDirectory()

def showMatches():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()    
    oOutputParameterHandler.addParameter('siteUrl', SPORT_LIVE[0])
    oGui.addDir(SITE_IDENTIFIER, 'showChannels', 'قنوات مباشرة', 'foot.png', oOutputParameterHandler)

    sHost = base64.b64decode('L3p5eC5uZGNtdWltZXJwaXBhLmlwYS8vOnNwdHRo')
    dHost = sHost.decode("utf-8")
    sUrl = dHost[::-1]
    import urllib.parse
    parsed_url = urllib.parse.urlparse(sUrl)
    sHost = parsed_url.netloc

    try:
        headers = {
            "user-agent": "Dart/3.3 (dart:io)",
            "content-type": "application/json",
            "accept-encoding": "gzip",
            "host": sHost
        }

        sHtmlContent = requests.get(f'{sUrl}api/105/all', headers=headers).json()

        for channel in sHtmlContent["List"]:
            oOutputParameterHandler = cOutputParameterHandler() 

            mStatus = channel["live"]
            siteUrl = f'{sUrl}api1/{channel["matchId"]}'
            sTitle = f'{channel["name1"]} vs {channel["name2"]}'
            if str(mStatus) == 'True':
                sTitle = f'{sTitle} [COLOR red]● مباشر[/COLOR]'
            sThumb = channel["image1"]       
            sDesc = f'[COLOR orange]وقت المباراة[/COLOR] \n {channel["start_time"]}(+2) \n \n [COLOR orange]الدوري[/COLOR] \n {channel["ligue"]} \n \n [COLOR orange]حالة البث[/COLOR] \n {str(channel["finished"]).replace("False", "Live on Time").replace("True", "Ended")}'
            
            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)

            oGui.addMisc(SITE_IDENTIFIER, 'showLinks2', sTitle, 'foot.png', sThumb, sDesc, oOutputParameterHandler)
    except:
        oGui.addText(SITE_IDENTIFIER, '[COLOR orange] تعذر الاتصال بالموقع [/COLOR]', 'none.png')

    oGui.setEndOfDirectory()  

def showLinks2():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.enableCache(False)
    oRequestHandler.addHeaderEntry('content-type', "application/json")
    oRequestHandler.addHeaderEntry('User-Agent', "Dart/3.3 (dart:io)")
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    for item in sHtmlContent:
        oOutputParameterHandler = cOutputParameterHandler()
        if '{"' in item["link"]:
            data = json.loads(item["link"])
            for key, value in data.items():
                sHosterUrl = f'{value}|{item["header1"]}={item["header"]}'
                sDisplayTitle = f'{sMovieTitle} ({key})'

                oHoster = cHosterGui().checkHoster(sHosterUrl)
                sHosterUrl = sHosterUrl 
                if oHoster:
                    oHoster.setDisplayName(sDisplayTitle)
                    oHoster.setFileName(sMovieTitle)
                    cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb, oOutputParameterHandler)

        else:
            sHosterUrl = f'{item["link"]}|{item["header1"]}={item["header"]}'

            oHoster = cHosterGui().checkHoster(sHosterUrl)
            sHosterUrl = sHosterUrl 
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb, oOutputParameterHandler)

    oGui.setEndOfDirectory()    

def showLinks():

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
   
    sHosterUrl = f'{sUrl}|User-Agent=Android-App@2024'

    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sMovieTitle)
    sUrl = sUrl.replace(' ', '%20')
    oGuiElement.setMediaUrl(sHosterUrl)
    oGuiElement.setThumbnail(sThumb)
    oGuiElement.setDescription('')

    from resources.lib.player import cPlayer
    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer()

    return False, False