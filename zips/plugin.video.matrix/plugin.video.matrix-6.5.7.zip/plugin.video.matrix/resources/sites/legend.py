# -*- coding: utf-8 -*-
from Cryptodome.Cipher import AES
import random
import base64
import base64, json, re
import urllib.parse
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.parser import cParser
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, siteManager

SITE_IDENTIFIER = 'legend'
SITE_NAME = 'The Legend [COLOR orange]تحت التجربة[/COLOR]'
SITE_DESC = 'Arab VOD'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

dHost = ["koi3ayg88sla5fka955927x61uhevkbvcd6nrpqseyc90firw1.s-14.shop",
         "nwn6iey8pea3p0s7c7psajyx3vqgtb1m5sir2972obernaluxd.15-1.top",
         "klubf470iv9ne5f5bph4om3149ri7c7tcqhspwjt58l91uaa8v.s-29.shop",
         "tvdfait12zj3eytc40lnr9qgwi2agvox982q7gq1e4m79rkmno.19-1.top",
         "s6nzwlo1c3aewrk04lv1mh9cvut2nok8cya58i3jmbztp6fvgi.s-27.shop"
         ]
sKey = base64.b64decode('d3ZAdkVARyY5TitqWnghYw==').decode("utf-8")
sKey = sKey[::-1]

URL_MAIN = dHost[random.randint(0, len(dHost)-1)]
URL_WEB = URL_MAIN
TV_TV = (True, 'showDailyList')

def load():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', f'https://{URL_MAIN}/api/v6.2/main')
    oGui.addDir(SITE_IDENTIFIER, 'showDailyList', 'Latest list', 'tv.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showDailyList():
    oGui = cGui()

    sHtmlContent = get_categories()
    oOutputParameterHandler = cOutputParameterHandler() 
    for category in sHtmlContent["data"]:

        siteUrl = category["id"]
        sTitle = category["name"]
        sThumb = category["image"]    
        sDesc = ''
        
        oOutputParameterHandler.addParameter('siteUrl',siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)

        oGui.addMisc(SITE_IDENTIFIER, 'showCatList', sTitle, 'listes.png', sThumb, sDesc, oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showCatList():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    nPage = oInputParameterHandler.getValue('nPage')

    if nPage is False:
        nPage = 1

    sHtmlContent = get_category(sUrl, nPage)
    oOutputParameterHandler = cOutputParameterHandler()

    for category in sHtmlContent["data"]["items"]:
        siteUrl = category["id"]
        sTitle = category["name"]
        sThumb = category["image"]
        sDesc = ''

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)

        if "source" in category:
            oGui.addMisc(SITE_IDENTIFIER, 'showCatList', sTitle, 'listes.png', sThumb, sDesc, oOutputParameterHandler)
        else:
            oGui.addMisc(SITE_IDENTIFIER, 'showCHLinks', sTitle, 'listes.png', sThumb, sDesc, oOutputParameterHandler)

    sNextPage = __checkForNextPage(sHtmlContent)
    if sNextPage:
        nPage = int(nPage) + 1 
        oOutputParameterHandler.addParameter('nPage', nPage)
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oGui.addDir(SITE_IDENTIFIER, 'showCatList', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showCHLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    nPage = oInputParameterHandler.getValue('nPage')

    if nPage is False:
        nPage = 1

    sHtmlContent = get_category(sUrl, nPage)

    itemList = []
    oOutputParameterHandler = cOutputParameterHandler() 
    for sLinks in sHtmlContent["data"]["items"]:

            sHosterUrl = sLinks["source"]
            if '<<R>>' in sHosterUrl:
                sHosterUrl = sHosterUrl.replace('|', '&').replace('<<R>>', '|Referer=')

            sTitle = sLinks["name"]
            sThumb = sLinks["image"]

            season, episode = None, None
            if ' - ' in sTitle:
                parts = sTitle.split(' - ')
                if len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit():
                    season = int(parts[0])
                    episode = int(parts[1])
            elif 'الحلقة' in sTitle:
                match = re.search(r'الحلقة\s*(\d+)', sTitle)
                if match:
                    episode = int(match.group(1))
                    season = 1
            elif 'الموسم' in sTitle and 'الحلقة' in sTitle:
                match = re.search(r'الموسم\s*(\d+)\s*[-–]?\s*الحلقة\s*(\d+)', sTitle)
                if match:
                    season = int(match.group(1))
                    episode = int(match.group(2))

            if season and episode:
                sDisplayTitle = f'{sMovieTitle} - S{season:02d}E{episode:02d}'
            else:
                sDisplayTitle = f'{sMovieTitle} - {sTitle}'

            if sDisplayTitle not in itemList:
                itemList.append(sDisplayTitle)	
                oOutputParameterHandler.addParameter('sHosterUrl', sHosterUrl)
                oOutputParameterHandler.addParameter('siteUrl', sUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sDisplayTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                if season and episode:
                    oGui.addEpisode(SITE_IDENTIFIER, 'showLinks', sDisplayTitle, '', sThumb, sDisplayTitle, oOutputParameterHandler)
                else:
                    oGui.addLink(SITE_IDENTIFIER, 'showLinks', sDisplayTitle, sThumb, sDisplayTitle, oOutputParameterHandler)


    sNextPage = __checkForNextPage(sHtmlContent)
    if sNextPage:
        nPage = int(nPage) + 1 
        oOutputParameterHandler.addParameter('nPage', nPage)
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oGui.addDir(SITE_IDENTIFIER, 'showCatList', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sHosterUrl = oInputParameterHandler.getValue('sHosterUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    
    sources = sHosterUrl.replace('urlvplayer://', '').split('!')
    for sHosterUrl in sources:
        if '<<R>>' in sHosterUrl:
            sHosterUrl = sHosterUrl.replace('|', '&').replace('<<R>>', '|Referer=')
        else:
            sHosterUrl = sHosterUrl

        oHoster = cHosterGui().checkHoster(sHosterUrl)
        if oHoster:
            if oHoster.getPluginIdentifier() == 'direct_link':
                sHosterUrl += '|User-Agent=Mozilla/5.0 (Android 15; Mobile; rv:138.0) Gecko/138.0 Firefox/138.0'
            oHoster.setDisplayName(sMovieTitle)
            oHoster.setFileName(sMovieTitle)
            cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()

def __checkForNextPage(sHtmlContent):
    pagination = sHtmlContent.get("data", {}).get("pagination", {})
    if pagination:
        if int(pagination.get("pages", 1)) != int(pagination.get("page", 1)):
            return int(pagination.get("page", 1))
    return False

def extract_domain(url):
  parsed_url = urllib.parse.urlparse(url)
  return parsed_url.netloc

def decrypt_base64_url(encoded):
    key = bytes.fromhex("4e5c6d1a8b3fe8137a3b9df26a9c4de195267b8e6f6c0b4e1c3ae1d27f2b4e6f")
    iv = bytes.fromhex("a9c21f8d7e6b4a9db12e4f9d5c1a7b8e")

    encoded = encoded.replace('-', '+').replace('_', '/')
    encoded += '=' * (-len(encoded) % 4)

    encrypted = base64.b64decode(encoded)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = cipher.decrypt(encrypted)

    pad_len = decrypted[-1]
    return decrypted[:-pad_len].decode('utf-8')

def req(path):

    oRequestHandler = cRequestHandler(path)
    oRequestHandler.addHeaderEntry('Connection', "Keep-Alive")
    oRequestHandler.addHeaderEntry('accept-encoding', "gzip")
    oRequestHandler.addHeaderEntry('Host', URL_MAIN)
    oRequestHandler.addHeaderEntry('User-Agent', "Mozilla/5.0 (Android 15; Mobile; rv:138.0) Gecko/138.0 Firefox/138.0")
    oRequestHandler.enableCache(False)
    sHtmlContent = oRequestHandler.request()
    try:
      return json.loads(decrypt_base64_url(sHtmlContent))
    
    except Exception:
      return {
        "success": False,
        "error": "can't parse json."
      }

def get_categories():
    return req(f'https://{URL_MAIN}/api/v6.2/main')

def get_category(category_id, nPage):
    return req(f"https://{URL_MAIN}/api/v6.2/category/{category_id}?page={nPage}")

def get_category_channels(category_id):
    return req(f"https://{URL_MAIN}/api/v6.2/matches/{category_id}")

