# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

setup(
    name='matrix',
    version='0.1',
    packages=find_packages(),

    install_requires=['foo>=3'],

    author='matrix Media',
    author_email='',

    summary='Just another Python package for the cheese shop',
    url='',
    license='',
    long_description='Long description of the package',
)
