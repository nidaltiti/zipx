#-*- coding: utf-8 -*-

from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.hosters.hoster import iHoster
from resources.lib.packer import cPacker
from resources.lib.comaddon import VSlog
from resources.lib.util import urlHostName

UA = 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36'

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'uqload', 'Uqload')

    def __getHost(self, url):
        parts = url.split('//', 1)
        host = parts[0] + '//' + parts[1].split('/', 1)[0]
        return host

    def _getMediaLinkForGuest(self, autoPlay = False):
        VSlog(self._url)
        api_call = ''
        oParser = cParser()

        oRequest = cRequestHandler(self._url)
        oRequest.enableCache(False)
        sHtmlContent = oRequest.request()
        url2 = self.__getHost(oRequest.getRealUrl())

        sPattern = r'(eval\(function\(p,a,c,k,e(?:.|\s)+?\))<\/script>'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            data = aResult[1][0]
            sHtmlContent = cPacker().unpack(data)

        sPattern = r'file:"([^"]+)"\}'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            api_call = aResult[1][0] 

        sPattern1 = 'sources.+?"([^"]+mp4)"'
        aResult = oParser.parse(sHtmlContent, sPattern1)
        if aResult[0]:
            api_call = f"{aResult[1][0]}|User-Agent={UA}&Referer={url2}/&Host={urlHostName(url2)}"


        if api_call:
            return True, api_call

        return False, False
