# -*- coding: utf-8 -*-

from resources.lib.util import urlHostName
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.hosters.hoster import iHoster
from resources.lib.packer import cPacker
from resources.lib.comaddon import dialog
from resources.lib.comaddon import VSlog

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'estream', 'FireStream')

    def _getMediaLinkForGuest(self, autoPlay = False):
        VSlog(self._url)
        api_call = False

        oRequest = cRequestHandler(self._url)
        oRequest.addHeaderEntry('Referer', f'https://{urlHostName(self._url)}/')
        oRequest.addHeaderEntry('User-Agent', UA)
        oRequest.enableCache(False)
        sHtmlContent = oRequest.request()

        oParser = cParser()
        sPattern = '<source *src="([^"]+)" *type=\'video/.+?\''
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            api_call = aResult[1][0]

        sPattern = '<script type=\'text/javascript\'>(.+?)</script>'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            stri = cPacker().unpack(aResult[1][0])
            sPattern = 'file:"([^"]+)",label:"([0-9]+)"}'
            aResult = oParser.parse(stri, sPattern)
            if aResult[0]:
                url = []
                qua = []

                for aEntry in aResult[1]:
                    url.append(aEntry[0])
                    qua.append(aEntry[1][:3] + '*' + aEntry[1][3:])

                api_call = dialog().VSselectqual(qua, url)

        sPattern = r'id="token-blob"[^>]+>([^<]+)'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            from resources.lib import helpers
            blob = aResult[1][0]
            parts = self._url.split("/")
            media_id = parts[-1].split("#")[0].split("?")[0]

            oRequestHandler = cRequestHandler(f'https://{urlHostName(self._url)}/api/videos/{media_id}/resolve')
            oRequestHandler.addHeaderEntry('Referer', f'https://{urlHostName(self._url)}/')
            oRequestHandler.addHeaderEntry('Origin', f'https://{urlHostName(self._url)}')
            oRequestHandler.addHeaderEntry('User-Agent', UA)
            oRequestHandler.addJSONEntry('blob', blob)
            oRequestHandler.setRequestType(1)
            sHtmlContent = oRequestHandler.request(jsonDecode=True)
            headers = {'Referer':f'https://{urlHostName(self._url)}/',
                       'Origin':f'https://{urlHostName(self._url)}',
                       'User-Agent':UA}

            api_call = sHtmlContent.get('signedVideoUrl') + helpers.append_headers(headers)


        if api_call:
            return True, api_call

        return False, False
