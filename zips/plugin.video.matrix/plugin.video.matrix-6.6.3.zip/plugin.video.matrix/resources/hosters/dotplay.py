#-*- coding: utf-8 -*-
from resources.lib.handler.requestHandler import cRequestHandler
from resources.hosters.hoster import iHoster
from resources.lib.comaddon import VSlog
import base64
import json
import re

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0"

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'dotplay', 'DotPlay')

    def isDownloadable(self):
        return True

    def _getMediaLinkForGuest(self, autoPlay=False):
        VSlog(self._url)

        codeMatch = re.search(r'embed/([a-zA-Z0-9]+)', self._url)
        if not codeMatch:
            return False, False
        code = codeMatch.group(1)

        apiUrl = f'https://dotplay.net/api.php?code={code}'
        oRequestHandler = cRequestHandler(apiUrl)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('Referer', f'https://dotplay.net/embed/{code}')
        oRequestHandler.addHeaderEntry('Accept', 'application/json')
        oRequestHandler.enableCache(False)
        sResponse = oRequestHandler.request()

        try:
            data = json.loads(sResponse)
            if data.get('success') and data.get('video_url'):
                decoded = base64.b64decode(data['video_url']).decode('utf-8')
                parts = decoded.split('|')
                videoUrl = parts[0]
                if videoUrl:
                    return True, f'{videoUrl}|Referer=https://dotplay.net/embed/{code}&User-Agent={UA}'
        except Exception as e:
            VSlog(f'DotPlay parse error: {e}')

        return False, False
