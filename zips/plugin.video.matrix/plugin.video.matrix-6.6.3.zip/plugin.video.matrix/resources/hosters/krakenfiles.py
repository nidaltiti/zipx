#-*- coding: utf-8 -*-

from resources.lib.handler.requestHandler import cRequestHandler
from resources.hosters.hoster import iHoster
from resources.lib import helpers
from resources.lib.comaddon import VSlog
from resources.lib.parser import cParser
from resources.lib.util import urlHostName
from six.moves import urllib_parse

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0"

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'krakenfiles', 'Krakenfiles')

    def _getMediaLinkForGuest(self, autoPlay = False):
        oRequest = cRequestHandler(self._url)
        oRequest.enableCache(False)
        oRequest.addHeaderEntry('User-Agent', UA)
        oRequest.addHeaderEntry('Accept-Language', "en-US,en;q=0.9")
        sHtmlContent = oRequest.request()

        api_call = ''

        oParser = cParser()
        sPattern = 'source src="([^"]+)'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0] is True:
            api_call = aResult[1][0]
            if api_call.startswith('//'):
                api_call = 'https:' + api_call

        headers = {
            "Accept": "*/*",
            "Accept-Encoding": "identity;q=1, *;q=0",
            "Accept-Language": "en-US,en;q=0.9",
            "Connection": "keep-alive",
            "Host": urlHostName(api_call),
            "Referer": f"https://{urlHostName(self._url)}/",
            "User-Agent": UA
        }

        if api_call:
            return True, urllib_parse.quote(api_call, '/:?=&') + helpers.append_headers(headers)

        return False, False