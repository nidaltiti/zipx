#-*- coding: utf-8 -*-

import json
from urllib.parse import unquote, urlparse, quote
from resources.lib.handler.requestHandler import cRequestHandler
from resources.hosters.hoster import iHoster
from resources.lib.comaddon import VSlog, siteManager
from resources.lib.util import urlHostName

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36'

HEADERS = {
    "User-Agent": UA,
    "Accept": "text/html,*/*;q=0.01",
    "Accept-Language": "en-US,en;q=0.5",
    "Sec-GPC": "1",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "Priority": "u=0",
    "Pragma": "no-cache",
    "Cache-Control": "no-cache",
    "Referer": siteManager().getUrlMain('sflix'),
    "Connection": "keep-alive"
}

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'rapidshare', 'Rapidshare')

    def _getMediaLinkForGuest(self, autoPlay = False):
        api_call = ''
        SubTitle = ''

        VSlog(self._url)

        if ('sub.list' in self._url):
            SubTitle = unquote(self._url.split('sub.list=')[1])
            self._url = self._url.split('?sub.list=')[0]

            oRequest = cRequestHandler(SubTitle)
            subs = oRequest.request(jsonDecode=True)
            arabic_sub = None
            english_sub = None
            for item in subs:
                label = item.get("label", "").lower()
                if "arabic" in label:
                    arabic_sub = item["file"]
                elif "english" in label:
                    english_sub = item["file"]

            SubTitle = arabic_sub or english_sub or ''

        media_url = self._url.replace("/e/", "/media/").replace("/e2/", "/media/")
        oRequestHandler = cRequestHandler(media_url)
        for key, value in HEADERS.items():
            oRequestHandler.addHeaderEntry(key, value)
        try:
            encoded_json = oRequestHandler.request(jsonDecode=True)
            encoded_result = encoded_json.get("result")
        except Exception:
            encoded_result = None

        if not encoded_result:
            return False, False

        multiDecryptAPI = "https://enc-dec.app/api"
        oRequestHandler = cRequestHandler(f"{multiDecryptAPI}/dec-mega")
        oRequestHandler.addJSONEntry('text', encoded_result)
        oRequestHandler.addJSONEntry('agent', HEADERS["User-Agent"])
        oRequestHandler.setRequestType(1)
        m3u8_data = oRequestHandler.request()

        if not m3u8_data.strip():
            VSlog("Encoded result is null or empty")
            return False, False

        try:
            root = json.loads(m3u8_data)
            result = root.get("result")
            if not result:
                VSlog("No 'result' object in M3U8 JSON")
                return False, False

            sources = result.get("sources", [])
            if sources:
                first = sources[0]
                if isinstance(first, dict):
                    m3u8_file = first.get("file")
                else:
                    m3u8_file = first if first else None

                if m3u8_file:
                    VSlog(f"M3U8 file: {m3u8_file}")
                    api_call = m3u8_file

                else:
                    VSlog("No 'file' found in first source")
            else:
                VSlog("No sources found in M3U8 data")

        except Exception as e:
            print("Failed to parse M3U8 JSON:", e)

        if api_call:
            if ('http' in SubTitle):
                return True, quote(api_call, ':/?=&') + '|User-Agent=' + HEADERS["User-Agent"] + '&Referer=' + f'https://{urlHostName(self._url)}/' + '&Origin=' + f'https://{urlHostName(self._url)}', SubTitle
            else:
                return True, quote(api_call, ':/?=&') + '|User-Agent=' + HEADERS["User-Agent"] + '&Referer=' + f'https://{urlHostName(self._url)}/' + '&Origin=' + f'https://{urlHostName(self._url)}'

        return False, False
