#-*- coding: utf-8 -*-
# https://github.com/Kodi-vStream/venom-xbmc-addons

import re
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.hosters.hoster import iHoster
from resources.lib.comaddon import dialog, VSlog

class cHoster(iHoster):
    def __init__(self):
        iHoster.__init__(self, 'dailymotion', 'Dailymotion')

    def isDownloadable(self):
        return True

    def setUrl(self, sUrl):
        self._url = str(sUrl)
        self.embedder = self._url

        if "metadata" not in self._url:
            url_path = self._url
            if '?video=' in self._url:
                video_id = self._url.split('?video=')[1]
            else:
                url_path = self._url.split('?')[0]

                if 'embed/video' in url_path or '/swf/video' in url_path:
                    video_id = url_path.split('/')[5]
                else:
                    video_id = url_path.split('/')[4]

            self._url = (
                f"https://www.dailymotion.com/player/metadata/video/{video_id}"
                f"?embedder={self.embedder}"
            )

    def _getMediaLinkForGuest(self, autoPlay = False):
        api_call = False
        url=[]
        qua=[]

        oRequest = cRequestHandler(self._url)
        oRequest.enableCache(False)
        sHtmlContent = oRequest.request()
        VSlog(self._url)

        oParser = cParser()
        sPattern =  r'{"type":"application.+?mpegURL","url":"([^"]+)"}'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            api_call = aResult[1][0]
            VSlog(f"Found HLS URL: {api_call}")

            oRequest = cRequestHandler(api_call)
            oRequest.enableCache(False)
            sHtmlContent = oRequest.request()

            qua = []
            url = []
            pattern = r'NAME="([^"]+)".*?\n\s*(https?://\S+)'
            matches = re.findall(pattern, sHtmlContent)
            for quality, link in reversed(matches):
                qua.append(quality)
                url.append(link)
            if qua and url:
                api_call = dialog().VSselectqual(qua, url)

        if api_call:
            return True, api_call+ f'|Referer={self.embedder}'

        return False, False