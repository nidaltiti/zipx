﻿#coding: utf-8
import re
import time
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import VSlog, addon
from resources.lib.util import urlHostName
from resources.lib.mCaptcha.mserver import CaptchaServer
from resources.hosters.hoster import iHoster
from resources.lib import util

UA = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:68.0) Gecko/20100101 Firefox/68.0'

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'vidmoly', 'Vidmoly')

    def _getMediaLinkForGuest(self, autoPlay = False):
        VSlog(self._url)
        if 'embed-' in self._url:
            eUrl = self._url
            self._url = self._url

        if '/w/' in self._url:
            oRequest = cRequestHandler(self._url)
            oRequest.addHeaderEntry('User-Agent', UA)
            sHtmlContent = oRequest.request()
            
            sPattern = 'iframe src="//([^"]+)"'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                self._url = 'https://' + aResult[1][0]

        if '|Referer=' in self._url:
            sReferer = self._url.split('|Referer=')[1]
            self._url = self._url.split('|Referer=')[0]
        else:
            sReferer = self._url

        api_call = ''

        match = re.search(r'embed-([^.]+)\.html', self._url)
        video_id = match.group(1) if match else ''
        VSlog(f'Extracted video ID: {video_id}')

        oParser = cParser()
        oRequest = cRequestHandler(self._url)
        oRequest.addHeaderEntry('Referer', sReferer)
        oRequest.addHeaderEntry('Cookie', f'cf_turnstile_demo_pass_{video_id}=1')
        oRequest.enableCache(False)
        sHtmlContent = oRequest.request()
		
        if ' can be watched as embed' in sHtmlContent:
            oRequest = cRequestHandler(eUrl)
            oRequest.addHeaderEntry('Referer', sReferer)
            oRequest.addHeaderEntry('Sec-Fetch-Dest', "iframe")
            oRequest.addHeaderEntry('Cookie', f'cf_turnstile_demo_pass_{video_id}=1')
            sHtmlContent = oRequest.request()

        match = re.search(r'data-sitekey="([^"]+)"', sHtmlContent)
        if match:
            sitekey = match.group(1)
            token = self.get_captcha(sitekey)

            oRequest = cRequestHandler(f'{self._url}?cfp={token}')
            oRequest.addHeaderEntry('Referer', sReferer)
            oRequest.enableCache(False)
            sHtmlContent = oRequest.request()

        sPattern = r'sources: [{file:"(.+?)"}],'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            api_call = aResult[1][0]
		
        sPattern = r'file:"(.+?)"}'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            api_call = aResult[1][0]

        sPattern = r',{file:"(.+?)",label'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            api_call = aResult[1][0]

        sPattern = r'file:\s*["\']([^"\']+)["\']'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            api_call = aResult[1][0]

        sPattern = r"sources:\s*\[\{\s*file:\s*'([^']+)'"
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            api_call = aResult[1][0]

        if api_call:
            return True, api_call +'|User-Agent=' + UA  + '&Referer=' + self._url       

        return False, False 

    def get_captcha(self, sitekey):
        # Turnstile for captcha handling
        captcha_data = {
            "siteUrl": self._url,
            "siteKey": sitekey,
            "captchaType": "cf_re"
        }

        try:
            last_gen = int(addon().getSetting(f"{urlHostName(self._url)}_mcreate"))
        except Exception:
            last_gen = 0

        if not addon().getSetting(f"{urlHostName(self._url)}_mcaptcha") or last_gen < (time.time() - (1 * 60)):
            server = CaptchaServer(captcha_data)
            server.start_server()
            return addon().getSetting(f"{urlHostName(self._url)}_mcaptcha")
        else:
            return addon().getSetting(f"{urlHostName(self._url)}_mcaptcha")