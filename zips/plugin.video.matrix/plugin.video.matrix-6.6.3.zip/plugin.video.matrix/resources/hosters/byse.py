#-*- coding: utf-8 -*-

import json
import base64
import time
import hashlib
from binascii import hexlify
from hashlib import sha256
from os import urandom
from random import uniform, choice
from resources.lib.handler.requestHandler import cRequestHandler
from resources.hosters.hoster import iHoster
from resources.lib.comaddon import VSlog
from Cryptodome.Cipher import AES as PyCryptoAES
from six.moves import urllib_parse

_ANDROID_PROFILES = [
    {
        "user_agent": "Mozilla/5.0 (Linux; Android 10; TX6s) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
        "model": "TX6s",
        "platform_version": "10.0.0",
        "hardware_concurrency": 4,
        "device_memory": 2,
        "pixel_ratio": 1,
        "screen_width": 1280,
        "screen_height": 720,
        "pointer_type": "coarse",
        "touch_points": 1,
        "webgl_vendor": "Google Inc. (ARM)",
        "webgl_renderer": "ANGLE (ARM, Mali-G31 MP2, OpenGL ES 3.2)",
    }
]

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'byse', 'Byse')

    def _getMediaLinkForGuest(self):
        VSlog(self._url)

        if '|Referer=' in self._url:
            self._url = self._url.split('|Referer=')[0].strip()
            VSlog('Hoster Vidara - setUrl : ' + self._url)

        try:
            media_id = self._url.split('/e/')[-1].split('/')[0]
        except Exception:
            return False, False

        ref = urllib_parse.urljoin(self._url, '/')
        profile = choice(_ANDROID_PROFILES)
        UA = profile["user_agent"]
        
        headers = {
            'User-Agent': UA,
            'Referer': ref,
            'Origin': ref[:-1]
        }
        
        # Step 1: Query endpoint variations using standard fallback logic
        embed_segment = ''
        details_url = '{0}api/videos/{1}/details'.format(ref, media_id)
        oRequest = cRequestHandler(details_url)
        for k, v in headers.items():
            oRequest.addHeaderEntry(k, v)
        sHtmlContent = oRequest.request()
        
        # If the direct API route answers with an empty body or 404 block, switch paths
        if not sHtmlContent:
            embed_segment = 'embed/'
            details_url = '{0}api/videos/{1}/{2}details'.format(ref, media_id, embed_segment)
            oRequest = cRequestHandler(details_url)
            for k, v in headers.items():
                oRequest.addHeaderEntry(k, v)
            sHtmlContent = oRequest.request()
            
        if not sHtmlContent:
            return False, False
            
        details = json.loads(sHtmlContent)
        embed_url = details.get('embed_frame_url')
        
        if embed_url:
            headers.update({
                'X-Embed-Parent': self._url,
                'X-Embed-Origin': ref[:-1],
                'X-Embed-Referer': ref
            })
            ref = urllib_parse.urljoin(embed_url, '/')
            headers.update({
                'Referer': ref,
                'Origin': ref[:-1],
            })

        # Step 2: Get Embed Settings with explicit domain configuration context
        settings_url = '{0}api/videos/{1}/{2}settings'.format(ref, media_id, embed_segment)
        oRequest = cRequestHandler(settings_url)
        for k, v in headers.items():
            oRequest.addHeaderEntry(k, v)
        sHtmlContent = oRequest.request()
        if not sHtmlContent:
            return False, False
            
        settings = json.loads(sHtmlContent)

        # Step 3: Handle Verification Flow
        if settings.get('captcha_required') or True:
            challenge_url = '{0}api/videos/access/challenge'.format(ref)
            oRequest = cRequestHandler(challenge_url)
            for k, v in headers.items():
                oRequest.addHeaderEntry(k, v)
            oRequest.setRequestType(1)
            oRequest.addParametersLine('{}')
            
            challenge_res = json.loads(oRequest.request())
            
            viewer_id = challenge_res.get("viewer_hint") or self.b64url_encode(urandom(16))
            device_id = self.b64url_encode(urandom(16))

            attest_url = '{0}api/videos/access/attest'.format(ref)
            oRequest = cRequestHandler(attest_url)
            for k, v in headers.items():
                oRequest.addHeaderEntry(k, v)
            oRequest.setRequestType(1)
            
            attest_payload = self.wn(challenge_res, profile, viewer_id, device_id)
            oRequest.addParametersLine(json.dumps(attest_payload))
            
            attest_res = json.loads(oRequest.request())
            fp_data = attest_res if attest_res else {}
            
            viewer_id = fp_data.get("viewer_id") or viewer_id
            device_id = fp_data.get("device_id") or device_id

            fingerprint = {
                'token': fp_data.get('token'),
                'viewer_id': viewer_id,
                'device_id': device_id,
                'confidence': fp_data.get('confidence'),
            }

            headers['Cookie'] = 'byse_viewer_id={0}; byse_device_id={1}'.format(viewer_id, device_id)

            captcha_url = '{0}api/videos/{1}/{2}captcha'.format(ref, media_id, embed_segment)
            oRequest = cRequestHandler(captcha_url)
            for k, v in headers.items():
                oRequest.addHeaderEntry(k, v)
            oRequest.setRequestType(1)
            oRequest.addParametersLine(json.dumps({'fingerprint': fingerprint}))
            captcha = json.loads(oRequest.request())

            solution = self.er(captcha['pow_nonce'], captcha['pow_difficulty'])
            if solution is None:
                return False, False

            verify_url = '{0}api/videos/{1}/{2}captcha/verify'.format(ref, media_id, embed_segment)
            oRequest = cRequestHandler(verify_url)
            for k, v in headers.items():
                oRequest.addHeaderEntry(k, v)
            oRequest.setRequestType(1)
            post_data = {'pow_token': captcha['pow_token'], 'solution': solution, 'fingerprint': fingerprint}
            oRequest.addParametersLine(json.dumps(post_data))
            verify = json.loads(oRequest.request())
            
            if verify.get('token'):
                headers.update({'X-Captcha-Token': verify.get('token')})

            playback_url = '{0}api/videos/{1}/{2}playback'.format(ref, media_id, embed_segment)
            oRequest = cRequestHandler(playback_url)
            for k, v in headers.items():
                oRequest.addHeaderEntry(k, v)
            oRequest.setRequestType(1)
            oRequest.addParametersLine(json.dumps({'fingerprint': fingerprint}))
            sHtmlContent2 = oRequest.request()
        else:
            playback_url = '{0}api/videos/{1}/{2}playback'.format(ref, media_id, embed_segment)
            oRequest = cRequestHandler(playback_url)
            for k, v in headers.items():
                oRequest.addHeaderEntry(k, v)
            oRequest.setRequestType(1)
            oRequest.addParametersLine(json.dumps(self.fp(16, 0.83, 0.94)))
            sHtmlContent2 = oRequest.request()

        if not sHtmlContent2:
            return False, False

        data = json.loads(sHtmlContent2)
        
        sources = data.get('sources')
        if sources:
            api_call = sources[0].get('url')
            if api_call.startswith('/'):
                api_call = urllib_parse.urljoin(ref, api_call)
            return True, api_call + '|%s' % '&'.join(['%s=%s' % (k, headers[k]) for k in headers if k != 'Content-Type'])

        pd = data.get('playback')
        if pd:
            iv = ft(pd.get('iv'))
            key = xn(pd.get('key_parts'), pd.get('version'))
            payload = ft(pd.get('payload'))

            tag = payload[-16:]
            ciphertext = payload[:-16]
            cipher = PyCryptoAES.new(key, PyCryptoAES.MODE_GCM, nonce=iv)
            pt = cipher.decrypt_and_verify(ciphertext, tag)
            ct = json.loads(pt.decode('latin-1'))

            sources = ct.get('sources')
            if sources:
                api_call = sources[0].get('url')
                clean_headers = {}
                for k in headers:
                    if k in ['User-Agent', 'Referer', 'Origin', 'Cookie']:
                        clean_headers[k] = headers[k]
                return True, api_call + '|%s' % '&'.join(['%s=%s' % (k, clean_headers[k]) for k in clean_headers])

        return False, False

    @staticmethod
    def b64url_encode(data):
        if isinstance(data, str):
            data = data.encode()
        return base64.b64encode(data).decode().replace("+", "-").replace("/", "_").replace("=", "")

    @classmethod
    def wn(cls, ch, p, viewer_id, device_id):
        from resources.lib.ecdsa import SigningKey, NIST256p
        
        nonce = ch.get('nonce', '')
        sk = SigningKey.generate(curve=NIST256p, hashfunc=sha256)
        vk = sk.verifying_key.to_string()
        signature = sk.sign(str(nonce).encode(), hashfunc=sha256)
        
        pub = {
            'crv': 'P-256', 'ext': True, 'key_ops': ['verify'], 'kty': 'EC',
            'x': cls.b64url_encode(vk[:32]),
            'y': cls.b64url_encode(vk[32:]),
        }
        
        r = uniform(0, 1)
        client = {
            "user_agent": p["user_agent"],
            "architecture": "arm",
            "bitness": "32",
            "platform": "Android",
            "platform_version": p["platform_version"],
            "model": p["model"],
            "ua_full_version": "137.0.7337.0",
            "brand_full_versions": [
                {"brand": "Chromium", "version": "137.0.7337.0"}
            ],
            "pixel_ratio": p["pixel_ratio"],
            "screen_width": p["screen_width"],
            "screen_height": p["screen_height"],
            "color_depth": 24,
            "languages": ["en-US"],
            "timezone": "America/New_York",
            "hardware_concurrency": p["hardware_concurrency"],
            "device_memory": p["device_memory"],
            "touch_points": p["touch_points"],
            "webgl_vendor": p["webgl_vendor"],
            "webgl_renderer": p["webgl_renderer"],
            "canvas_hash": cls.b64url_encode(hashlib.sha256(str(r).encode('ascii')).digest()),
            "audio_hash": cls.b64url_encode(hashlib.sha256(str(r + 1).encode('ascii')).digest()),
            "webgl_params_hash": cls.b64url_encode(hashlib.sha256(str(r + 2).encode('ascii')).digest()),
            "fonts_hash": cls.b64url_encode(hashlib.sha256(str(r + 3).encode('ascii')).digest()),
            "codecs_hash": cls.b64url_encode(hashlib.sha256(str(r + 4).encode('ascii')).digest()),
            "media_devices": "ai1ao1vi4",
            "pointer_type": p["pointer_type"],
            "extra": {
                "vendor": "Google Inc.",
                "appVersion": p["user_agent"].lstrip('Mozilla/')
            }
        }

        return {
            'viewer_id': '',
            'device_id': '',
            'challenge_id': ch['challenge_id'],
            'nonce': nonce,
            'signature': cls.b64url_encode(signature),
            'public_key': pub,
            'client': client,
            'storage': {},
            'attributes': {'entropy': 'high'}
        }

    @staticmethod
    def re(t, e):
        return ((t << e) | (t >> (32 - e))) & 0xFFFFFFFF

    def ye(self, t):
        m = 0xFFFFFFFF
        t[0] = (t[0] + t[1]) & m
        t[3] = self.re(t[3] ^ t[0], 16)
        t[2] = (t[2] + t[3]) & m
        t[1] = self.re(t[1] ^ t[2], 12)
        t[0] = (t[0] + t[1]) & m
        t[3] = self.re(t[3] ^ t[0], 8)
        t[2] = (t[2] + t[3]) & m
        t[1] = self.re(t[1] ^ t[2], 7)

    def gr(self, t):
        m = 0xFFFFFFFF
        e = [1779033703, 3144134277, 1013904242, 2773480762]
        be, lt, dr, lr, hr = 512, 511, 2, 2654435761, 2246822519
        for i in t:
            e[0] = (e[0] + i) & m
            e[0] = self.re(e[0], 7)
            self.ye(e)
        for _ in range(8):
            self.ye(e)
        r = [0] * be
        for i in range(be):
            self.ye(e)
            r[i] = (e[0] ^ e[2]) & m
        for i in range(dr):
            for s in range(be):
                a = r[s] & lt
                c = (r[s] + r[a]) & m
                c = self.re(c, 13)
                c = (c ^ ((r[(s + 1) & lt] * lr) & m)) & m
                r[s] = c
                e[0] = (e[0] ^ c) & m
                self.ye(e)
        n = [0] * 8
        o = int(be / 8)
        for i in range(8):
            self.ye(e)
            s = e[0]
            a = i * o
            for c in range(o):
                d = r[a + c]
                s = (s + d) & m
                s = self.re(s, 5)
                s = (s ^ ((d * hr) & m)) & m
            n[i] = (s ^ e[2]) & m
        return n

    @staticmethod
    def wr(t):
        e = 0
        for n in t:
            if n == 0:
                e += 32
                continue
            return e + (32 - n.bit_length())
        return e

    def er(self, t, e, r=90.0):
        if e <= 0:
            return '0'
        start = time.time()
        s = 0
        t += ':'
        while True:
            for _ in range(16384):
                d = self.gr((t + str(s)).encode('ascii'))
                if self.wr(d) >= e:
                    return str(s)
                s += 1
            if time.time() - start > r:
                return None

    def fp(self, x, y, z):
        v_id = hexlify(urandom(x)).decode()
        d_id = hexlify(urandom(x)).decode()
        ctime = int(time.time())
        t_data = {
            'viewer_id': v_id,
            'device_id': d_id,
            'confidence': round(uniform(y, z), 2),
            'iat': ctime,
            'exp': ctime + 600
        }
        
        def b64url_strip(s):
            return base64.urlsafe_b64encode(s.encode()).decode().rstrip('=')
            
        t_bdata = b64url_strip(json.dumps(t_data))
        t_sig = base64.urlsafe_b64encode(sha256(t_bdata.encode()).digest()).decode().rstrip('=')
        token = '{0}.{1}'.format(t_bdata, t_sig)
        t_data.update({'token': token})
        t_data.pop('iat')
        t_data.pop('exp')
        return {'fingerprint': t_data}


def ft(e):
    t = e.replace('-', '+').replace('_', '/')
    if len(t) % 4 != 0:
        t += '=' * (-len(t) % 4)
    r = base64.b64decode(t)
    return r

def xn(e, v):
    if v:
        v = int(v)
        e = [e[v - 1], e[len(e) - v]]
    t = list(map(ft, e))
    return b''.join(t)