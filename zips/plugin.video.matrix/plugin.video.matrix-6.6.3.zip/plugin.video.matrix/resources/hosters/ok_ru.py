# -*- coding: utf-8 -*-
import json
import requests
import re

from resources.lib.parser import cParser
from resources.hosters.hoster import iHoster
from resources.lib.comaddon import dialog, VSlog
from resources.lib.util import cUtil
from resources.lib import random_ua

UA = random_ua.get_pc_ua()

class cHoster(iHoster):
    def __init__(self):
        iHoster.__init__(self, 'ok_ru', 'Ok.ru')

    def getHostAndIdFromUrl(self, sUrl):
        sPattern = r'https*:\/\/.*?((?:(?:ok)|(?:odnoklassniki))\.ru)\/.+?\/([0-9]+)'
        oParser = cParser()
        aResult = oParser.parse(sUrl, sPattern)
        if aResult[0]:
            return aResult[1][0]
        return ''

    def _getMetadata(self, media_id):
        """Try metadata API first, fallback to embed if needed"""
        url = "http://www.ok.ru/dk?cmd=videoPlayerMetadata"
        data = {'mid': media_id}
        headers = {'User-Agent': UA}
        resp = requests.post(url, data=data, headers=headers)
        json_data = resp.json()

        if 'error' in json_data:
            if "notFound" in json_data['error']:
                # fallback to embed
                return self._getEmbed(media_id)
            else:
                return None
        return json_data

    def _getEmbed(self, media_id):
        url = f"http://www.ok.ru/videoembed/{media_id}"
        resp = requests.get(url, headers={'User-Agent': UA})
        html = resp.text
        match = re.search(r'data-options="({[^"]+})"', html)
        if match:
            json_data = json.loads(match.group(1).replace('&quot;', '"').replace('&amp;', '&'))
            metadata = json_data.get("flashvars", {}).get("metadata")
            if metadata:
                return json.loads(metadata)
        return None

    def _getMediaLinkForGuest(self, autoPlay=False):
        VSlog(self._url)
        v = self.getHostAndIdFromUrl(self._url)
        if not v:
            return False, False, None
        sHost, sId = v
        meta = self._getMetadata(sId)
        if not meta:
            return False, False, None

        resolutions = {
            "ultra": "2160",
            "quad": "1440",
            "full": "1080",
            "hd": "720",
            "sd": "480",
            "low": "360",
            "lowest": "240",
            "mobile": "144"
        }

        urls, qua = [], []
        subtitles = {}

        # collect video URLs
        if 'videos' in meta and len(meta['videos']) > 0:
            for entry in meta['videos']:
                res_name = entry['name']
                res_val = resolutions.get(res_name.lower(), res_name)
                urls.append(entry['url'])
                qua.append(f"{res_val}p" if res_val.isdigit() else res_val)
        elif 'hlsMasterPlaylistUrl' in meta:
            urls.append(meta['hlsMasterPlaylistUrl'])
            qua.append("HLS Stream")

        # collect subtitles if present
        if 'movie' in meta and 'subtitleTracks' in meta['movie']:
            for sub in meta['movie']['subtitleTracks']:
                if 'url' in sub and 'language' in sub:
                    suburl = 'https:' + sub['url'] if sub['url'].startswith('//') else sub['url']
                    subtitles[sub['language']] = suburl + '|User-Agent=' + UA

        if urls:
            api_call = dialog().VSselectqual(qua, urls)
            if api_call:
                api_call = api_call + '|Referer=' + self._url
                return True, api_call, subtitles if subtitles else None

        return False, False, None
