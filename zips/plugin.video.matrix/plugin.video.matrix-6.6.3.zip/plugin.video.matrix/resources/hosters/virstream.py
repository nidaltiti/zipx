﻿from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.hosters.hoster import iHoster
from resources.lib.packer import cPacker
from resources.lib.util import urlHostName
from resources.lib.comaddon import VSlog

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0"

class cHoster(iHoster):

    def __init__(self):
        iHoster.__init__(self, 'virstream', 'VirStream')
			
    def isDownloadable(self):
        return True

    def _getMediaLinkForGuest(self, autoPlay = False):
        VSlog(self._url)
        api_call = ''

        if '|Referer=' in self._url:
            sReferer = self._url.split('|Referer=')[1]
            self._url = self._url.split('|Referer=')[0]
        else:
            sReferer = f'https://{urlHostName(self._url)}/'

        oRequest = cRequestHandler(self._url)
        oRequest.addHeaderEntry('Accept-Language', 'en-US,en;q=0.9')
        oRequest.addHeaderEntry('User-Agent', UA)
        sHtmlContent = oRequest.request()
        oParser = cParser()
       
        sPattern = r"(eval\(function\(p,a,c,k,e,d\)[\s\S]+?\)\s*<\/script>)"
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            data = aResult[1][0]
            if ' < /script>' in data or ' </script>' in data:
                data = data.replace(' < /script>', '').replace(' </script>', '')

            sHtmlContent2 = cPacker().unpack(data)

            sPattern = r'file:"([^"]+)",type:"hls"'
            aResult = oParser.parse(sHtmlContent2, sPattern)
            if aResult[0]:
                api_call = aResult[1][0]

        if api_call:
            return True, f'{api_call}|User-Agent={UA}&Referer={sReferer}&Origin=https://{urlHostName(self._url)}&Connection=keep-alive&Accept-Language=en-US,en;q=0.9'

        return False, False