﻿# -*- coding: utf-8 -*-

import base64
import hmac
import hashlib
import json
import time
import os
import requests
from io import BytesIO
from Cryptodome.PublicKey import ECC, RSA
from Cryptodome.Signature import DSS
from Cryptodome.Hash import SHA256
from Cryptodome.Cipher import AES, PKCS1_v1_5
from resources.lib.parser import cParser
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, addon, siteManager
from resources.sites.akwam import showHosters as showAkwam
from resources.lib.util import cUtil, urlHostName

UA = "okhttp/5.0.0-alpha.6"

SITE_IDENTIFIER = 'egybest'
SITE_NAME = 'EgyBest'
SITE_DESC = 'arabic vod'

BASE_URL = "https://hrrejhp.com/mycimaa/public"
URL_MAIN = f'{BASE_URL}/api/'
M_EXT = 'p2lbgWkFrykA4QyUmpHihzmc5BNzIABq'
RESPONSE_SECRET = "EgyAppWatch_Enc_2026_xJ9Lp3Nq8RwV"

class EgyPlexAPIClient:
    def __init__(self, base_url: str, device_id: str = "android_6d0a86aced0d91f4"):
        self.base_url = base_url.rstrip("/")
        self.device_id = device_id
        self.app_id = "Egybest-mobile"
        self.platform = "android"

        # Generate local secp256r1 (p-256) key pair
        self.private_key = ECC.generate(curve='p256')
        self.public_key = self.private_key.public_key()

        # Fixed values captured once (from Frida)
        self.movie  = "0f681655261f9ca2fa86d0a07f696a0e119f0ec756f9709ab192f7cdd8699445 | /data/app/.../base.apk"
        self.hach   = "da595165ce372248ca2af3d346934d99744415740b8df6bf1c2dfd1d2de4c653|/data/app/.../base.apk"
        self.sizato = "59085785|/data/app/.../base.apk"
        self.apk_path = "/data/app/.../base.apk"

        self.session = requests.Session()
        self._registered = False
        self.firebase_token = self.generate_firebase_header()

    def generate_nonce(self) -> str:
        random_bytes = os.urandom(32)
        nonce = base64.b64encode(random_bytes).decode("utf-8")
        return nonce.rstrip("=")

    def compute_mp4File(self, nonce: str) -> str:
        sha256_hash = hashlib.sha256()
        sha256_hash.update(nonce.encode("utf-8"))
        sel_hash = sha256_hash.hexdigest()
        return f"{sel_hash}+{self.apk_path}"

    def rsa_encrypt_base64(self, data: str) -> str:
        pub_key_b64 = (
            "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvNZEb1gdnJDyj5WxFpsEjK0bwejd"
            "HmyV+9IzrnVGcGbsaDGjuHgQB4L1+Ch8ZLFSm2pWPCBBjbbRBkyuEonXdqOZLdxlotTDyxej"
            "di7/qDYkXwckgiYCBuRW4OR+DZa7scMPdOuBjYW4fe7IdDswfM94C0WjX1cYEH9AjIwk4Xh5"
            "9ov7EpncgTwlPC7Ri915MdO+6+edOg7VwBOhhFGk+IXG8GUEm68Dy7N4Hg1ElNifCP5t9SG"
            "/PETqiDS+Pad9cmWrQb7ylTt/mhoVppj9tOOto9lDsyAr3CD87Y2Nkl4IWygOpKiUsWfjg"
            "3fRrsthzNHV2kX6CQLudy1AIHa8twIDAQAB"
        )
        key_bytes = base64.b64decode(pub_key_b64)
        rsa_key = RSA.import_key(key_bytes)
        cipher = PKCS1_v1_5.new(rsa_key)

        data_bytes = data.encode("utf-8")
        out = BytesIO()
        for i in range(0, len(data_bytes), 245):
            out.write(cipher.encrypt(data_bytes[i:i+245]))
        return base64.b64encode(out.getvalue()).decode("utf-8")

    def generate_firebase_header(self) -> str:
        nonce = self.generate_nonce()
        mp4File = self.compute_mp4File(nonce)

        json_header = {
            "pkg": "com.egyappwatch",
            "version": "25.7.1",
            "version_code": "23",
            "m3u8": "true",
            "movie": self.movie,
            "mp4File": mp4File,
            "hach": self.hach,
            "sizato": self.sizato,
            "player": "not installed",
            "UserData": "false",
            "DataData": "false"
        }

        json_string = json.dumps(json_header, separators=(",", ":"))
        return self.rsa_encrypt_base64(json_string)


    def get_public_key_pem(self) -> str:
        # Export public key to X.509 SubjectPublicKeyInfo PEM format
        return self.public_key.export_key(format='PEM')

    def register_device(self):
        if self._registered:
            return
        try:
            start_url = f"{self.base_url}/api/security/register/start"
            res = self.session.post(start_url)
            if not res.ok:
                return
            
            data = res.json()
            registration_id = data.get("registration_id")
            
            finish_url = f"{self.base_url}/api/security/register/finish"
            payload = {
                "registration_id": registration_id,
                "app_version": "2.4",
                "device_id": self.device_id,
                "public_key": self.get_public_key_pem()
            }
            
            finish_res = self.session.post(finish_url, json=payload)
            if finish_res.ok:
                self._registered = True
        except Exception as e:
            pass

    def sign_payload(self, data_string: str) -> str:
        # Hash the string using SHA256 and sign via ECDSA (DSS)
        h = SHA256.new(data_string.encode('utf-8'))
        signer = DSS.new(self.private_key, 'fips-186-3')
        signature_bytes = signer.sign(h)
        return "ecdsa=" + base64.b64encode(signature_bytes).decode('utf-8')

    def get_signed_headers(self, endpoint: str) -> dict:
        return {
            "Accept": "application/json",
            "Accept-Encoding": "gzip",
            "Authorization": "Bearer AuHLIRR82MvrdTTeaQKUxdA7mlNuk0WD6NnX2ffpn0wqeMP5zwkCClOHClRIbCFf",
            "Connection": "Keep-Alive",
            "DataData": "dmlkZQ==",
            "Host": "hrrejhp.com",
            "packagename": "com.connectword.flechliv",
            "User-Agent": "EasyPlex (Android 11; Mi 5s; Xiaomi capricorn; en)",
        }
        if not self._registered:
            self.register_device()

        timestamp = str(int(time.time()))
        nonce_bytes = os.urandom(32)
        nonce = base64.b64encode(nonce_bytes).decode('utf-8').rstrip('=')

        canonical_path = f"/api/{endpoint.lstrip('/')}"
        string_to_sign = f"GET{canonical_path}{timestamp}{nonce}"
        signature = self.sign_payload(string_to_sign)

        return {
            "X-App-Id": self.app_id,
            "X-Device-Id": self.device_id,
            "X-Platform": self.platform,
            "X-Timestamp": timestamp,
            "X-Nonce": nonce,
            "X-Signature": signature,
            "X-Encrypt-Response": "1",
            "Accept": "application/json",
            "Firebase": self.firebase_token,
            "Authorization": "Bearer mobile_session_token_4db37cbc8bb2b37129dfa81c4bc734bf",
            "packagename": "com.egyappwatch",
            "User-Agent": "okhttp/5.0.0-alpha.6"
        }

# Initialize client instance
api_client = EgyPlexAPIClient(base_url=BASE_URL)

MOVIE_EN = (f'{URL_MAIN}networks/media/show/7093-vide-vide-vide-movie/{M_EXT}?page=1', 'showMovies')
MOVIE_AR = (f'{URL_MAIN}networks/media/show/7462-vide-vide-vide-movie/{M_EXT}?page=1', 'showMovies')
MOVIE_TURK = (f'{URL_MAIN}networks/media/show/7097-vide-vide-vide-movie/{M_EXT}?page=1', 'showMovies')
MOVIE_ASIAN = (f'{URL_MAIN}networks/media/show/7095-vide-vide-vide-movie/{M_EXT}?page=1', 'showMovies')
MOVIE_HI = (f'{URL_MAIN}networks/media/show/7096-vide-vide-vide-movie/{M_EXT}?page=1', 'showMovies')
MOVIE_DUBBED = (f'{URL_MAIN}genres/animes/all/{M_EXT}?page=1', 'showMovies')
ANIM_MOVIES = (f'{URL_MAIN}networks/media/show/7094-vide-vide-vide-movie/{M_EXT}?page=1', 'showMovies')
MOVIE_POP = (f'{URL_MAIN}genres/popularmovies/all/{M_EXT}?page=1', 'showMovies')

SERIE_EN = (f'{URL_MAIN}networks/media/show/7865-vide-vide-vide-serie/{M_EXT}?page=1', 'showSeries')
SERIE_ASIA = (f'{URL_MAIN}networks/media/show/7866-vide-vide-vide-serie/{M_EXT}?page=1', 'showSeries')
SERIE_AR = (f'{URL_MAIN}networks/media/show/7007-vide-vide-vide-serie/{M_EXT}?page=1', 'showSeries')
SERIE_TR = (f'{URL_MAIN}networks/media/show/7867-vide-vide-vide-serie/{M_EXT}?page=1', 'showSeries')
SERIE_HEND = (f'{URL_MAIN}networks/media/show/7868-vide-vide-vide-serie/{M_EXT}?page=1', 'showSeries')
REPLAYTV_NEWS = (f'{URL_MAIN}networks/media/show/7461-vide-vide-vide-serie/{M_EXT}?page=1', 'showSeries')
SERIE_NETFLIX = (f'{URL_MAIN}networks/media/show/213/{M_EXT}?page=1', 'showSeries')
RAMADAN_SERIES = (f'{URL_MAIN}networks/media/show/8618-vide-vide-vide-serie/{M_EXT}?page=1', 'showSeries')
SERIE_DUBBED = (f'{URL_MAIN}genres/latestanimes/all/{M_EXT}?page=1', 'showSeries')

ANIM_NEWS = (f'{URL_MAIN}networks/media/show/7869/{M_EXT}?page=1', 'showSeries')
DOC_SERIES = (f'{URL_MAIN}networks/media/show/213/{M_EXT}?page=1', 'showSeries')

URL_SEARCH = (f'{URL_MAIN}search/', 'showSeries')
URL_SEARCH_MOVIES = (f'{URL_MAIN}search/', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}search/', 'showSeries')
FUNCTION_SEARCH = 'showMovies'

def _decrypt_response(response_data):
    if not isinstance(response_data, dict) or not response_data.get('encrypted'):
        return response_data
    
    try:
        iv = base64.b64decode(response_data["iv"])
        tag = base64.b64decode(response_data["tag"])
        aad = base64.b64decode(response_data["aad"])
        ciphertext = base64.b64decode(response_data["ciphertext"])
        
        aad_decoded_str = aad.decode('utf-8', errors='ignore')
        aad_lines = aad_decoded_str.split('\n')
        
        timestamp = aad_lines[2] if len(aad_lines) >= 4 else "1787829382"
        nonce = aad_lines[3] if len(aad_lines) >= 4 else "7+kQT6kL35UDLG3cCWxZ6WD3uLfakinqC7TVBBkVEX8"
            
        session_id = ""
        key_material = f"easyplex-response-v1|{session_id}|{nonce}|{timestamp}"
        
        aes_key = hmac.new(
            RESPONSE_SECRET.encode('utf-8'),
            key_material.encode('utf-8'),
            hashlib.sha256
        ).digest()
        
        encrypted_payload = ciphertext + tag
        cipher = AES.new(aes_key, AES.MODE_GCM, nonce=iv)
        cipher.update(aad)
        plaintext_bytes = cipher.decrypt_and_verify(encrypted_payload[:-16], encrypted_payload[-16:])
        
        return json.loads(plaintext_bytes.decode('utf-8'))
    except Exception as e:
        VSlog(f'Decryption failed: {e}')
        return response_data

def request_json(url):
    try:
        parsed_path = url.split('/api/')[-1]
        headers = api_client.get_signed_headers(parsed_path)
        
        response = api_client.session.get(url, headers=headers)
        if response.ok:
            return response.json() # _decrypt_response(response.json())
    except Exception as e:
        VSlog(f'API Request failed: {e}')
    return {}

def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', RAMADAN_SERIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'رمضان', 'rmdn.png', oOutputParameterHandler) 

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام عربية', 'arab.png', oOutputParameterHandler)
  
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_ASIAN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أسيوية', 'asia.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_TURK[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام تركية', 'turk.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_HI[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام هندية', 'hend.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', ANIM_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام انيميشن', 'anim.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_ASIA[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أسيوية', 'asia.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_TR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات تركية', 'turk.png', oOutputParameterHandler)
     
    oOutputParameterHandler.addParameter('siteUrl', DOC_SERIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات وثائقية', 'doc.png', oOutputParameterHandler) 
        
    oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات انمي', 'anime.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_DUBBED[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات مدبلجة', 'mdblg.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', REPLAYTV_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'برامج تلفزيونية', 'brmg.png', oOutputParameterHandler) 

    oGui.setEndOfDirectory()
    
def showSearch():
    oGui = cGui()
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search/{sSearchText}/{M_EXT}'
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showSeriesSearch():
    oGui = cGui()
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search/{sSearchText}/{M_EXT}'
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return

def showMovies(sSearch = ''):
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    
    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    if M_EXT not in sUrl:
        sUrl = f'{sUrl}/{M_EXT}'

    sHtmlContent_Main = request_json(sUrl)
    sHtmlContent = sHtmlContent_Main.get('search') if sSearch else sHtmlContent_Main.get('data')

    if sHtmlContent:
        for aEntry in sHtmlContent:
            sType = aEntry.get('type')
            if sType == 'Serie':
                continue
            sTitle = aEntry.get('title') if aEntry.get('title') else aEntry.get('name', "")
            siteUrl = f'{URL_MAIN}media/detail/{aEntry.get("id")}/{M_EXT}'
            sThumb = aEntry.get('poster_path')
            sDesc = aEntry.get('overview') if aEntry.get('overview') else ''
            sYear = ''

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)

            oGui.addMovie(SITE_IDENTIFIER, 'showLink', sTitle.replace('مترجم',''), '', sThumb, sDesc, oOutputParameterHandler)

    if not sSearch:
        sNextPage = __checkForNextPage(sHtmlContent_Main)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
            oGui.setEndOfDirectory()

def showSeries(sSearch = ''):
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()

    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    if M_EXT not in sUrl:
        sUrl = f'{sUrl}/{M_EXT}'

    sHtmlContent_Main = request_json(sUrl)
    sHtmlContent = sHtmlContent_Main.get('search') if sSearch else sHtmlContent_Main.get('data')

    if sHtmlContent:
        for aEntry in sHtmlContent:
            sType = aEntry.get('type')
            if sType == 'Movie':
                continue
            sTitle = aEntry.get('title') if aEntry.get('title') else aEntry.get('name', "")
            siteUrl = f'{URL_MAIN}series/show/{aEntry.get("id")}/{M_EXT}'
            sThumb = aEntry.get('poster_path')
            sDesc = aEntry.get('overview') if aEntry.get('overview') else ''
            sYear = ''

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)
                
            oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle.replace('مترجم',''), '', sThumb, sDesc, oOutputParameterHandler)

    if not sSearch:
        sNextPage = __checkForNextPage(sHtmlContent_Main)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()
        
def showSeasons():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sDesc = oInputParameterHandler.getValue('sDesc')

    sHtmlContent = request_json(sUrl)

    if sHtmlContent and sHtmlContent.get('seasons'):
        for season in sHtmlContent.get('seasons', {}):
            sSeason = season.get('season_number','')
            season_id = season.get('id','')
            siteUrl = f'{URL_MAIN}series/season/{season_id}/{M_EXT}'
            sTitle = ("%s S%s") % (sMovieTitle, str(sSeason))      

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('season_id', season_id)
            oOutputParameterHandler.addParameter('sThumb', sThumb)

            oGui.addSeason(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)  

    oGui.setEndOfDirectory() 
  
def showEpisodes():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    season_id = oInputParameterHandler.getValue('season_id')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sDesc = oInputParameterHandler.getValue('sDesc')

    sHtmlContent = request_json(sUrl)
    if sHtmlContent:
        for episode in sHtmlContent['episodes']:
            episode_id = episode['episode_number']
            sTitle = ("%s E%s") % (sMovieTitle, str(episode_id))         
            sThumb_ep = episode.get('still_path', sThumb)

            oOutputParameterHandler.addParameter('siteUrl', sUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('season_id', season_id)
            oOutputParameterHandler.addParameter('episode_id', episode_id)
            oOutputParameterHandler.addParameter('sThumb', sThumb_ep)
            
            oGui.addEpisode(SITE_IDENTIFIER, 'showLink', sTitle, '', sThumb_ep, sDesc, oOutputParameterHandler)
       
    oGui.setEndOfDirectory() 
    
def showLink():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    season_id = oInputParameterHandler.getValue('season_id')
    episode_id = oInputParameterHandler.getValue('episode_id')

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'
    
    oParser = cParser()  
    sHtmlContent = request_json(sUrl)
    if sHtmlContent:
        if episode_id:
            for episode in sHtmlContent['episodes']:
                if str(episode['episode_number']) == str(episode_id):
                    sHtmlContent = episode['videos']
        else:
            sHtmlContent = sHtmlContent.get('videos', [])

        if isinstance(sHtmlContent, list):
            for aEntry in sHtmlContent:
                sHosterUrl = aEntry.get('link')
                if not sHosterUrl:
                    continue
   
                if 'fasel' in sHosterUrl or 'fasoul' in sHosterUrl: 
                    if 'm3u8' not in sHosterUrl:
                        from urllib.parse import urlparse, urlunparse
                        faselMain = siteManager().getUrlMain('faselhd')
                        sHosterUrl = urlunparse(urlparse(sHosterUrl)._replace(netloc=urlparse(faselMain).netloc))

                    oRequestHandler = cRequestHandler(sHosterUrl)
                    oRequestHandler.enableCache(False)
                    sHtmlContentStr = oRequestHandler.request()

                    sPattern = r'player_iframe.location.href = ["\']([^"\']+)["\'].+?</i>(.+?)</a>'
                    aResult = oParser.parse(sHtmlContentStr, sPattern) 
                    if aResult[0]:
                        for aSubEntry in aResult[1]:
                            sHosterUrl = aSubEntry[0]
                            sHoster = aSubEntry[1]
                            sTitle = f'{sMovieTitle} ({sHoster})'
                            if useDialog:
                                results.append((sHoster, sHosterUrl, 'faselhd'))
                            else:
                                oHoster = cHosterGui().getHoster('faselhd')
                                if oHoster:
                                    oHoster.setDisplayName(sTitle)
                                    oHoster.setFileName(sMovieTitle)
                                    cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

                elif 'ak.sv' in sHosterUrl:
                    oOutputParameterHandler = cOutputParameterHandler()
                    oOutputParameterHandler.addParameter('siteUrl', sHosterUrl)
                    oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
                    oOutputParameterHandler.addParameter('sThumb', sThumb)
                    oGui.addMovie(SITE_IDENTIFIER, 'showAkwam', f'{sMovieTitle} [COLOR gold] - Akwam[/COLOR]', '', sThumb, '', oOutputParameterHandler)

                elif any(x in sHosterUrl for x in ['akwam', 'animeiat', 'wecima', 'arabseed']):
                    try:
                        test_url = f'{BASE_URL}/test.php?api={sHosterUrl}'
                        oRequest = cRequestHandler(test_url)
                        oRequest.enableCache(False)
                        data = oRequest.request()
                        
                        sPattern = r'href="([^"]+)">\s*<quality>(.+?)</quality>' 
                        aResult = oParser.parse(data, sPattern)
                        if aResult[0]:
                            for aSubEntry in aResult[1]:
                                sHosterUrl = aSubEntry[0]
                                sHost = aSubEntry[1].upper()
                                sTitle = f'{sMovieTitle} ({sHost})'

                                if useDialog:
                                    results.append((sHost, sHosterUrl, 'Dummy'))
                                else:
                                    oHoster = cHosterGui().checkHoster(sHosterUrl)
                                    if oHoster:
                                        oHoster.setDisplayName(sTitle)
                                        oHoster.setFileName(sMovieTitle)
                                        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)  
                    except:
                        VSlog('Api Failed')

                else:
                    if useDialog:
                        results.append(('', sHosterUrl, 'Dummy'))
                    else:
                        import re
                        sQual_match = re.search(r'(\d{3,4}[pP])', sHosterUrl)
                        if sQual_match:
                            sQual = sQual_match.group(1).upper()
                        else:
                            sQual = 'HD' 

                        sDisplayTitle = f"{sMovieTitle} [{sQual}]" if sQual else sMovieTitle
                        oOutput = cOutputParameterHandler()
                        oOutput.addParameter('sHosterUrl', sHosterUrl)
                        oOutput.addParameter('siteUrl', sUrl)
                        oOutput.addParameter('sMovieTitle', sDisplayTitle)
                        oOutput.addParameter('sThumb', sThumb)
                        oGui.addLink(SITE_IDENTIFIER, 'showMegaLinks', sDisplayTitle, sThumb, sDisplayTitle, oOutput)
        

    if useDialog and results:
        fixedHoster = 'Dummy'
        for r in results:
            if len(r) == 3 and r[2] != 'Dummy':
                fixedHoster = r[2]
                break
        select_results = [(r[0], r[1]) for r in results]
        cHosterGui().selectHoster(select_results, sMovieTitle, SITE_NAME, sThumb, fixedHoster=fixedHoster)
    else:
        oGui.setEndOfDirectory() 

def showMegaLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sHosterUrl = oInputParameterHandler.getValue('sHosterUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sQual = oInputParameterHandler.getValue('sQual')
    sThumb = oInputParameterHandler.getValue('sThumb')

    if '.mp4' in sHosterUrl:
        oParser = cParser() 
        oRequestHandler = cRequestHandler(sHosterUrl)
        oRequestHandler.setTimeout(10)
        sHtmlContent = oRequestHandler.request()

        if '<iframe' in sHtmlContent:
            sPattern = r'<iframe[^>]+src="([^"]+)"'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0]:
                sHosterUrl = aResult[1][0] 
            oHoster = cHosterGui().getHoster('direct_link')
        else:
            oHoster = cHosterGui().checkHoster(sHosterUrl)

    else:
        oHoster = cHosterGui().checkHoster(sHosterUrl)
    if oHoster:
        oHoster.setDisplayName(sMovieTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()

def __checkForNextPage(sHtmlContent):
    if not isinstance(sHtmlContent, dict):
        return False
    return sHtmlContent.get('next_page_url', False)

def getUrl():
    oRequestHandler = cRequestHandler('https://chafcha.com/api_urls.json')
    sHtmlContent = request_json('https://chafcha.com/api_urls.json')
    if sHtmlContent:
        return sHtmlContent.get('backupApiUrl')
    return None