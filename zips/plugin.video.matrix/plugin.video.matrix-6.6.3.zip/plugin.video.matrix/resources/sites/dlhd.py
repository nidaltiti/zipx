# -*- coding: utf-8 -*-

import re
import base64
import ast
from urllib.parse import urlparse
import json
from resources.lib.comaddon import siteManager, isMatrix, VSlog
from resources.lib.gui.gui import cGui
from resources.lib.gui.hoster import cHosterGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.util import cUtil
from resources.lib.util import urlHostName

from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import unpad

SITE_IDENTIFIER = 'dlhd'
SITE_NAME = 'DaddyLiveHD'
SITE_DESC = 'Sports Events'
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

DOMAINS = urlHostName(URL_MAIN)
STD_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'

SPORT_GENRES = ('https://raw.githubusercontent.com/qwertyuiop8899/logo/main/daddyliveSchedule.json', 'showGenres')
SPORT_LIVE = ('https://raw.githubusercontent.com/qwertyuiop8899/logo/main/daddyliveSchedule.json', 'showGenres')
SPORT_TV = (f'{URL_MAIN}24-7-channels.php', 'showTV')


def load():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()

    oOutputParameterHandler.addParameter('siteUrl', SPORT_GENRES[0])
    oGui.addDir(SITE_IDENTIFIER, SPORT_GENRES[1], 'Sports (Genres)', 'genres.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SPORT_TV[0])
    oGui.addDir(SITE_IDENTIFIER, SPORT_TV[1], 'Channels 24/7', 'tv.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def showTV():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    
    try:
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('User-Agent', STD_AGENT)
        oRequestHandler.addHeaderEntry('Referer', "https://%s/" % DOMAINS)
        sHtmlContent = oRequestHandler.request()
        
        pattern = r'<a class="card"\s+href="([^"]+)".+?class="card__title">(.+?)</div>'
        matches = re.findall(pattern, sHtmlContent, re.DOTALL | re.IGNORECASE)
        
        for href, title in matches:
            title = title.strip()
            if "18+" in title:
                continue
                
            channel_id = href.split("=")[-1]           
            sDisplayTitle = "%s [CH-%s]" % (title, channel_id)
            
            oOutputParameterHandler.addParameter('siteUrl', str(channel_id))
            oOutputParameterHandler.addParameter('sMovieTitle', title)
            oOutputParameterHandler.addParameter('sDesc', sDisplayTitle)
            
            oGui.addLink(SITE_IDENTIFIER, 'showLink', sDisplayTitle, 'tv.png', title, oOutputParameterHandler)
            
    except Exception as e:
        pass

    oGui.setEndOfDirectory()


def showGenres():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    result = json.loads(sHtmlContent)

    sportGenre = {}
    bMatrix = isMatrix()
    for days in result:
        shows = result[days]
        for sTitle in shows:
            if 'Tv Show' in sTitle:
                continue
            
            if not bMatrix:
                sTitle = sTitle.decode('utf-8', 'ignore')

            emoji_pattern = re.compile(
                "["
                "\U0001F600-\U0001F64F"  # emoticons
                "\U0001F300-\U0001F5FF"  # symbols & pictographs
                "\U0001F680-\U0001F6FF"  # transport & map symbols
                "\U0001F700-\U0001F77F"  # alchemical symbols
                "\U0001F780-\U0001F7FF"  # geometric shapes extended
                "\U0001F800-\U0001F8FF"  # supplemental arrows
                "\U0001F900-\U0001F9FF"  # supplemental symbols & pictographs
                "\U0001FA00-\U0001FA6F"  # chess, symbols
                "\U0001FA70-\U0001FAFF"  # food, drink, activities
                "\U00002702-\U000027B0"  # dingbats
                "\U000024C2-\U0001F251"  # enclosed characters
                "]+",
                flags=re.UNICODE
            )

            sDisplayTitle = emoji_pattern.sub(r'', str(sTitle))
            sDisplayTitle = sDisplayTitle.replace('Soccer', 'Football')
            
            if sDisplayTitle in sportGenre:
                continue
            sportGenre[sDisplayTitle] = sTitle

    for sDisplayTitle, sTitle in sorted(sportGenre.items()):
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sDesc', sDisplayTitle)
        oGui.addMisc(SITE_IDENTIFIER, 'showMovies', sDisplayTitle, 'sport.png', '', sTitle, oOutputParameterHandler)

    oGui.setEndOfDirectory()


def showMovies():
    oGui = cGui()
    oUtil = cUtil()
    oOutputParameterHandler = cOutputParameterHandler()
    oInputParameterHandler = cInputParameterHandler()
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    result = json.loads(sHtmlContent)

    for days in result:
        shows = result[days]
        for showName in shows:
            if showName != sMovieTitle:
                continue

            show = shows[showName]
            for events in show:
                timeEvent = events['time']
                hours, minute = timeEvent.split(':')
                hours = (int(hours) + 1) % 24
                time = '%02d:%s' % (hours, minute)
                sTitle = events['event']
                sTitle = oUtil.formatUTF8(sTitle)
                
                sDisplayTitle = '%s - %s' % (time, sTitle)
                oOutputParameterHandler.addParameter('siteUrl', sUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sDesc', sDisplayTitle)
                oGui.addMisc(SITE_IDENTIFIER, 'showHoster', sDisplayTitle, 'sport.png', '', sTitle, oOutputParameterHandler)
                
    oGui.setEndOfDirectory()


def showHoster():
    oGui = cGui()
    oUtil = cUtil()
    oOutputParameterHandler = cOutputParameterHandler()
    oInputParameterHandler = cInputParameterHandler()
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()
    result = json.loads(sHtmlContent)

    for days in result:
        shows = result[days]
        for showName in shows:
            show = shows[showName]
            for events in show:
                timeEvent = events['time']
                eventName = events['event']
                eventName = oUtil.formatUTF8(eventName)
                
                if sMovieTitle != eventName:
                    continue

                hours, minute = timeEvent.split(':')
                hours = (int(hours) + 1) % 24
                time = '%02d:%s' % (hours, minute)
            
                for channel in events['channels']:
                    channelName = channel['channel_name']
                    channelId = channel['channel_id']
            
                    sDisplayTitle = '%s - %s [%s]' % (time, eventName[0:30], channelName)
                    oOutputParameterHandler.addParameter('siteUrl', str(channelId))
                    oOutputParameterHandler.addParameter('sMovieTitle', sDisplayTitle)
                    oOutputParameterHandler.addParameter('sDesc', eventName)
        
                    oGui.addLink(SITE_IDENTIFIER, 'showLink', sDisplayTitle, 'sport.png', eventName, oOutputParameterHandler)
            
    oGui.setEndOfDirectory()


def showLink():
    oGui = cGui()
    oHosterGui = cHosterGui()
    hosterDirectLink = oHosterGui.getHoster('direct_link')

    oInputParameterHandler = cInputParameterHandler()
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    channelId = oInputParameterHandler.getValue('siteUrl')

    page_url = "https://%s/stream/stream-%s.php" % (DOMAINS, channelId)
    page_referer = "https://%s/watch.php?id=%s" % (DOMAINS, channelId)
    
    try:
        oRequestHandler = cRequestHandler(page_url)
        oRequestHandler.addHeaderEntry('User-Agent', STD_AGENT)
        oRequestHandler.addHeaderEntry('Referer', page_referer)
        sHtmlContent = oRequestHandler.request()

        player_urls = []
        if btn_matches := re.findall(r'button[^>]*data-url=["\']([^"\']+)["\']', sHtmlContent, re.IGNORECASE):
            player_urls = btn_matches
        elif center_matches := re.findall(r'center\s*>\s*<a[^>]*href=["\']([^"\']+)["\']', sHtmlContent, re.IGNORECASE):
            player_urls = ["https://%s%s" % (DOMAINS, m) if m.startswith('/') else m for m in center_matches]
        else:
            player_urls = [page_url]

        if player_urls:
            target_player_url = player_urls[0]
            
            oReqPlayer = cRequestHandler(target_player_url)
            oReqPlayer.addHeaderEntry('User-Agent', STD_AGENT)
            oReqPlayer.addHeaderEntry('Referer', "https://%s/" % DOMAINS)
            sPlayerHtml = oReqPlayer.request()

            iframe_match = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', sPlayerHtml, re.IGNORECASE)

            if iframe_match:
                iframe = iframe_match.group(1)
                if iframe.startswith("//"):
                    iframe = "https:" + iframe
                elif iframe.startswith("/"):
                    iframe = "https://%s%s" % (DOMAINS, iframe)

                if "premiumtv" in iframe or "daddy" in iframe:
                    oReqCustom = cRequestHandler(iframe)
                    oReqCustom.addHeaderEntry('User-Agent', STD_AGENT)
                    oReqCustom.addHeaderEntry('Referer', URL_MAIN)
                    sCustomHtml = oReqCustom.request()

                    clappr_match = re.search(r'source:\s*(?:window\.)?atob\([\'"]([^\'"]+)[\'"]\)', sCustomHtml)
                    if clappr_match:
                        encoded_stream = clappr_match.group(1)
                        decoded_stream = base64.b64decode(encoded_stream).decode('utf-8')
                        
                        sUrl = "%s|Referer=%s" % (decoded_stream, iframe)
                        
                        hosterDirectLink.setDisplayName(sMovieTitle)
                        hosterDirectLink.setFileName(sMovieTitle)
                        oHosterGui.showHoster(oGui, hosterDirectLink, sUrl, '')
                        oGui.setEndOfDirectory()
                        return

                if '-embed' in iframe:
                    hdrs = {
                    "Content-Type": "application/json",
                    "Origin": f"https://{urlHostName(iframe)}",
                    "Referer": f"https://{urlHostName(iframe)}/",
                    "Sec-Fetch-Dest": "empty",
                    "Sec-Fetch-Mode": "cors",
                    "Sec-Fetch-Site": "cross-site",
                    "User-Agent": STD_AGENT
                    }
                    oParser = cParser()    
                    oRequestHandler = cRequestHandler(iframe)
                    oRequestHandler.enableCache(False)
                    for key, value in hdrs.items():
                        oRequestHandler.addHeaderEntry(key, value)
                    sHtmlContent = oRequestHandler.request()

                    sPattern = r'streamUrl = "(https.+?\.m3u8)["\']'
                    aResult = oParser.parse(sHtmlContent, sPattern)
                    if aResult[0]:
                        sHosterUrl = aResult[1][0]
                        sUrl = "%s|Referer=%s" % (sHosterUrl, iframe)
                        
                        hosterDirectLink.setDisplayName(sMovieTitle)
                        hosterDirectLink.setFileName(sMovieTitle)
                        oHosterGui.showHoster(oGui, hosterDirectLink, sUrl, '')
                        oGui.setEndOfDirectory()
                        return
                    else:
                        sPattern = r'STREAM_URL = "(https.+?\.m3u8)["\']'
                        aResult = oParser.parse(sHtmlContent, sPattern)
                        if aResult[0]:
                            sHosterUrl = aResult[1][0]
                            sUrl = "%s|Referer=%s" % (sHosterUrl, iframe)
                            
                            hosterDirectLink.setDisplayName(sMovieTitle)
                            hosterDirectLink.setFileName(sMovieTitle)
                            oHosterGui.showHoster(oGui, hosterDirectLink, sUrl, '')
                            oGui.setEndOfDirectory()
                            return

                oReqIframe = cRequestHandler(iframe)
                oReqIframe.addHeaderEntry('User-Agent', STD_AGENT)
                oReqIframe.addHeaderEntry('Referer', "https://%s/" % DOMAINS)
                sIframeContent = oReqIframe.request()

                if "wikisport" in iframe or "lovecdn" in iframe:
                    nested_match = re.search(r'iframe.*src="(.+?)"', sIframeContent)
                    if nested_match:
                        iframe = nested_match.group(1)
                        if iframe.startswith("//"): iframe = "https:" + iframe
                        oReqIframe = cRequestHandler(iframe)
                        oReqIframe.addHeaderEntry('Referer', iframe)
                        sIframeContent = oReqIframe.request()

                sUrl = ""

                # CASE 1: Const CHANNEL_KEY Decryption Mapping
                if "CHANNEL_KEY" in sIframeContent:
                    key_m = re.search(r'const CHANNEL_KEY\s*=\s*"([^"]+)"', sIframeContent)
                    token_m = re.search(r'const AUTH_TOKEN\s*=\s*"([^"]+)"', sIframeContent)
                    if key_m and token_m:
                        channel_key = key_m.group(1)
                        auth_token = token_m.group(1)
                        netloc = urlparse(iframe).netloc
                        
                        lookup_url = "https://%s/server_lookup.js?channel_id=%s" % (netloc, channel_key)
                        oReqLookup = cRequestHandler(lookup_url)
                        oReqLookup.addHeaderEntry('Authorization', 'Bearer %s' % auth_token)
                        oReqLookup.addHeaderEntry('X-Channel-Key', channel_key)
                        oReqLookup.addHeaderEntry('Referer', iframe)
                        
                        lookup_data = json.loads(oReqLookup.request())
                        server_key = lookup_data.get('server_key')
                        if server_key == "top1/cdn":
                            sUrl = "https://top1.giokko.ru/top1/cdn/%s/mono.m3u8" % channel_key
                        else:
                            sUrl = "https://%snew.giokko.ru/%s/%s/mono.m3u8" % (server_key, server_key, channel_key)

                # CASE 2: Hex escaped Eval string unpackers
                elif "eval('\\x0a" in sIframeContent:
                    eval_m = re.search(r"eval\('(\\x0a.+)'\)", sIframeContent)
                    if eval_m:
                        info = base64.b16decode(eval_m.group(1).replace("\\x", "").upper()).decode('utf-8', 'ignore')
                        s_match = re.search(r'(?:let|const) streamURL = "(.*)"', info)
                        if s_match: sUrl = s_match.group(1)

                # CASE 3: Atob Base64 string decode
                elif "atob('Y29uc3" in sIframeContent:
                    atob_m = re.search(r"atob\('(Y29uc3.+?)'", sIframeContent)
                    if atob_m:
                        player_info = base64.b64decode(atob_m.group(1)).decode('utf-8')
                        init_url_m = re.search(r'const initUrl.*=.*"(.+?)";', player_info)
                        if init_url_m:
                            oReqInit = cRequestHandler(init_url_m.group(1))
                            sUrl = base64.b64decode(oReqInit.request().strip()).decode('utf-8')

                # CASE 4: Vidembed AES decrypt wrapper 
                elif "vidembed" in iframe:
                    body_class_m = re.search(r'<body[^>]+class=["\']([^"\']+)["\']', sIframeContent, re.IGNORECASE)
                    if body_class_m:
                        aes_iv = body_class_m.group(1).split()[0].replace("container-", "")
                        parsed = urlparse(iframe)
                        origin = "https://www.%s" % parsed.netloc
                        stream_id = [p for p in parsed.path.split("/") if p][-1]
                        
                        import requests
                        r_source = requests.post(
                            "%s/api/source/%s" % (origin, stream_id),
                            params={"type": "live"},
                            json={"d": "www.%s" % parsed.netloc, "r": "%s/stream/%s" % (origin, stream_id)},
                            headers={"Referer": origin + "/", "Origin": origin},
                            timeout=5, verify=False
                        ).json()
                        
                        aes = AES.new(base64.b64decode("W8o/hbp+p0s/jftdRQXDyQ=="), AES.MODE_CBC, iv=base64.b64decode(aes_iv))
                        decrypted = aes.decrypt(base64.b64decode(r_source["player"]))
                        info = json.loads(unpad(decrypted, 16).decode("utf-8"))
                        sUrl = info["source_file"]

                # CASE 5: ZHD CDN dynamic token extraction
                elif "zhdcdn" in iframe:
                    src_m = re.search(r'iframe src="(.+?)"', sIframeContent)
                    if src_m:
                        zhd_frame = src_m.group(1).replace("'+encodeURIComponent(document.referrer)+'", "https://%s/" % DOMAINS)
                        if zhd_frame.startswith("//"): zhd_frame = "https:" + zhd_frame
                        oReqZhd = cRequestHandler(zhd_frame)
                        oReqZhd.addHeaderEntry('Referer', zhd_frame)
                        sZhdHtml = oReqZhd.request()
                        crf_m = re.search(r'id="crf__" value=\'(.+?)\'', sZhdHtml)
                        if crf_m:
                            sUrl = base64.b64decode(crf_m.group(1)).decode('utf-8')

                # CASE 6: Packed byte loops offset sequence matching
                elif "function" in sIframeContent and "base64" in sIframeContent:
                    mo = re.search(r'([a-zA-Z0-9_]+=\[(?:\[\d+,".+?"\],?)+])', sIframeContent)
                    var_m = re.search(r"var .=(.+?)\(\)\+(.+?)\(\);", sIframeContent)
                    if mo and var_m:
                        num1 = int(re.search(r"function " + var_m.group(1) + r"\(\)\{return (\d+);\}", sIframeContent).group(1))
                        num2 = int(re.search(r"function " + var_m.group(2) + r"\(\)\{return (\d+);\}", sIframeContent).group(1))
                        total_offset = num1 + num2
                        vals = sorted(re.findall(r'\[(\d+),"(.+?)"\],?', mo.group(1)), key=lambda x: int(x[0]))
                        sUrl = bytes(map(lambda x: int(re.sub(r"\D", "", base64.b64decode(x[1]).decode("utf-8"))) - total_offset, vals)).decode("utf-8")

                # CASE 7: JavaScript joined multi-array lists
                elif 'fid="' in sIframeContent and 'embed.js"' in sIframeContent:
                    f_m = re.search(r'fid="(.+?)".+src=\"(.+?)\/embed\.js"', sIframeContent)
                    if f_m:
                        origin = "https:" + f_m.group(2) if f_m.group(2).startswith("//") else f_m.group(2)
                        oReqJs = cRequestHandler("%s/embed.php?player=desktop&live=%s" % (origin, f_m.group(1)))
                        oReqJs.addHeaderEntry('Referer', iframe)
                        sJsCode = oReqJs.request()
                        arr_m = re.search(r'return\((\["h","t".+?\])', sJsCode)
                        if arr_m:
                            sUrl = "".join(ast.literal_eval(arr_m.group(1))).replace("\\", "").replace("////", "//")

                # CASE 8: Direct fallback fmp4 token stream urls
                elif "embed.html?token=" in iframe:
                    sUrl = iframe.replace("/embed.html", "/index.fmp4.m3u8")

                if sUrl:
                    if "|" not in sUrl:
                        sUrl += '|User-Agent=%s&Referer=https://%s/' % (STD_AGENT, urlparse(iframe).netloc)
                    
                    hosterDirectLink.setDisplayName(sMovieTitle)
                    hosterDirectLink.setFileName(sMovieTitle)
                    oHosterGui.showHoster(oGui, hosterDirectLink, sUrl, '')

    except Exception:
        pass

    oGui.setEndOfDirectory()