﻿# -*- coding: utf-8 -*-
import time
import re
from datetime import datetime
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.parser import cParser
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, siteManager, addon
from resources.lib.util import urlHostName

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0"

SITE_IDENTIFIER = 'majedkoora'
SITE_NAME = 'Majed-Koora'
SITE_DESC = 'sports vod'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

SPORT_LIVE = (f'{URL_MAIN}api/v1/matches?lang=ar', 'showMatches')

def load():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()    
    oOutputParameterHandler.addParameter('siteUrl', SPORT_LIVE[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMatches', 'بث مباشر', 'foot.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showMatches():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    today_date = datetime.today().strftime("%Y-%m-%d")
    sUrl = f'{sUrl}&date={today_date}&scope=all'

    HEADERS = {
        "Accept": "application/json",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive",
        "Host": urlHostName(sUrl),
        "Referer": URL_MAIN,
        "User-Agent": UA
    }

    oRequestHandler = cRequestHandler(sUrl)
    for key, value in HEADERS.items():
        oRequestHandler.addHeaderEntry(key, value)
    try:
        sHtmlContent = oRequestHandler.request(jsonDecode=True)

        matches = sHtmlContent.get("matches", [])
        for match in matches:
            oOutputParameterHandler = cOutputParameterHandler()

            home = match.get("home_team", {}).get("name", "")
            away = match.get("away_team", {}).get("name", "")
            home_score = match.get("home_team", {}).get("score", 0)
            away_score = match.get("away_team", {}).get("score", 0)

            sTitle = f"{home} ({home_score}) vs {away} ({away_score})"
            siteUrl = sUrl
            if match.get("watch_ready"):
                siteUrl = match.get("watch_url", sUrl)

            mStatus = match.get("state_text") or match.get("state") or ""
            if match.get("state") == "live":
                sTitle = f'{sTitle} [COLOR red]● مباشر[/COLOR]'

            # Logo handling with URL_Main
            sThumb = match.get("home_team", {}).get("logo") or match.get("away_team", {}).get("logo") or "foot.png"
            if sThumb and not str(sThumb).startswith("http"):
                sThumb = f"{URL_MAIN.rstrip('/')}{sThumb}"

            commentator = match.get("broadcast", {}).get("commentator") or "تعليق عربي"
            channel = match.get("broadcast", {}).get("channel") or "غير متوفر"
            tournament = match.get("tournament", {}).get("name", "")
            stadium = match.get("stadium") or "غير محدد"

            # Base description
            sDesc = (
                f'[COLOR orange]وقت المباراة:[/COLOR] {match.get("time")} | '
                f'[COLOR orange]حالة البث:[/COLOR] {mStatus}\n'
                f'[COLOR orange]المعلق:[/COLOR] {commentator} | '
                f'[COLOR orange]القناة:[/COLOR] {channel}\n'
                f'[COLOR orange]البطولة:[/COLOR] {tournament}\n'
                f'[COLOR orange]الملعب:[/COLOR] {stadium}'
            )

            # Streams handling
            if not match.get("watch_ready"):
                sDesc += "\n\n[COLOR red]البث غير متاح حالياً[/COLOR]"

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)

            oGui.addMisc(SITE_IDENTIFIER, 'showLinks', sTitle, 'foot.png', sThumb, sDesc, oOutputParameterHandler)

    except:
        oGui.addText(SITE_IDENTIFIER, '[COLOR orange] تعذر الاتصال بالموقع [/COLOR]', 'none.png')

    oGui.setEndOfDirectory()  

def showLinks():
    oGui = cGui()
    from resources.lib import helpers

    oInputParameterHandler = cInputParameterHandler()
    apiUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    HEADERS = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive",
        "Host": urlHostName(apiUrl),
        "Referer": URL_MAIN,
        "User-Agent": UA
    }

    oRequestHandler = cRequestHandler(apiUrl)
    for key, value in HEADERS.items():
        oRequestHandler.addHeaderEntry(key, value)
    sHtmlContent = oRequestHandler.request()

    from urllib.parse import urlparse, parse_qs
    parsed_url = urlparse(apiUrl)
    query_params = parse_qs(parsed_url.query)
    mk_value = query_params.get('mk', [None])[0]
    nUrl = f'{URL_MAIN}api/public/watch-card?key={mk_value}'

    HEADERS = {
        "Accept": "application/json",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive",
        "Host": urlHostName(URL_MAIN),
        "Referer": f'https://{urlHostName(apiUrl)}/',
        "User-Agent": UA
    }

    oRequestHandler = cRequestHandler(nUrl)
    for key, value in HEADERS.items():
        oRequestHandler.addHeaderEntry(key, value)
    data = oRequestHandler.request(jsonDecode=True)

    sStreams = data.get("watch", {}).get("servers", [])
    results = []
    for server in sStreams:
        VSlog(server)
        server_name = server.get("name")
        sHosterUrl = server.get("url")

        if not sHosterUrl:
            continue

        HEADERS = {
            "Accept-Language": "en-US,en;q=0.9",
            "Connection": "keep-alive",
            "Host": urlHostName(sHosterUrl),
            "Origin": f"https://{urlHostName(apiUrl)}",
            "User-Agent": UA
        }

        if '?channel=' in sHosterUrl or '&channel=' in sHosterUrl:
            VSlog(f"Processing encrypted stream for server: {server_name}")
            try:
                headers = {
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Connection": "keep-alive",
                    "Host": urlHostName(sHosterUrl),
                    "User-Agent": UA
                }
                oRequest = cRequestHandler(sHosterUrl)
                for key, value in headers.items():
                    oRequest.addHeaderEntry(key, value)
                page = oRequest.request()

                oParser = cParser()
                sPattern = r'name="majed-player-authorization" content="([^"]+)"'
                aResult = oParser.parse(page, sPattern)
                if aResult[0]:
                    sAuth = aResult[1][0] 
                sApi = f'https://{urlHostName(sHosterUrl)}/api/stream.php?id={sHosterUrl.split("channel=")[-1]}'

                oRequest = cRequestHandler(sApi)
                for key, value in headers.items():
                    oRequest.addHeaderEntry(key, value)
                oRequest.addHeaderEntry('X-Player-Authorization', sAuth)
                page = oRequest.request(jsonDecode=True)

                iv = base64url_decode(page["iv"])
                tag = base64url_decode(page["tag"])
                ciphertext = base64url_decode(page["data"])

                import hashlib, json
                from Cryptodome.Cipher import AES

                key_input = f"majed-player-stream-v1|{sAuth}".encode('utf-8')
                secret_key = hashlib.sha256(key_input).digest()

                cipher = AES.new(secret_key, AES.MODE_GCM, nonce=iv)
                cipher.update(b"majed-player-stream-v1")

                decrypted_bytes = cipher.decrypt_and_verify(ciphertext, tag)
                page = json.loads(decrypted_bytes.decode('utf-8'))

                hdrs = {
                    "Connection": "keep-alive",
                    "Origin": f"https://{urlHostName(sHosterUrl)}",
                    "User-Agent": UA
                }

                sHosterUrl = page.get("url", sHosterUrl) + helpers.append_headers(hdrs)
            except:
                sHosterUrl = sHosterUrl + helpers.append_headers(HEADERS)

        if 'good' in sHosterUrl:
            try:
                stream_key_match = re.search(r'\?(\d+)', sHosterUrl)
                stream_key = stream_key_match.group(1) if stream_key_match else None

                sApi = f'https://{urlHostName(sHosterUrl)}/api/player?src={stream_key}'
    
                oRequest = cRequestHandler(sApi)
                oRequest.addHeaderEntry('User-Agent', UA)
                oRequest.addHeaderEntry('Referer', sHosterUrl)
                page = oRequest.request(jsonDecode=True)

                sHosterUrl = page.get("sources", {}).get("master")
            except:
                sHosterUrl = sHosterUrl + helpers.append_headers(HEADERS)
        if sHosterUrl.endswith("/iframe"):
            sHosterUrl = sHosterUrl.replace('/iframe', '/manifest/video.m3u8')

        sHosterUrl = sHosterUrl
        results.append((f'{sMovieTitle} - {server_name}', sHosterUrl))

    useDialog = addon().getSetting('HosterDialog') == 'true'
    if useDialog:
        for title, url in results:
            results.append((SITE_NAME, url, 'direct_link'))
    else:
        for title, url in results:
            if '.m3u8' in url or '.css' in url and 'ok.ru' not in url:
                oHoster = cHosterGui().getHoster('direct_link')
            else:
                oHoster = cHosterGui().checkHoster(url)
            if oHoster:
                oHoster.setDisplayName(title)
                oHoster.setFileName(title)
                cHosterGui().showHoster(oGui, oHoster, url, sThumb)

    oGui.setEndOfDirectory()  

def showHosters():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sHosterUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oHoster = cHosterGui().checkHoster(sHosterUrl)
    if oHoster:
        oHoster.setDisplayName(sMovieTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()

def base64url_decode(data: str) -> bytes:
    import base64
    """Decodes a Base64URL string with required padding."""
    padding = '=' * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)