﻿# -*- coding: utf-8 -*-

import base64
import re
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, VSlog, siteManager, addon
from resources.lib.parser import cParser
from resources.lib.util import cUtil
from resources.lib import random_ua

UA = random_ua.get_phone_ua()

SITE_IDENTIFIER = 'brstej'
SITE_NAME = 'Brstej'
SITE_DESC = 'arabic vod'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

MOVIE_AR = ('عربية', 'showMoviesLists')
MOVIE_TURK = ('تركية', 'showMoviesLists')
MOVIE_HI = ('هندية', 'showMoviesLists')

RAMADAN_SERIES = ('رمضان', 'showSeriesLists')
SERIE_AR = ('عربية', 'showSeriesLists')
SERIE_EN = ('اجنبية', 'showSeriesLists')
SERIE_TR = ('تركية', 'showSeriesLists')
SERIE_ASIA = ('اسيوية', 'showSeriesLists')

ANIM_NEWS = ('انمي', 'showSeriesLists')

URL_SEARCH = (f'{URL_MAIN}search.php?keywords=', 'showSeries')
URL_SEARCH_MOVIES = (f'{URL_MAIN}search.php?keywords=', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}search.php?keywords=', 'showSeries')
FUNCTION_SEARCH = 'showSearch'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', RAMADAN_SERIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesLists', 'رمضان', 'rmdn.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_TURK[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMoviesLists', 'أفلام تركية', 'turk.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMoviesLists', 'أفلام عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_HI[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMoviesLists', 'أفلام هندية', 'hend.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesLists', 'مسلسلات عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesLists', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_ASIA[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesLists', 'مسلسلات أسيوية', 'asia.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_TR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesLists', 'مسلسلات تركية', 'turk.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesLists', 'مسلسلات انمي', 'anime.png', oOutputParameterHandler)  

    oGui.setEndOfDirectory()
 
def showSeriesSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search.php?keywords={sSearchText}'
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search.php?keywords=فيلم+{sSearchText}'
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return

def showMoviesLists():
    oGui = cGui()

    oParser = cParser()
    oInputParameterHandler = cInputParameterHandler()
    sCat = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(f'{URL_MAIN}/ind6')
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Connection', 'keep-alive')
    oRequestHandler.addHeaderEntry('Accept', '*/*')
    sHtmlContent = oRequestHandler.request()

    sPattern = r'<a href="([^"]+)".+?class="sub_ca">(.+?)</a>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            if 'افلام' not in aEntry[1]:
                continue
            
            if sCat in aEntry[1]:
                sUrl = aEntry[0]
                sTitle = aEntry[1].replace('<b>','').replace('</b>','')
                oOutputParameterHandler.addParameter('siteUrl', sUrl) 
                oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'film.png', oOutputParameterHandler)
 
    oGui.setEndOfDirectory()

def showMovies(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
        sPattern = r'<article class="prs-card">.+?<img src="([^"]+)".+?href="([^"]+)">(.+?)</a></h3>'
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        sPattern = r'<article class="pmc-card">.+?img src="([^"]+)".+?href="([^"]+)">(.+?)</a></h3>'

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Connection', 'keep-alive')
    oRequestHandler.addHeaderEntry('Accept', '*/*')
    sHtmlContent = oRequestHandler.request()
    
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0] :
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            if "مسلسل"  in aEntry[2]:
                continue
            if "حلقة"  in aEntry[2]:
                continue
            
            sTitle = cUtil().CleanMovieName(aEntry[2])
            siteUrl = aEntry[1].replace("watch.php","play.php")
            sDesc = ""
            sThumb = aEntry[0]
            if sThumb.startswith('/'):
                sThumb = URL_MAIN + sThumb
            sYear = ''
            m = re.search(r'([0-9]{4})', sTitle)
            if m:
                sYear = str(m.group(0))

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)

            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

        progress_.VSclose(progress_)
 
    if not sSearch:
        oGui.setEndOfDirectory()

def showSeriesLists():
    oGui = cGui()

    oParser = cParser()
    oInputParameterHandler = cInputParameterHandler()
    sCat = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(f'{URL_MAIN}/ind6')
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Connection', 'keep-alive')
    oRequestHandler.addHeaderEntry('Accept', '*/*')
    sHtmlContent = oRequestHandler.request()

    sStart = '<div class="navslide-header">'
    sEnd = '<div class="navslide-divider">'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'<a href="([^"]+)".+?class="sub_ca">(.+?)</a>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            if 'مسلسلات' not in aEntry[1]:
                continue
            
            if 'عربية' == sCat:
                    if sCat in aEntry[1] or 'شامية' in aEntry[1] or 'خليجية ' in aEntry[1] or 'مصرية' in  aEntry[1]:
                        sUrl = aEntry[0]
                        sTitle = aEntry[1].replace('<b>','').replace('</b>','')
                        oOutputParameterHandler.addParameter('siteUrl', sUrl) 
                        oGui.addDir(SITE_IDENTIFIER, 'showSeries', sTitle, 'mslsl.png', oOutputParameterHandler)
            else:
                if sCat in aEntry[1]:
                    sUrl = aEntry[0]
                    sTitle = aEntry[1].replace('<b>','').replace('</b>','')
                    oOutputParameterHandler.addParameter('siteUrl', sUrl) 
                    oGui.addDir(SITE_IDENTIFIER, 'showSeries', sTitle, 'mslsl.png', oOutputParameterHandler)
 
    oGui.setEndOfDirectory()

def showSeries(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
        sPattern = r'<article class="prs-card">.+?<img src="([^"]+)".+?href="([^"]+)">(.+?)</a></h3>'
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
    
    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Connection', 'keep-alive')
    oRequestHandler.addHeaderEntry('Accept', '*/*')
    sHtmlContent = oRequestHandler.request()

    sPattern = r'<div class="thumbnail.+?<a href="([^"]+)"\s*title="([^"]+)".+?img src="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    itemList = []	
    if aResult[0] :
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            if sSearch:
                if "فيلم" in aEntry[2] or "فلم" in aEntry[2]:
                    continue
                sTitle = cUtil().CleanSeriesName(aEntry[2])
                siteUrl = aEntry[1]
                sDesc = ""
                sThumb = aEntry[0]
                if sThumb.startswith('/'):
                    sThumb = URL_MAIN + sThumb
                sYear = ''
                m = re.search(r'([0-9]{4})', sTitle)
                if m:
                    sYear = str(m.group(0))
            else:
                if "فيلم" in aEntry[1] or "فلم"  in aEntry[1]:
                    continue

                siteUrl = aEntry[0]           
                sTitle = cUtil().CleanSeriesName(aEntry[1])
                sThumb = aEntry[2]
                if sThumb.startswith('/'):
                    sThumb = URL_MAIN + sThumb
                sDesc = ''
                sYear = ''
                m = re.search(r'([0-9]{4})', sTitle)
                if m:
                    sYear = str(m.group(0))

            if sTitle not in itemList:
                itemList.append(sTitle)				
                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sYear', sYear)
                oOutputParameterHandler.addParameter('sThumb', sThumb)

                oGui.addTV(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
 
        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

        progress_.VSclose(progress_)
        
    if not sSearch:
        oGui.setEndOfDirectory()
	
def __checkForNextPage(sHtmlContent):
    oParser = cParser()
    sPattern = r'<li class="active">\s*<a href="#".+?<a href="([^"]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0] :     
        return URL_MAIN+aResult[1][0]

    sPattern = r'aria-current="page">.*?</a><a href="([^"]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0] :     
        return aResult[1][0]

    return False
	
def showEpisodes():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Connection', 'keep-alive')
    oRequestHandler.addHeaderEntry('Accept', '*/*')
    sHtmlContent = oRequestHandler.request()

    sPattern = r'<div class="pwr-season-panel"[^>]*>\s*<h3 class="pwr-season-fallback">([^<]+)</h3>(.*?)</div>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:
            sSeasonName = aEntry[0].strip()
            
            season_num_match = re.search(r'\d+', sSeasonName)
            sSeason = f"S{season_num_match.group(0)}" if season_num_match else "S1"
            
            sPanelContent = aEntry[1]

            sEpPattern = r'href="([^"]+)"[^>]*title="([^"]+)"[^>]*>\s*<strong>(\d+)</strong>'
            aEpResult = oParser.parse(sPanelContent, sEpPattern)
            if aEpResult[0]:
                for aEpEntry in aEpResult[1]:
                    epUrl = aEpEntry[0]
                    if not epUrl.startswith('http'):
                        siteUrl = f'{URL_MAIN}{epUrl}'
                    else:
                        siteUrl = epUrl
                        
                    siteUrl = siteUrl.replace("watch.php", "play.php")
                    
                    epNum = aEpEntry[2]
                    sTitle = f'{sMovieTitle} {sSeason} E{epNum}'
            
                    oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                    oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                    oOutputParameterHandler.addParameter('sThumb', sThumb)
                    oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, '', oOutputParameterHandler)    
       
    oGui.setEndOfDirectory()

def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Connection', 'keep-alive')
    oRequestHandler.addHeaderEntry('Accept', '*/*')
    sHtmlContent = oRequestHandler.request()

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    sPattern = r'data-embed-url=["\']([^"\']+)["\']'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0] :
        for aEntry in aResult[1]:
            
            sHosterUrl = aEntry
            if sHosterUrl.startswith('//'):
                sHosterUrl = f'http:{sHosterUrl}'

            if 'watch.php?id=' in sHosterUrl:
                try:
                    oRequestHandler = cRequestHandler(sHosterUrl)
                    oRequestHandler.addHeaderEntry('User-Agent', UA)
                    oRequestHandler.addHeaderEntry('Connection', 'keep-alive')
                    oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
                    sHtmlContent0 = oRequestHandler.request()

                    sPattern = r'"use strict";(.+?)</script>'
                    aResult = oParser.parse(sHtmlContent0, sPattern)	
                    if aResult[0] :
                        for aEntry in aResult[1]:
                            js_code = aEntry

                            sHtmlContent1 = decodeHtml(js_code)
                            
                            from resources.lib.packer import cPacker
                            sHtmlContent2 = cPacker().unpack(sHtmlContent1)
                            
                            sPattern = r'const manifest="([^"]+)"'
                            aResult = oParser.parse(sHtmlContent2, sPattern)	
                            if aResult[0] :
                                for aEntry in aResult[1]:
                                    sHosterUrl = aEntry
                except Exception as e:
                    continue

            if 'bit.ly' in sHosterUrl:
                oRequestHandler = cRequestHandler(sHosterUrl)
                sRequestContent = oRequestHandler.request()
                sHosterUrl = oRequestHandler.getRealUrl()

            results.append((SITE_NAME, sHosterUrl))

    else:
        sPattern = r'<iframe src=["\']([^"\']+)["\']'
        aResult = oParser.parse(sHtmlContent, sPattern)	
        if aResult[0] :
            for aEntry in aResult[1]:
            
                sHosterUrl = aEntry
                if sHosterUrl.startswith('//'):
                    sHosterUrl = 'http:' + sHosterUrl

                if 'bit.ly' in sHosterUrl:
                    oRequestHandler = cRequestHandler(sHosterUrl)
                    sHosterUrl = oRequestHandler.getRealUrl()

                results.append((SITE_NAME, sHosterUrl))

    if useDialog and results:
        cHosterGui().selectHoster(results, sMovieTitle, SITE_NAME, sThumb)
    else:
        for sTitle, sHosterUrl in results:
            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

        oGui.setEndOfDirectory()

def decodeHtml(js_code):

    _A_match = re.search(r'var _A=\[(.*?)\];', js_code, re.S)
    _O_match = re.search(r'var _O=(\d+);', js_code)
    _K_match = re.search(r'var _K="([^"]+)";', js_code)

    _A_raw = _A_match.group(1)
    _A = re.findall(r'"([^"]+)"', _A_raw)

    _O = int(_O_match.group(1))
    _S = "".join(_A)
    _O %= len(_S)
    _K = _K_match.group(1)

    _U = _S[-_O:] + _S[:-_O]
    _C = "".join(ch for ch in _U if ch.isalnum() or ch in "+/=")

    _B = base64.b64decode(_C)
    _KB = base64.b64decode(_K)

    _arr = bytearray(len(_B))
    for i in range(len(_B)):
        _arr[i] = (_B[i] ^ _KB[i % len(_KB)]) & 0xFF

    try:
        decoded = _arr.decode("utf-8")
    except UnicodeDecodeError:
        decoded = _arr.decode("latin1")

    match = re.search(r'(eval\(.*\))', decoded, re.S)
    if match:
        eval_part = match.group(1)
        if ';if(false)':
            eval_part = eval_part.split(';if(false)')[0]

        return eval_part
