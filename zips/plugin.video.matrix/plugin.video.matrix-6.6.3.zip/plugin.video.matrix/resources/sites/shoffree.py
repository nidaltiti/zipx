﻿# -*- coding: utf-8 -*-

import base64
import re
import urllib
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, VSlog, siteManager, addon
from resources.lib.parser import cParser
from resources.lib.util import cUtil, urlHostName
from resources.lib import random_ua

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0"

SITE_IDENTIFIER = 'shoffree'
SITE_NAME = 'Shoffree'
SITE_DESC = 'arabic vod'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

MOVIE_EN = (f'{URL_MAIN}movies?language=en&sort_by=latest', 'showMovies')
MOVIE_AR = (f'{URL_MAIN}movies?language=ar&sort_by=latest', 'showMovies')
MOVIE_HI = (f'{URL_MAIN}movies?language=hi&sort_by=latest', 'showMovies')
MOVIE_ASIAN = (f'{URL_MAIN}movies?language=ko&sort_by=latest', 'showMovies')
MOVIE_TURK = (f'{URL_MAIN}movies?language=tr&sort_by=latest', 'showMovies')
KID_MOVIES = (f'{URL_MAIN}movies?genre=14&sort_by=latest', 'showMovies')
MOVIE_GENRES = (True, 'moviesGenres')
MOVIE_ANNEES = (f'{URL_MAIN}movies', 'showYears')

RAMADAN_SERIES = (f'{URL_MAIN}ramadan', 'showSeries')
SERIE_EN = (f'{URL_MAIN}series?language=en&sort_by=latest', 'showSeries')
SERIE_AR = (f'{URL_MAIN}series?language=ar&sort_by=latest', 'showSeries')
SERIE_TR = (f'{URL_MAIN}series?language=tr&sort_by=latest', 'showSeries')
SERIE_HEND = (f'{URL_MAIN}series?language=hi&sort_by=latest', 'showSeries')
SERIE_ASIA = (f'{URL_MAIN}series?language=ko&sort_by=latest', 'showSeries')
SERIE_GENRES = (True, 'seriesGenres')
SERIE_ANNEES = (f'{URL_MAIN}series', 'showSerieYears')

ANIM_NEWS = (f'{URL_MAIN}series?genre=40', 'showSeries')
ANIM_MOVIES = (f'{URL_MAIN}movies?genre=40', 'showMovies')

URL_SEARCH = (f'{URL_MAIN}search?query=', 'showMovies')
URL_SEARCH_MOVIES = (f'{URL_MAIN}search?category=movies&query=', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}search?category=series&query=', 'showSeries')
URL_SEARCH_ANIMS = (f'{URL_MAIN}search?category=anime&query=', 'showSeries')
FUNCTION_SEARCH = 'showMovies'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', RAMADAN_SERIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'رمضان', 'rmdn.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_ASIAN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أسيوية', 'asia.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_TURK[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام تركية', 'turk.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_HI[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام هندية', 'hend.png', oOutputParameterHandler) 
 
    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام كرتون', 'crtoon.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_ASIA[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أسيوية', 'asia.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_TR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات تركية', 'turk.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_HEND[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات هندية', 'hend.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', ANIM_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'افلام انمي', 'anime.png', oOutputParameterHandler)
  
    oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات انمي', 'anime.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_GENRES[0])
    oGui.addDir(SITE_IDENTIFIER, SERIE_GENRES[1], 'المسلسلات (الأنواع)', 'mslsl.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_GENRES[0])
    oGui.addDir(SITE_IDENTIFIER, MOVIE_GENRES[1], 'الأفلام (الأنواع)', 'film.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}movies')
    oGui.addDir(SITE_IDENTIFIER, 'showYears', 'أفلام (بالسنوات)', 'annees.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}series')
    oGui.addDir(SITE_IDENTIFIER, 'showSerieYears', 'مسلسلات (بالسنوات)', 'annees.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}movies')
    oGui.addDir(SITE_IDENTIFIER, 'showLang', 'أفلام (حسب اللغة)', 'film.png', oOutputParameterHandler)	

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}series')
    oGui.addDir(SITE_IDENTIFIER, 'showSerieLang', 'مسلسلات (حسب اللغة)', 'mslsl.png', oOutputParameterHandler)	

    oGui.setEndOfDirectory()

def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText is not False:
        sUrl = f'{URL_MAIN}search?category=movies&query={sSearchText}'
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showSeriesSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText is not False:
        sUrl = f'{URL_MAIN}search?category=series&query={sSearchText}'
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return

def showYears():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser()
    oRequestHandler = cRequestHandler(URL_MAIN)
    sHtmlContent = oRequestHandler.request()

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'data-year="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in reversed(aResult[1]):
 
            sYear = aEntry
            oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}movies?year={sYear}') 
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', sYear, 'annees.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSerieYears():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser()
    oRequestHandler = cRequestHandler(URL_MAIN)
    sHtmlContent = oRequestHandler.request()

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'data-year="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in reversed(aResult[1]):
 
            sYear = aEntry
            oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}series?year={sYear}') 
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', sYear, 'annees.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showLang():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser()
    oRequestHandler = cRequestHandler(URL_MAIN)
    sHtmlContent = oRequestHandler.request()

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = '<option>كل اللغات</option> '
    sEnd = '</select>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'<option value="([^"]+)">([^<]+)</option>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
 
            sYear = aEntry[0]
            sTitle = aEntry[1]
            oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}movies?language={sYear}') 
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'annees.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSerieLang():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser()
    oRequestHandler = cRequestHandler(URL_MAIN)
    sHtmlContent = oRequestHandler.request()

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = '<option>كل اللغات</option> '
    sEnd = '</select>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'<option value="([^"]+)">([^<]+)</option>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
 
            sYear = aEntry
            oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}series?lang={sYear}') 
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', sYear, 'annees.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def seriesGenres():
    oGui = cGui()

    liste = []
    liste.append(['اكشن', f'{URL_MAIN}series?genre=8'])
    liste.append(['انيميشن', f'{URL_MAIN}series?genre=14'])
    liste.append(['مغامرات', f'{URL_MAIN}series?genre=12'])
    liste.append(['غموض', f'{URL_MAIN}series?genre=7'])
    liste.append(['تاريخي', f'{URL_MAIN}series?genre=28'])
    liste.append(['كوميديا', f'{URL_MAIN}series?genre=16'])
    liste.append(['موسيقى', f'{URL_MAIN}series?genre=20'])
    liste.append(['رياضي', f'{URL_MAIN}series?genre=25'])
    liste.append(['دراما', f'{URL_MAIN}series?genre=6'])
    liste.append(['رعب', f'{URL_MAIN}series?genre=9'])
    liste.append(['عائلى', f'{URL_MAIN}series?genre=15'])
    liste.append(['فانتازيا', f'{URL_MAIN}series?genre=38'])
    liste.append(['حروب', f'{URL_MAIN}series?genre=36'])
    liste.append(['الجريمة', f'{URL_MAIN}series?genre=17'])
    liste.append(['رومانسى', f'{URL_MAIN}series?genre=5'])
    liste.append(['خيال علمى', f'{URL_MAIN}series?genre=13'])
    liste.append(['اثارة', f'{URL_MAIN}series?genre=11'])
    liste.append(['وثائقى', f'{URL_MAIN}series?genre=19'])

    for sTitle, sUrl in liste:

        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oGui.addDir(SITE_IDENTIFIER, 'showSeries', sTitle, 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def moviesGenres():
    oGui = cGui()

    liste = []
    liste.append(['اكشن', f'{URL_MAIN}movies?genre=8'])
    liste.append(['انيميشن', f'{URL_MAIN}movies?genre=14'])
    liste.append(['مغامرات', f'{URL_MAIN}movies?genre=12'])
    liste.append(['غموض', f'{URL_MAIN}movies?genre=7'])
    liste.append(['تاريخي', f'{URL_MAIN}movies?genre=28'])
    liste.append(['كوميديا', f'{URL_MAIN}movies?genre=16'])
    liste.append(['موسيقى', f'{URL_MAIN}movies?genre=20'])
    liste.append(['رياضي', f'{URL_MAIN}movies?genre=25'])
    liste.append(['دراما', f'{URL_MAIN}movies?genre=6'])
    liste.append(['رعب', f'{URL_MAIN}movies?genre=9'])
    liste.append(['عائلى', f'{URL_MAIN}movies?genre=15'])
    liste.append(['فانتازيا', f'{URL_MAIN}movies?genre=38'])
    liste.append(['حروب', f'{URL_MAIN}movies?genre=36'])
    liste.append(['الجريمة', f'{URL_MAIN}movies?genre=17'])
    liste.append(['رومانسى', f'{URL_MAIN}movies?genre=5'])
    liste.append(['خيال علمى', f'{URL_MAIN}movies?genre=13'])
    liste.append(['اثارة', f'{URL_MAIN}movies?genre=11'])
    liste.append(['وثائقى', f'{URL_MAIN}movies?genre=19'])

    for sTitle, sUrl in liste:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()	

def showMovies(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        sPattern = r'<article class="video-card .+?<a href="([^"]+)"\s+title="([^"]+)".+?img src="([^"]+)"\s+alt='

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    if sSearch:
        sStart = 'id="results">'
        sEnd = '</main'
        sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)
        sPattern = r'<a\s+href="([^"]+)" rel class=".*?" title="([^"]+)">\s+<img\s+src="([^"]+)"\s+alt='

    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0] is True:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            if 'serie/' in aEntry[0] or 'episode/' in aEntry[0]:
                continue 

            sTitle = cUtil().CleanMovieName(aEntry[1])
            siteUrl = aEntry[0]
            sThumb = aEntry[2].replace('/w342','/w500')
            sDesc = ''
            sYear = ''
            m = re.search(r'([0-9]{4})', sTitle)
            if m:
               sYear = str(m.group(0))

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)
			
            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
        sNextPage = __checkForNextPage(sHtmlContent, sUrl)
        if sNextPage != False:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
 
    if not sSearch:
        oGui.setEndOfDirectory()
 
def showSeries(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        sPattern = r'<article class="video-card .+?<a href="([^"]+)"\s+title="([^"]+)".+?img src="([^"]+)"\s+alt='

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    if sSearch:
        sStart = 'id="results">'
        sEnd = '</main'
        sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)
        sPattern = r'<a\s+href="([^"]+)" rel class=".*?" title="([^"]+)">\s+<img\s+src="([^"]+)"\s+alt='

    aResult = oParser.parse(sHtmlContent, sPattern)
    itemList = []		
    if aResult[0] is True:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            if 'movie/' in aEntry[0]:
                continue 
 
            sTitle = cUtil().CleanSeriesName(aEntry[1])
            siteUrl = aEntry[0]
            sThumb = aEntry[2].replace('/w342','/w500')
            sDesc = ''

            if sTitle not in itemList:
                itemList.append(sTitle)	
                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sDesc', sDesc)
                oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)

        sNextPage = __checkForNextPage(sHtmlContent, sUrl)
        if sNextPage != False:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
 
    if not sSearch:
        oGui.setEndOfDirectory()
 
def showSeasons():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    oParser = cParser()
 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sMovieTitle = re.sub(r"S\d{2}|S\d", "", sMovieTitle)
    sStart = '<div id="seasons-area"'
    sEnd = '</button></div>'
    sHtmlContent1 = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'<a href="([^"]+)".+?img src="([^"]+)".+?class="s-year">(.+?)</span>'
    aResult = oParser.parse(sHtmlContent1, sPattern) 
    if aResult[0] is True:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            sTitle = (cUtil().ConvertSeasons(aEntry[2])).replace("-"," ")
            sTitle = f'{sMovieTitle} {sTitle}'
            siteUrl = aEntry[0]
            sThumb = aEntry[1].replace('/w342','/w500')
            sDesc = ""

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sMovieUrl', sUrl)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oGui.addSeason(SITE_IDENTIFIER, 'showEps', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    else:
        sPattern = r'<a class="sku" href="(.+?)">(.+?)<em>(.+?)</em>'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0] is True:
            oOutputParameterHandler = cOutputParameterHandler() 
            for aEntry in aResult[1]:

                sTitle = f'{sMovieTitle} E{aEntry[2].replace(" ","")}'
                siteUrl = aEntry[0]
                sThumb = sThumb
                sDesc = ''
                sHost = ''

                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sHost', sHost)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
 
                oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    oGui.setEndOfDirectory() 
 
def showEps():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = '<div id="episodes-area"'
    sEnd = '</button></div>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'href="([^"]+)".+?img src="([^"]+)".+?class="ep-title-label">(.+?)</span>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0] is True:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:

            sTitle = f'{sMovieTitle} E{aEntry[2].replace("الحلقة ","")}'
            siteUrl = aEntry[0]
            sThumb = aEntry[1].replace('/w342','/w500')
            sDesc = ''
            sHost = ''

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sHost', sHost)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
 
            oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
       
    oGui.setEndOfDirectory() 
 
def __checkForNextPage(sHtmlContent, sUrl):
    oParser = cParser()
    sPattern = r'<link\s+rel="next"\s+href="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        return f'{sUrl}&{aResult[1][0]}'

    return False

def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    from urllib.parse import urlparse
    try:
        parsed = urlparse(sUrl)
        sParts = parsed.path.strip("/").split("/")
        watch_url = f'https://{urlHostName(sUrl)}/streem/watch/serie/{sParts[1]}/{sParts[3]}'
        api_url = f'https://{urlHostName(sUrl)}/streem/sources/serie/{sParts[1]}/{sParts[3]}'
    except:
        watch_url = f'https://{urlHostName(sUrl)}/streem/watch/movie/{sParts[1]}'
        api_url = f'https://{urlHostName(sUrl)}/streem/sources/movie/{sParts[1]}'

    oParser = cParser()
    oRequestHandler = cRequestHandler(watch_url)
    oRequestHandler.addHeaderEntry('Accept', 'application/json, text/javascript, */*; q=0.01')
    oRequestHandler.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Referer', watch_url)
    sHtmlContent = oRequestHandler.request()
    cook = oRequestHandler.GetCookies()

    sPattern = r'\}\)\("([^"]+)",\s*"([^"]+)"\);'
    aResult = oParser.parse(sHtmlContent,sPattern)
    if aResult[0]:
        for aEntry in aResult[1]:
            key = aEntry[0]
            payload = aEntry[1]
            sHtmlContent1 = decode_payload(key, payload)

            sPattern = r'const KEY\s*=\s*[\'"]([^\'"]+)[\'"]'
            aResult = oParser.parse(sHtmlContent1,sPattern)
            if aResult[0]:
                mkey = aResult[1][0] 

                for sServer in ['1', '2', '3', '4']:
                    oRequestHandler = cRequestHandler(api_url)
                    oRequestHandler.addHeaderEntry('Accept', 'application/json, text/javascript, */*; q=0.01')
                    oRequestHandler.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
                    oRequestHandler.addHeaderEntry('User-Agent', UA)
                    oRequestHandler.addHeaderEntry('Referer', watch_url)
                    oRequestHandler.addHeaderEntry('Origin', f'https://{urlHostName(sUrl)}')
                    oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
                    oRequestHandler.addHeaderEntry('Cookie', cook)
                    oRequestHandler.addParameters('key', mkey)
                    oRequestHandler.addParameters('server', sServer)
                    oRequestHandler.setRequestType(1)
                    sHtmlContent = oRequestHandler.request(jsonDecode=True)

                    sPattern = r"'Referer':\s*([^,}\]]+)"
                    aResult = oParser.parse(sHtmlContent, sPattern)
                    if aResult[0]:
                        for aEntry in aResult[1]:
                            sReferer = aEntry

                    sPattern = r"'file':\s*'([^']+)'"
                    aResult = oParser.parse(sHtmlContent, sPattern)
                    if aResult[0]:
                        for aEntry in aResult[1]:
                            url = aEntry
                            if url.endswith("/"):
                                url = url[:-1]
                            if '?url' in url:
                                url = url.split('?url=')[1]
                            
                            else:
                                sHosterUrl = url

                            if sReferer != 'False':
                                sHosterUrl = f'{sHosterUrl}|Referer={sReferer}'

                            results.append((SITE_NAME, sHosterUrl, 'direct_link'))

    if useDialog and results:
        if any(len(r) == 3 for r in results):
            for r in results:
                fixedHoster = r[2]
            select_results = [(r[0], r[1]) for r in results]
            cHosterGui().selectHoster(select_results, sMovieTitle, SITE_NAME, sThumb, fixedHoster=fixedHoster)
    else:
        for sTitle, sHosterUrl, sHosterType in results:
            oHoster = cHosterGui().getHoster(sHosterType)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

        oGui.setEndOfDirectory()

def xor(a, b):
    return a ^ b

def mod(a, b):
    return a % b

def hex_to_dec(s):
    return int(s, 16)

def decrypt(data, pwd):
    output = []
    hex_pairs = [data[i:i+2] for i in range(0, len(data), 2)]
    for i, pair in enumerate(hex_pairs):
        char_byte = hex_to_dec(pair)
        key_char = ord(pwd[mod(i, len(pwd))])
        output.append(chr(xor(char_byte, key_char)))
    return ''.join(output)

def decode_payload(key, payload):
    base64_data = decrypt(payload, key)
    decoded_bytes = base64.b64decode(base64_data)
    final_html = urllib.parse.unquote(decoded_bytes.decode("latin1"))
    return final_html