# -*- coding: utf-8 -*-

from resources.lib.parser import cParser
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.comaddon import progress, addon, VSlog, siteManager
import re

SITE_IDENTIFIER = 'primewire'
SITE_NAME = 'PrimeWire'
SITE_DESC = 'english vod'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

MOVIE_EN = (f'{URL_MAIN}filter?sort=Featured&type=movie', 'showMovies')
KID_MOVIES = (f'{URL_MAIN}filter?genre%5B%5D=Animation&type=movie', 'showMovies')
MOVIE_POP = (f'{URL_MAIN}filter?sort=Trending+Today&type=movie', 'showMovies')
MOVIE_GENRES = (f'{URL_MAIN}movies', 'showGenreMovie')

SERIE_EN = (f'sSearch=', 'showSeries')
ANIM_NEWS = (f'sSearch=', 'showSeries')

URL_SEARCH_MOVIES = ('', 'showMovies')
URL_SEARCH_SERIES = ('', 'showSeries')
FUNCTION_SEARCH = 'showMovies'

def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'search/movie')
    oGui.addDir(SITE_IDENTIFIER, 'showSearchMovie', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'search/tv')
    oGui.addDir(SITE_IDENTIFIER, 'showSearchSerie', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام انيميشن', 'anim.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_POP[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام رائجة', 'pop.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}movies')
    oGui.addDir(SITE_IDENTIFIER, 'showGenreSeries', 'المسلسلات (تصنيفات)', 'genres.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}tv')
    oGui.addDir(SITE_IDENTIFIER, 'showGenreMovie', 'الافلام (تصنيفات)', 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSearchMovie():
    oGui = cGui()

    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        showMovies(sSearchText.replace(' ', '+'))
        oGui.setEndOfDirectory()
        return

def showSearchSerie():
    oGui = cGui()

    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        showSeries(sSearchText.replace(' ', '+'))
        oGui.setEndOfDirectory()
        return

def showGenreMovie():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'class="genre-filter.+?value="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:

            sTitle = aEntry
            sGenres = f'{URL_MAIN}filter?genre%5B%5D={aEntry}&type=movie'
            oOutputParameterHandler.addParameter('siteUrl', sGenres) 
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showGenreSeries():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'class="genre-filter.+?value="([^"]+)">'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:

            sTitle = aEntry
            sGenres = f'{URL_MAIN}filter?genre%5B%5D={aEntry}&type=tv'
            oOutputParameterHandler.addParameter('siteUrl', sGenres) 
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', sTitle, 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showMovies(sSearch=''):
    oGui = cGui()
    if sSearch:
        sUrl = f'{URL_MAIN}filter?s={sSearch}&ds={generate_pw_search_key(sSearch)}'
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        if 'sSearch=' in sUrl:
            sSearch = sUrl.split("sSearch=")[1]
            sUrl = f'{URL_MAIN}filter?s={sSearch}&ds={generate_pw_search_key(sSearch)}'

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'<div class="index_item.+?href="([^"]+)"\s+title="([^"]+)".+?src="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            if "/tv/"  in aEntry[0]:
                continue

            sTitle = aEntry[1]
            pattern = r"/movie/(\d+)"
            match = re.search(pattern, aEntry[0])
            if match:
                movie_id = match.group(1)
            siteUrl = f'{URL_MAIN}api/v1/s?s_id={movie_id}&type=movie'
            sThumb = f'{URL_MAIN[:-1]}{aEntry[2]}'
            sDesc = ''
            sYear = ''
            m = re.search(r'([0-9]{4})', sTitle)
            if m:
                sYear = str(m.group(0))

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)
            oOutputParameterHandler.addParameter('sType', 'movie')

            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    sPattern = r'<a class="" href="([^"]+)">(.+?)</a>'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:

            sTitle = f'[COLOR red]Page: {aEntry[1]}[/COLOR]'
            siteUrl = f'{URL_MAIN[:-1]}{aEntry[0]}'
            sThumb = ""

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
        
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'next.png', oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()

def showSeries(sSearch=''):
    oGui = cGui()
    if sSearch:
        sUrl = f'{URL_MAIN}filter?s={sSearch}&ds={generate_pw_search_key(sSearch)}'
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')
        if 'sSearch=' in sUrl:
            sSearch = sUrl.split("sSearch=")[1]
            sUrl = f'{URL_MAIN}filter?s={sSearch}&ds={generate_pw_search_key(sSearch)}'
    
    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'<div class="index_item.+?href="([^"]+)"\s+title="([^"]+)".+?src="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            if "/movie/"  in aEntry[0]:
                continue

            sTitle = aEntry[1]
            siteUrl = f'{URL_MAIN[:-1]}{aEntry[0]}'
            sThumb = f'{URL_MAIN[:-1]}{aEntry[2]}'
            sDesc = ''
            sYear = ''
            m = re.search(r'([0-9]{4})', sTitle)
            if m:
                sYear = str(m.group(0))
            
            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)

            oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    sPattern = r'<a class="" href="([^"]+)">(.+?)</a>'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:

            sTitle = f'[COLOR red]Page: {aEntry[1]}[/COLOR]'
            siteUrl = f'{URL_MAIN[:-1]}{aEntry[0]}'
            sThumb = ""

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
        
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', sTitle, 'next.png', oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()

def showSeasons():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r' <a data-id="([^"]+)"\s+class="season-toggle"\s+href=".*?">► Season (.+?)<span.+?data-show-id="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:
            
            sSeason = aEntry[1]
            sTitle = f'{sMovieTitle} S{sSeason}'
            siteUrl = f'{sUrl}|{aEntry[2]}&{sSeason}'
            sThumb = sThumb
            sDesc = ""
 
            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            
            oGui.addSeason(SITE_IDENTIFIER, 'showSeriesEpisode', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    oGui.setEndOfDirectory() 

def showSeriesEpisode():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    sUrl, sSeason = sUrl.split('|')
    sID, sSeason = sSeason.split('&')

    oParser = cParser()  
    oRequest = cRequestHandler(sUrl)
    page = oRequest.request()

    sPattern = fr'>► Season {sSeason}<span(.+?)</div>\s+</div>'
    aResult = oParser.parse(page,sPattern)
    if aResult[0]:
        seasonHtml = aResult[1][0] 

        sPattern = r'<a href="([^"]+)">.+?class="tv_episode_name">(.+?)</span>.+?value="([^"]+)"'
        aResult = oParser.parse(seasonHtml, sPattern)
        if aResult[0]:
            oOutputParameterHandler = cOutputParameterHandler()  
            for aEntry in aResult[1]:
                
                sEpisode = aEntry[0].split("-episode-")[1]
                sTitle = f'{sMovieTitle} E{sEpisode}'
                sDisplayTitle = f'{sMovieTitle} E{sEpisode} [COLOR orange]{aEntry[1]} [/COLOR]'
                siteUrl = f'{URL_MAIN}api/v1/s?e_id={aEntry[2]}&s_id={sID}&type=tv'
                sThumb = sThumb
                sDesc = ""

                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
    
                oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sDisplayTitle, '', sThumb, sDesc, oOutputParameterHandler)
       
    oGui.setEndOfDirectory() 

def showHosters():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('Referer', URL_MAIN)
    sHtmlContent = oRequest.request(jsonDecode=True)
    
    sServers = sHtmlContent.get("servers", "")
    for sServer in sServers:
        oOutputParameterHandler = cOutputParameterHandler()

        sTitle = sServer.get("name")
        sDisplayTitle = f'{sMovieTitle} [COLOR coral]- {sTitle} [/COLOR]'
        sKey = sServer.get("key")
        sSize = sServer.get("file_size")
        sFile = sServer.get("file_name")

        sDesc = f'[COLOR coral]File Name:[/COLOR]\n {sFile} \n\n [COLOR coral]File Size:[/COLOR]\n {sSize}'   

        oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sKey', sKey)

        oGui.addLink(SITE_IDENTIFIER, 'showLinks', sDisplayTitle, sThumb, sDesc, oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sHosterUrl = oInputParameterHandler.getValue('sHosterUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sKey = oInputParameterHandler.getValue('sKey')

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    sUrl = f"{URL_MAIN}api/v1/l?key={sKey}"

    oParser = cParser()

    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('sReferer', URL_MAIN)
    sHtmlContent = oRequest.request()

    sPattern = r'"link":\s+"([^"]+)".+?"host":\s+"([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        for aEntry in aResult[1]:

            sHosterUrl = aEntry[0]
            sHost = aEntry[1]
            results.append((sMovieTitle, sHosterUrl))

    if useDialog and results:
        cHosterGui().selectHoster(results, sMovieTitle, SITE_NAME, sThumb)
    else:
        for sTitle, sHosterUrl in results:
            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

        oGui.setEndOfDirectory()

def generate_pw_search_key(query):
    import hashlib
    hardcoded_key = "JyjId97F9PVqUPuMO0"
    combined_string = query.replace('+', ' ') + hardcoded_key
    hashed_string = hashlib.sha1(combined_string.encode()).hexdigest()
    return hashed_string[:10]

def requestSearch(sUrl):
    oGui = cGui()

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'"imdb_id":"([^"]+)".+?"tmdb_id":(\d+),'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        imdb_id, tmdb_id = aResult[1][0]
        return imdb_id, tmdb_id

    return None, None