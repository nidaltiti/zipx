# -*- coding: utf-8 -*-

import re
import base64
import uuid
import json
import six
import time
import requests
from resources.lib.mCaptcha.mserver import CaptchaServer
from resources.lib.comaddon import addon, siteManager, VSlog
from resources.lib.gui.gui import cGui
from resources.lib.util import urlHostName
from resources.lib.gui.hoster import cHosterGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib import random_ua

UA = random_ua.get_ua()

sSession = requests.session()

SITE_IDENTIFIER = 'iptv'
SITE_NAME = '[COLOR orange]Premium IPTV[/COLOR]'
SITE_DESC = 'Watch Live television'

URL_MAIN = 'https://ugeen.live'

iHost = 'https://ugeen.live/api'

URL_WEB = f'{URL_MAIN}/get.php?username=accountname&password=accountpassword&type=m3u_plus&output=mpegts'

TV_TV = (True, 'showMenuTV')

icon = 'tv.png'
sRootArt = ''
addons = addon()

# ==============================================================================
# --- FINGERPRINT ENGINE ---
# ==============================================================================

def to_int32(val):
    val = val & 0xFFFFFFFF
    return val if val < 0x80000000 else val - 0x100000000

def js_shift(val, n):
    return to_int32(to_int32(val) << (n & 31))

def sync_hash32(s):
    h1, h2, h3, h4 = 2166136261, 3141592653, 1234567891, 987654321
    for c in s:
        code = ord(c)
        h1_i = to_int32(int(h1)) ^ code
        h1 = h1_i + (js_shift(h1_i, 1) + js_shift(h1_i, 4) + js_shift(h1_i, 7) + js_shift(h1_i, 8) + js_shift(h1_i, 24))
        h2_i = to_int32(int(h2)) ^ code
        h2 = h2_i + (js_shift(h2_i, 1) + js_shift(h2_i, 5) + js_shift(h2_i, 7) + js_shift(h2_i, 9) + js_shift(h2_i, 23))
        h3_i = to_int32(int(h3)) ^ code
        h3 = h3_i + (js_shift(h3_i, 2) + js_shift(h3_i, 4) + js_shift(h3_i, 6) + js_shift(h3_i, 10) + js_shift(h3_i, 22))
        h4_i = to_int32(int(h4)) ^ code
        h4 = h4_i + (js_shift(h4_i, 3) + js_shift(h4_i, 5) + js_shift(h4_i, 8) + js_shift(h4_i, 11) + js_shift(h4_i, 21))

    hex1 = f"{int(h1) & 0xFFFFFFFF:08x}"
    hex2 = f"{int(h2) & 0xFFFFFFFF:08x}"
    hex3 = f"{int(h3) & 0xFFFFFFFF:08x}"
    hex4 = f"{int(h4) & 0xFFFFFFFF:08x}"
    return hex1 + hex2 + hex3 + hex4

def get_device_storage_id():
    """Retrieves or creates a persistent storage ID in addon settings."""
    try:
        storage_id = addons.getSetting('device_storage_id')
    except Exception:
        storage_id = ''

    if not storage_id:
        storage_id = uuid.uuid4().hex
        try:
            addons.setSetting('device_storage_id', storage_id)
        except Exception:
            pass
    return storage_id

def get_device_fingerprint():
    """Generates the fp2_ fingerprint required by Ugeen API."""
    storage_id = get_device_storage_id()
    user_agent = UA
    language = "en-US"
    platform_str = "Win32"
    hardware_concurrency = "8"
    device_memory = "8"
    screen_width = "1920"
    screen_height = "1080"
    color_depth = "24"
    tz_offset = "-180"
    tz_name = "UTC"
    
    canvas_fp = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAyCAYAAAA9y/1eAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQ="
    webgl_fp = "Google Inc. (NVIDIA)~ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)"
    audio_fp = "44100"

    parts = [
        user_agent, language, platform_str, hardware_concurrency,
        device_memory, screen_width, screen_height, color_depth,
        tz_offset, tz_name, canvas_fp, webgl_fp, audio_fp, storage_id
    ]
    raw = "||".join(parts)
    return "fp2_" + sync_hash32(raw)

# ==============================================================================
# --- ADDON LOGIC ---
# ==============================================================================

class track:
    def __init__(self, length, title, path, icon, data=''):
        self.length = length
        self.title = title
        self.path = path
        self.icon = icon
        self.data = data

def load():
    oGui = cGui()

    if (addons.getSetting('hoster_iptv_username') == '') and (addons.getSetting('hoster_iptv_password') == ''):
        oOutputParameterHandler = cOutputParameterHandler()
        oGui.addDir(SITE_IDENTIFIER, 'opensetting', '[COLOR %s]%s[/COLOR]' % ('orange', 'Requires a Premium or Account'), 'none.png', oOutputParameterHandler)

    else:
        oOutputParameterHandler = cOutputParameterHandler()
        oGui.addDir(SITE_IDENTIFIER, 'showMenuTV', addons.VSlang(30115), 'tv.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showMenuTV():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', URL_WEB)
    oGui.addDir(SITE_IDENTIFIER, 'showWeb', addons.VSlang(30332), 'tv.png', oOutputParameterHandler)
    oGui.setEndOfDirectory()

def parseM3U(sUrl=None):  
    if not sUrl:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    inf = oRequestHandler.request().split('\n')

    playlist = []
    song = track(None, None, None, None)
    ValidEntry = False

    for line in inf:
        line = line.strip()
        if line.startswith('#EXTINF:'):
            length, title = line.split('#EXTINF:')[1].split(',', 1)
            try:
                licon = line.split('#EXTINF:')[1].partition('tvg-logo=')[2]
                icon = licon.split('"')[1]
            except:
                icon = 'tv.png'
            ValidEntry = True
            song = track(length, title, None, icon)

        elif len(line) != 0:
            if ValidEntry and (not (line.startswith('!') or line.startswith('#'))):
                ValidEntry = False
                song.path = line
                playlist.append(song)
                song = track(None, None, None, None)

    return playlist

def showWeb():
    oGui = cGui()

    if (addons.getSetting('hoster_iptv_username') == '') and (addons.getSetting('hoster_iptv_password') == ''):
        if (addons.getSetting('hoster_iptv_account_email') == '') and (addons.getSetting('hoster_iptv_account_password') == ''):
            oOutputParameterHandler = cOutputParameterHandler()
            oGui.addDir(SITE_IDENTIFIER, 'opensetting', '[COLOR %s]%s[/COLOR]' % ('orange', 'Requires a Premium or Free Account'), 'none.png', oOutputParameterHandler)
        else:
            get_Bearer()
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', 'http://')
            oGui.addText(SITE_IDENTIFIER, '[COLOR orange]Renew Completed, Go Back and try Again[/COLOR]')

    else:
        Iuser = addons.getSetting('hoster_iptv_username')
        Ipass = addons.getSetting('hoster_iptv_password')

        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl').replace('P_L_U_S', '+').replace('accountname', Iuser).replace('accountpassword', Ipass)

        if sUrl == 'TV':
            sUrl = URL_WEB.replace('P_L_U_S', '+').replace('accountname', Iuser).replace('accountpassword', Ipass)

        playlist = parseM3U(sUrl=sUrl)
        if not playlist:
            if (addons.getSetting('hoster_iptv_account_email') == '') and (addons.getSetting('hoster_iptv_account_password') == ''):
                oOutputParameterHandler = cOutputParameterHandler()
                oGui.addDir(SITE_IDENTIFIER, 'opensetting', '[COLOR %s]%s[/COLOR]' % ('orange', 'Requires a Premium or Free Account'), 'none.png', oOutputParameterHandler)
            else:
                get_Bearer()
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', 'http://')
                oGui.addText(SITE_IDENTIFIER, '[COLOR orange]Renew Completed, Go Back and try Again[/COLOR]')

        else:
            oRequestHandler = cRequestHandler(sUrl)
            sHtmlContent = oRequestHandler.request()
            groups = set()
            current_group = None

            for line in sHtmlContent.splitlines():
                if line.startswith("#EXTINF"):
                    match = re.search(r'group-title="([^"]+)"', line)
                    if match:
                        current_group = match.group(1)
                        groups.add(current_group)

            for group in sorted(groups, key=str.lower):
                sTitle = group
                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl', sUrl)
                oOutputParameterHandler.addParameter('sGroup', sTitle)
                oGui.addDir(SITE_IDENTIFIER, 'showGroup', sTitle.replace('⚽',''), 'tv.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showGroup():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sGroup = oInputParameterHandler.getValue('sGroup')

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    groups = {}
    current_group = None
    current_name = None
    current_logo = None

    for line in sHtmlContent.splitlines():
        if line.startswith("#EXTINF"):
            match_group = re.search(r'group-title="([^"]+)"', line)
            match_name = re.search(r'tvg-name="([^"]+)"', line)
            match_logo = re.search(r'tvg-logo="([^"]+)"', line)
            if match_group:
                current_group = match_group.group(1)
            if match_name:
                current_name = match_name.group(1)
            if match_logo:
                current_logo = match_logo.group(1)
                if 'http' not in current_logo:
                    current_logo = 'special://home/addons/plugin.video.matrixflix/resources/art/tv.png'

        elif line.startswith("http"):
            if current_group == sGroup:
                if current_group not in groups:
                    groups[current_group] = []
                groups[current_group].append((current_name, current_logo, line))

    for name, logo, link in groups.get(sGroup, []):
        sThumb = logo
        sTitle = name
        sHosterUrl = link.replace('+', 'P_L_U_S')

        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sHosterUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumbnail', sThumb)
        oGui.addMisc(SITE_IDENTIFIER, 'play__', sTitle, 'foot.png', sThumb, '', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def play__(): 
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumbnail = oInputParameterHandler.getValue('sThumbnail')

    if 'youtube' in sUrl:
        oHoster = cHosterGui().checkHoster(sUrl)

        if oHoster:
            oHoster.setDisplayName(sTitle)
            oHoster.setFileName(sTitle)
            cHosterGui().showHoster(oGui, oHoster, sUrl, sThumbnail)

    else:
        oHoster = cHosterGui().getHoster('direct_link')
        if oHoster:
            oHoster.setDisplayName(sTitle)
            oHoster.setFileName(sTitle)
            cHosterGui().showHoster(oGui, oHoster, sUrl, sThumbnail)

    oGui.setEndOfDirectory()

def set_setting(id, value):
    if not isinstance(value, six.string_types):
        value = str(value)
    addons.setSetting(id, value)

def get_Bearer():
    sBearer, sUser, sPass = account_login()
    set_setting('bearer_token', sBearer)
    set_setting('hoster_iptv_username', sUser)
    set_setting('hoster_iptv_password', sPass)
    set_setting('last_bearer_create', str(int(time.time())))
    renewSubs(sBearer)

    return sBearer

def account_login():
    Iuser = addons.getSetting('hoster_iptv_account_email')
    Ipass = addons.getSetting('hoster_iptv_account_password')

    url = f"{URL_MAIN}/api/auth/login"
    user = Iuser
    password = Ipass
    captcha = get_captcha()
    
    payload = {
        'email': user,
        'password': password,
        'recaptcha': captcha
    }

    headers = {
        "host": f"{urlHostName(URL_MAIN)}",
        "proxy-connection": "keep-alive",
        "accept": "application/json",
        "authorization": "Bearer",
        "X-Device-Fingerprint": get_device_fingerprint(),
        "user-agent": UA,
        "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        "origin": URL_MAIN,
        "referer": f"{URL_MAIN}/",
        "accept-encoding": "gzip, deflate",
        "accept-language": "en-US,en;q=0.9",
        "X-Requested-With": "XMLHttpRequest"
    }

    response = sSession.post(url, data=payload, headers=headers).json()
    return response["access"]["token"], response["user"]["iptv_user"], response["user"]["iptv_pass"] 

def renewSubs(Bearer):
    code, token = get_code(Bearer)
    if not code or not token:
        VSlog("Renewal cancelled: Unable to retrieve a valid code or token.")
        return

    payload = {
        "code": code,
        "token": token,
        "bouquetId": '384'
    }

    url = f"{URL_MAIN}/api/v1/subscriptions"

    headers = {
        "host": f"{urlHostName(URL_MAIN)}",
        "proxy-connection": "keep-alive",
        "accept": "application/json",
        "authorization": f"Bearer {Bearer}",
        "X-Device-Fingerprint": get_device_fingerprint(),
        "user-agent": UA,
        "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Origin": URL_MAIN,
        "Referer": f"{URL_MAIN}/",
        "accept-encoding": "gzip, deflate",
        "accept-language": "en-US,en;q=0.9"
    }

    response = sSession.post(url, data=payload, headers=headers)
    VSlog(response.text)

def get_captcha():
    sUrl = f"{URL_MAIN}:443"
    
    captcha_data = {
        "siteUrl": sUrl,
        "siteKey": "6LexPvMgAAAAALN68SVJjCdXthMxNSs9Sp6Q4Pdr",
        "captchaType": "INVISIBLE"
    }

    try:
        last_gen = int(addons.getSetting(f"{urlHostName(sUrl)}_mcreate"))
    except Exception:
        last_gen = 0

    if not addons.getSetting(f"{urlHostName(sUrl)}_mcaptcha") or last_gen < (time.time() - (5 * 60)):
        server = CaptchaServer(captcha_data)
        server.start_server()
        return addons.getSetting(f"{urlHostName(sUrl)}_mcaptcha")
    else:
        return addons.getSetting(f"{urlHostName(sUrl)}_mcaptcha")

def decode_base64(jwt_string: str) -> dict:
    parts = jwt_string.split(".")
    if len(parts) != 3:
        raise ValueError("Invalid JWT format")

    payload_b64 = parts[1]
    padded_b64 = payload_b64 + "=" * (-len(payload_b64) % 4)

    decoded_bytes = base64.urlsafe_b64decode(padded_b64)
    return json.loads(decoded_bytes.decode("utf-8"))

def get_code(Bearer=None):
    if not Bearer:
        Bearer = addons.getSetting('bearer_token')

    url = f"{URL_MAIN}/api/v1/codes"

    headers = {
        "host": f"{urlHostName(URL_MAIN)}",
        "accept": "application/json",
        "authorization": f"Bearer {Bearer}",
        "Origin": URL_MAIN,
        "Referer": f"{URL_MAIN}/renew.html",
        "User-Agent": UA,
        "X-Device-Fingerprint": get_device_fingerprint(),
        "accept-encoding": "gzip, deflate",
        "accept-language": "en-US,en;q=0.9"
    }

    try:
        res = sSession.get(url, headers=headers)
        data = res.json()
    except Exception as e:
        VSlog(f"JSON parsing error in get_code: {e}")
        return None, None

    if isinstance(data, dict) and data.get("code") == 401:
        VSlog("Authentication failed (401 Unauthorized) in get_code")
        return None, None

    uri = data.get("uri")
    token = data.get("token")

    if not token:
        VSlog("Error: Token missing in get_code response")
        return None, None

    nUrl = f'{URL_MAIN}/api/v1/codes/download?token={token}'
    sSession.get(nUrl, headers=headers)

    try:
        datas = decode_base64(token)
        VSlog(datas)
        code = datas.get("code", {}).get("code")
        return code, token
    except Exception as e:
        VSlog(f"JWT decode error in get_code: {e}")
        return None, None

def opensetting():
    addon().openSettings()