﻿# -*- coding: utf-8 -*-
import re
import os, json, time
import xbmcaddon
import xbmc
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.player import cPlayer
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.comaddon import addon, VSlog
from resources.lib.util import cUtil

from resources.lib.stalker import (
    find_working_mac,
    resolve_vod_stream,
    fetch_stalker_categories,
    fetch_stalker_channels_for_category,
    resolve_stalker_stream,
    fetch_stalker_listing,
    _make_sn_device_ids,
    fetch_stalker_seasons,
    resolve_series_stream,
    _stalker_request
)

SITE_IDENTIFIER = 'stalker'
SITE_NAME = 'Stalker IPTV'
SITE_DESC = 'MAG portal integration'

CACHE_FILE = os.path.join(
    xbmcaddon.Addon().getAddonInfo('profile'),
    'stalker_cache.json'
)

def _load_cache():
    try:
        if os.path.exists(CACHE_FILE):
            with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except:
        pass
    return {"favorites": [], "recent": []}

def _save_cache(data):
    try:
        os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
        with open(CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    except:
        pass

def add_to_recent(title, portal, mac, cmd, stream_url):
    data = _load_cache()
    entry = {
        "title": title,
        "portal": portal,
        "mac": mac,
        "cmd": cmd,
        "stream_url": stream_url,
        "timestamp": time.time()
    }
    data["recent"].insert(0, entry)
    data["recent"] = data["recent"][:50]
    _save_cache(data)

def add_to_favorites(title, portal, mac, cmd, stream_url):
    data = _load_cache()
    entry = {
        "title": title,
        "portal": portal,
        "mac": mac,
        "cmd": cmd,
        "stream_url": stream_url
    }
    if not any(f["title"] == title and f["portal"] == portal for f in data["favorites"]):
        data["favorites"].append(entry)
    _save_cache(data)

def showFavorites():
    oGui = cGui()
    data = _load_cache()
    for fav in data.get("favorites", []):
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('portal', fav["portal"])
        oOutputParameterHandler.addParameter('mac', fav["mac"])
        oOutputParameterHandler.addParameter('cmd', fav["cmd"])
        oGui.addDir(SITE_IDENTIFIER, 'playStream', f'{fav["title"]}', 'fav.png', oOutputParameterHandler)
    oGui.setEndOfDirectory()

def showRecent():
    oGui = cGui()
    data = _load_cache()
    for rec in data.get("recent", []):
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('portal', rec["portal"])
        oOutputParameterHandler.addParameter('mac', rec["mac"])
        oOutputParameterHandler.addParameter('cmd', rec["cmd"])
        oGui.addDir(SITE_IDENTIFIER, 'playStream', f'{rec["title"]}', 'recent.png', oOutputParameterHandler)
    oGui.setEndOfDirectory()

def _get_saved_portal_mac():
    addons = addon()
    portal = addons.getSetting('stalker_portal')
    mac = addons.getSetting('stalker_mac')
    if portal and mac:
        return portal, mac
    return None, None

def _save_portal_mac(portal, mac):
    addons = addon()
    addons.setSetting('stalker_portal', portal)
    addons.setSetting('stalker_mac', mac)

def _ensure_portal_mac(force=False):
    portal, mac = _get_saved_portal_mac()
    if not portal or not mac or force:
        portal, mac = find_working_mac()
        if portal and mac:
            _save_portal_mac(portal, mac)
    return portal, mac


def forceRefreshPortal():
    import xbmcgui

    dialog = xbmcgui.Dialog()
    confirm = dialog.yesno(
        "تحديث Portal",
        "سيؤدي هذا إلى حذف Portal/MAC الحالي والبحث عن عنوان جديد.\n\nهل تريد المتابعة؟"
    )

    if not confirm:
        xbmcgui.Dialog().notification("MatrixFlix", "تم الالغاء", xbmcgui.NOTIFICATION_INFO, 3000)

        return

    portal, mac = _ensure_portal_mac(force=True)
    if portal and mac:
        _save_portal_mac(portal, mac)
        xbmcgui.Dialog().notification("MatrixFlix", f"New portal saved", xbmcgui.NOTIFICATION_INFO, 5000)
    else:
        xbmcgui.Dialog().notification("MatrixFlix", "No working portal found", xbmcgui.NOTIFICATION_ERROR, 5000)


def load():
    oGui = cGui()
    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'stalker://')

    oGui.addDir(SITE_IDENTIFIER, 'searchMovies', 'Search Movies', 'search.png', oOutputParameterHandler)
    oGui.addDir(SITE_IDENTIFIER, 'searchSeries', 'Search Series', 'search.png', oOutputParameterHandler)
    oGui.addDir(SITE_IDENTIFIER, 'showCategoriesLive', 'Live TV', 'tv.png', oOutputParameterHandler)
    oGui.addDir(SITE_IDENTIFIER, 'showCategoriesMovies', 'Movies/VOD', 'film.png', oOutputParameterHandler)
    oGui.addDir(SITE_IDENTIFIER, 'showCategoriesSeries', 'Series', 'mslsl.png', oOutputParameterHandler)
    #oGui.addDir(SITE_IDENTIFIER, 'showFavorites', 'Favorites', 'mark.png', oOutputParameterHandler)
    #oGui.addDir(SITE_IDENTIFIER, 'showRecent', 'Recently Watched', 'buzz.png', oOutputParameterHandler)

    oGui.addDir(SITE_IDENTIFIER, 'forceRefreshPortal', '[COLOR gold]Force Find New Portal[/COLOR]', 'replay.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def showCategoriesLive():
    _showCategories('itv', 'showChannelsLive')

def showChannelsLive():
    _showChannels('itv', 'playStream')

def showChannelsMovies():
    _showChannels('vod', 'playStream')

def showChannelsSeries():
    _showChannels('series', 'playStream')

def searchMovies():
    _searchContent('vod')

def searchSeries():
    _searchContent('series')

def _searchContent(content_type=None):
    oGui = cGui()
    oInput = cInputParameterHandler()
    if not content_type:
        content_type = oInput.getValue('content_type')

    sSearchText = oInput.getValue('search') or oGui.showKeyBoard()
    if not sSearchText:
        return

    portal, mac = _ensure_portal_mac()
    if not portal or not mac:
        oGui.addText(SITE_IDENTIFIER, '[COLOR red]No working portal found[/COLOR]')
        oGui.setEndOfDirectory()
        return

    page = int(oInput.getValue('page') or "1")

    params = {
        'type': content_type,
        'action': 'get_ordered_list',
        'p': str(page),
        'search': sSearchText,
        'JsHttpRequest': '1-xml'
    }
    if content_type == 'series':
        params['sortby'] = 'added'

    res = _stalker_request(portal, mac, 'get_ordered_list', params)
    js = res.get('js') or {}
    chans = js.get('data', [])

    for ch in chans:
        sTitle = ch.get('title') or ch.get('name')
        sThumb = ch.get('logo') or ch.get('screenshot_uri') or ''
        sDesc = ch.get('description', '')
        video_id = ch.get('id')

        oOutput = cOutputParameterHandler()
        oOutput.addParameter('siteUrl', 'http://matrixflix/')
        oOutput.addParameter('portal', portal)
        oOutput.addParameter('mac', mac)
        oOutput.addParameter('content_type', content_type)
        oOutput.addParameter('page', str(page))
        oOutput.addParameter('video_id', video_id)
        oOutput.addParameter('sMovieTitle', sTitle)
        oOutput.addParameter('sThumb', sThumb)
        oOutput.addParameter('sDesc', sDesc)
        oOutput.addParameter('cmd', ch.get('cmd',''))

        if content_type == 'vod':
            oGui.addMovie(SITE_IDENTIFIER, 'playMovie', sTitle, '', sThumb, sDesc, oOutput)
        elif content_type == 'series':
            oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutput)
        else:
            oGui.addMisc(SITE_IDENTIFIER, 'playStream', sTitle, '', sThumb, sDesc, oOutput)

    total_items = int(js.get('total_items', len(chans)))
    max_page_items = int(js.get('max_page_items', len(chans)))
    if page * max_page_items < total_items:
        oOutput = cOutputParameterHandler()
        oOutput.addParameter('portal', portal)
        oOutput.addParameter('mac', mac)
        oOutput.addParameter('content_type', content_type)
        oOutput.addParameter('page', str(page + 1))
        oOutput.addParameter('search', sSearchText)
        oGui.addDir(SITE_IDENTIFIER, '_searchContent', f'Next Page ▶ (Page {page+1})', '', oOutput)

    oGui.setEndOfDirectory()


def showCategoriesMovies():
    oGui = cGui()
    portal, mac = _ensure_portal_mac()
    cats = fetch_stalker_categories(portal, mac, 'vod')
    if not cats:
        oGui.setEndOfDirectory()
        return

    for cat in cats:
        sTitle = cat.get('title') or cat.get('name')
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('portal', portal)
        oOutputParameterHandler.addParameter('mac', mac)
        oOutputParameterHandler.addParameter('category_id', cat.get('id'))
        oGui.addDir(SITE_IDENTIFIER, 'showMoviesListing', sTitle, 'film.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showMoviesListing():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    portal = oInputParameterHandler.getValue('portal')
    mac = oInputParameterHandler.getValue('mac')
    category_id = oInputParameterHandler.getValue('category_id')
    page = int(oInputParameterHandler.getValue('page') or 1)

    listing = fetch_stalker_listing(portal, mac, 'vod', category_id, page)
    data = listing.get('data', [])
    total_items = int(listing.get('total_items', 0))
    max_page_items = int(listing.get('max_page_items', 0))

    for v in data:
        sDesc = v.get('description','')
        sTitle = clean_title(v.get('name','') or v.get('title',''))
        sThumb = v.get('screenshot_uri','')

        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://matrixflix/')
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('portal', portal)
        oOutputParameterHandler.addParameter('mac', mac)
        oOutputParameterHandler.addParameter('video_id', v.get('id'))
        oOutputParameterHandler.addParameter('cmd', v.get('cmd',''))
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sDesc', sDesc)

        oGui.addMovie(SITE_IDENTIFIER, 'playMovie', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if total_items > page * max_page_items:
        next_page = page + 1
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('portal', portal)
        oOutputParameterHandler.addParameter('mac', mac)
        oOutputParameterHandler.addParameter('category_id', category_id)
        oOutputParameterHandler.addParameter('page', str(next_page))
        oGui.addDir(SITE_IDENTIFIER, 'showMoviesListing', '[COLOR yellow]Next Page >>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def playMovie():
    oGui = cGui()
    oInput = cInputParameterHandler()
    sMovieTitle = oInput.getValue('sMovieTitle')
    sThumb = oInput.getValue('sThumb') or ''
    sDesc = oInput.getValue('sDesc') or ''
    portal = oInput.getValue('portal')
    mac = oInput.getValue('mac')
    video_id = oInput.getValue('video_id')
    cmd = oInput.getValue('cmd') or ''

    xbmc.executebuiltin('ActivateWindow(busydialog)')
    try:
        stream_url = resolve_vod_stream(portal, mac, video_id, cmd=cmd)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialog)')

    if not stream_url:
        oGui.addText(SITE_IDENTIFIER, '[COLOR red]Stream resolution failed[/COLOR]')
        oGui.setEndOfDirectory()
        return

    stream_url = stream_url.replace(' ', '%20')

    sn, _, _ = _make_sn_device_ids(mac)
    user_agent = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Mobile Safari/533.3"
    headers = f"User-Agent={user_agent}&Cookie=mac={mac}; stb_lang=en; timezone=GMT; sn={sn}&Referer={portal}/c/index.html"
    
    final_stream_url = f"{stream_url}|{headers}"

    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sMovieTitle)
    oGuiElement.setMediaUrl(final_stream_url)
    oGuiElement.setThumbnail(sThumb)
    oGuiElement.setDescription(sDesc)

    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer()
    return


def showCategoriesSeries():
    oGui = cGui()
    portal, mac = _ensure_portal_mac()
    cats = fetch_stalker_categories(portal, mac, 'series')
    if not cats:
        oGui.setEndOfDirectory()
        return

    for cat in cats:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('portal', portal)
        oOutputParameterHandler.addParameter('mac', mac)
        oOutputParameterHandler.addParameter('category_id', cat.get('id'))
        oGui.addDir(SITE_IDENTIFIER, 'showSeriesListing', cat.get('title', cat.get('name','')), 'mslsl.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSeriesListing():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    portal = oInputParameterHandler.getValue('portal')
    mac = oInputParameterHandler.getValue('mac')
    category_id = oInputParameterHandler.getValue('category_id')
    page = int(oInputParameterHandler.getValue('page') or 1)

    listing = fetch_stalker_listing(portal, mac, 'series', category_id, page)
    data = listing.get('data', [])
    total_items = int(listing.get('total_items', 0))
    max_page_items = int(listing.get('max_page_items', 0))

    for v in data:
        oOutputParameterHandler = cOutputParameterHandler()
        sTitle = v.get('name','')
        sDisplayTitle = clean_title(cUtil().CleanSeriesName(sTitle))
        sDesc = v.get('description','')
        sThumb = v.get('screenshot_uri','')
        sYear = ''
        m = re.search(r'([0-9]{4})', sTitle)
        if m:
            sYear = str(m.group(0))

        oOutputParameterHandler.addParameter('siteUrl', 'http://matrixflix/')
        oOutputParameterHandler.addParameter('portal', portal)
        oOutputParameterHandler.addParameter('mac', mac)
        oOutputParameterHandler.addParameter('video_id', v.get('id'))
        oOutputParameterHandler.addParameter('cmd', v.get('cmd',''))
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sDesc', sDesc)
        oOutputParameterHandler.addParameter('sYear', sYear)

        oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sDisplayTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if total_items > page * max_page_items:
        next_page = page + 1
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('portal', portal)
        oOutputParameterHandler.addParameter('mac', mac)
        oOutputParameterHandler.addParameter('category_id', category_id)
        oOutputParameterHandler.addParameter('page', str(next_page))
        oGui.addDir(SITE_IDENTIFIER, 'showSeriesListing', '[COLOR teal]Next Page >>[/COLOR]', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSeasons():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb') or ''
    sDesc = oInputParameterHandler.getValue('sDesc') or ''
    portal = oInputParameterHandler.getValue('portal')
    mac = oInputParameterHandler.getValue('mac')
    video_id = oInputParameterHandler.getValue('video_id')

    seasons = fetch_stalker_seasons(portal, mac, video_id)
    for s in seasons.get('data', []):
        sTitle = f"{sMovieTitle} {(cUtil().ConvertSeasons(s.get('name','') or s.get('title','')))}"

        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://matrixflix/')
        oOutputParameterHandler.addParameter('portal', portal)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sDesc', sDesc)
        oOutputParameterHandler.addParameter('mac', mac)
        oOutputParameterHandler.addParameter('video_id', video_id)
        oOutputParameterHandler.addParameter('season_id', s['id'])
        oOutputParameterHandler.addParameter('start', s['series'][0])
        oOutputParameterHandler.addParameter('end', s['series'][-1])
        oOutputParameterHandler.addParameter('cmd', s.get('cmd',''))

        oGui.addSeason(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)  

    oGui.setEndOfDirectory()

def showEpisodes():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb') or ''
    sDesc = oInputParameterHandler.getValue('sDesc') or ''
    portal = oInputParameterHandler.getValue('portal')
    mac = oInputParameterHandler.getValue('mac')
    video_id = oInputParameterHandler.getValue('video_id')
    season_id = oInputParameterHandler.getValue('season_id')
    start = int(oInputParameterHandler.getValue('start'))
    end = int(oInputParameterHandler.getValue('end'))
    cmd = oInputParameterHandler.getValue('cmd')

    for episode_no in range(start, end + 1):
        sTitle = f"{sMovieTitle} E{episode_no}"

        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://matrixflix/')
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sDesc', sDesc)
        oOutputParameterHandler.addParameter('portal', portal)
        oOutputParameterHandler.addParameter('mac', mac)
        oOutputParameterHandler.addParameter('video_id', video_id)
        oOutputParameterHandler.addParameter('season_id', season_id)
        oOutputParameterHandler.addParameter('series', episode_no)
        oOutputParameterHandler.addParameter('cmd', cmd)

        oGui.addEpisode(SITE_IDENTIFIER, 'playEpisode', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    oGui.setEndOfDirectory()

def playEpisode():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb') or ''
    sDesc = oInputParameterHandler.getValue('sDesc') or ''

    portal = oInputParameterHandler.getValue('portal')
    mac = oInputParameterHandler.getValue('mac')
    video_id = oInputParameterHandler.getValue('video_id')
    series = oInputParameterHandler.getValue('series')
    cmd = oInputParameterHandler.getValue('cmd')

    xbmc.executebuiltin('ActivateWindow(busydialog)')

    try:
        stream_url = resolve_series_stream(portal, mac, video_id, series=series, cmd=cmd)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialog)')

    if not stream_url:
        oGui.addText(SITE_IDENTIFIER, '[COLOR red]Stream resolution failed[/COLOR]')
        oGui.setEndOfDirectory()
        return

    stream_url = stream_url.replace(' ', '%20')

    sn, _, _ = _make_sn_device_ids(mac)
    user_agent = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Mobile Safari/533.3"
    headers = f"User-Agent={user_agent}&Cookie=mac={mac}; stb_lang=en; timezone=GMT; sn={sn}&Referer={portal}/c/index.html"
    final_stream_url = f"{stream_url}|{headers}"

    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(sMovieTitle)
    oGuiElement.setMediaUrl(final_stream_url)
    oGuiElement.setThumbnail(sThumb)
    oGuiElement.setDescription(sDesc)

    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer()
    return

def _showCategories(content_type, next_func):
    oGui = cGui()
    portal, mac = _ensure_portal_mac()
    if not portal or not mac:
        oGui.addText(SITE_IDENTIFIER, '[COLOR red]No working portal found[/COLOR]')
        oGui.setEndOfDirectory()
        return

    cats = fetch_stalker_categories(portal, mac, content_type)
    for cat in cats:
        sTitle = cat.get('name') or cat.get('title')
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('portal', portal)
        oOutputParameterHandler.addParameter('mac', mac)
        oOutputParameterHandler.addParameter('category_id', cat['id'])
        oOutputParameterHandler.addParameter('content_type', content_type)
        oGui.addDir(SITE_IDENTIFIER, next_func, sTitle, 'icon.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def _showChannels(content_type=None, next_func=None):
    oGui = cGui()
    oInput = cInputParameterHandler()

    portal, mac = _ensure_portal_mac()
    if not portal or not mac:
        oGui.addText(SITE_IDENTIFIER, '[COLOR red]No working portal found[/COLOR]')
        oGui.setEndOfDirectory()
        return
    
    category_id = oInput.getValue('category_id')
    page = int(oInput.getValue('page') or "1")

    if not content_type:
        content_type = oInput.getValue('content_type')
    if not next_func:
        next_func = oInput.getValue('next_func')

    chans, total_items, max_page_items = fetch_stalker_channels_for_category(
        portal, mac, content_type, category_id, page
    )

    for ch in chans:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://matrixflix/')
        oOutputParameterHandler.addParameter('portal', portal)
        oOutputParameterHandler.addParameter('mac', mac)
        oOutputParameterHandler.addParameter('cmd', ch['url'].split('|')[-1])
        oOutputParameterHandler.addParameter('category_id', category_id)
        oOutputParameterHandler.addParameter('page', str(page))
        oOutputParameterHandler.addParameter('content_type', content_type)
        oOutputParameterHandler.addParameter('next_func', next_func)
        oOutputParameterHandler.addParameter('ch', ch['title'])

        title = ch.get('title', '')
        logo = ch.get('logo', '')

        if content_type == 'vod':
            oGui.addMovie(SITE_IDENTIFIER, next_func, title, '', logo, '', oOutputParameterHandler)
        elif content_type == 'series':
            oGui.addTV(SITE_IDENTIFIER, next_func, title, '', logo, '', oOutputParameterHandler)
        else:
            oGui.addMisc(SITE_IDENTIFIER, next_func, title, title, logo, '', oOutputParameterHandler)

    if page * max_page_items < total_items:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('category_id', category_id)
        oOutputParameterHandler.addParameter('page', str(page + 1))
        oOutputParameterHandler.addParameter('content_type', content_type)
        oOutputParameterHandler.addParameter('next_func', next_func)
        oGui.addDir(SITE_IDENTIFIER, '_showChannels', f'Next Page ▶ (Page {page+1})', '', oOutputParameterHandler)

    oGui.setEndOfDirectory()


def playStream():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    portal = oInputParameterHandler.getValue('portal')
    mac = oInputParameterHandler.getValue('mac')
    cmd = oInputParameterHandler.getValue('cmd')
    ch = oInputParameterHandler.getValue('ch')

    xbmc.executebuiltin('ActivateWindow(busydialog)')

    try:
        stream_url = resolve_stalker_stream(portal, mac, cmd)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialog)')

    if not stream_url:
        oGui.addText(SITE_IDENTIFIER, '[COLOR red]Stream resolution failed[/COLOR]')
        oGui.setEndOfDirectory()
        return

    stream_url = stream_url.replace(' ', '%20')

    sn, _, _ = _make_sn_device_ids(mac)
    user_agent = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Mobile Safari/533.3"
    headers = f"User-Agent={user_agent}&Cookie=mac={mac}; stb_lang=en; timezone=GMT; sn={sn}&Referer={portal}/c/index.html"
    final_stream_url = f"{stream_url}|{headers}"

    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setTitle(ch)
    oGuiElement.setMediaUrl(final_stream_url)
    oGuiElement.setThumbnail('')
    oGuiElement.setDescription(ch)

    oPlayer = cPlayer()
    oPlayer.clearPlayList()
    oPlayer.addItemToPlaylist(oGuiElement)
    oPlayer.startPlayer()
    return

def clean_title(raw_title, strip_year=True):
    import unicodedata
    if not raw_title:
        return ''

    title = unicodedata.normalize('NFKD', raw_title)
    title = ''.join(ch for ch in title if unicodedata.category(ch)[0] != 'C')

    title = re.sub(r'^┃[^┃]+┃\s*', '', title)
    title = re.sub(r'[┃]+', '', title)

    if strip_year:
        title = re.sub(r'\(\d{4}\)$', '', title).strip()

    title = re.sub(r'\s{2,}', ' ', title).strip()

    return title
