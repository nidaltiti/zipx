﻿# -*- coding: utf-8 -*-

import base64
import re
import datetime as dt
from datetime import timedelta
from resources.lib import helpers
from Cryptodome.Cipher import AES
from resources.lib.util import urlHostName
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, addon
from resources.lib.parser import cParser
from resources.lib import random_ua

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 Edg/149.0.0.0"

SITE_IDENTIFIER = 'tims'
SITE_NAME = 'TimStreams'
SITE_DESC = 'Sports live'
 
URL_MAIN = "https://timst.cfd/api/live-upcoming"
WORKER_URL = "https://nhjjhhjhjjhfjj.pages.dev/fetch"
SECRET_KEY = "8paW@#1UgOw4=A8iT*5we"

SPORT_LIVE = (URL_MAIN, 'showLive')

GENRE_MAP = {
    1: "Football",
    2: "Motorsport",
    3: "MMA (Mixed Martial Arts)",
    4: "FCC (Full-Contact Combat Sports)",
    5: "Boxing",
    6: "Wrestling",
    7: "Basketball",
    8: "American Football",
    9: "Baseball",
    10: "Tennis",
    11: "Hockey",
    12: "Darts",
    13: "Cricket",
    14: "Cycling",
    15: "Rugby",
    16: "Live Shows",
    17: "Others / Uncategorized"
}

def load():
    oGui = cGui()

    oOutputParameterHandler = cOutputParameterHandler()    
    oOutputParameterHandler.addParameter('siteUrl', SPORT_LIVE[0])
    oGui.addDir(SITE_IDENTIFIER, 'showLive', 'بث مباشر', 'sport.png', oOutputParameterHandler)
   
    oGui.setEndOfDirectory()
	
def showLive():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    headers = {
        "Accept": "*/*",
        "Host": urlHostName(sUrl),
        "Referer": "https://timstreams.st/",
        "User-Agent": UA
    }

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.enableCache(False)
    for key, value in headers.items():
        oRequestHandler.addHeaderEntry(key, value)

    sHtmlContent = oRequestHandler.request(jsonDecode=True)
    sEvents = sHtmlContent.get("events", [])

    for e in sEvents:
        if not isinstance(e.get("streams"), list):
            continue

        oOutputParameterHandler = cOutputParameterHandler()

        sTitle = e.get("name")
        sThumb = e.get("logo")
        siteUrl = e.get("url")
        sTime = to_bahrain_time(e.get("time"))
        sStarted = has_started(e.get("time"))
        genre_name = GENRE_MAP.get(e.get("genre"), f"Unknown ({e.get('genre')})")

        sDesc = (
            f"[COLOR orange]الرياضة[/COLOR]\n {genre_name}\n\n"
            f"[COLOR orange]الوقت[/COLOR]\n {sTime}\n\n"
            f"[COLOR orange]الحالة[/COLOR]\n {'بدأت' if sStarted else 'لم تبدأ بعد'}"
        )
        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sDesc', sDesc)

        streams = [
            {
                "name": s.get("name"),
                "url": s.get("url"),
                "vip": bool(s.get("vip")),
            }
            for s in e.get("streams", [])
        ]
        oOutputParameterHandler.addListParameter('streams', streams)

        oGui.addMisc(SITE_IDENTIFIER, 'showLinks', sTitle, 'sport.png', sThumb, sDesc, oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sDesc = oInputParameterHandler.getValue('sDesc')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sStreams = oInputParameterHandler.getList('streams')

    for s in sStreams:
        #if '-embed' in s.get('url'):
        slug = s.get('url') 
        #else:         
        #    slug = extract_slug(s.get('url'))
        siteUrl = s.get('url')
        sTitle = f"{sMovieTitle} [COLOR orange] {s.get('name')} [/COLOR]"
 
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('slug', slug)

        oGui.addMisc(SITE_IDENTIFIER, 'showHosters', sTitle, 'sport.png', sThumb, sDesc, oOutputParameterHandler)     

    oGui.setEndOfDirectory()  

def showHosters():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    slug = oInputParameterHandler.getValue('slug')
    VSlog(slug)
    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    hdrs = {
    "Content-Type": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Host": urlHostName(sUrl),
    "Referer": "https://timstreams.st/", #f"https://{urlHostName(sUrl)}/",
    "Sec-Fetch-Dest": "iframe",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "cross-site",
    "User-Agent": UA
    }

    if '-embed' in slug:
        oParser = cParser()    
        oRequestHandler = cRequestHandler(slug)
        oRequestHandler.enableCache(False)
        for key, value in hdrs.items():
            oRequestHandler.addHeaderEntry(key, value)
        sHtmlContent = oRequestHandler.request()

        sPattern = r'streamUrl = "(https.+?\.m3u8)["\']'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            sHosterUrl = aResult[1][0]

    else:
        from urllib.parse import urlparse, parse_qs
        oRequestHandler = cRequestHandler(slug)
        oRequestHandler.enableCache(False)
        for key, value in hdrs.items():
            oRequestHandler.addHeaderEntry(key, value)
        #oRequestHandler.addJSONEntry('id', slug)
        #oRequestHandler.setRequestType(1)
        sHtmlContent = oRequestHandler.request() #(jsonDecode=True)

        #sHosterUrl = decrypt_url(sHtmlContent.get("url", ""), SECRET_KEY)

        hdrs2 = {
            "Referer": f"https://{urlHostName(slug)}/",
            "User-Agent": UA
        }

        match = re.search(r'var\s+CDN_BASE\s*=\s*["\']([^"\']+)["\']', sHtmlContent)
        if match:
            cdn_base = match.group(1)

            # 2. Extract stream id from embed URL
            parsed = urlparse(slug)
            parts = [p for p in parsed.path.split("/") if p]

            stream_id = None
            qs = parse_qs(parsed.query)
            if "id" in qs:
                stream_id = qs["id"][0]
            else:
                if "embed" in parts:
                    idx = parts.index("embed")
                    if idx + 1 < len(parts):
                        stream_id = parts[idx + 1]
                else:
                    stream_id = parts[-1] if parts else None

            if not stream_id:
                raise ValueError("No stream id found in URL")

            # 3. Construct final m3u8
            sHosterUrl = f"{cdn_base}{stream_id}.m3u8"
            sHosterUrl = sHosterUrl + helpers.append_headers(hdrs2)

        match = re.search(r'source:\s*"([^"]+)"\s*\+\s*ID', sHtmlContent)
        if match:
            base = match.group(1)
            m = re.search(r"[?&]id=([^&]+)", slug)
            if m:
                stream_id = m.group(1)
            else:
                m = re.search(r"/embed/([^/?#]+)", slug)
                if m:
                    stream_id = m.group(1)
                else:
                    stream_id = re.search(r"/([^/?#]+)(?:[?#]|$)", slug).group(1)

            sHosterUrl = f"{base}{stream_id}.m3u8" + helpers.append_headers(hdrs2)

        match = re.search(r'data-signed-url=["\']([^"\']+)["\']', sHtmlContent)
        if match:
            sHosterUrl = match.group(1) + helpers.append_headers(hdrs2)
            
        hdrs2 = {
            "Referer": f"https://{urlHostName(slug)}/",
            "Host": urlHostName(slug),
            "User-Agent": UA
        }

        oParser = cParser() 
        sStart = '<h3>Embed this video</h3>'
        sEnd = '</script>'
        sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

        def decode_obfuscated_js(sHtmlContent):
            arrays = re.findall(r'var\s+[a-zA-Z0-9_]+\s*=\s*\[([^\]]+)\]', sHtmlContent, re.DOTALL)
            consts = re.findall(r'[a-zA-Z0-9_]+\s*=\s*(\d+)', sHtmlContent)
            if not arrays or len(consts) < 2:
                return None

            arr = [int(x.strip()) for x in arrays[0].split(',') if x.strip().isdigit()]

            xor_const, sub_const = int(consts[0]), int(consts[1])

            def run_decode(xor_c, sub_c):
                return "".join(chr(((val ^ xor_c) - sub_c + 256) % 256) for val in arr)

            decoded1 = run_decode(xor_const, sub_const)
            decoded2 = run_decode(sub_const, xor_const)

            for decoded in (decoded1, decoded2):
                if "SIGNED_URL" in decoded:
                    return decoded

            return decoded1

        decoded = decode_obfuscated_js(sHtmlContent)
        if decoded:
            match = re.search(r'var\s+SIGNED_URL\s*=\s*["\']([^"\']+)["\']', decoded)
            if match:
                hdrs3 = {
                    "Referer": f"https://{urlHostName(slug)}/",
                    "Host": urlHostName(match.group(1)),
                    "User-Agent": UA
                }
                sHosterUrl = match.group(1) + helpers.append_headers(hdrs3)

            match = re.search(r'url=["\']([^"\']+)["\']', decoded)
            if match:
                hdrs3 = {
                    "Referer": f"https://{urlHostName(slug)}/",
                    "Host": urlHostName(match.group(1)),
                    "User-Agent": UA
                }
                sHosterUrl = match.group(1) + helpers.append_headers(hdrs3)

    if useDialog:
        results.append((SITE_NAME, sHosterUrl, 'direct_link'))
    else:
        oHoster = cHosterGui().getHoster('direct_link')
        if oHoster:
            oHoster.setDisplayName(sMovieTitle)
            oHoster.setFileName(sMovieTitle)
            cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)    

    if useDialog and results:
        if any(len(r) == 3 for r in results):
            for r in results:
                fixedHoster = r[2]
            select_results = [(r[0], r[1]) for r in results]
            cHosterGui().selectHoster(select_results, sMovieTitle, SITE_NAME, sThumb, fixedHoster=fixedHoster)

    else:
        oGui.setEndOfDirectory()  

def decrypt_url(b64data, key_str):
    raw = base64.b64decode(b64data)
    iv = raw[:12]
    ciphertext = raw[12:-16]
    tag = raw[-16:]
    key = key_str.encode("utf-8")[:16]
    cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
    decrypted = cipher.decrypt_and_verify(ciphertext, tag)
    return decrypted.decode("utf-8")

def extract_slug(embed_url):
    m = re.search(r"/embed/([^/?#]+)", embed_url)
    return m.group(1) if m else None

def to_bahrain_time(et_str, as_string=True):
    try:
        if not et_str:
            return None
        dt_et = dt.datetime.strptime(et_str, "%Y-%m-%dT%H:%M")
        dt_local = dt_et + timedelta(hours=7)
        return dt_local.strftime("%Y-%m-%d %H:%M") if as_string else dt_local
    except:
        return et_str
def has_started(et_str):
    try:
        if not et_str:
            return False
        dt_local = to_bahrain_time(et_str, as_string=False)
        return dt.datetime.now() >= dt_local
    except:
        return True

