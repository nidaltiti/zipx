﻿# -*- coding: utf-8 -*-

import re
from urllib.parse import quote_plus
# from Cryptodome.Cipher import AES
# from Cryptodome.Util.Padding import unpad
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.parser import cParser
from resources.lib.comaddon import progress, VSlog, siteManager, addon
from resources.lib.util import urlHostName

SITE_IDENTIFIER = 'sflix'
SITE_NAME = 'sFlix'
SITE_DESC = 'english vod'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)
multiDecryptAPI = "https://enc-dec.app/api"

MOVIE_EN = (f'{URL_MAIN}/movie', 'showMovies')
KID_MOVIES = (f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=404&sort=updated_date', 'showMovies')
MOVIE_GENRES = (True, 'moviesGenres')
SERIE_EN = (f'{URL_MAIN}/tv', 'showSeries')
ANIM_NEWS = (f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=404&sort=updated_date', 'showSeries')
SERIE_GENRES = (True, 'seriesGenres')

URL_SEARCH_MOVIES = (f'{URL_MAIN}/browser?keyword=', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}/browser?keyword=', 'showSeries')
FUNCTION_SEARCH = 'showMovies'
	
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}/home')
    oGui.addDir(SITE_IDENTIFIER, 'showHome', 'محتوى الصفحة الرئيسية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام انيميشن', 'anim.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات انيميشن', 'anime.png', oOutputParameterHandler)  

    oOutputParameterHandler.addParameter('siteUrl', SERIE_GENRES[0])
    oGui.addDir(SITE_IDENTIFIER, SERIE_GENRES[1], 'المسلسلات (الأنواع)', 'mslsl.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_GENRES[0])
    oGui.addDir(SITE_IDENTIFIER, MOVIE_GENRES[1], 'الأفلام (الأنواع)', 'film.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSearch():
    oGui = cGui()
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f"{URL_MAIN}/browser?keyword={sSearchText.replace(' ','-')}"
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return  
    
def showSeriesSearch():
    oGui = cGui()
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f"{URL_MAIN}/browser?keyword={sSearchText.replace(' ','-')}"
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return  

def seriesGenres():
    oGui = cGui()

    liste = []
    liste.append(['Action', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=14&sort=updated_date'])
    liste.append(['Adventure', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=109&sort=updated_date'])
    liste.append(['Animated', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=404&sort=updated_date'])
    liste.append(['Biography', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=312&sort=updated_date'])
    liste.append(['Comedy', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=1&sort=updated_date'])
    liste.append(['Crime', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=126&sort=updated_date'])
    liste.append(['Drama', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=12&sort=updated_date'])
    liste.append(['Documentary', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=92&sort=updated_date'])
    liste.append(['Family', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=78&sort=updated_date'])
    liste.append(['Fantasy', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=53&sort=updated_date'])
    liste.append(['History', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=239&sort=updated_date'])
    liste.append(['Horror', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=2&sort=updated_date'])
    liste.append(['Music', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=1809&sort=updated_date'])
    liste.append(['Mystery', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=154&sort=updated_date'])
    liste.append(['Romance', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=44&sort=updated_date'])
    liste.append(['Sci-Fi', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=162&sort=updated_date'])
    liste.append(['Thriller', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=13&sort=updated_date'])
    liste.append(['War', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=436&sort=updated_date'])
    liste.append(['Western', f'{URL_MAIN}/browser?type%5B%5D=tv&genre%5B%5D=1443&sort=updated_date'])

    for sTitle, sUrl in liste:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oGui.addDir(SITE_IDENTIFIER, 'showSeries', sTitle, 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def moviesGenres():
    oGui = cGui()

    liste = []
    liste.append(['Action', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=14&sort=updated_date'])
    liste.append(['Adventure', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=109&sort=updated_date'])
    liste.append(['Animated', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=404&sort=updated_date'])
    liste.append(['Biography', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=312&sort=updated_date'])
    liste.append(['Comedy', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=1&sort=updated_date'])
    liste.append(['Crime', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=126&sort=updated_date'])
    liste.append(['Drama', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=12&sort=updated_date'])
    liste.append(['Documentary', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=92&sort=updated_date'])
    liste.append(['Family', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=78&sort=updated_date'])
    liste.append(['Fantasy', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=53&sort=updated_date'])
    liste.append(['History', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=239&sort=updated_date'])
    liste.append(['Horror', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=2&sort=updated_date'])
    liste.append(['Music', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=1809&sort=updated_date'])
    liste.append(['Mystery', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=154&sort=updated_date'])
    liste.append(['Romance', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=44&sort=updated_date'])
    liste.append(['Sci-Fi', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=162&sort=updated_date'])
    liste.append(['Thriller', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=13&sort=updated_date'])
    liste.append(['War', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=436&sort=updated_date'])
    liste.append(['Western', f'{URL_MAIN}/browser?type%5B%5D=movie&genre%5B%5D=1443&sort=updated_date'])

    for sTitle, sUrl in liste:
        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', sUrl)
        oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'genres.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showHome():
    oGui = cGui()
      
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = 'class="section-name">Trending</span>'
    sEnd = '</section>'
    sHtmlContent0 = oParser.abParse(sHtmlContent, sStart, sEnd)

    oGui.addText(SITE_IDENTIFIER, u'\u2193' + '[COLOR gold]Trending[/COLOR]', 'pop.png')

    sPattern = r'<div class="inner">.+?href="([^"]+)".+?data-src="([^"]+)"\s+alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent0, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            
            sTitle = aEntry[2]
            siteUrl = f'{URL_MAIN}{aEntry[0]}'
            sThumb = aEntry[1].replace('@300','')
            sDesc = ''
            sYear = ''

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)

            if "/tv-"  in aEntry[0]:
                oGui.addTV(SITE_IDENTIFIER, 'showSeasons', f'[COLOR lightcoral]TV-[/COLOR] {sTitle}', '', sThumb, sDesc, oOutputParameterHandler)
            else:
                oGui.addTV(SITE_IDENTIFIER, 'showHosters', f'[COLOR yellow]Movie-[/COLOR] {sTitle}', '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)

    sStart = 'class="section-name">Latest Movies</h2>'
    sEnd = '</section>'
    sHtmlContent0 = oParser.abParse(sHtmlContent, sStart, sEnd)

    oGui.addText(SITE_IDENTIFIER, u'\u2193' + '[COLOR gold]Latest Movies[/COLOR]', 'film.png')

    sPattern = r'<div class="inner">.+?href="([^"]+)".+?data-src="([^"]+)"\s+alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent0, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            
            sTitle = aEntry[2]
            siteUrl = f'{URL_MAIN}{aEntry[0]}'
            sThumb = aEntry[1].replace('@300','')
            sDesc = ''
            sYear = ''

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)

            oGui.addTV(SITE_IDENTIFIER, 'showHosters', f'[COLOR yellow]Movie-[/COLOR] {sTitle}', '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)

    sStart = 'class="section-name">Latest TV-Shows</h2>'
    sEnd = '</section>'
    sHtmlContent0 = oParser.abParse(sHtmlContent, sStart, sEnd)

    oGui.addText(SITE_IDENTIFIER, u'\u2193' + '[COLOR gold]Latest TV Shows[/COLOR]', 'mslsl.png')

    sPattern = r'<div class="inner">.+?href="([^"]+)".+?data-src="([^"]+)"\s+alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent0, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            
            sTitle = aEntry[2]
            siteUrl = f'{URL_MAIN}{aEntry[0]}'
            sThumb = aEntry[1].replace('@300','')
            sDesc = ''
            sYear = ''

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)

            oGui.addTV(SITE_IDENTIFIER, 'showSeasons', f'[COLOR lightcoral]TV-[/COLOR] {sTitle}', '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)

    oGui.setEndOfDirectory()  

def showMovies(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('Referer', URL_MAIN)
    sHtmlContent = oRequestHandler.request()

    sStart = '<div class="container">'
    sEnd = '</main>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'<div class="item">.+?href="([^"]+)".+?data-src="([^"]+)"\s+alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            if "/tv-"  in aEntry[0]:
                continue

            sTitle = aEntry[2]
            siteUrl = f'{URL_MAIN}{aEntry[0]}#ep=1'
            sThumb = aEntry[1].replace('@300','')
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sDesc', sDesc)
            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
 
    if not sSearch:
        oGui.setEndOfDirectory()  

def showSeries(sSearch = ''):
    oGui = cGui()
    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = '<div class="container">'
    sEnd = '</main>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'<div class="item">.+?href="([^"]+)".+?data-src="([^"]+)"\s+alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            if "/movie-"  in aEntry[0]:
                continue

            sTitle = aEntry[2]
            siteUrl = f'{URL_MAIN}{aEntry[0]}'
            sThumb = aEntry[1]
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sDesc', sDesc)

            oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showSeries', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
 
    if not sSearch:
        oGui.setEndOfDirectory()  

def showSeasons():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'data-id="([^"]+)" data-live='
    aResult = re.findall(sPattern, sHtmlContent)
    if aResult:
        eid = aResult[0]
        enc_target_id = encrypt(eid)
        episodes_url = f"{URL_MAIN}/ajax/episodes/list?id={eid}&_={enc_target_id}"
        oRequestHandler = cRequestHandler(episodes_url)
        oRequestHandler.addHeaderEntry('Referer', sUrl)
        episodes_resp = oRequestHandler.request(jsonDecode=True)
        
        episodes_html = episodes_resp.get("result", "")

        season_re = re.compile(
            r'<ul[^>]*data-season="(?P<season>\d+)"[^>]*>(?P<body>.*?)</ul>',
            re.S
        )

        for s in season_re.finditer(episodes_html):
            oOutputParameterHandler = cOutputParameterHandler() 
            sSeason = int(s.group("season"))
            sTitle = f'{sMovieTitle} S{sSeason}'
            siteUrl = f'{sUrl}?season={sSeason}'
            sThumb = sThumb
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sDesc', sDesc)

            oGui.addSeason(SITE_IDENTIFIER, 'showEps', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    oGui.setEndOfDirectory()  
        
def showEps():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    
    sUrl, sSeason = sUrl.split('?season=')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'data-id="([^"]+)" data-live='
    aResult = re.findall(sPattern, sHtmlContent)
    if aResult:
        eid = aResult[0]
        enc_target_id = encrypt(eid)
        episodes_url = f"{URL_MAIN}/ajax/episodes/list?id={eid}&_={enc_target_id}"
        oRequestHandler = cRequestHandler(episodes_url)
        oRequestHandler.addHeaderEntry('Referer', sUrl)
        episodes_resp = oRequestHandler.request(jsonDecode=True)
        
        episodes_html = episodes_resp.get("result", "")

        season_re = re.compile(
            r'<ul[^>]*data-season="(?P<season>\d+)"[^>]*>(?P<body>.*?)</ul>',
            re.S
        )

        episode_block_re = re.compile(
            r'<a[^>]*>(.*?)</a>',
            re.S
        )

        attr = {
            "num": re.compile(r'num="(\d+)"'),
            "eid": re.compile(r'eid="([^"]+)"'),
            "slug": re.compile(r'slug="([^"]+)"'),
            "date": re.compile(r'title="(\d{4}-\d{2}-\d{2})"'),
            "url": re.compile(r'href="([^"]+)"'),
            "title": re.compile(r'<span>\s*([^<]+)\s*</span>\s*</a>')
        }

        result = []

        for s in season_re.finditer(episodes_html):
            season_number = int(s.group("season"))
            body = s.group("body")

            episodes = []

            for a in re.finditer(r'<a[^>]*>.*?</a>', body, re.S):
                tag = a.group(0)

                num = attr["num"].search(tag)
                if not num:
                    continue

                episodes.append({
                    "episode_number": int(num.group(1)),
                    "eid": attr["eid"].search(tag).group(1),
                    "slug": attr["slug"].search(tag).group(1),
                    "air_date": attr["date"].search(tag).group(1),
                    "title": re.findall(r'<span>([^<]+)</span>', tag)[-1].strip(),
                    "url": attr["url"].search(tag).group(1)
                })

            result.append({
                "season": season_number,
                "episodes": episodes
            })




        season_2_episodes = next(
            (s["episodes"] for s in result if s["season"] == int(sSeason)),
            []
        )

        for sEpisode in season_2_episodes:
            sTitle = f'{sMovieTitle} E{sEpisode["episode_number"]:02d} [COLOR coral]{sEpisode["title"]}[/COLOR]'
            siteUrl = sEpisode["url"]
            eID = sEpisode["eid"]
            sThumb = sThumb 
            sDesc = sEpisode["air_date"]

            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('eID', eID)
            oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, sThumb, sThumb, sDesc, oOutputParameterHandler)
       
    oGui.setEndOfDirectory() 

def showHosters(season: int = 1, episode: int = 1):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    eid = oInputParameterHandler.getValue('eID')
    
    if not eid:
        oRequestHandler = cRequestHandler(sUrl)
        oRequestHandler.addHeaderEntry('Referer', sUrl.split('#')[0])
        sHtmlContent = oRequestHandler.request()

        sPattern = r'data-id="([^"]+)" data-live='
        aResult = re.findall(sPattern, sHtmlContent)
        if aResult:
            eid = aResult[0]

            enc_target_id = encrypt(eid)
            episodes_url = f"{URL_MAIN}/ajax/episodes/list?id={eid}&_={enc_target_id}"
            oRequestHandler = cRequestHandler(episodes_url)
            oRequestHandler.addHeaderEntry('Referer', sUrl)
            episodes_resp = oRequestHandler.request(jsonDecode=True)
            
            episodes_html = episodes_resp.get("result", "")
            episodes_obj = parse_html(episodes_html)
            result = episodes_obj.get("result", {})

            season_obj = result.get(str(season), {})
            episode_obj = season_obj.get(str(episode), {})
            eid = episode_obj.get("eid")

    enc_target_id = encrypt(eid)
    servers_url = f"{URL_MAIN}/ajax/links/list?eid={eid}&_={enc_target_id}"
    oRequestHandler = cRequestHandler(servers_url)
    oRequestHandler.addHeaderEntry('Referer', sUrl)
    shtml = oRequestHandler.request(jsonDecode=True)
    servers_html = shtml.get("result", "")

    servers_obj = parse_html(servers_html)
    servers = extract_all_servers(servers_obj)
    for server in servers:
        lid = server["lid"]
        sHost = server["name"]
        enc_lid = encrypt(lid)

        oRequestHandler = cRequestHandler(f"{URL_MAIN}/ajax/links/view?id={lid}&_={enc_lid}")
        shtml = oRequestHandler.request(jsonDecode=True)
        encrypted_embed = shtml.get("result", "")
        if not encrypted_embed:
            continue

        embed_url = decrypt(encrypted_embed)
        if URL_MAIN in embed_url:
            oRequestHandler = cRequestHandler(sUrl)
            oRequestHandler.addHeaderEntry('Referer', sUrl.split('#')[0])
            embed_html = oRequestHandler.request()
            iframe_match = re.search(r'<iframe[^>]+src="([^"]+)"', embed_html)
            if iframe_match:
                embed_url = iframe_match.group(1)

        oOutputParameterHandler = cOutputParameterHandler()
        sTitle = f'{sMovieTitle} [COLOR coral]{sHost}[/COLOR]'
        oOutputParameterHandler.addParameter('siteUrl', embed_url)
        oOutputParameterHandler.addParameter('referer', sUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)

        oGui.addLink(SITE_IDENTIFIER, 'showHostersLinks', sTitle, sThumb, sTitle, oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showHostersLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    sHosterUrl = sUrl
    oHoster = cHosterGui().getHoster('rapidshare')
    if oHoster:
        oHoster.setDisplayName(sMovieTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()

def __checkForNextPage(sHtmlContent):
    oParser = cParser()
    sPattern = r'<li class="page-item active".+?<a class="page-link" href="([^"]+)"'	
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        return aResult[1][0]

    return False


def encrypt(content_id: str) -> str:
    oRequestHandler = cRequestHandler(f"{multiDecryptAPI}/enc-movies-flix?text={content_id}")
    data = oRequestHandler.request(jsonDecode=True)

    return data.get("result", "")

def decrypt(text: str) -> str:
    oRequestHandler = cRequestHandler(f"{multiDecryptAPI}/dec-movies-flix")
    oRequestHandler.addJSONEntry('text', text)
    oRequestHandler.setRequestType(1)
    data = oRequestHandler.request(jsonDecode=True)

    return data.get("result", {}).get("url", "")

def parse_html(html: str) -> dict:
    oRequestHandler = cRequestHandler(f"{multiDecryptAPI}/parse-html")
    oRequestHandler.addJSONEntry('text', html)
    oRequestHandler.setRequestType(1)

    try:
        return oRequestHandler.request(jsonDecode=True)
    except Exception:
        clean = oRequestHandler.request().strip('"').replace('\\"', '"').replace('\\\\', '\\')
        try:
            import json
            return json.loads(clean)
        except Exception:
            return {}

def extract_all_servers(root: dict):
    servers = []
    try:
        result = root.get("result", {})
        default_obj = result.get("default", {})
        for key, server_node in default_obj.items():
            lid = server_node.get("lid")
            name = server_node.get("name")
            if lid and name:
                servers.append({"name": name, "lid": lid})
    except Exception as e:
        print("Error extracting servers:", e)
    return servers