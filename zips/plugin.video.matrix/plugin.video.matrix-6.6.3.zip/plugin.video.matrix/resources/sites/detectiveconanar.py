﻿# -*- coding: utf-8 -*-

import re, time
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, siteManager, VSlog, addon
from resources.lib.util import cUtil
from resources.lib.parser import cParser
 
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0"

SITE_IDENTIFIER = 'detectiveconanar'
SITE_NAME = 'Detectiveconanar'
SITE_DESC = 'arabic vod'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)
ANIM_NEWS = (f'{URL_MAIN}episodes/', 'showSeries')
ANIM_MOVIES = (f'{URL_MAIN}movies/', 'showMovies')
 
def load():
    addons = addon()
    oGui = cGui()

    if (addons.getSetting('hoster_connan_username') == '') and (addons.getSetting('hoster_connan_password') == ''):
        oGui.addText(SITE_IDENTIFIER, '[COLOR %s]%s[/COLOR]' % ('red', 'الموقع يطلب حساب لاظهار الروابط'))

        oOutputParameterHandler = cOutputParameterHandler()
        oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
        oGui.addDir(SITE_IDENTIFIER, 'opensetting', addons.VSlang(30023), 'none.png', oOutputParameterHandler)
        oGui.setEndOfDirectory()
    else:
        oOutputParameterHandler = cOutputParameterHandler()   
        oOutputParameterHandler.addParameter('siteUrl', ANIM_MOVIES[0])
        oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام انمي', 'anime.png', oOutputParameterHandler)
        
        oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}tvshows/')
        oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات انمي', 'anime.png', oOutputParameterHandler)

        oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
        oGui.addDir(SITE_IDENTIFIER, 'showEpisodes', 'احدث الحلقات', 'anime.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()
   
def showMovies(sSearch = ''):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    cook = account_login()

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addCookiesEntry(cook)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'class="film-poster">\s*<img data-src="([^"]+)".+?alt="([^"]+)".+?<a href="([^"]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            sTitle = aEntry[1]       
            sDesc = '' 
            siteUrl = aEntry[2]
            sThumb = aEntry[0]

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('cook', cook)

            oGui.addMisc(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
        
        progress_.VSclose(progress_)
 
        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showMovies', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)
 
    if not sSearch:
        oGui.setEndOfDirectory()

def showSeries(sSearch = ''):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    json_data = [
                {
                    "name": "يايبا – أسطورة الساموراي",
                    "link": f"{URL_MAIN}tvshows/yaiba-samurai-legend/",
                    "poster": f"{URL_MAIN}wp-content/uploads/2025/04/cxD3FQP4hDU5hSABwdQCvGrrnz6-185x278.jpg"
                },
                {
                    "name": "المتحري كونان مدبلج للعربية",
                    "link": f"{URL_MAIN}tvshows/%d8%a7%d9%84%d9%85%d8%aa%d8%ad%d8%b1%d9%8a-%d9%83%d9%88%d9%86%d8%a7%d9%86-%d9%85%d8%af%d8%a8%d9%84%d8%ac-%d9%84%d9%84%d8%b9%d8%b1%d8%a8%d9%8a%d8%a9/",
                    "poster": f"{URL_MAIN}wp-content/uploads/2024/01/DCPOSTER-DUB-copy-2-1-185x278.png"
                },
                {
                    "name": "المتحري كونان – المجرم هانزوا سان",
                    "link": f"{URL_MAIN}tvshows/detective-conan-the-culprit-hanzawa/",
                    "poster": f"{URL_MAIN}wp-content/uploads/2022/10/lxxh5cjBYZcymABOJWTlWnujakH-185x278.jpg"
                },
                {
                    "name": "المتحري كونان – يوميات زيرو",
                    "link": f"{URL_MAIN}tvshows/detective-conan-zeros-tea-time/",
                    "poster": f"{URL_MAIN}wp-content/uploads/2022/04/shjOlyxLSNIBL7jsPFuaDxArTH1-185x278.jpg"
                },
                {
                    "name": "أوفا المتحري كونان",
                    "link": f"{URL_MAIN}tvshows/ova/",
                    "poster": f"{URL_MAIN}wp-content/uploads/2021/06/1o2o7RELi8rtRrTh8iHYkprpDrn-185x278.jpg"
                },
                {
                    "name": "الإصدارات الخاصة",
                    "link": f"{URL_MAIN}tvshows/%d9%8d%d9%8fsps/",
                    "poster": f"{URL_MAIN}wp-content/uploads/2021/06/mLxiiTOOSyelQAb8SY0s39lFBa9-185x278.jpg"
                },
                {
                    "name": "Magic Kaito 1412",
                    "link": f"{URL_MAIN}tvshows/magic-kaito-1412/",
                    "poster": f"{URL_MAIN}wp-content/uploads/2021/06/uEUset1GJx7QvGyWsSMecRcysJp-185x278.jpg"
                },
                {
                    "name": "Magic Kaito: Kid the Phantom Thief",
                    "link": f"{URL_MAIN}tvshows/magic-kaito-kid-the-phantom-thief/",
                    "poster": f"{URL_MAIN}wp-content/uploads/2021/06/lK0VNYGpHgLjsh140BKmfnGOSWq-185x278.jpg"
                },
                {
                    "name": "قصص قوشو القصيرة",
                    "link": f"{URL_MAIN}tvshows/%d9%90ag-shortstories/",
                    "poster": f"{URL_MAIN}wp-content/uploads/2021/06/a8RLI9LWX0aheyfK8ohF6xxwrKy-185x278.jpg"
                },
                {
                    "name": "المتحري كونان",
                    "link": f"{URL_MAIN}tvshows/detectiveconan/",
                    "poster": f"{URL_MAIN}wp-content/uploads/2021/06/9ve6LW4ltMMpp9WjoR4MGViOp9V-185x278.jpg"
                }
                ]

    if json_data:
        total = len(json_data)
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()
        
        for aEntry in json_data:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break

            siteUrl = aEntry["link"]
            sThumb = aEntry["poster"]
            sDesc = ''
            sTitle = aEntry["name"].replace('الموسم ','S').replace('الحلقة ','E').replace('للعربية','').replace('مدبلجة','مدبلج').replace('مترجمة','مترجم').replace('عربي','').replace('أنمي','')

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
			
            oGui.addAnime(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)

    if not sSearch:
        oGui.setEndOfDirectory()

def showSeasons():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser() 
    cook = account_login()

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addCookiesEntry(cook)
    sHtmlContent = oRequestHandler.request()

    sStart = 'class="os-list">'
    sEnd = '</section>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'href="([^"]+)"\s+class="os-item"\s+title="([^"]+)".+?url\(([^)]+)\);'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler()  
        for aEntry in aResult[1]:
            
            sTitle = cUtil().CleanSeriesName(aEntry[1])
            siteUrl = aEntry[0]
            sThumb = aEntry[2]
            sDesc = ""
 
            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            
            oGui.addSeason(SITE_IDENTIFIER, 'showSeasonEps', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    oGui.setEndOfDirectory() 

def showSeasonEps(sSearch = ''):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser() 
    cook = account_login()

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addCookiesEntry(cook)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'data-number="([^"]+)".+?href="([^"]+)".+?class=".+?">(.+?)</div>'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            siteUrl = aEntry[1]
            sThumb = sThumb
            sDesc = ''
            sTitle = f'{sMovieTitle} E{aEntry[2]}'

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
			
            oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)

    oGui.setEndOfDirectory()

def showEpisodes(sSearch = ''):
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    cook = account_login()

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addCookiesEntry(cook)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'class="film-poster">.+?data-src="([^"]+)".+?alt="([^"]+)".+?<a href="([^"]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            siteUrl = aEntry[2]
            sThumb = aEntry[0]
            sDesc = ''
            sTitle = aEntry[1].replace('الموسم ','S').replace('الحلقة ','E').replace('للعربية','').replace('مدبلجة','مدبلج').replace('مترجمة','مترجم').replace('عربي','').replace('أنمي','')

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
			
            oGui.addMisc(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
        sNextPage = __checkForNextPage(sHtmlContent)
        if sNextPage:
            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl', sNextPage)
            oGui.addDir(SITE_IDENTIFIER, 'showEpisodes', '[COLOR teal]Next >>>[/COLOR]', 'next.png', oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()

def __checkForNextPage(sHtmlContent):
    oParser = cParser()
    sPattern = r'<a title="التالي" class="page-link" href="([^"]+)'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        return aResult[1][0]
    
    else:
        sPattern = r'<span class="current">.+?href=(.+?) class='
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            return aResult[1][0].replace("'","")

    return False

def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()    
    cook = account_login()
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addCookiesEntry(cook)
    oRequestHandler.addHeaderEntry('accept', "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7")
    oRequestHandler.addHeaderEntry('content-type', "application/x-www-form-urlencoded")
    oRequestHandler.addHeaderEntry('user-agent', UA)
    oRequestHandler.addHeaderEntry('referer', f"{URL_MAIN}wp-login.php")
    sHtmlContent = oRequestHandler.request()      

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    sPattern = r'data-embed="([^"]+)".+?class="btn">(.+?)</a>'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        for aEntry in aResult[1]:
            if 'Blog' in aEntry[1]:
                continue

            sLink = aEntry[0]
            if sLink.startswith('//'):
               sLink = f'http:{sLink}'
            
            try:
                sQual = re.search(r"\(([^)]+)\)", aEntry[1]).group(1)
            except:
                sQual = aEntry[1]

            sDisplayTitle = f'{sMovieTitle} [{sQual}]'
            sHosterUrl = f'{sLink}|Referer={URL_MAIN}'
            results.append((sQual, sHosterUrl))

    useDialog = addon().getSetting('HosterDialog') == 'true'
    if useDialog:
        cHosterGui().selectHoster(results, sMovieTitle, SITE_NAME, sThumb, fixedHoster='jimmy')

    else:
        for sQual, sHosterUrl in results:
            oHoster = cHosterGui().getHoster('jimmy')
            if oHoster:
                oHoster.setDisplayName(sDisplayTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

        oGui.setEndOfDirectory()

def account_login(force=False):
    # tempfix
    # return 'wpdiscuz_nonce_e619744f790045bf4afa8104daabef09=9daa7d5c3a; wordpress_test_cookie=WP%20Cookie%20check; wordpress_logged_in_e619744f790045bf4afa8104daabef09=MatrixUser%7C1805760570%7CZr5Pc0PcTFgH3XEcbdTXj1grATOf5uTlPhQuOk1xpzh%7C330c647f86175f50c5ea566d4c41d5b7826f2f41ecf2b6285bdcf1dfbfe9f0dc'
    import time
    addons = addon()
    aUser = addons.getSetting('hoster_connan_username')
    aPass = addons.getSetting('hoster_connan_password')

    try:
        last_gen = int(addons.getSetting('last_connan_cookie_create'))
    except Exception:
        last_gen = 0

    if not addons.getSetting('last_connan_cookie') or last_gen < (time.time() - (2 * 60 * 60)) or force:

        oRequestHandler = cRequestHandler(f"{URL_MAIN}")
        oRequestHandler.addHeaderEntry('accept', "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7")
        oRequestHandler.addHeaderEntry('user-agent', UA)
        response = oRequestHandler.request()  

        oRequestHandler = cRequestHandler(f"{URL_MAIN}wp-login.php")
        oRequestHandler.addHeaderEntry('accept', "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7")
        oRequestHandler.addHeaderEntry('user-agent', UA)
        response = oRequestHandler.request()  

        oRequestHandler = cRequestHandler(f"{URL_MAIN}wp-login.php")
        oRequestHandler.addHeaderEntry('accept', "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7")
        oRequestHandler.addHeaderEntry('user-agent', UA)
        oRequestHandler.addParameters('log', aUser)
        oRequestHandler.addParameters('pwd', aPass)
        oRequestHandler.addParameters('redirect_to', f"{URL_MAIN}wp-admin/")
        oRequestHandler.addParameters('testcookie', "1")
        oRequestHandler.setRequestType(1)
        response = oRequestHandler.request()  

        cook = oRequestHandler.GetCookies()

        addons.setSetting('last_connan_cookie', cook)
        addons.setSetting('last_connan_cookie_create', str(int(time.time())))

        return cook
    else:
        return addons.getSetting('last_connan_cookie')

def opensetting():
    addon().openSettings()