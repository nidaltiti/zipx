﻿# -*- coding: utf-8 -*-

import binascii
import json
import time
from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import unpad

from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, siteManager, addon
from resources.lib.util import Quote, cUtil, urlHostName, Unquote
from resources.lib import random_ua

UA = random_ua.get_pc_ua()

SITE_IDENTIFIER = 'carateen'
SITE_NAME = 'Carateen'
SITE_DESC = 'arabic cartoon vod'
 
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

KID_MOVIES = (f'{URL_MAIN}api/tvshows', 'showMovies')
KID_CARTOON = (f'{URL_MAIN}api/tvshows', 'showSeries')

URL_SEARCH = ('', 'showMovies')
URL_SEARCH_MOVIES = ('', 'showMovies')
URL_SEARCH_SERIES = ('', 'showSeries')
FUNCTION_SEARCH = 'showSeries'

KEY = b"7annaba3l_loves_crypto_safe_key!"
HEADERS = {
    "Accept": "application/json, text/plain, */*",
    "Host": urlHostName(URL_MAIN),
    "Referer": URL_MAIN,
    "User-Agent": UA,
    "X-Carateen-Client": "web-frontend-v1"
    }

def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSearchMovies', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', KID_CARTOON[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSearchSeries', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام', 'crtoon.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات', 'crtoon.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}api/sp/tvshows')
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات SpaceToon', 'crtoon.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}api/sp/tvshows')
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام SpaceToon', 'crtoon.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}api/sp/recentEpisodes')
    oGui.addDir(SITE_IDENTIFIER, 'showEpisodes', 'أجدد الحلقات', 'crtoon.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSearchMovies():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        showMovies(sSearchText)
        oGui.setEndOfDirectory()
        return

def showSearchSeries():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        showSeries(sSearchText)
        oGui.setEndOfDirectory()
        return
  
def showMovies(sSearch = ''):
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    if sUrl is False:
        sUrl = f'{URL_MAIN}api/tvshows'
        sSearch = Unquote(sSearch)

    oRequestHandler = cRequestHandler(sUrl)
    for key, value in HEADERS.items():
        oRequestHandler.addHeaderEntry(key, value)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    iv_hex = sHtmlContent["iv"]
    ciphertext_hex = sHtmlContent["encryptedData"]

    videos = decrypt_payload(ciphertext_hex, iv_hex)

    oOutputParameterHandler = cOutputParameterHandler()
    for item in videos:

        if item.get("is_movie", "") == 0 or 'مسلسل' in item.get("category", ''):
            continue
        if sSearch:
            if sSearch.lower() not in (item.get("title") or item.get("name", "")).lower():
                continue

        sTitle = cUtil().CleanMovieName(item.get("title") or item.get("name"))
        seriesID = item.get("id", "")
        if '/sp/' in sUrl:
            siteUrl = f'{URL_MAIN}api/sp/episodes?id={seriesID}'
        else:
            siteUrl = f'{URL_MAIN}api/episodes?id={seriesID}|movie'
        sThumb = item.get("poster_cover") or item.get("cover_full_path")
        if not sThumb.startswith('http'):
            sThumb = f'{URL_MAIN}assets/img/posters/{sThumb}'
        sYear = item.get("release_year", "")
        sDesc = item.get("description") or item.get("pref")

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sYear', sYear)
        oOutputParameterHandler.addParameter('sDesc', sDesc)

        oGui.addMovie(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if not sSearch:
        oGui.setEndOfDirectory()

			
def showSeries(sSearch = ''):
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    if sUrl is False or sUrl is None:
        sUrl = f'{URL_MAIN}api/sp/tvshows'
        sSearch = Unquote(sSearch)

    oRequestHandler = cRequestHandler(sUrl)
    for key, value in HEADERS.items():
        oRequestHandler.addHeaderEntry(key, value)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    iv_hex = sHtmlContent["iv"]
    ciphertext_hex = sHtmlContent["encryptedData"]

    videos = decrypt_payload(ciphertext_hex, iv_hex)

    oOutputParameterHandler = cOutputParameterHandler()
    for item in videos:

        if item.get("is_movie", "") == 1 or 'فيلم' in item.get("category", ''):
            continue
        
        if sSearch:
            if sSearch.lower() not in (item.get("title") or item.get("name", "")).lower():
                continue

        sTitle = cUtil().CleanMovieName(item.get("title") or item.get("name"))
        seriesID = item.get("id", "")
        if '/sp/' in sUrl:
            siteUrl = f'{URL_MAIN}api/sp/episodes?id={seriesID}'
        else:
            siteUrl = f'{URL_MAIN}api/episodes?id={seriesID}'
        sThumb = item.get("poster_cover") or item.get("cover_full_path")
        if not sThumb.startswith('http'):
            sThumb = f'{URL_MAIN}assets/img/posters/{sThumb}'
        sYear = item.get("release_year", "")
        sDesc = item.get("description") or item.get("pref")

        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sYear', sYear)
        oOutputParameterHandler.addParameter('sDesc', sDesc)

        oGui.addTV(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
 
    if not sSearch:
        oGui.setEndOfDirectory()

def showEpisodes():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    sDesc = oInputParameterHandler.getValue('sDesc')
    if sUrl.endswith('|movie'):
        sUrl = sUrl.replace('|movie', '')
        sType = 'movie'
    else:
        sType = 'series'

    oRequestHandler = cRequestHandler(sUrl)
    for key, value in HEADERS.items():
        oRequestHandler.addHeaderEntry(key, value)
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    iv_hex = sHtmlContent["iv"]
    ciphertext_hex = sHtmlContent["encryptedData"]

    sEpisodes = decrypt_payload(ciphertext_hex, iv_hex)

    for sEpi in sEpisodes:
        oOutputParameterHandler = cOutputParameterHandler()
        
        seriesID = sEpi.get("id", "")
        if sType == 'movie':
            sTitle = f'{sMovieTitle} [COLOR yellow]{sEpi.get("title", "")}[/COLOR]'
            siteUrl = f'{URL_MAIN}api/episode?episodeId={seriesID}&showId={sUrl.split("episodes?id=")[1]}'
        elif  '/sp' not in sUrl:
            if sMovieTitle is False or sMovieTitle is None:
                sMovieTitle = sEpi.get("name", "")
            sENumber = sEpi.get("title", "")
            if '. ' in sENumber:
                sENumber = sENumber.split('. ')[0] 
            if '- ' in sENumber:
                sENumber = sENumber.split('- ')[0] 

            sTitle = f'{sMovieTitle} E{sENumber}'
            siteUrl = f'{URL_MAIN}api/episode?episodeId={seriesID}&showId={sUrl.split("episodes?id=")[1]}'         
        else:
            if sMovieTitle is False or sMovieTitle is None:
                sMovieTitle = sEpi.get("name", "")
            sTitle = f'{sMovieTitle} E{sEpi.get("number", "")} - [COLOR coral]{sEpi.get("pref", "حلقة")}[/COLOR]'
            siteUrl = f'{URL_MAIN}api/sp/episode/link|{seriesID}&{get_anonymous_id()}'
        sThumb = sEpi.get("poster_cover") or sEpi.get("cover_full_path") or sEpi.get("thumbnail")
        if not sThumb.startswith('http'):
            sThumb = f'{URL_MAIN}assets/img/posters/{sThumb}' if 'poster' in sEpi else f'{URL_MAIN}assets/img/thumbnails/{sThumb}'
        sDesc = sEpi.get("description") or sEpi.get("pref")
        
        oOutputParameterHandler.addParameter('siteUrl', siteUrl)
        oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('sDesc', sDesc)

        if sType == 'movie':
            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
        else:
            oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
       
    oGui.setEndOfDirectory()

def showHosters():
    oGui = cGui()
    from resources.lib import helpers

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    results = []
    useDialog = addon().getSetting('HosterDialog') == 'true'

    if '&showId=' in sUrl:
        oRequestHandler = cRequestHandler(sUrl)
        for key, value in HEADERS.items():
            oRequestHandler.addHeaderEntry(key, value)
        oRequestHandler.setTimeout(60)
        sHtmlContent = oRequestHandler.request(jsonDecode=True)
    else:
        sUrl, episodeID = sUrl.split('|') if '|' in sUrl else (sUrl, None)
        episodeID, userID = episodeID.split('&') if '&' in episodeID else (episodeID, None)
        oRequestHandler = cRequestHandler(sUrl)
        for key, value in HEADERS.items():
            oRequestHandler.addHeaderEntry(key, value)
        oRequestHandler.addJSONEntry('episodeId', episodeID)
        oRequestHandler.addJSONEntry('userId', userID or get_anonymous_id())
        oRequestHandler.setTimeout(60)
        oRequestHandler.setRequestType(1)
        sHtmlContent = oRequestHandler.request(jsonDecode=True)

    iv_hex = sHtmlContent["iv"]
    ciphertext_hex = sHtmlContent["encryptedData"]

    videos = decrypt_payload(ciphertext_hex, iv_hex)       
                
    sHosterUrl = videos.get('link') or videos.get('streamUrl')
    if '?id=' in sHosterUrl:
        sHosterUrl = Unquote(sHosterUrl.split('?id=')[1])
    if '?url=' in sHosterUrl:
        sHosterUrl = Unquote(sHosterUrl.split('?url=')[1])

    headers = {
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive",
        "Host": urlHostName(sHosterUrl),
        "Origin": f"https://{urlHostName(URL_MAIN)}",
        "Referer": f"https://{urlHostName(URL_MAIN)}/",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "cross-site",
        "User-Agent": UA
        }
    
    sHosterUrl = sHosterUrl + helpers.append_headers(headers)
    results.append((urlHostName(sHosterUrl), sHosterUrl))

    if useDialog and results:
        cHosterGui().selectHoster(results, sMovieTitle, SITE_NAME, sThumb)
    else:
        for sTitle, sHosterUrl in results:
            oHoster = cHosterGui().checkHoster(sHosterUrl)
            if oHoster:
                oHoster.setDisplayName(sMovieTitle)
                oHoster.setFileName(sMovieTitle)
                cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

        oGui.setEndOfDirectory()		

def decrypt_payload(ciphertext_hex, iv_hex, key=KEY):
    try:
        ciphertext = binascii.unhexlify(ciphertext_hex)
        iv = binascii.unhexlify(iv_hex)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        decrypted = unpad(cipher.decrypt(ciphertext), AES.block_size)
        decrypted_str = decrypted.decode("utf-8")
        return json.loads(decrypted_str)
        
    except (ValueError, KeyError, json.JSONDecodeError) as e:
        VSlog(f"Decryption or parsing failed: {e}")
        return None

def get_anonymous_id():
    import random
            
    rand_part = ''.join(random.choice("abcdefghijklmnopqrstuvwxyz0123456789") for _ in range(13))
    timestamp_part = base36_encode(int(time.time() * 1000))
    anon_id = f"anon_{rand_part}_{timestamp_part}"

    return anon_id

def base36_encode(number):
    chars = "0123456789abcdefghijklmnopqrstuvwxyz"
    result = ""
    while number:
        number, i = divmod(number, 36)
        result = chars[i] + result
    return result or "0"