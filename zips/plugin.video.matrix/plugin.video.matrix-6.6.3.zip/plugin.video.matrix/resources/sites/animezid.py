﻿# -*- coding: utf-8 -*-

import re, json
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, VSlog, siteManager, addon, dialog, VSupdate
from resources.lib.parser import cParser
from resources.lib.util import cUtil, urlHostName
from resources.lib.multihost import cMegamax
from resources.lib import random_ua

UA = random_ua.get_pc_ua()

SITE_IDENTIFIER = 'animezid'
SITE_NAME = 'Animezid'
SITE_DESC = 'arabic vod'
 
URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER)

KID_MOVIES = (f'{URL_MAIN}category.php?cat=movies', 'showMovies')
KID_CARTOON = (f'{URL_MAIN}category.php?cat=series', 'showSeries')
ANIM_NEWS = (f'{URL_MAIN}category.php?cat=anime', 'showSeriesLinks')

URL_SEARCH = (f'{URL_MAIN}search.php?keywords=', 'showMovies')
URL_SEARCH_MOVIES = (f'{URL_MAIN}search.php?keywords=', 'showMoviesSearch')
URL_SEARCH_ANIMS = (f'{URL_MAIN}search.php?keywords=', 'showSeriesSearch')
FUNCTION_SEARCH = 'showMovies'
 
def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://matrixflix/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://matrixflix/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearchSeries', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://matrixflix/')
    oGui.addDir(SITE_IDENTIFIER, 'updateDomain', 'تحديث رابط الموقع', 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام كرتون', 'anime.png', oOutputParameterHandler)
 
    oOutputParameterHandler.addParameter('siteUrl', KID_CARTOON[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات كرتون', 'anime.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesLinks', 'مسلسلات انمي', 'anime.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def updateDomain():
    new_url = random_ua.update_site_url(SITE_IDENTIFIER)
    try:
        dialog().VSinfo(f"تم تحديث الرابط بنجاح: {new_url}", SITE_NAME)
    except Exception:
        pass
        
    VSupdate()
    return

def showSearchSeries():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search.php?keywords={sSearchText}'
        showSeriesSearch(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showSearch():
    oGui = cGui()
 
    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}search.php?keywords={sSearchText}'
        showMoviesSearch(sUrl)
        oGui.setEndOfDirectory()
        return

def showMoviesSearch(sSearch = ''):
    oGui = cGui()
    if sSearch:
      sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = '<section aria-labelledby="az-results-title">'
    sEnd = '</section>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'<article class="az-card.+?href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            if "فيلم" not in aEntry[2]:
                continue
 
            sTitle = aEntry[2]
            siteUrl = aEntry[0].replace('watch.php?','play.php?')
            sDesc = ''
            sThumb = aEntry[1]
			
            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oGui.addMisc(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler) 
        
        progress_.VSclose(progress_)
 
    if not sSearch:
        oGui.setEndOfDirectory() 
			
def showSeriesSearch(sSearch = ''):
    oGui = cGui()
    if sSearch:
      sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = '<section aria-labelledby="az-results-title">'
    sEnd = '</section>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'<article class="az-card.+?href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            if "فيلم" in aEntry[2]:
                continue
 
            sTitle = aEntry[2]
            siteUrl = aEntry[0].replace('watch.php?','play.php?')
            sDesc = ''
            sThumb = aEntry[1]

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)

            oGui.addAnime(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
        
        progress_.VSclose(progress_)
 
    if not sSearch:
        oGui.setEndOfDirectory()

def showMovies(sSearch = ''):
    oGui = cGui()
    if sSearch:
      sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = '<section class="az-subcategories"'
    sEnd = '</section>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'href="([^"]+)".+?src="([^"]+)"\s+alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            sTitle = aEntry[2]
            siteUrl = aEntry[0]
            sDesc = ''
            sThumb = aEntry[1]
			
            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oGui.addMisc(SITE_IDENTIFIER, 'showMoviesLinks', sTitle, '', sThumb, sDesc, oOutputParameterHandler) 
        
        progress_.VSclose(progress_)

    if not sSearch:
        oGui.setEndOfDirectory() 

def showMoviesLinks(sSearch = ''):
    
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'<article class="az-card">.+?href="([^"]+)".+?src="([^"]+)"\s+alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            sTitle = cUtil().CleanMovieName(aEntry[2])
            siteUrl = aEntry[0].replace('watch.php?','play.php?')
            sThumb = aEntry[1]
            sDesc = ''
            sYear = ''
            m = re.search(r'([0-9]{4})', sTitle)
            if m:
                sYear = str(m.group(0))
                sTitle = sTitle.replace(sYear,'')

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
			
            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
    sStart = '<ul class="pagination'
    sEnd = '<div class='
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)
    sPattern = r'href="([^"]+)">([^<]+)</a>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        for aEntry in aResult[1]:
            sTitle = aEntry[1]
        
            sTitle = "PAGE " + sTitle
            sTitle = '[COLOR red]'+sTitle+'[/COLOR]'
            siteUrl = aEntry[0]
            if 'http' not in aEntry[0]:
                siteUrl = f'{URL_MAIN}{aEntry[0]}'

            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
        
            oGui.addDir(SITE_IDENTIFIER, 'showMoviesLinks', sTitle, '', oOutputParameterHandler)
 
    if not sSearch:
        oGui.setEndOfDirectory()
			
def showSeries(sSearch = ''):
    oGui = cGui()
    if sSearch:
      sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = '<section class="az-subcategories"'
    sEnd = '</section>'
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'href="([^"]+)".+?src="([^"]+)"\s+alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            sTitle = aEntry[2]
            siteUrl = aEntry[0]
            sDesc = ''
            sThumb = aEntry[1]

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            
            oGui.addMisc(SITE_IDENTIFIER, 'showSeriesLinks', sTitle, '', sThumb, sDesc, oOutputParameterHandler) 
       
        progress_.VSclose(progress_)
 
    if not sSearch:
        oGui.setEndOfDirectory()
 
def showSeriesLinks():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'<article class="az-card.+?href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
 
            sTitle =  aEntry[2].replace("مسلسل","").replace("انمي","").replace("مترجمة","").replace("مترجم","")
            siteUrl = aEntry[0]
            sThumb = aEntry[1]
            sDesc = ''

            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oGui.addAnime(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    sStart = '<ul class="pagination'
    sEnd = '<div class='
    sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)
    sPattern = r'href="([^"]+)">([^<]+)</a>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        for aEntry in aResult[1]:       
            sTitle = f'[COLOR red]Page: {aEntry[1]}[/COLOR]'
            siteUrl = aEntry[0]
            if 'http' not in aEntry[0]:
                siteUrl = f'{URL_MAIN}{aEntry[0]}'

            oOutputParameterHandler = cOutputParameterHandler()
            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
        
            oGui.addDir(SITE_IDENTIFIER, 'showSeriesLinks', sTitle, 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSeasons():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = '<section class="az-series-seasons'
    sEnd = '</section>'
    sHtmlContent2 = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'href="([^"]+)".+?img src="([^"]+)".+?<strong>(.+?)</strong>'
    aResult = oParser.parse(sHtmlContent2, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
 
            sTitle = f'{sMovieTitle} S{aEntry[2]}'
            siteUrl = aEntry[0].replace('watch.php?','play.php?')
            sThumb = aEntry[1]
            sDesc = ''
			
            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
			
            oGui.addSeason(SITE_IDENTIFIER, 'showEpisodes', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    oGui.setEndOfDirectory()

 
def showEpisodes():
    oGui = cGui()
    
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser() 
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sStart = '<section class="az-series-episodes'
    sEnd = '</section>'
    sHtmlContent2 = oParser.abParse(sHtmlContent, sStart, sEnd)

    sPattern = r'href="([^"]+)".+?img src="([^"]+)".+?<strong>(.+?)</strong>'
    aResult = oParser.parse(sHtmlContent2, sPattern)
    if aResult[0]:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:
 
            sTitle = f'{sMovieTitle} E{aEntry[2]}'
            siteUrl = aEntry[0].replace('watch.php?','play.php?')
            sThumb = aEntry[1]
            sDesc = ''
			
            oOutputParameterHandler.addParameter('siteUrl',siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
			
            oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc,  oOutputParameterHandler)

    sStart = '<ul class="pagination'
    sEnd = '</nav>'
    if sStart in sHtmlContent and sEnd in sHtmlContent:
        sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)
        sPattern = r'href="([^"]+)">([^<]+)</a>'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            for aEntry in aResult[1]:       
                sTitle = f'[COLOR red]Page: {aEntry[1]}[/COLOR]'
                siteUrl = aEntry[0]
                if 'http' not in aEntry[0]:
                    siteUrl = f'{URL_MAIN}{aEntry[0]}'

                oOutputParameterHandler = cOutputParameterHandler()
                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
            
                oGui.addDir(SITE_IDENTIFIER, 'showEpisodes', sTitle, 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showHosters():
    oGui = cGui()
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()    
    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    sHtmlContent = oRequestHandler.request()
    cook = oRequestHandler.GetCookies()

    VideoID = sUrl.split('?vid=')[1]
    sPattern = r'data-playback-create-url="([^"]+)"\s*data-playback-csrf="([^"]+)"'
    aResult = oParser.parse(sHtmlContent,sPattern)
    if aResult[0]:
        for aEntry in aResult[1]:
            m3url = aEntry[0]
            mCSRF = aEntry[1]

            headers = {
                "Content-Type": "application/json",
                "Cookie": cook,
                "Host": urlHostName(URL_MAIN),
                "Origin": f"https://{urlHostName(URL_MAIN)}",
                "User-Agent": UA,
                "X-Playback-CSRF": mCSRF
            }

            oRequestHandler = cRequestHandler(m3url)
            for key, value in headers.items():
                oRequestHandler.addHeaderEntry(key, value)
            oRequestHandler.setTimeout(60)
            oRequestHandler.setRequestType(1)
            oRequestHandler.addJSONEntry('content_id', VideoID)
            sHtmlContent = oRequestHandler.request(jsonDecode=True)

            sSessionID = sHtmlContent.get("session_id")
            for source in sHtmlContent.get("sources", []):
                provider = source.get("provider")
                src_id = source.get("id")
                sQual = source.get('quality', '') or ''
                sHosterUrl = f'{URL_MAIN}web-playback/sessions/{sSessionID}/sources/{src_id}/resolve'

                sDisplayTitle = f'{sMovieTitle} -[COLOR coral][{provider}][/COLOR]'
                oOutput = cOutputParameterHandler()
                oOutput.addParameter('sHosterUrl', sHosterUrl)
                oOutput.addParameter('cook', cook)
                oOutput.addParameter('mCSRF', mCSRF)
                oOutput.addParameter('siteUrl', sUrl)
                oOutput.addParameter('sMovieTitle', sMovieTitle)
                oOutput.addParameter('sThumb', sThumb)
                oOutput.addParameter('sQual', sQual)

                oGui.addLink(SITE_IDENTIFIER, 'showLinks', sDisplayTitle, sThumb, sDisplayTitle, oOutput)


        oGui.setEndOfDirectory()

def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('sHosterUrl')
    cook = oInputParameterHandler.getValue('cook')
    mCSRF = oInputParameterHandler.getValue('mCSRF')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sQual = oInputParameterHandler.getValue('sQual')
    sThumb = oInputParameterHandler.getValue('sThumb')

    headers = {
        "Content-Type": "application/json",
        "Cookie": cook,
        "Host": urlHostName(URL_MAIN),
        "Origin": f"https://{urlHostName(URL_MAIN)}",
        "User-Agent": UA,
        "X-Playback-CSRF": mCSRF
    }

    oRequestHandler = cRequestHandler(sUrl)
    for key, value in headers.items():
        oRequestHandler.addHeaderEntry(key, value)
    oRequestHandler.setTimeout(60)
    oRequestHandler.setRequestType(1)
    oRequestHandler.addParametersLine(json.dumps({}))
    sHtmlContent = oRequestHandler.request(jsonDecode=True)

    nUrl = sHtmlContent.get('launch_url')
    oRequestHandler = cRequestHandler(nUrl)
    for key, value in headers.items():
        oRequestHandler.addHeaderEntry(key, value)
    oRequestHandler.setTimeout(60)
    sHtmlContent = oRequestHandler.request()

    sHosterUrl = oRequestHandler.getRealUrl()

    if bool(re.search(r'mega.*max', sHosterUrl)) or bool(re.search(r'mega.*zid', sHosterUrl)):
        data = cMegamax().GetUrls(sHosterUrl)
        if data:
            for item in data:
                sHosterUrl = item.split(',')[0].split('=')[1]
                sQual = item.split(',')[1].split('=')[1]
                sLabel = item.split(',')[2].split('=')[1]

                sDisplayTitle = f'{sMovieTitle} [COLOR coral][{sQual}][/COLOR][COLOR orange] - {sLabel}[/COLOR]'
                oOutput = cOutputParameterHandler()
                oOutput.addParameter('sHosterUrl', sHosterUrl)
                oOutput.addParameter('sQual', sQual)
                oOutput.addParameter('siteUrl', sUrl)
                oOutput.addParameter('sMovieTitle', sMovieTitle)
                oOutput.addParameter('sThumb', sThumb)
                oGui.addLink(SITE_IDENTIFIER, 'showMegaLinks', sDisplayTitle, sThumb, sDisplayTitle, oOutput)

    else:
        if 'bestx' in sHosterUrl:
            sHosterUrl = f'{sHosterUrl}|Referer={URL_MAIN}'

    sDisplayTitle = f'{sMovieTitle} [COLOR coral] [{sQual}] [/COLOR]'   
    oHoster = cHosterGui().checkHoster(sHosterUrl)
    if oHoster:
        oHoster.setDisplayName(sDisplayTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()

def showMegaLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sHosterUrl = oInputParameterHandler.getValue('sHosterUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sQual = oInputParameterHandler.getValue('sQual')
    sThumb = oInputParameterHandler.getValue('sThumb')

    sDisplayTitle = f'{sMovieTitle} [COLOR coral] [{sQual}] [/COLOR]'   
    oHoster = cHosterGui().checkHoster(sHosterUrl)
    if oHoster:
        oHoster.setDisplayName(sDisplayTitle)
        oHoster.setFileName(sMovieTitle)
        cHosterGui().showHoster(oGui, oHoster, sHosterUrl, sThumb)

    oGui.setEndOfDirectory()