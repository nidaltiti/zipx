# -*- coding: utf-8 -*-

import re
import urllib.parse
from resources.lib.gui.hoster import cHosterGui
from resources.lib.gui.gui import cGui
from resources.lib.handler.inputParameterHandler import cInputParameterHandler
from resources.lib.handler.outputParameterHandler import cOutputParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import progress, VSlog, siteManager, addon
from resources.lib.parser import cParser
from resources.lib.util import Quote, urlHostName, cUtil
from resources.lib import random_ua

UA = random_ua.get_ua()

SITE_IDENTIFIER = 'arabseed'
SITE_NAME = 'Arabseed'
SITE_DESC = 'arabic vod'

URL_MAIN = siteManager().getUrlMain(SITE_IDENTIFIER) 
#MAIN_URL = siteManager().getUrlMain(SITE_IDENTIFIER)
#URL_MAIN = random_ua.get_arabseedUrl(MAIN_URL)

MOVIE_CLASSIC = (f'{URL_MAIN}category/افلام-كلاسيكيه/', 'showMovies')
MOVIE_EN = (f'{URL_MAIN}category/foreign-movies-12/', 'showMovies')
MOVIE_AR = (f'{URL_MAIN}category/arabic-movies-12/', 'showMovies')
MOVIE_DUBBED = (f'{URL_MAIN}category/افلام-مدبلجة-1/', 'showMovies')
MOVIE_HI = (f'{URL_MAIN}category/indian-movies/', 'showMovies')
MOVIE_ASIAN = (f'{URL_MAIN}category/asian-movies/', 'showMovies')
MOVIE_TURK = (f'{URL_MAIN}category/turkish-movies/', 'showMovies')
KID_MOVIES = (f'{URL_MAIN}category/افلام-انيميشن/', 'showMovies')

SERIE_TR = (f'{URL_MAIN}category/turkish-series-2/', 'showSeries')
SERIE_DUBBED = (f'{URL_MAIN}category/مسلسلات-مدبلجة/', 'showSeries')
SERIE_ASIA = (f'{URL_MAIN}category/مسلسلات-كوريه/', 'showSeries')
SERIE_HEND = (f'{URL_MAIN}category/مسلسلات-هندية/', 'showSeries')
SERIE_EN = (f'{URL_MAIN}category/foreign-series-5/', 'showSeries')
SERIE_AR = (f'{URL_MAIN}category/arabic-series-10/', 'showSeries')
RAMADAN_SERIES = (f'{URL_MAIN}category/%d95%d8%b3%d94%d8%b3%d94%d8%a7%d8%aa-%d8%b1%d95%d8%b6%d8%a7%d96/ramadan-series-2026-1/', 'showSeries')

SPORT_WWE = (f'{URL_MAIN}category/wwe-shows/', 'showMovies')
ANIM_NEWS = (f'{URL_MAIN}category/cartoon-series/', 'showSeries')

REPLAYTV_NEWS = (f'{URL_MAIN}category/برامج-تلفزيونية/', 'showMovies')
URL_SEARCH_MOVIES = (f'{URL_MAIN}find/?type=movies&word=', 'showMovies')
URL_SEARCH_SERIES = (f'{URL_MAIN}find/?type=&word=', 'showSeries')
URL_SEARCH_ANIMS = (f'{URL_MAIN}find/?find=', 'showSeries')
FUNCTION_SEARCH = 'showMovies'

def load():
    oGui = cGui()
    addons = addon()

    oOutputParameterHandler = cOutputParameterHandler()
    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSearch', addons.VSlang(30078), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', 'http://venom/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeriesSearch', addons.VSlang(30079), 'search.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', RAMADAN_SERIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات رمضان', 'rmdn.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أجنبية', 'agnab.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام عربية', 'arab.png', oOutputParameterHandler)
 
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_ASIAN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام أسيوية', 'asia.png', oOutputParameterHandler)
   
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_TURK[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام تركية', 'turk.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', MOVIE_CLASSIC[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام كلاسيكية', 'class.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_HI[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام هندية', 'hend.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', KID_MOVIES[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام كرتون', 'anim.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', MOVIE_DUBBED[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'أفلام مدبلجة', 'mdblg.png', oOutputParameterHandler) 

    oOutputParameterHandler.addParameter('siteUrl', SERIE_EN[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أجنبية', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_AR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات عربية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}category/مسلسلات-مصريه/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات مصرية', 'arab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_ASIA[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات أسيوية', 'asia.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_TR[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات تركية', 'turk.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_HEND[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات هندية', 'hend.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', SERIE_DUBBED[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات مدبلجة', 'mdblg.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', ANIM_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات انمي', 'anime.png', oOutputParameterHandler)  

    oOutputParameterHandler.addParameter('siteUrl', SPORT_WWE[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'مصارعة', 'wwe.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', REPLAYTV_NEWS[0])
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'برامج تلفزيونية', 'brmg.png', oOutputParameterHandler)
	
    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}category/netfilx/مسلسلات-netfilx-1/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'مسلسلات Netfilx', 'agnab.png', oOutputParameterHandler)
    
    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}category/netfilx/افلام-netfilx/')
    oGui.addDir(SITE_IDENTIFIER, 'showMovies', 'افلام Netfilx', 'agnab.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}category/ramadan-series-2025/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'رمضان 2025', 'rmdn.png', oOutputParameterHandler)

    oOutputParameterHandler.addParameter('siteUrl', f'{URL_MAIN}category/ramadan-series-2024/')
    oGui.addDir(SITE_IDENTIFIER, 'showSeries', 'رمضان 2024', 'rmdn.png', oOutputParameterHandler)

    oGui.setEndOfDirectory()

def showSearch():
    oGui = cGui()

    sSearchText = oGui.showKeyBoard()    
    if sSearchText:
        sUrl = f'{URL_MAIN}find/?type=movies&word='+sSearchText
        showMovies(sUrl)
        oGui.setEndOfDirectory()
        return
 
def showSeriesSearch():
    oGui = cGui()

    sSearchText = oGui.showKeyBoard()
    if sSearchText:
        sUrl = f'{URL_MAIN}find/?type=&word='+sSearchText
        showSeries(sUrl)
        oGui.setEndOfDirectory()
        return
			
def showMovies(sSearch = ''):
    oGui = cGui()

    oParser = cParser()

    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Referer', Quote(sUrl))
    sHtmlContent = oRequestHandler.request()

    sPattern = r'class="item__contents[^>]*>\s*<a href="([^"]+)"[^>]*>.*?data-src="([^"]*)".*?alt="([^"]+)"'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
 
            sTitle = cUtil().CleanMovieName(aEntry[2])
            siteUrl = aEntry[0]
            sThumb = aEntry[1]
            sDesc = ''
            sYear = ''
            m = re.search(r'([0-9]{4})', sTitle)
            if m:
               sYear = str(m.group(0))

            oOutputParameterHandler.addParameter('siteUrl', siteUrl)
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
            oOutputParameterHandler.addParameter('sYear', sYear)
            oOutputParameterHandler.addParameter('sDesc', sDesc)

            oGui.addMovie(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
 
    if not sSearch:
        sPattern = r'<li><a class="page-numbers" href="([^<]+)">([^<]+)</a></li>'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            oOutputParameterHandler = cOutputParameterHandler()
            for aEntry in aResult[1]:
    
                sTitle = f'[COLOR red]Page: {aEntry[1]}[/COLOR]'
                siteUrl = aEntry[0]

                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                
                oGui.addDir(SITE_IDENTIFIER, 'showMovies', sTitle, 'next.png', oOutputParameterHandler)
                
        oGui.setEndOfDirectory()
 
def showSeries(sSearch = ''):
    oGui = cGui()
    oParser = cParser()

    if sSearch:
        sUrl = sSearch
    else:
        oInputParameterHandler = cInputParameterHandler()
        sUrl = oInputParameterHandler.getValue('siteUrl')

    oRequestHandler = cRequestHandler(sUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('Referer', Quote(sUrl))
    sHtmlContent = oRequestHandler.request()

    sPattern = r'class="item__contents[^>]*>\s*<a href="([^"]+)"[^>]*>.*?data-src="([^"]*)".*?alt="([^"]+)"'
    itemList = []
    aResult = oParser.parse(sHtmlContent, sPattern)	
    if aResult[0]:
        total = len(aResult[1])
        progress_ = progress().VScreate(SITE_NAME)
        oOutputParameterHandler = cOutputParameterHandler()    
        for aEntry in aResult[1]:
            progress_.VSupdate(progress_, total)
            if progress_.iscanceled():
                break
            
            if 'فيلم' in aEntry[2]:
                continue
            if 'تحميل' in aEntry[2]:
                continue

            sTitle = cUtil().CleanSeriesName(aEntry[2])
            siteUrl = aEntry[0]
            sThumb = aEntry[1]
            sDesc = ''

            if sTitle not in itemList:
                itemList.append(sTitle)	
                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
                oOutputParameterHandler.addParameter('sDesc', sDesc)
                oGui.addTV(SITE_IDENTIFIER, 'showSeasons', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

        progress_.VSclose(progress_)
            
    if not sSearch:
        sPattern = r'<li><a class="page-numbers" href="([^<]+)">([^<]+)</a></li>'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0]:
            oOutputParameterHandler = cOutputParameterHandler()
            for aEntry in aResult[1]:
    
                sTitle = f'[COLOR red]Page: {aEntry[1]}[/COLOR]'
                siteUrl = aEntry[0]

                oOutputParameterHandler.addParameter('siteUrl',siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                
                oGui.addDir(SITE_IDENTIFIER, 'showSeries', sTitle, 'next.png', oOutputParameterHandler)

        oGui.setEndOfDirectory()
 
def showSeasons():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    sPattern = r'["\']csrf__token["\']: ["\']([^"\']+)["\']' 
    aResult = oParser.parse(sHtmlContent,sPattern)
    if aResult[0]:
        csrf_token = aResult[1][0]

    sPattern = r'data-term="([^"]+)">.+?</i>\s*</div>\s*<span>(.+?)</span>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0] is True:
        oOutputParameterHandler = cOutputParameterHandler() 
        for aEntry in aResult[1]:

            sMovieTitle = re.sub(r"S\d{2}|S\d", "", sMovieTitle)
            sSeason = (cUtil().ConvertSeasons(aEntry[1])).strip()
            sTitle = f'{sMovieTitle} {sSeason}'
            post = aEntry[0]
            sThumb = sThumb

            oOutputParameterHandler.addParameter('siteUrl', f'{sUrl}|post={post}&csrf_token={csrf_token}')
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)
 
            oGui.addSeason(SITE_IDENTIFIER, 'showEps', sTitle, '', sThumb, '', oOutputParameterHandler)

    else:
        sPattern = r'<div\s+data-id="([^"]+)"'
        aResult = oParser.parse(sHtmlContent, sPattern)
        if aResult[0] is True:
            oOutputParameterHandler = cOutputParameterHandler() 

            sTitle = sMovieTitle
            if 'موسم' not in sMovieTitle:
                sTitle = f'{sMovieTitle} S1'

            post = aResult[1][0]
            sThumb = sThumb

            oOutputParameterHandler.addParameter('siteUrl', f'{sUrl}|post={post}&csrf_token={csrf_token}')
            oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
            oOutputParameterHandler.addParameter('sThumb', sThumb)

            oGui.addSeason(SITE_IDENTIFIER, 'showEps', sTitle, '', sThumb, '', oOutputParameterHandler)

        else:
            sPattern = r'<meta property="og:title" content="([^"]+)".+?<link rel="canonical" href="([^"]+)"'
            aResult = oParser.parse(sHtmlContent, sPattern)
            if aResult[0] is True:
                oOutputParameterHandler = cOutputParameterHandler() 
                for aEntry in aResult[1]:

                    sTitle = (cUtil().CleanMovieName(aEntry[0])).replace("‎عرب سيد - Arabseed","")
                    sTitle = (cUtil().ConvertSeasons(sTitle)).split('الحلقة')[0]
                    sSeason = sTitle.replace(sMovieTitle,'').replace(' - ','')
                    if 'موسم' not in aEntry[0]:
                        sTitle = f'{sTitle} S1'
                    else:
                        sTitle = f'{sMovieTitle} {sSeason}'
                    
                    siteUrl = aEntry[1]
                    sThumb = sThumb
                    sDesc = ''

                    oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                    oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                    oOutputParameterHandler.addParameter('sThumb', sThumb)
    
                    oGui.addSeason(SITE_IDENTIFIER, 'showEps', sTitle, '', sThumb, sDesc, oOutputParameterHandler)
       
    oGui.setEndOfDirectory() 
 
def showEps():
    oGui = cGui()
   
    oInputParameterHandler = cInputParameterHandler()
    sUrl = oInputParameterHandler.getValue('siteUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    offset = oInputParameterHandler.getValue('offset')

    post = re.search(r'post=([^&]+)', sUrl).group(1)
    csrf_token = re.search(r'csrf_token=([^&]+)', sUrl).group(1)
    if '|' in sUrl:
        sUrl = sUrl.split('|')[0]

    oParser = cParser()
    oOutputParameterHandler = cOutputParameterHandler() 
    hasmore = False
    if csrf_token:
        oRequestHandler = cRequestHandler(f'{URL_MAIN}season__episodes/')
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('referer', URL_MAIN)
        oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
        oRequestHandler.addParameters('season_id', post)
        if offset:
            oRequestHandler.addParameters('offset', offset)
        oRequestHandler.addParameters('csrf_token', csrf_token)
        oRequestHandler.setRequestType(1)
        sHtmlContent = oRequestHandler.request(jsonDecode=True)
        if sHtmlContent.get('hasmore'):
            hasmore = True

        if sHtmlContent.get('type') == 'success':
            sHtmlContent = sHtmlContent.get('html', '')
            li_tags = re.findall(r'epi__num', sHtmlContent)
            noffset = len(li_tags)
            if offset:
                offset = int(offset) + int(noffset)
            else:
                offset = noffset
    else:
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()

    sPattern = r'<a href="([^"]+)".+?class="epi__num">.*?<b>(.+?)</b>'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
            for aEntry in aResult[1]:

                sEp = f'E{aEntry[1].replace(" ","")}'
                if "مدبلج" in sMovieTitle:
                    sMovieTitle = f'مدبلج {sMovieTitle.replace("مدبلج","")}'
                sTitle = f'{sMovieTitle} {sEp}'
                siteUrl = aEntry[0]
                sThumb = sThumb
                sDesc = ''

                oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                oOutputParameterHandler.addParameter('sThumb', sThumb)
             
                oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    else:
        oRequestHandler = cRequestHandler(sUrl)
        sHtmlContent = oRequestHandler.request()

        sStart = '<ul class="episodes__list'
        sEnd = '<div class="break'
        sHtmlContent = oParser.abParse(sHtmlContent, sStart, sEnd)

        sPattern = r'<a href="([^"]+)".+?class="epi__num">.*?<b>(.+?)</b>'
        aResult = oParser.parse(sHtmlContent, sPattern)  
        if aResult[0]:
                for aEntry in aResult[1]:

                    sEp = f'E{aEntry[1].replace(" ","")}'
                    if "مدبلج" in sMovieTitle:
                        sMovieTitle = f'مدبلج {sMovieTitle.replace("مدبلج","")}'
                    sTitle = f'{sMovieTitle} {sEp}'
                    siteUrl = aEntry[0]
                    sThumb = sThumb
                    sDesc = ''

                    oOutputParameterHandler.addParameter('siteUrl', siteUrl)
                    oOutputParameterHandler.addParameter('sMovieTitle', sTitle)
                    oOutputParameterHandler.addParameter('sThumb', sThumb)
                
                    oGui.addEpisode(SITE_IDENTIFIER, 'showHosters', sTitle, '', sThumb, sDesc, oOutputParameterHandler)

    if hasmore:
        oOutputParameterHandler.addParameter('siteUrl', f'{sUrl}|post={post}&csrf_token={csrf_token}')
        oOutputParameterHandler.addParameter('sMovieTitle', sMovieTitle)
        oOutputParameterHandler.addParameter('sThumb', sThumb)
        oOutputParameterHandler.addParameter('csrf_token', csrf_token)
        oOutputParameterHandler.addParameter('post', post)
        oOutputParameterHandler.addParameter('offset', offset)
        
        oGui.addDir(SITE_IDENTIFIER, 'showEps', 'More Episodes', 'next.png', oOutputParameterHandler)

    oGui.setEndOfDirectory() 

def showHosters():
    oGui = cGui()
    oInput = cInputParameterHandler()
    sUrl = oInput.getValue('siteUrl')
    sMovieTitle = oInput.getValue('sMovieTitle')
    sThumb = oInput.getValue('sThumb')

    oParser = cParser()
    oRequestHandler = cRequestHandler(sUrl)
    sHtmlContent = oRequestHandler.request()

    results = []
    servers_list = []

    def resolveHoster(m3url, cookies, post_id, csrf_token, sServer, sQual, sName):
        oReq = cRequestHandler(f'https://{urlHostName(m3url)}/get__watch__server/')
        oReq.addHeaderEntry('User-Agent', UA)
        oReq.addHeaderEntry('referer', urllib.parse.quote(m3url, '/:?=&amp;'))
        oReq.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
        oReq.addHeaderEntry("Cookie", cookies)
        oReq.addParameters('quality', sQual)
        oReq.addParameters('post_id', post_id)
        oReq.addParameters('server', sServer)
        oReq.addParameters('csrf_token', csrf_token)
        oReq.setRequestType(1)
        sJson = oReq.request(jsonDecode=True)
        if sJson and sJson.get('type') == 'success':
            sHosterUrl = sJson['server']
            results.append((sQual, sHosterUrl, sName))

    sPattern = r'<a href="([^"]+)" class="btton watch__btn">'
    aResult = oParser.parse(sHtmlContent, sPattern)
    if aResult[0]:
        m3url = aResult[1][0].replace(' ', '')
        oRequestHandler = cRequestHandler(m3url)
        oRequestHandler.addHeaderEntry('User-Agent', UA)
        oRequestHandler.addHeaderEntry('referer', URL_MAIN)
        sHtmlContent = oRequestHandler.request()
        cookies = oRequestHandler.GetCookies() + ";"

        csrf_token = oParser.parse(sHtmlContent, r'["\']csrf__token["\']: ["\']([^"\']+)["\']')[1][0]
        post_id = oParser.parse(sHtmlContent, r'["\']psot_id["\']: ["\']([^"\']+)["\']')[1][0]

        sQualContent = oParser.abParse(sHtmlContent, 'class="qualities__list">', '</ul>')
        aQuals = oParser.parse(sQualContent, r'<div class="qu">(.+?)</div>')

        def collect_servers_for_quality(sQual):
            oReq = cRequestHandler(f'https://{urlHostName(m3url)}/get__quality__servers/')
            oReq.addHeaderEntry('User-Agent', UA)
            oReq.addHeaderEntry('referer', m3url)
            oReq.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
            oReq.addHeaderEntry("Cookie", cookies)
            oReq.addParameters('post_id', post_id)
            oReq.addParameters('quality', sQual)
            oReq.addParameters('csrf_token', csrf_token)
            oReq.setRequestType(1)
            sHtmlContent0 = oReq.request(jsonDecode=True)
            if sHtmlContent0 and sHtmlContent0.get('type') == 'success':
                html = sHtmlContent0['html']
                aRes2 = oParser.parse(html, r'data-server="([^"]+)"\s*data-qu="([^"]+)".+?<span>(.+?)</span>')
                if aRes2[0]:
                    for sServer, sQual2, sName in aRes2[1]:
                        servers_list.append((sQual2, sServer, sName))

        if aQuals[0]:
            for sQual in reversed(aQuals[1]):
                collect_servers_for_quality(sQual)
        else:
            aRes2 = oParser.parse(sHtmlContent, r'data-server="([^"]+)"\s*data-qu="([^"]+)".+?<span>(.+?)</span>')
            if aRes2[0]:
                for sServer, sQual, sName in aRes2[1]:
                    servers_list.append((sQual, sServer, sName))

        useDialog = addon().getSetting('HosterDialog') == 'true'

        if useDialog:
            for sQual, sServer, sName in servers_list:
                resolveHoster(m3url, cookies, post_id, csrf_token, sServer, sQual, sName)

            if results:
                cHosterGui().selectHoster(
                    [(f'{sQual}p [COLOR coral]{sName}[/COLOR]', url)
                     for sQual, url, sName in results],
                    sMovieTitle, SITE_NAME, sThumb
                )
            else:
                oGui.addText(SITE_IDENTIFIER, '[COLOR orange] لم يتم العثور على روابط مباشرة [/COLOR]', 'none.png')
                oGui.setEndOfDirectory()
        else:
            for sQual, sServer, sName in servers_list:
                sTitle = f'{sMovieTitle} ({sQual}p) [COLOR coral]{sName}[/COLOR]'
                oOutput = cOutputParameterHandler()
                oOutput.addParameter('sHosterUrl', f'https://{urlHostName(m3url)}/get__watch__server/')
                oOutput.addParameter('siteUrl', sUrl)
                oOutput.addParameter('sMovieTitle', sMovieTitle)
                oOutput.addParameter('sThumb', sThumb)
                oOutput.addParameter('csrf_token', csrf_token)
                oOutput.addParameter('sServer', sServer)
                oOutput.addParameter('sQual', sQual)
                oOutput.addParameter('cookies', cookies)
                oOutput.addParameter('m3url', m3url)
                oOutput.addParameter('post_id', post_id)
                oGui.addLink(SITE_IDENTIFIER, 'showLinks', sTitle, sThumb, sTitle, oOutput)

            if not servers_list:
                oGui.addText(SITE_IDENTIFIER, '[COLOR orange] تعذر الحصول على روابط مشاهدة [/COLOR]', 'none.png')
            oGui.setEndOfDirectory()
    else:
        oGui.addText(SITE_IDENTIFIER, '[COLOR orange] تعذر الحصول على روابط مشاهدة [/COLOR]', 'none.png')
        oGui.setEndOfDirectory()


def showLinks():
    oGui = cGui()

    oInputParameterHandler = cInputParameterHandler()
    sHosterUrl = oInputParameterHandler.getValue('sHosterUrl')
    sMovieTitle = oInputParameterHandler.getValue('sMovieTitle')
    sThumb = oInputParameterHandler.getValue('sThumb')
    csrf_token = oInputParameterHandler.getValue('csrf_token')
    sServer = oInputParameterHandler.getValue('sServer')
    sQual = oInputParameterHandler.getValue('sQual')
    cookies = oInputParameterHandler.getValue('cookies')
    m3url = oInputParameterHandler.getValue('m3url')
    post_id = oInputParameterHandler.getValue('post_id')

    oRequestHandler = cRequestHandler(sHosterUrl)
    oRequestHandler.addHeaderEntry('User-Agent', UA)
    oRequestHandler.addHeaderEntry('referer', urllib.parse.quote(m3url, '/:?=&amp;'))
    oRequestHandler.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
    oRequestHandler.addHeaderEntry("Cookie", cookies)
    oRequestHandler.addParameters('quality', sQual)
    oRequestHandler.addParameters('post_id', post_id)
    oRequestHandler.addParameters('server', sServer)
    oRequestHandler.addParameters('csrf_token', csrf_token)
    oRequestHandler.setRequestType(1)

    sJson = oRequestHandler.request(jsonDecode=True)
    if sJson and sJson.get('type') == 'success':
        sFinalUrl = sJson['server']

        oHoster = cHosterGui().checkHoster(sFinalUrl)
        if oHoster:
            oHoster.setDisplayName(sMovieTitle)
            oHoster.setFileName(sMovieTitle)
            cHosterGui().showHoster(oGui, oHoster, sFinalUrl, sThumb)
    else:
        oGui.addText(SITE_IDENTIFIER, '[COLOR orange] فشل جلب الرابط النهائي [/COLOR]', 'none.png')

    oGui.setEndOfDirectory()
