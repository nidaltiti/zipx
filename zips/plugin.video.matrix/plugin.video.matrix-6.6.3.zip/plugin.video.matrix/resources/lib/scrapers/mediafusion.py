# -*- coding: utf-8 -*-
from logging import config
import re
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog, addon
from resources.lib.util import QuotePlus
from resources.lib import random_ua

UA = random_ua.get_phone_ua()

sStop = 0

def get_links(sType, imdb_id, sTitle, sSeason, sEpisode):
    addons = addon()
    sConfig = QuotePlus('D-VB6XV7ihJSEIwDttLGJEBwGOm5jk0SauzzN776n-vpQACSP9gqDv6r_EOlRRgXABiH52LcNFY3QdsRHHlqHId-ZwrsLx3RkuaW4fp3LzLP8')

    sMagnetUrls = []
   
    if sType == 'movie':
        sUrl = f'https://mediafusionfortheweebs.midnightignite.me/{sConfig}/stream/movie/{imdb_id}.json'

    elif sType == 'tv':
        sUrl = f'https://mediafusionfortheweebs.midnightignite.me/{sConfig}/stream/series/{imdb_id}%3A{sSeason}%3A{sEpisode}.json'
     
    if 1:
        oRequest = cRequestHandler(sUrl)
        oRequest.addHeaderEntry('User-Agent', UA)
        oRequest.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8')
        oRequest.addHeaderEntry('Accept-Language', 'en-US,en;q=0.5')
        oRequest.addHeaderEntry('Connection', 'keep-alive')
        oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
        data = oRequest.request(jsonDecode=True)


        for aEntry in data['streams']:
            if sStop == 1:
                break

            sName = aEntry['description']
            sFileName = aEntry['behaviorHints']['filename']
            sTrackers = aEntry['sources']

            match = re.search(r'📦\s*([\d.]+)\s*(GB|MB)', sName)
            sSize = 0
            if match:
                size_val, unit = match.groups()
                sSize = float(size_val)
                if unit == 'MB':
                    sSize = sSize / 1000

            sLinks = aEntry['infoHash']
            sLink = f'magnet:?xt=urn:btih:{sLinks}&dn={QuotePlus(sTitle)}' + "&tr=" + "&tr=".join(
                [x[8:] for x in sTrackers if x.startswith("tracker:")]
            )

            sRes = {
                '4k': '2160p',
                '2160': '2160p',
                '1080': '1080p',
                '720': '720p',
                'hd': '720p',
                '480': '480p',
                '360': '360p',
                'cam': 'CAM'
            }

            sQual = next((sRes[key] for key in sRes if key in sFileName.lower()), 'HD')

            max_size = int(addons.getSetting('scrapers_size_limit'))

            try:
                sName = re.split(r"👤", sName)[0].strip()
            except Exception:
                continue

            if sSize < max_size:
                sMagnetUrls.append((sFileName, sLink, f'{sSize:.2f}', sQual))

    return sMagnetUrls