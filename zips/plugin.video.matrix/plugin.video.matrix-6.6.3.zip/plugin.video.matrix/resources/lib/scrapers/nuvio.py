# -*- coding: utf-8 -*-

from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.comaddon import VSlog
from resources.lib import random_ua

UA = random_ua.get_phone_ua()

sStop = 0

def get_links(sType, imdb_id, sTitle, sSeason, sEpisode):
    base_url = "https://nuviostreams.hayd.uk"
    febbox_cookie = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NzA5OTcwMjAsIm5iZiI6MTc3MDk5NzAyMCwiZXhwIjoxODAyMTAxMDQwLCJkYXRhIjp7InVpZCI6MzM1NjkzLCJ0b2tlbiI6ImI0MTFkMzg3YjQxOWE2MjFiZTI1NDRmOTU1YjkwZTRjIn19.nzBp0FvupceH4di3ljIIwqgFzRFtVf94Eqdgxo8tVK0"

    sMagnetUrls = []
   
    if sType == 'movie':
        sUrl = f"{base_url}/cookie={febbox_cookie}/stream/movie/{imdb_id}.json"

    elif sType == 'tv':
        sUrl = f"{base_url}/cookie={febbox_cookie}/stream/series/{imdb_id}:{sSeason}:{sEpisode}.json"
     
    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('User-Agent', UA)
    oRequest.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8')
    oRequest.addHeaderEntry('Accept-Language', 'en-US,en;q=0.5')
    oRequest.addHeaderEntry('Connection', 'keep-alive')
    oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
    data = oRequest.request(jsonDecode=True)

    for aEntry in data['streams']:            
        
        sName = aEntry['title']          
        sLink = aEntry['url']
        referer = (
            aEntry.get("behaviorHints", {})
            .get("proxyHeaders", {})
            .get("request", {})
            .get("Referer", "")
        )
        if referer:
            sLink = f'{sLink}|Referer={referer}'
        sRes = {    '4k': '2160p',
                    '2160': '2160p',
                    '1080': '1080p',
                    '720': '720p',
                    '480': '480p',
                    '360': '360p'}

        sQual = next((sRes[key] for key in sRes if key in sName), 'HD')
        
        sMagnetUrls.append((sName, sLink, sQual))

    return sMagnetUrls