import codecs, requests, xbmc, xbmcvfs

wyzie_url = 'https://sub.wyzie.ru/search'
fallback_api = 'https://opensubtitles-v3.strem.io'
timeout = 5.05

def _get(url, params=None, stream=False, retry=False, headers=None):
    response = requests.get(url, params=params, stream=stream, timeout=timeout, headers=headers)
    if retry and response.status_code == 429:
        xbmc.sleep(10000)
        return _get(url, params=params, stream=stream, headers=headers)
    return response

def search(imdb_id, language, season=None, episode=None):
    # First try Wyzie
    params = {'id': imdb_id, 'language': language, 'format': 'srt'}
    if season: params.update({'season': season, 'episode': episode})
    response = _get(wyzie_url, params=params, retry=True)
    if response.ok:
        try:
            data = response.json()
            if data:
                return data
        except Exception:
            pass

    # Fallback to JSON API
    if season is None:
        url = f"{fallback_api}/subtitles/movie/{imdb_id}.json"
    else:
        url = f"{fallback_api}/subtitles/series/{imdb_id}:{season}:{episode}.json"

    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    }
    resp = _get(url, headers=headers)
    if resp.ok:
        try:
            api_json = resp.json()
            subs = api_json.get("subtitles", [])

            results = []
            for it in subs:
                lan = it.get("lang", "Unknown")
                suburl = it.get("url")
                results.append({
                    "language": lan.capitalize(),
                    "url": suburl,
                    "encoding": it.get("SubEncoding", "UTF-8")
                })
            return results
        except Exception:
            return []
    return []

def download(url, final_path):
    response = _get(url, stream=True, retry=True)
    try:
        if response.encoding and 'utf-8' in response.encoding.lower():
            content = response.text
        else:
            content = codecs.decode(response.content, encoding='utf-8')
    except Exception:
        content = response.content
    with xbmcvfs.File(final_path, 'w') as file:
        file.write(content)
    return final_path
