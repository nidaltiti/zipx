﻿# -*- coding: utf-8 -*-
from resources.lib.comaddon import VSlog, dialog, VSPath
import xbmc, xbmcgui, xbmcaddon, os, sys, json, requests
import random
monitor = xbmc.Monitor()

MACLIST_URL = "https://raw.githubusercontent.com/Voodoo19/Voodoo-/refs/heads/master/Hdr/maclist.json"

def load_json_safe(url):
    import re
    resp = requests.get(url, timeout=10)
    text = resp.text

    # Remove broken patterns like ',"",' after portal lines
    text = re.sub(r'",\s*",', '",', text)
    text = re.sub(r',"\s*"', ',"', text)

    # Also remove trailing commas before } or ]
    text = re.sub(r",\s*}", "}", text)
    text = re.sub(r",\s*]", "]", text)

    return json.loads(text)

def fetch_random_setlist(count, set_new):
    """
    Build a random setlist like:
    [['mac_0', '...'], ['server_0', '...'], ..., ['set', set_new]]
    """

    resp = requests.get(MACLIST_URL, timeout=10)
    data = load_json_safe(MACLIST_URL)


    # Flatten (mac, portal) pairs
    pairs = []
    for entry in data.values():
        portal = entry.get("portal")
        macs = entry.get("macs", [])
        if not portal or not macs:
            continue
        for mac in macs:
            pairs.append((mac, portal))

    if not pairs:
        return [['set', set_new]]

    selected = random.sample(pairs, min(count, len(pairs)))

    setlist = []
    for idx, (mac, portal) in enumerate(selected):
        setlist.append([f"mac_{idx}", mac])
        setlist.append([f"server_{idx}", portal])

    setlist.append(['set', set_new])
    return setlist

def pvrstalkerinstall():
    try:
        try:
            stalkeraddonpath = VSPath('special://home/addons/pvr.stalker/addon.xml')
            if xbmc.getCondVisibility('System.HasAddon(pvr.stalker)') == False and os.path.exists(stalkeraddonpath) == False:
                while xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                    if monitor.waitForAbort(0.1):
                        sys.exit()
                yes = xbmcgui.Dialog().yesno("[B]matrix[/B]", "يتوفر خيار (تجريبي) لتفعيل الإعداد المسبق لمشاهدة بث القنوات المباشرة!!![CR]إذا كنت مهتمًا، فعليك تثبيت مشغل الـ PVR الآن. وإلا، فاختر [B]إلغاء[/B].[CR]هل تريد تثبيت [B][COLOR skyblue]PVR Stalker client[/COLOR][/B] الآن؟", nolabel='[B]إلغاء[/B]', yeslabel='[B]تثبيت[/B]')
                if yes == False:
                    return False
                else:
                    dialog().VSinfo('بدء تثبيت PVR Stalker', 'matrix', 4)
                    xbmc.executebuiltin('InstallAddon(pvr.stalker)')
                    xbmc.executebuiltin('SendClick(11)')
                    x = 0
                    while xbmc.getCondVisibility('System.HasAddon(pvr.stalker)') == False and x < 60:
                        x += 1
                        if monitor.waitForAbort(1):
                            sys.exit()
                    if xbmc.getCondVisibility('System.HasAddon(pvr.stalker)'):
                        dialog().VSinfo('تم تثبيت PVR Stalker', 'matrix', 4)
                        return True
                    else:
                        return False
            else:
                return True
        except BaseException:
            return False

    except BaseException:
        return False

def setpvrstalker():
    if pvrstalkerinstall():
        enablestalker()
        try:
            setaddon = xbmcaddon.Addon('pvr.stalker')
            set_prev = setaddon.getSetting('set')
            set_new = '1.0'
            if set_prev == '' or set_prev is None:
                set_prev = '0'
            changes = []
            if str(set_new) > str(set_prev):
                dialog().VSinfo('بدء إعداد PVR Stalker', 'matrix', 4)
                setlist = fetch_random_setlist(count=15, set_new=set_new)

                if dissablestalker():
                    dialog().VSinfo('تطبيق إعدادات PVR Stalker...', 'matrix', 4)
                    for setitem in setlist:
                        if monitor.waitForAbort(0.1):
                            sys.exit()
                        setid = setitem[0]
                        setvalue = setitem[1]
                        prevsetvalue = setaddon.getSetting(setid)
                        if setvalue != prevsetvalue:
                            setaddon.setSetting(setid, setvalue)
                            changes.append(setitem)
                else:
                    dialog().VSinfo('غير قادر على تكوين Gateway-MAC في Stalker...', 'matrix', 4)

            if len(changes) > 0:
                enablestalker()
                xbmcgui.Dialog().ok("[B]matrix[/B]", "تم تحديث إعدادات سيرفرات PVR %s." % str(len(changes)))
                restartstalker()
                return True
            else:
                enablestalker()
                return 
        except BaseException:
            dialog().VSinfo('غير قادر على تطبيق إعدادات Stalker...', 'matrix', 4)
            return
    else:
        return True


def OKdialogClick():
    x = 0
    while not xbmc.getCondVisibility("Window.isActive(okdialog)") and x < 100:
        x += 1
        xbmc.sleep(100)
    
    if xbmc.getCondVisibility("Window.isActive(okdialog)"):
        xbmc.executebuiltin('SendClick(11)')

def dissablestalker():
    if isenabled('pvr.stalker') == True:
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
        x = 0
        xbmc.sleep(1000)
        while isenabled('pvr.stalker') == True and x < 10:
            x += 1
            if monitor.waitForAbort(1):
                sys.exit()
        if isenabled('pvr.stalker') == False:
            return True
        else:
            return False
    else:
        return True

def enablestalker():
    if isenabled('pvr.stalker') == False:
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":true}}')
        x = 0
        xbmc.sleep(1000)
        while isenabled('pvr.stalker') == False and x < 10:
            x += 1
            if monitor.waitForAbort(1):
                sys.exit()
        if isenabled('pvr.stalker') == True:
            return True
        else:
            return False
    else:
        return True

def restartstalker():
    try:
        dialog().VSinfo('أعد تشغيل PVR Stalker...', 'matrix', 4)
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
        xbmc.sleep(1000)
        x = 0
        while isenabled('pvr.stalker') == True and x < 10:
            x += 1
            xbmc.sleep(1000)
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":6,"params":{"addonid": "pvr.stalker","enabled":true}}')
        xbmc.sleep(1000)
        x = 0
        while isenabled('pvr.stalker') == False and x < 10:
            x += 1
            xbmc.sleep(1000)
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
        xbmc.sleep(1000)
        x = 0
        while isenabled('pvr.stalker') == True and x < 10:
            x += 1
            xbmc.sleep(1000)
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":6,"params":{"addonid": "pvr.stalker","enabled":true}}')
        xbmc.sleep(1000)
        x = 0
        while isenabled('pvr.stalker') == False and x < 10:
            x += 1
            xbmc.sleep(1000)
        dialog().VSinfo('تم إعادة تشغيل PVR Stalker', 'matrix', 4)

    except:
        dialog().VSinfo('غير قادر على إعادة التشغيل...', 'matrix', 4)

def isenabled(addonid):
    query = '{ "jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddonDetails", "params": { "addonid": "%s", "properties" : ["name", "thumbnail", "fanart", "enabled", "installed", "path", "dependencies"] } }' % addonid
    addonDetails = xbmc.executeJSONRPC(query)
    details_result = json.loads(addonDetails)
    if "error" in details_result:
        return False
    elif details_result['result']['addon']['enabled'] == True:
        return True
    else:
        return False

if __name__ == '__main__':
    setpvrstalker()
